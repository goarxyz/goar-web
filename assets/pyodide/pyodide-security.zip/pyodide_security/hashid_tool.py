"""hashid equivalent — identify hash formats by structure and length."""

from __future__ import annotations

import re
from typing import Any

# (name, john_mode, hashcat_mode, regex, confidence_base)
_RULES: list[tuple[str, str, str | None, re.Pattern[str], int]] = [
    ("MD5", "raw-md5", "0", re.compile(r"^[a-fA-F0-9]{32}$"), 90),
    ("MD4 / NTLM", "raw-md4 / nt", "900 / 1000", re.compile(r"^[a-fA-F0-9]{32}$"), 70),
    ("SHA-1", "raw-sha1", "100", re.compile(r"^[a-fA-F0-9]{40}$"), 90),
    ("SHA-224", "raw-sha224", "1300", re.compile(r"^[a-fA-F0-9]{56}$"), 90),
    ("SHA-256", "raw-sha256", "1400", re.compile(r"^[a-fA-F0-9]{64}$"), 90),
    ("SHA-384", "raw-sha384", "10800", re.compile(r"^[a-fA-F0-9]{96}$"), 90),
    ("SHA-512", "raw-sha512", "1700", re.compile(r"^[a-fA-F0-9]{128}$"), 90),
    ("SHA3-256", "raw-sha3-256", "17400", re.compile(r"^[a-fA-F0-9]{64}$"), 40),
    ("SHA3-512", "raw-sha3-512", "17600", re.compile(r"^[a-fA-F0-9]{128}$"), 40),
    ("BLAKE2b-512", "raw-blake2b", None, re.compile(r"^[a-fA-F0-9]{128}$"), 30),
    ("MySQL 4.1+", "mysql-sha1", "300", re.compile(r"^\*[a-fA-F0-9]{40}$"), 95),
    ("LM Hash", "lm", "3000", re.compile(r"^[a-fA-F0-9]{32}$"), 30),
    (
        "bcrypt",
        "bcrypt",
        "3200",
        re.compile(r"^\$2[aby]?\$\d{2}\$[./A-Za-z0-9]{53}$"),
        99,
    ),
    (
        "md5crypt ($1$)",
        "md5crypt",
        "500",
        re.compile(r"^\$1\$[./A-Za-z0-9]{1,8}\$[./A-Za-z0-9]{22}$"),
        99,
    ),
    (
        "sha256crypt ($5$)",
        "sha256crypt",
        "7400",
        re.compile(r"^\$5\$(rounds=\d+\$)?[./A-Za-z0-9]{1,16}\$[./A-Za-z0-9]{43}$"),
        99,
    ),
    (
        "sha512crypt ($6$)",
        "sha512crypt",
        "1800",
        re.compile(r"^\$6\$(rounds=\d+\$)?[./A-Za-z0-9]{1,16}\$[./A-Za-z0-9]{86}$"),
        99,
    ),
    (
        "Argon2",
        "argon2",
        None,
        re.compile(r"^\$argon2(id|i|d)\$v=\d+\$m=\d+,t=\d+,p=\d+\$.+$"),
        99,
    ),
    (
        "PBKDF2-SHA256 (Django)",
        "django",
        "10000",
        re.compile(r"^pbkdf2_sha256\$\d+\$[A-Za-z0-9+/]+\$[A-Za-z0-9+/=]+$"),
        99,
    ),
    (
        "Django MD5",
        "django",
        None,
        re.compile(r"^md5\$[A-Za-z0-9]+\$[a-fA-F0-9]{32}$"),
        99,
    ),
    (
        "WordPress PHPass",
        "phpass",
        "400",
        re.compile(r"^\$P\$[./A-Za-z0-9]{31}$"),
        99,
    ),
    (
        "Drupal 7+",
        "drupal7",
        "7900",
        re.compile(r"^\$S\$[./A-Za-z0-9]{52}$"),
        99,
    ),
    (
        "Cisco-IOS Type 9 (scrypt)",
        "cisco9",
        None,
        re.compile(r"^\$9\$[A-Za-z0-9./]+$"),
        95,
    ),
    (
        "Cisco-IOS Type 5 (md5crypt)",
        "cisco5",
        "500",
        re.compile(r"^\$1\$[A-Za-z0-9./]+\$[A-Za-z0-9./]+$"),
        90,
    ),
    (
        "JWT",
        "jwt",
        None,
        re.compile(r"^eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*$"),
        99,
    ),
    (
        "AWS Access Key ID",
        None,
        None,
        re.compile(r"^AKIA[0-9A-Z]{16}$"),
        95,
    ),
    (
        "CRC32",
        None,
        None,
        re.compile(r"^[a-fA-F0-9]{8}$"),
        40,
    ),
    (
        "Base64 (generic)",
        None,
        None,
        re.compile(r"^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$"),
        20,
    ),
]


def identify(hash_value: str) -> dict[str, Any]:
    h = (hash_value or "").strip()
    if not h:
        raise ValueError("hash_value is required")

    matches: list[dict[str, Any]] = []
    for name, john, hashcat, rx, conf in _RULES:
        if rx.match(h):
            # lower confidence for ambiguous hex lengths when multiple match
            matches.append(
                {
                    "name": name,
                    "john": john,
                    "hashcat": hashcat,
                    "confidence": conf,
                }
            )

    # Ambiguity: 32-hex could be MD5/MD4/NTLM/LM
    hex32 = re.fullmatch(r"[a-fA-F0-9]{32}", h)
    if hex32:
        for m in matches:
            if m["name"] in ("MD5", "MD4 / NTLM", "LM Hash"):
                pass  # keep listed

    matches.sort(key=lambda x: -x["confidence"])
    return {
        "input": h[:200],
        "length": len(h),
        "matches": matches,
        "best": matches[0] if matches else None,
    }
