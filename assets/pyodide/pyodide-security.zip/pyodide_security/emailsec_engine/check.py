"""Email security — SPF, DMARC and DKIM discovery through shared DoH."""
from __future__ import annotations
from typing import Any
from ..subenum_engine.sources import clean_domain
from ..subenum_engine.resolve import doh_resolve
from .._http import redact_url
async def _txt(name:str,provider:str='cloudflare',**opts:Any)->dict[str,Any]:
 res=await doh_resolve(name,'TXT',provider=provider,**opts);records=[]
 for ans in res.get('answers') or []:
  d=str(ans.get('data') or '').strip().strip('"')
  if d:records.append(d)
 return {'records':records,'dns':res}
async def check(domain:str,provider:str='cloudflare',max_tests:int=0,timeout_ms:int=7000,headers:str='',retries:int=0,retry_statuses:str='408,429,500,502,503,504',route:str='auto',service_base:str='',selectors:str='default,google,selector1,selector2,k1,s1,s2,dkim,mail,smtp',max_selectors:int=10)->dict[str,Any]:
 domain=clean_domain(domain);cap=int(max_tests or 0);used=0;opts={'headers':headers,'timeout_ms':timeout_ms,'retries':retries,'retry_statuses':retry_statuses,'route':route,'service_base':service_base};queries={}
 async def lookup(name:str):
  nonlocal used
  if cap>0 and used>=cap:return []
  used+=1;value=await _txt(name,provider,**opts);queries[name]=value['dns'];return value['records']
 spf=await lookup(domain);dmarc=await lookup(f'_dmarc.{domain}');dkim={};selector_list=[x.strip() for x in str(selectors or '').replace('\n',',').split(',') if x.strip()][:max(1,min(int(max_selectors or 10),50))]
 for sel in selector_list:
  recs=await lookup(f'{sel}._domainkey.{domain}')
  if recs:dkim[sel]=recs
 spf_rec=[r for r in spf if 'v=spf1' in r.lower()];dmarc_rec=[r for r in dmarc if 'v=dmarc1' in r.lower()];issues=[]
 if not spf_rec:issues.append({'issue':'missing SPF','severity':'medium'})
 elif '+all' in spf_rec[0].lower():issues.append({'issue':'SPF +all (permissive)','severity':'high'})
 elif '~all' in spf_rec[0].lower():issues.append({'issue':'SPF softfail ~all','severity':'low'})
 if not dmarc_rec:issues.append({'issue':'missing DMARC','severity':'medium'})
 else:
  pol=dmarc_rec[0].lower()
  if 'p=none' in pol:issues.append({'issue':'DMARC p=none','severity':'low'})
  if 'p=reject' not in pol and 'p=quarantine' not in pol:issues.append({'issue':'DMARC weak policy','severity':'medium'})
 if not dkim:issues.append({'issue':'no configured DKIM selectors found','severity':'info'})
 return {'ok':True,'domain':domain,'spf':spf_rec,'dmarc':dmarc_rec,'dkim':dkim,'issues':issues,'issue_count':len(issues),'queries_run':used,'query_results':queries,'selectors_tested':selector_list,'request':{'provider':provider,'timeout_ms':timeout_ms,'retries':retries,'route':route,'service_base':redact_url(service_base or '')},'engine':'emailsec','equivalent':'SPF/DMARC/DKIM check'}
