"""Browser-adapted CMSeeK database detection through the shared Goar transport."""
from __future__ import annotations
import gzip
import json
import re
from pathlib import Path
from typing import Any
from urllib.parse import urljoin
from .._http import http_request, redact_url
from .. import policy

_DB: dict[str,Any]|None=None
_PATH=Path(__file__).with_name("cmseek_db.json.gz")

def _db()->dict[str,Any]:
    global _DB
    if _DB is None:
        with gzip.open(_PATH,"rt",encoding="utf-8") as handle:_DB=json.load(handle)
    return _DB

def list_cms(limit:int=0)->dict[str,Any]:
    cms=_db()["cms"];rows=cms[:int(limit)] if limit and limit>0 else cms
    return {"ok":True,"count":len(cms),"returned":len(rows),"cms":rows,"source":_db()["source"],"engine":"cms","equivalent":"CMSeeK"}

def list_rules(where:str="",limit:int=0)->dict[str,Any]:
    rules=_db()["rules"]
    if where:rules=[row for row in rules if row.get("where")==where]
    rows=rules[:int(limit)] if limit and limit>0 else rules
    return {"ok":True,"count":len(rules),"returned":len(rows),"rules":rows,"engine":"cms"}

def _match(body:str,headers:dict[str,str],path:str="")->list[dict[str,Any]]:
    header_blob="\n".join(f"{key}: {value}" for key,value in headers.items()).lower();body_l=(body or "").lower();match=re.search(r'<meta[^>]+name=["\']generator["\'][^>]+content=["\']([^"\']+)',body or "",re.I|re.S) or re.search(r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+name=["\']generator["\']',body or "",re.I|re.S);generator=match.group(1).lower() if match else "";hits={}
    for rule in _db()["rules"]:
        needle=str(rule.get("needle") or "").lower();where=rule.get("where") or "source"
        if not needle:continue
        matched=(where=="header" and needle in header_blob) or (where=="generator" and needle in generator) or (where=="source" and needle in body_l)
        if matched:
            cms_id=rule.get("cms_id") or ""
            if cms_id not in hits:hits[cms_id]={"cms_id":cms_id,"cms":rule.get("cms") or cms_id,"matches":[],"confidence":0}
            hits[cms_id]["matches"].append({"needle":rule.get("needle"),"where":where,"path":path});hits[cms_id]["confidence"]=min(100,hits[cms_id]["confidence"]+(40 if where=="header" else 25))
    return sorted(hits.values(),key=lambda item:-item["confidence"])

def _headers(raw:str,user_agent:str)->dict[str,str]:
    out={"User-Agent":user_agent};text=str(raw or "").strip()
    if text.startswith("{"):
        parsed=json.loads(text)
        if not isinstance(parsed,dict):raise ValueError("headers JSON must be an object")
        out.update({str(key):str(value) for key,value in parsed.items()})
    else:
        for line in text.splitlines():
            if ":" in line:
                key,_,value=line.partition(":");out[key.strip()]=value.strip()
    return out

def _route(value:Any)->bool|None:
    if value in (None,"","auto","AUTO"):return None
    if value in (True,"proxy","PROXY","true","True"):return True
    if value in (False,"direct","DIRECT","false","False"):return False
    raise ValueError("route must be auto, proxy, or direct")

def _items(raw:str)->list[str]:
    return list(dict.fromkeys(value.strip() for value in str(raw or "").replace(",","\n").splitlines() if value.strip()))

def _safe_url(value:Any)->str:
    safe=redact_url(value)
    return re.sub(r"(?i)(%3f|%26)(apikey|api_key|key|token|access_token|authorization|secret|signature|sig)(%3d|=)[^&#]*",lambda match:match.group(1)+match.group(2)+match.group(3)+"[redacted]",safe)

def _merge(groups:list[list[dict[str,Any]]])->list[dict[str,Any]]:
    merged={}
    for rows in groups:
        for row in rows:
            current=merged.setdefault(row["cms_id"],{"cms_id":row["cms_id"],"cms":row["cms"],"matches":[],"confidence":0})
            current["matches"].extend(row["matches"]);current["confidence"]=min(100,current["confidence"]+row["confidence"])
    return sorted(merged.values(),key=lambda item:-item["confidence"])

async def detect(url:str,user_agent:str="pyodide-security/cmseek/1.0",paths:str="/",max_paths:int=5,headers:str="",timeout_ms:int=8000,retries:int=0,retry_statuses:str="408,429,500,502,503,504",route:str="auto",strict_cms:str="",ignore_cms:str="",stop_on_detection:bool=False,include_bodies:bool=False)->dict[str,Any]:
    url=str(url or "").strip()
    if not url:return {"ok":False,"error":"url required","engine":"cms"}
    if not url.startswith(("http://","https://")):url="https://"+url
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err:return {"ok":False,"error":err,"engine":"cms"}
    selected_paths=(_items(paths) or ["/"])[:max(1,min(int(max_paths or 5),30))];timeout=max(1000,min(int(timeout_ms or 8000),120000));retry_count=max(0,min(int(retries or 0),5));retryable={int(value.strip()) for value in str(retry_statuses or "").split(",") if value.strip().isdigit()};use_proxy=_route(route);request_headers=_headers(headers,user_agent);groups=[];probes=[];attempts=[]
    for path in selected_paths:
        target=urljoin(url.rstrip("/")+"/",path.lstrip("/")) if path not in ("", "/") else url
        response={}
        for index in range(retry_count+1):
            response=await http_request(target,headers=request_headers,timeout_ms=timeout,use_proxy=use_proxy)
            attempts.append({"path":path,"attempt":index+1,"status":response.get("status"),"error":response.get("error"),"transport":response.get("transport"),"final_url":_safe_url(response.get("final_url"))})
            if response.get("ok") or int(response.get("status") or 0) not in retryable:break
        body=str(response.get("body") or "");response_headers={str(key).lower():str(value) for key,value in (response.get("headers") or {}).items()};rows=_match(body,response_headers,path);groups.append(rows);probes.append({"path":path,"url":_safe_url(target),"final_url":_safe_url(response.get("final_url") or target),"status":response.get("status"),"headers":response_headers,"body_length":len(body),"body":body if include_bodies else "","matches":rows,"transport":response.get("transport"),"error":response.get("error")})
        if stop_on_detection and rows:break
    ranked=_merge(groups);strict=set(_items(strict_cms));ignored=set(_items(ignore_cms))
    if strict:ranked=[row for row in ranked if row["cms_id"] in strict or row["cms"].lower() in {item.lower() for item in strict}]
    if ignored:ranked=[row for row in ranked if row["cms_id"] not in ignored and row["cms"].lower() not in {item.lower() for item in ignored}]
    safe_headers={key:("[redacted]" if key.lower() in {"authorization","cookie","x-api-key"} else value) for key,value in request_headers.items()}
    return {"ok":True,"url":_safe_url(url),"detected":bool(ranked),"cms":ranked,"primary":ranked[0] if ranked else None,"rule_db":len(_db()["rules"]),"cms_db":len(_db()["cms"]),"probes":probes,"attempts":attempts,"attempt_count":len(attempts),"request":{"paths":selected_paths,"headers":safe_headers,"timeout_ms":timeout,"retries":retry_count,"route":"auto" if use_proxy is None else ("proxy" if use_proxy else "direct"),"strict_cms":sorted(strict),"ignore_cms":sorted(ignored)},"engine":"cms","source":_db()["source"],"equivalent":"CMSeeK","coverage_note":"Bundled header/generator/source rules only; native robots, directory, deep scans, version detection and brute-force modules are not claimed."}

def detect_offline(headers:str|dict="",body:str="")->dict[str,Any]:
    hdrs={str(key).lower():str(value) for key,value in headers.items()} if isinstance(headers,dict) else {key.strip().lower():value.strip() for key,_,value in (line.partition(":") for line in str(headers or "").splitlines() if ":" in line)}
    ranked=_match(body or "",hdrs)
    return {"ok":True,"detected":bool(ranked),"cms":ranked,"primary":ranked[0] if ranked else None,"rule_db":len(_db()["rules"]),"engine":"cms","mode":"offline"}
