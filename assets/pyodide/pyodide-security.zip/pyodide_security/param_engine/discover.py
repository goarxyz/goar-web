
"""HTTP parameter discovery — converted from s0md3v/Arjun.
Source: https://github.com/s0md3v/Arjun
Ports anomaly.define/compare + chunked bruter + real db wordlists.
"""
from __future__ import annotations
import json, re, random, string
from xml.sax.saxutils import escape as xml_escape
from pathlib import Path
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse
from .._http import http_request, redact_url
from .. import policy

_DB = Path(__file__).resolve().parent / "db"

def _remove_tags(html: str) -> str:
    return re.sub(r"<[^>]+>", "", html or "")

def _diff_map(a: str, b: str) -> list[str]:
    lb = set((b or "").splitlines())
    return [line for line in (a or "").splitlines() if line in lb][:50]

def _rand_value(n: int = 6) -> str:
    return "".join(random.choice(string.ascii_lowercase + string.digits) for _ in range(n))

def define_factors(resp_a: dict, resp_b: dict, wordlist: list[str], value: str) -> dict[str, Any]:
    """Port of arjun.core.anomaly.define"""
    body_1, body_2 = resp_a.get("body") or "", resp_b.get("body") or ""
    code_1, code_2 = int(resp_a.get("status") or 0), int(resp_b.get("status") or 0)
    hdrs_1 = sorted((resp_a.get("headers") or {}).keys(), key=str.lower)
    hdrs_2 = sorted((resp_b.get("headers") or {}).keys(), key=str.lower)
    factors: dict[str, Any] = {k: None for k in (
        "same_code","same_body","same_plaintext","lines_num","lines_diff",
        "same_headers","same_redirect","param_missing","value_missing")}
    if code_1 == code_2 and code_1:
        factors["same_code"] = code_1
    if [h.lower() for h in hdrs_1] == [h.lower() for h in hdrs_2]:
        factors["same_headers"] = [h.lower() for h in hdrs_1]
    loc1 = loc2 = ""
    for k,v in (resp_a.get("headers") or {}).items():
        if k.lower()=="location": loc1=v
    for k,v in (resp_b.get("headers") or {}).items():
        if k.lower()=="location": loc2=v
    if urlparse(loc1).path == urlparse(loc2).path:
        factors["same_redirect"] = urlparse(loc1).path
    if body_1 == body_2:
        factors["same_body"] = body_1
    elif body_1.count("\n") == body_2.count("\n"):
        factors["lines_num"] = body_1.count("\n")
    elif _remove_tags(body_1) == _remove_tags(body_2):
        factors["same_plaintext"] = _remove_tags(body_1)
    else:
        factors["lines_diff"] = _diff_map(body_1, body_2)
    factors["param_missing"] = [w for w in wordlist if w in body_2][:200]
    if value not in body_2:
        factors["value_missing"] = True
    return factors

def compare(resp: dict, factors: dict, params: dict) -> tuple:
    """Port of arjun.core.anomaly.compare"""
    body = resp.get("body") or ""
    status = int(resp.get("status") or 0)
    these = sorted((resp.get("headers") or {}).keys(), key=str.lower)
    these_l = [h.lower() for h in these]
    if factors["same_code"] is not None and status != factors["same_code"]:
        return ("http code", list(params.keys()), "same_code")
    if factors["same_headers"] is not None and these_l != factors["same_headers"]:
        return ("http headers", list(params.keys()), "same_headers")
    if factors["same_redirect"] is not None:
        loc = ""
        for k,v in (resp.get("headers") or {}).items():
            if k.lower()=="location": loc=v; break
        if loc and urlparse(loc).path != factors["same_redirect"]:
            return ("redirection", list(params.keys()), "same_redirect")
    if factors["same_body"] is not None and body != factors["same_body"]:
        return ("body length", list(params.keys()), "same_body")
    if factors["lines_num"] is not None and body.count("\n") != factors["lines_num"]:
        return ("number of lines", list(params.keys()), "lines_num")
    if factors["same_plaintext"] is not None and _remove_tags(body) != factors["same_plaintext"]:
        return ("text length", list(params.keys()), "same_plaintext")
    if factors["lines_diff"] is not None:
        for line in factors["lines_diff"]:
            if line not in body:
                return ("lines", list(params.keys()), "lines_diff")
    if factors["param_missing"] is not None:
        for param in params:
            if len(param) < 5: continue
            if param not in factors["param_missing"] and re.search(r"[\'\"\s]%s[\'\"\s]" % re.escape(param), body):
                return ("param name reflection", list(params.keys()), "param_missing")
    if factors["value_missing"] is not None:
        for value in params.values():
            if not isinstance(value, str) or len(value) != 6: continue
            if value in body and re.search(r"[\'\"\s]%s[\'\"\s]" % re.escape(value), body):
                return ("param value reflection", list(params.keys()), "value_missing")
    return ("", [], "")

def _load_wordlist(size: str = "small") -> list[str]:
    mapping = {"small": _DB/"small.txt", "medium": _DB/"medium.txt", "large": _DB/"large.txt"}
    path = mapping.get((size or "small").lower()) or mapping["small"]
    if not path.exists(): return []
    return [ln.strip() for ln in path.read_text(encoding="utf-8", errors="replace").splitlines() if ln.strip() and not ln.startswith("#")]

def _headers(raw: str | dict | None, user_agent: str) -> dict[str, str]:
    result = {"User-Agent": user_agent}
    if raw in (None, ""):
        return result
    if isinstance(raw, dict):
        result.update({str(k): str(v) for k, v in raw.items()})
        return result
    text = str(raw).strip()
    if text.startswith("{"):
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValueError(f"headers must be JSON or Header: value lines: {exc}") from exc
        if not isinstance(parsed, dict):
            raise ValueError("headers JSON must be an object")
        result.update({str(k): str(v) for k, v in parsed.items()})
        return result
    for line in text.splitlines():
        if ":" in line:
            key, _, value = line.partition(":")
            if key.strip():
                result[key.strip()] = value.strip()
    return result


def _safe_headers(headers: dict[str, str]) -> dict[str, str]:
    return {k: ("[redacted]" if k.lower() in {"authorization", "cookie", "x-api-key"} else v) for k, v in headers.items()}


def _route(value: str | bool | None) -> bool | None:
    if value in (None, "", "auto", "AUTO"):
        return None
    if value in (True, "proxy", "PROXY", "true", "True"):
        return True
    if value in (False, "direct", "DIRECT", "false", "False"):
        return False
    raise ValueError("route must be auto, proxy, or direct")


async def _dispatch(url: str, method: str, headers: dict[str, str], params: dict[str, str], timeout_ms: int, retries: int, retry_statuses: set[int], use_proxy: bool | None) -> dict[str, Any]:
    mode = (method or "GET").upper()
    if mode not in {"GET", "POST", "POST-JSON", "POST-XML"}:
        raise ValueError("method must be GET, POST, POST-JSON, or POST-XML")
    request_url = url
    body = None
    request_headers = dict(headers)
    http_method = "GET" if mode == "GET" else "POST"
    if mode == "GET":
        parsed = urlparse(url)
        query = dict(parse_qsl(parsed.query, keep_blank_values=True))
        query.update(params)
        request_url = urlunparse(parsed._replace(query=urlencode(query, doseq=True)))
    elif mode == "POST":
        request_headers.setdefault("Content-Type", "application/x-www-form-urlencoded")
        body = urlencode(params)
    elif mode == "POST-JSON":
        request_headers.setdefault("Content-Type", "application/json")
        body = json.dumps(params, separators=(",", ":"))
    else:
        request_headers.setdefault("Content-Type", "application/xml")
        body = "<request>" + "".join(f"<{xml_escape(k)}>{xml_escape(str(v))}</{xml_escape(k)}>" for k, v in params.items()) + "</request>"
    attempts: list[dict[str, Any]] = []
    response: dict[str, Any] = {}
    for index in range(max(0, min(int(retries or 0), 5)) + 1):
        response = await http_request(request_url, method=http_method, headers=request_headers, body=body, timeout_ms=max(1000, min(int(timeout_ms or 8000), 120000)), use_proxy=use_proxy)
        attempts.append({"attempt": index + 1, "status": response.get("status"), "ok": response.get("ok"), "transport": response.get("transport"), "elapsed_ms": response.get("elapsed_ms"), "error": response.get("error"), "final_url": redact_url(response.get("final_url"))})
        if response.get("ok") or int(response.get("status") or 0) not in retry_statuses:
            break
    response = dict(response)
    response["attempts"] = attempts
    response["attempt_count"] = len(attempts)
    response["request"] = {"url": redact_url(request_url), "mode": mode, "headers": _safe_headers(request_headers), "timeout_ms": max(1000, min(int(timeout_ms or 8000), 120000)), "route": "auto" if use_proxy is None else ("proxy" if use_proxy else "direct")}
    response["final_url"] = redact_url(response.get("final_url") or request_url)
    return response


def heuristic_extract(url: str, body: str) -> list[str]:
    found = []
    for k,_ in parse_qsl(urlparse(url).query, keep_blank_values=True):
        found.append(k)
    for pat in (r'<input[^>]+name=["\']([^"\']+)', r'<select[^>]+name=["\']([^"\']+)',
                r'[?&]([a-zA-Z_][\w]{0,40})=', r'["\']([a-zA-Z_][\w]{0,30})["\']\s*:'):
        for m in re.finditer(pat, body or "", re.I):
            found.append(m.group(1))
    seen, out = set(), []
    for w in found:
        if w and w not in seen and len(w) < 48:
            seen.add(w); out.append(w)
    return out

async def discover(url: str, wordlist: str = "small", chunk_size: int = 25, max_chunks: int = 4,
                   max_params: int | None = None, max_tests: int = 0,
                   method: str = "GET", user_agent: str = "pyodide-security/arjun/3.0",
                   headers: str = "", timeout_ms: int = 8000, retries: int = 0,
                   retry_statuses: str = "408,429,500,502,503,504", route: str = "auto") -> dict[str, Any]:
    if max_params is not None:
        # approximate: one param per request when narrowing
        max_chunks = max(1, int(max_params) // max(1, int(chunk_size)))
    err = policy.check_url_for_active(url)
    if err: return {"ok": False, "error": err, "engine": "param"}
    if not url.startswith(("http://","https://")): url = "https://" + url
    headers = _headers(headers, user_agent)
    method = (method or "GET").upper()
    timeout_ms = max(1000, min(int(timeout_ms or 8000), 120000))
    retries = max(0, min(int(retries or 0), 5))
    retryable = {int(item.strip()) for item in str(retry_statuses or "").split(",") if item.strip().isdigit()}
    use_proxy = _route(route)
    base1 = await _dispatch(url, method, headers, {}, timeout_ms, retries, retryable, use_proxy)
    requests_run = base1.get("attempt_count", 1)
    if int(max_tests or 0) > 0 and requests_run >= int(max_tests):
        base2 = base1
    else:
        base2 = await _dispatch(url, method, headers, {}, timeout_ms, retries, retryable, use_proxy)
        requests_run += base2.get("attempt_count", 1)
    body = base1.get("body") or ""
    heuristic = heuristic_extract(url, body)
    if wordlist in ("small","medium","large"):
        words = _load_wordlist(wordlist); wl_name = wordlist
    elif "," in wordlist or "\n" in wordlist:
        words = [w.strip() for w in wordlist.replace(",","\n").splitlines() if w.strip()]; wl_name = "custom"
    else:
        words = _load_wordlist("small"); wl_name = "small"
    ordered, seen = list(heuristic), set(heuristic)
    for w in words:
        if w not in seen: ordered.append(w); seen.add(w)
    ordered = ordered[: max(1, min(int(chunk_size)*int(max_chunks), 2000))]
    factors = define_factors(base1, base2, ordered[:100], _rand_value())
    found, tested_chunks = [], 0
    cs = max(1, min(int(chunk_size), 50))
    for i in range(0, len(ordered), cs):
        if int(max_tests or 0) > 0 and requests_run >= int(max_tests): break
        if not policy.can_request() or tested_chunks >= int(max_chunks): break
        chunk = ordered[i:i+cs]
        params = {x: _rand_value() for x in chunk}
        resp = await _dispatch(url, method, headers, params, timeout_ms, retries, retryable, use_proxy)
        requests_run += resp.get("attempt_count", 1)
        tested_chunks += 1
        anomaly, _, _ = compare(resp, factors, params)
        if anomaly:
            for param in chunk:
                if int(max_tests or 0) > 0 and requests_run >= int(max_tests): break
                if not policy.can_request(): break
                single = {param: _rand_value()}
                r2 = await _dispatch(url, method, headers, single, timeout_ms, retries, retryable, use_proxy)
                requests_run += r2.get("attempt_count", 1)
                a2, _, f2 = compare(r2, factors, single)
                if a2:
                    found.append({"param": param, "anomaly": a2, "factor": f2, "method": method, "status": r2.get("status")})
    by_param = {f["param"]: f for f in found}
    return {
        "ok": True, "url": redact_url(url), "method": method, "wordlist": wl_name, "wordlist_size": len(words),
        "heuristic_params": heuristic, "chunks_tested": tested_chunks,
        "params_found": list(by_param.values()), "count": len(by_param),
        "factors_used": {k: (v is not None) for k,v in factors.items()},
        "request": {"headers": _safe_headers(headers), "timeout_ms": timeout_ms, "retries": retries, "route": "auto" if use_proxy is None else ("proxy" if use_proxy else "direct"), "retry_statuses": sorted(retryable)},
        "requests_run": requests_run,
        "engine": "param", "version": "3.0-arjun", "equivalent": "s0md3v/Arjun",
        "source": "https://github.com/s0md3v/Arjun", "policy": policy.status(),
    }

def list_common(limit: int = 0, size: str = "small") -> dict[str, Any]:
    words = _load_wordlist(size)
    if limit and limit > 0: words = words[:int(limit)]
    return {"count": len(words), "size": size, "params": words,
            "available": {"small": 835, "medium": 10984, "large": 25889},
            "source": "Arjun db/*.txt"}
