"""
CRLF injection scanner — PortSwigger / PayloadsAllTheThings class.

Detects header injection via %0d%0a / \\r\\n in query, path, and headers
that causes reflected Set-Cookie, Location, or arbitrary response headers.
"""

from __future__ import annotations

import json
import re
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse, quote

from .._http import http_request
from .. import policy

# (id, placement, vector_template, look_for)
# {INJECT} replaced with CRLF sequence variants
_VECTORS: list[dict[str, Any]] = [
    {
        "id": "set-cookie-query",
        "placement": "query",
        "param": "q",
        "vector": "psec{INJECT}Set-Cookie:psec_crlf=1",
        "expect_header": "set-cookie",
        "expect_value": "psec_crlf",
        "severity": "high",
    },
    {
        "id": "location-query",
        "placement": "query",
        "param": "q",
        "vector": "psec{INJECT}Location:https://evil.psec.example/",
        "expect_header": "location",
        "expect_value": "evil.psec.example",
        "severity": "high",
    },
    {
        "id": "x-header-query",
        "placement": "query",
        "param": "q",
        "vector": "psec{INJECT}X-Psec-Crlf: injected",
        "expect_header": "x-psec-crlf",
        "expect_value": "injected",
        "severity": "medium",
    },
    {
        "id": "set-cookie-path",
        "placement": "path",
        "vector": "/psec{INJECT}Set-Cookie:psec_crlf=1",
        "expect_header": "set-cookie",
        "expect_value": "psec_crlf",
        "severity": "high",
    },
    {
        "id": "double-encode",
        "placement": "query",
        "param": "q",
        "vector": "psec{INJECT_DBL}Set-Cookie:psec_crlf=1",
        "expect_header": "set-cookie",
        "expect_value": "psec_crlf",
        "severity": "high",
    },
]

_INJECT_VARIANTS = [
    ("%0d%0a", "url-encoded CRLF"),
    ("%0a", "url-encoded LF"),
    ("%0d", "url-encoded CR"),
    ("%0d%0a%00", "CRLF+null"),
    ("%250d%250a", "double-encoded CRLF"),
]


def _route(value: str | bool | None) -> bool | None:
    if value in (None, "", "auto", "AUTO"): return None
    if value in (True, "proxy", "PROXY", "true", "True"): return True
    if value in (False, "direct", "DIRECT", "false", "False"): return False
    raise ValueError("route must be auto, proxy, or direct")


def _headers(raw: str, user_agent: str) -> dict[str, str]:
    out = {"User-Agent": user_agent}; text = str(raw or "").strip()
    if text.startswith("{"):
        parsed = json.loads(text)
        if not isinstance(parsed, dict): raise ValueError("headers JSON must be an object")
        out.update({str(k): str(v) for k, v in parsed.items()})
    else:
        for line in text.splitlines():
            if ":" in line:
                key, _, value = line.partition(":")
                if key.strip(): out[key.strip()] = value.strip()
    return out


def _safe(value: Any) -> str:
    return re.sub(r"(?im)(token|secret|cookie|authorization|api_key|apikey)(=|:)\s*[^\r\n,;]+", lambda m: f"{m.group(1)}{m.group(2)}[redacted]", str(value or ""))


def _hget(headers: dict, name: str) -> str:
    ln = name.lower()
    for k, v in (headers or {}).items():
        if k.lower() == ln:
            return str(v or "")
    return ""


async def scan(
    url: str,
    max_variants: int = 3,
    max_tests: int = 0,
    user_agent: str = "pyodide-security/crlf-engine/2.0",
    headers: str = "", timeout_ms: int = 8000, retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504", route: str = "auto",
    parameters: str = "", placements: str = "query,path", include_tests: bool = True,
    include_body_echo: bool = True, preview_chars: int = 200,
) -> dict[str, Any]:
    err = policy.check_url_for_active(url)
    if err:
        return {"ok": False, "error": err, "engine": "crlf"}

    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    p = urlparse(url)
    base_params = dict(parse_qsl(p.query, keep_blank_values=True))
    headers = _headers(headers, user_agent)
    timeout = max(1000, min(int(timeout_ms or 8000), 120000)); retry_count=max(0,min(int(retries or 0),5)); retryable={int(x.strip()) for x in str(retry_statuses or '').split(',') if x.strip().isdigit()}; use_proxy=_route(route)
    requested = {x.strip() for x in str(parameters or '').split(',') if x.strip()} or set(base_params) or {'q'}
    allowed = {x.strip().lower() for x in str(placements or 'query,path').split(',') if x.strip()} or {'query','path'}
    variants = _INJECT_VARIANTS[: max(1, min(int(max_variants), 5))]
    baseline = await http_request(url, headers=headers, timeout_ms=timeout, use_proxy=use_proxy)

    findings = []
    tests = []

    for vec in _VECTORS:
        for inj, inj_name in variants:
            if int(max_tests or 0) > 0 and len(tests) >= int(max_tests):
                break
            if not policy.can_request():
                break
            # pick inject token
            token = inj
            raw = vec["vector"]
            if "{INJECT_DBL}" in raw:
                # force double-encode variant
                token = "%250d%250a"
                payload = raw.replace("{INJECT_DBL}", token)
            else:
                payload = raw.replace("{INJECT}", token)

            if vec["placement"] not in allowed:
                continue
            if vec["placement"] == "query":
                param = vec.get("param") or next(iter(requested))
                for candidate in (requested if parameters else {param}):
                    q = dict(base_params); q[candidate] = payload
                    test_url = urlunparse(p._replace(query=urlencode(q, doseq=True)))
                    break
            else:
                # path injection — append to path
                new_path = (p.path.rstrip("/") + payload).replace("//", "/")
                test_url = urlunparse(p._replace(path=new_path, query=urlencode(base_params, doseq=True)))

            resp = {}; attempts=[]
            for attempt_index in range(retry_count + 1):
                resp = await http_request(test_url, headers=headers, timeout_ms=timeout, use_proxy=use_proxy)
                attempts.append({"attempt":attempt_index+1,"status":resp.get("status"),"ok":resp.get("ok"),"transport":resp.get("transport"),"elapsed_ms":resp.get("elapsed_ms"),"error":_safe(resp.get("error"))})
                if resp.get("ok") or int(resp.get("status") or 0) not in retryable: break
            hdrs = resp.get("headers") or {}
            expect_h = vec["expect_header"]
            expect_v = vec["expect_value"]
            got = _hget(hdrs, expect_h)
            hit = expect_v.lower() in got.lower() if got else False

            # also check raw body for reflected header text (some servers echo)
            body = resp.get("body") or ""
            body_hit = bool(include_body_echo) and expect_v.lower() in body.lower() and "psec" in body.lower()

            entry = {
                "id": vec["id"],
                "variant": inj_name,
                "placement": vec["placement"],
                "severity": vec["severity"],
                "status": resp.get("status"),
                "header_hit": hit,
                "body_echo": body_hit,
                "observed_header": got[:200] if got else None,
                "error": _safe(resp.get("error")),
                "url_sample": test_url[:200], "attempts": attempts,
                "body_preview": _safe(body)[:max(0,min(int(preview_chars or 200),200000))] if include_body_echo else None,
            }
            tests.append(entry)
            if hit:
                findings.append(entry)
        if int(max_tests or 0) > 0 and len(tests) >= int(max_tests):
            break

    findings.sort(key=lambda x: 0 if x["severity"] == "high" else 1)
    return {
        "ok": True,
        "url": url,
        "baseline": {"status": baseline.get("status"), "length": len(str(baseline.get("body") or "")), "transport": baseline.get("transport")},
        "tested": len(tests),
        "vulnerable": bool(findings),
        "findings": findings,
        "tests": tests if include_tests else None,
        "attempt_count": sum(len(t.get("attempts") or []) for t in tests),
        "request": {"headers": {k:("[redacted]" if k.lower() in {"authorization","cookie","x-api-key"} else v) for k,v in headers.items()}, "timeout_ms":timeout,"retries":retry_count,"route":"auto" if use_proxy is None else ("proxy" if use_proxy else "direct"),"placements":sorted(allowed),"parameters":sorted(requested)},
        "engine": "crlf",
        "version": "2.0",
        "equivalent": "PortSwigger CRLF / header injection",
        "policy": policy.status(),
    }
