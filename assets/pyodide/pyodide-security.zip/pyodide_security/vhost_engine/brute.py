"""
Virtual-host discovery — a browser-adapted Gobuster VHost workflow.

The module retains its bundled SecLists namelist and runs every probe through the
shared Goar transport. It intentionally does not claim native Gobuster's Go
connection pool, TLS/SNI controls, proxy adapters, or arbitrary concurrency.
"""

from __future__ import annotations

import gzip
import re
from pathlib import Path
from statistics import median
from typing import Any
from urllib.parse import urlparse

from .._http import http_request, redact_url
from .. import policy

_PATH = Path(__file__).with_name("data") / "vhosts.txt.gz"
_WORDS: list[str] | None = None
_SENSITIVE_HEADERS = {"authorization", "cookie", "x-api-key", "proxy-authorization"}


def _words() -> list[str]:
    global _WORDS
    if _WORDS is None:
        with gzip.open(_PATH, "rt", encoding="utf-8") as f:
            _WORDS = [ln.strip() for ln in f.read().splitlines() if ln.strip()]
    return _WORDS


def list_wordlist(limit: int = 0) -> dict[str, Any]:
    rows = _words()
    out = rows[: int(limit)] if limit and limit > 0 else rows
    return {
        "ok": True,
        "count": len(rows),
        "returned": len(out),
        "words": out,
        "source": "SecLists/Discovery/DNS/namelist.txt (top 8k)",
        "engine": "vhost",
    }


def _header_object(raw: str | dict[str, Any] | None) -> dict[str, str]:
    """Accept Files JSON or conventional Header: value lines."""
    if raw in (None, ""):
        return {}
    if isinstance(raw, dict):
        return {str(key): str(value) for key, value in raw.items()}
    value = str(raw).strip()
    if value.startswith("{"):
        import json
        parsed = json.loads(value)
        if not isinstance(parsed, dict):
            raise ValueError("headers must be a JSON object or Header: value lines")
        return {str(key): str(item) for key, item in parsed.items()}
    out: dict[str, str] = {}
    for line in value.splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if ":" not in line:
            raise ValueError(f"invalid header line: {line!r}")
        key, item = line.split(":", 1)
        if not key.strip():
            raise ValueError("header names cannot be empty")
        out[key.strip()] = item.strip()
    return out


def _safe_headers(headers: dict[str, str]) -> dict[str, str]:
    return {key: "[redacted]" if key.lower() in _SENSITIVE_HEADERS else value for key, value in headers.items()}


def _wordlist(raw: str | list[str] | None, limit: int) -> tuple[list[str], str]:
    """Return bounded custom candidates or the preserved bundled list."""
    values: list[str] = []
    if isinstance(raw, list):
        values = [str(item).strip() for item in raw]
    elif raw not in (None, ""):
        values = [item.strip() for item in re.split(r"[\r\n,]+", str(raw))]
    values = [item for item in values if item and not item.startswith("#")]
    unique = list(dict.fromkeys(values))
    if unique:
        return unique[:limit], "custom"
    return _words()[:limit], "SecLists/Discovery/DNS/namelist.txt (top 8k)"


def _route_flag(value: str | bool | None) -> bool | None:
    if value in (None, "", "auto", "AUTO"):
        return None
    if value in (True, "proxy", "PROXY", "true", "True"):
        return True
    if value in (False, "direct", "DIRECT", "false", "False"):
        return False
    raise ValueError("route must be auto, proxy, or direct")


def _status_set(raw: str | list[int] | None) -> set[int]:
    if isinstance(raw, list):
        return {int(item) for item in raw}
    return {int(item.strip()) for item in str(raw or "").split(",") if item.strip().isdigit()}


def _length_set(raw: str | list[int] | None) -> set[int]:
    """Parse Gobuster-style exact lengths and bounded inclusive ranges."""
    if isinstance(raw, list):
        return {max(0, int(item)) for item in raw}
    out: set[int] = set()
    for part in str(raw or "").split(","):
        item = part.strip()
        if not item:
            continue
        if "-" in item:
            left, right = item.split("-", 1)
            if left.strip().isdigit() and right.strip().isdigit():
                start, end = int(left), int(right)
                if 0 <= start <= end and end - start <= 10000:
                    out.update(range(start, end + 1))
            continue
        if item.isdigit():
            out.add(int(item))
    return out


def _candidate_host(word: str, base_host: str, append_domain: bool) -> str:
    candidate = word.strip().strip(".")
    if not candidate:
        return ""
    if not append_domain or candidate.lower().endswith("." + base_host.lower()) or candidate.lower() == base_host.lower():
        return candidate
    return f"{candidate}.{base_host}" if base_host else candidate


def _safe_preview(value: Any, limit: int) -> str:
    """Optional server-response preview with obvious credential-like values masked."""
    text = str(value or "")[: max(0, min(int(limit or 0), 2000))]
    return re.sub(
        r"(?i)\b(authorization|cookie|api[_-]?key|access[_-]?token|token|secret|password)\s*([:=])\s*([\"']?)[^\s,;\"'<>]{3,}",
        lambda match: f"{match.group(1)}{match.group(2)}[redacted]",
        text,
    )


async def _request_with_retries(
    url: str,
    headers: dict[str, str],
    timeout_ms: int,
    retries: int,
    retryable: set[int],
    use_proxy: bool | None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    result: dict[str, Any] = {}
    attempts: list[dict[str, Any]] = []
    for attempt in range(retries + 1):
        result = await http_request(url, method="GET", headers=headers, timeout_ms=timeout_ms, use_proxy=use_proxy)
        attempts.append({
            "attempt": attempt + 1,
            "status": result.get("status"),
            "ok": result.get("ok"),
            "transport": result.get("transport"),
            "elapsed_ms": result.get("elapsed_ms"),
            "error": result.get("error"),
        })
        if result.get("ok") or int(result.get("status") or 0) not in retryable:
            break
    return result, attempts


async def brute(
    url: str,
    max_hosts: int = 40,
    user_agent: str = "pyodide-security/vhost/2.0",
    domain: str = "",
    wordlist: str = "",
    max_words: int = 0,
    headers: str | dict[str, Any] = "",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str | bool | None = "auto",
    append_domain: bool = True,
    baseline_requests: int = 2,
    exclude_statuses: str = "",
    exclude_lengths: str = "",
    length_tolerance: int = 0,
    include_preview: bool = False,
    preview_chars: int = 200,
) -> dict[str, Any]:
    """Run a bounded Host-header VHost discovery workflow through Goar transport."""
    err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "engine": "vhost"}
    target = str(url or "").strip()
    if not target.startswith(("http://", "https://")):
        target = "https://" + target
    parsed = urlparse(target)
    base_host = str(domain or parsed.hostname or "").strip().strip(".")
    if not base_host:
        return {"ok": False, "error": "a target URL or domain is required", "engine": "vhost"}

    raw_limit = max_words if int(max_words or 0) > 0 else max_hosts
    limit = max(1, min(int(raw_limit or 40), 120))
    timeout_ms = max(1000, min(int(timeout_ms or 8000), 120000))
    retries = max(0, min(int(retries or 0), 3))
    baseline_requests = max(1, min(int(baseline_requests or 1), 3))
    use_proxy = _route_flag(route)
    retryable = _status_set(retry_statuses)
    excluded_statuses = _status_set(exclude_statuses)
    excluded_lengths = _length_set(exclude_lengths)
    request_headers = _header_object(headers)
    request_headers.setdefault("User-Agent", str(user_agent or "pyodide-security/vhost/2.0"))

    words, wordlist_source = _wordlist(wordlist, limit)
    base_headers = dict(request_headers)
    base_headers["Host"] = base_host
    baseline_rows: list[dict[str, Any]] = []
    baseline_attempts: list[dict[str, Any]] = []
    for _ in range(baseline_requests):
        if not policy.can_request():
            break
        response, attempts = await _request_with_retries(target, base_headers, timeout_ms, retries, retryable, use_proxy)
        baseline_attempts.extend(attempts)
        baseline_rows.append({
            "status": int(response.get("status") or 0),
            "length": len(str(response.get("body") or "")),
            "transport": response.get("transport"),
            "elapsed_ms": response.get("elapsed_ms"),
            "error": response.get("error"),
        })
    if not baseline_rows:
        return {
            "ok": False,
            "error": "no baseline request could be made within the active-scan policy budget",
            "url": redact_url(target),
            "engine": "vhost",
        }

    baseline_lengths = [row["length"] for row in baseline_rows]
    baseline_statuses = [row["status"] for row in baseline_rows]
    baseline_length = int(median(baseline_lengths))
    observed_spread = max(baseline_lengths) - min(baseline_lengths)
    tolerance = max(50, int(baseline_length * 0.15), observed_spread + 10, max(0, int(length_tolerance or 0)))
    baseline_status = max(set(baseline_statuses), key=baseline_statuses.count)
    found: list[dict[str, Any]] = []
    results: list[dict[str, Any]] = []
    tested = 0
    total_attempts = len(baseline_attempts)
    stopped_reason: str | None = None

    for word in words:
        if not policy.can_request():
            stopped_reason = "policy request budget exhausted"
            break
        host = _candidate_host(word, base_host, bool(append_domain))
        if not host:
            continue
        tested += 1
        candidate_headers = dict(request_headers)
        candidate_headers["Host"] = host
        response, attempts = await _request_with_retries(target, candidate_headers, timeout_ms, retries, retryable, use_proxy)
        total_attempts += len(attempts)
        status = int(response.get("status") or 0)
        body = str(response.get("body") or "")
        length = len(body)
        delta = length - baseline_length
        matches_baseline = status == baseline_status and abs(delta) <= tolerance
        excluded = status in excluded_statuses or length in excluded_lengths
        record = {
            "word": word,
            "host": host,
            "status": status,
            "length": length,
            "delta": delta,
            "matches_baseline": matches_baseline,
            "excluded": excluded,
            "final_url": redact_url(response.get("final_url") or target),
            "transport": response.get("transport"),
            "elapsed_ms": response.get("elapsed_ms"),
            "attempts": attempts,
            "error": response.get("error"),
        }
        if include_preview:
            record["preview"] = _safe_preview(body, preview_chars)
        results.append(record)
        if not excluded and not matches_baseline:
            found.append(record)

    return {
        "ok": True,
        "url": redact_url(target),
        "base_host": base_host,
        "append_domain": bool(append_domain),
        "wordlist_source": wordlist_source,
        "wordlist_size": len(_words()),
        "candidate_count": len(words),
        "tested": tested,
        "stopped_reason": stopped_reason,
        "baseline": {
            "requests": baseline_rows,
            "status": baseline_status,
            "length": baseline_length,
            "length_spread": observed_spread,
            "length_tolerance": tolerance,
            "attempts": baseline_attempts,
        },
        "results": results,
        "found": found,
        "found_count": len(found),
        "request_count": total_attempts,
        "request": {
            "method": "GET",
            "url": redact_url(target),
            "headers": _safe_headers(request_headers),
            "timeout_ms": timeout_ms,
            "retries": retries,
            "retry_statuses": sorted(retryable),
            "route": "auto" if use_proxy is None else ("proxy" if use_proxy else "direct"),
            "exclude_statuses": sorted(excluded_statuses),
            "exclude_lengths": sorted(excluded_lengths),
        },
        "engine": "vhost-gobuster-adapted",
        "source": "SecLists namelist" if wordlist_source.startswith("SecLists") else "custom wordlist",
        "limitations": [
            "Browser-adapted Host-header probing; native Gobuster TLS/SNI, connection-pool, proxy-adapter and arbitrary-concurrency behavior is not claimed.",
            "Results are heuristic baseline differences, not DNS validation or proof of host ownership.",
        ],
    }
