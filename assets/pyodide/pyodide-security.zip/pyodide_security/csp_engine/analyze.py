"""Browser-adapted Content Security Policy analysis through shared Goar transport."""
from __future__ import annotations
import json
import re
from typing import Any
from urllib.parse import urljoin
from .._http import http_request, redact_url
from .. import policy

DANGEROUS=["'unsafe-inline'","'unsafe-eval'","data:","blob:","*"]

def parse_csp(header:str)->dict[str,list[str]]:
    output={}
    for part in str(header or "").split(";"):
        bits=part.strip().split()
        if bits:output[bits[0].lower()]=bits[1:]
    return output

def analyze_policy(csp:str,report_only:bool=False)->dict[str,Any]:
    directives=parse_csp(csp);issues=[]
    def issue(text:str,severity:str,directive:str=""):issues.append({"issue":text,"severity":severity,"directive":directive or None,"enforcement":"report-only" if report_only else "enforced"})
    if not directives:issue("missing CSP","medium")
    for directive,values in directives.items():
        joined=" ".join(values).lower();unsafe_context=directive in {"script-src","script-src-elem","script-src-attr","style-src","style-src-elem","style-src-attr","default-src"}
        if "'unsafe-inline'" in joined and unsafe_context:issue(directive+" allows 'unsafe-inline'","high",directive)
        if "'unsafe-eval'" in joined:issue(directive+" allows 'unsafe-eval'","high",directive)
        if ("data:" in joined or "blob:" in joined) and directive.startswith("script"):issue(directive+" allows data:/blob:","medium",directive)
        if "*" in values:issue(directive+" allows *","medium" if directive in {"default-src","script-src"} else "low",directive)
        if directive=="frame-ancestors" and "*" in values:issue("frame-ancestors allows *","medium",directive)
    if "default-src" not in directives:issue("missing default-src","low","default-src")
    if "object-src" not in directives:issue("missing object-src","low","object-src")
    if "base-uri" not in directives:issue("missing base-uri","low","base-uri")
    if "frame-ancestors" not in directives:issue("missing frame-ancestors","low","frame-ancestors")
    if "form-action" not in directives:issue("missing form-action","low","form-action")
    report_destinations={key:values for key,values in directives.items() if key in {"report-to","report-uri"}}
    severity_counts={level:sum(1 for row in issues if row["severity"]==level) for level in ("high","medium","low","info")}
    return {"directives":directives,"issues":issues,"issue_count":len(issues),"directive_count":len(directives),"report_only":bool(report_only),"report_destinations":report_destinations,"severity_counts":severity_counts}

def _headers(raw:str,user_agent:str)->dict[str,str]:
    output={"User-Agent":user_agent};text=str(raw or "").strip()
    if text.startswith("{"):
        parsed=json.loads(text)
        if not isinstance(parsed,dict):raise ValueError("headers JSON must be an object")
        output.update({str(key):str(value) for key,value in parsed.items()})
    else:
        for line in text.splitlines():
            if ":" in line:
                key,_,value=line.partition(":");output[key.strip()]=value.strip()
    return output

def _route(value:Any)->bool|None:
    if value in (None,"","auto","AUTO"):return None
    if value in (True,"proxy","PROXY","true","True"):return True
    if value in (False,"direct","DIRECT","false","False"):return False
    raise ValueError("route must be auto, proxy, or direct")
def _items(raw:str)->list[str]:return list(dict.fromkeys(item.strip() for item in str(raw or "").replace(",","\n").splitlines() if item.strip()))
def _safe_url(value:Any)->str:
    safe=redact_url(value)
    return re.sub(r"(?i)(%3f|%26)(apikey|api_key|key|token|access_token|authorization|secret|signature|sig)(%3d|=)[^&#]*",lambda match:match.group(1)+match.group(2)+match.group(3)+"[redacted]",safe)

async def analyze(url:str,user_agent:str="pyodide-security/csp/2.0",paths:str="/",max_paths:int=3,headers:str="",timeout_ms:int=8000,retries:int=0,retry_statuses:str="408,429,500,502,503,504",route:str="auto",stop_on_issue:bool=False,include_policies:bool=True)->dict[str,Any]:
    url=str(url or "").strip()
    if not url:return {"ok":False,"error":"url required","engine":"csp"}
    if not url.startswith(("http://","https://")):url="https://"+url
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err:return {"ok":False,"error":err,"engine":"csp"}
    selected=(_items(paths) or ["/"])[:max(1,min(int(max_paths or 3),20))];timeout=max(1000,min(int(timeout_ms or 8000),120000));retry_count=max(0,min(int(retries or 0),5));retryable={int(value.strip()) for value in str(retry_statuses or "").split(",") if value.strip().isdigit()};use_proxy=_route(route);request_headers=_headers(headers,user_agent);probes=[];attempts=[];all_issues=[];all_directives={};first_csp=None;first_report_only=None
    for path in selected:
        target=urljoin(url.rstrip("/")+"/",path.lstrip("/")) if path not in ("", "/") else url;response={}
        for index in range(retry_count+1):
            response=await http_request(target,headers=request_headers,timeout_ms=timeout,use_proxy=use_proxy)
            attempts.append({"path":path,"attempt":index+1,"status":response.get("status"),"error":response.get("error"),"transport":response.get("transport"),"final_url":_safe_url(response.get("final_url"))})
            if response.get("ok") or int(response.get("status") or 0) not in retryable:break
        hdrs={str(key).lower():str(value) for key,value in (response.get("headers") or {}).items()};enforced=hdrs.get("content-security-policy","");report=hdrs.get("content-security-policy-report-only","");first_csp=enforced if first_csp is None else first_csp;first_report_only=report if first_report_only is None else first_report_only;enforced_analysis=analyze_policy(enforced,False);report_analysis=analyze_policy(report,True) if report else None;path_issues=[{**row,"path":path} for row in enforced_analysis["issues"]]
        if report_analysis:path_issues.extend([{**row,"path":path} for row in report_analysis["issues"]])
        all_issues.extend(path_issues);all_directives[path]={"enforced":enforced_analysis["directives"],"report_only":report_analysis["directives"] if report_analysis else {}};probes.append({"path":path,"url":_safe_url(target),"final_url":_safe_url(response.get("final_url") or target),"status":response.get("status"),"csp":enforced if include_policies else bool(enforced),"csp_report_only":report if include_policies else bool(report),"enforced_directive_count":enforced_analysis["directive_count"],"report_only_directive_count":report_analysis["directive_count"] if report_analysis else 0,"issue_count":len(path_issues),"transport":response.get("transport"),"error":response.get("error")})
        if stop_on_issue and path_issues:break
    severity_counts={level:sum(1 for row in all_issues if row["severity"]==level) for level in ("high","medium","low","info")};safe_headers={key:("[redacted]" if key.lower() in {"authorization","cookie","x-api-key"} else value) for key,value in request_headers.items()}
    return {"ok":True,"url":_safe_url(url),"status":probes[0]["status"] if probes else None,"csp":first_csp or None,"csp_report_only":first_report_only or None,"directives":all_directives,"issues":all_issues,"issue_count":len(all_issues),"severity_counts":severity_counts,"probes":probes,"attempts":attempts,"attempt_count":len(attempts),"request":{"paths":selected,"headers":safe_headers,"timeout_ms":timeout,"retries":retry_count,"route":"auto" if use_proxy is None else ("proxy" if use_proxy else "direct")},"engine":"csp","equivalent":"CSP evaluator","coverage_note":"Observed CSP headers only; policy composition, browser enforcement and violation-report delivery are not emulated."}

async def scan_url(url:str,**kw):return await analyze(url,**kw)
