"""Offline dictionary / rules cracker — john/hashcat-class modes that run in-browser.

Supported modes (raw, unsalted):
  md5, md4, sha1, sha256, sha512, ntlm, hmac-sha256

Designed for Pyodide: caps candidate volume, pure stdlib + local MD4.
"""

from __future__ import annotations

import hashlib
import hmac
import time
from typing import Any, Callable

from ._md4 import md4, ntlm_hash

MAX_CANDIDATES = 50_000
MAX_WORDLIST_CHARS = 2_000_000


def _norm_hash(h: str) -> str:
    h = h.strip().lower()
    if h.startswith("0x"):
        h = h[2:]
    return h


def _hasher(mode: str) -> Callable[[str], str]:
    m = mode.lower().replace("_", "-")

    if m == "md5":
        return lambda p: hashlib.md5(p.encode("utf-8")).hexdigest()
    if m == "md4":
        return lambda p: md4(p.encode("utf-8")).hex()
    if m == "sha1":
        return lambda p: hashlib.sha1(p.encode("utf-8")).hexdigest()
    if m == "sha256":
        return lambda p: hashlib.sha256(p.encode("utf-8")).hexdigest()
    if m == "sha512":
        return lambda p: hashlib.sha512(p.encode("utf-8")).hexdigest()
    if m == "ntlm":
        return lambda p: ntlm_hash(p).hex()
    if m in ("hmac-sha256", "hmac_sha256"):
        # key == password, message empty — uncommon; use password as message with empty key? 
        # Real mode: HMAC-SHA256(key=password, msg=provided) — we use msg=""
        return lambda p: hmac.new(p.encode("utf-8"), b"", "sha256").hexdigest()
    raise ValueError(
        "mode must be one of: md5, md4, sha1, sha256, sha512, ntlm, hmac-sha256"
    )


def _rules_expand(word: str, rules: bool) -> list[str]:
    out = [word]
    if not rules:
        return out
    variants = {
        word,
        word.lower(),
        word.upper(),
        word.capitalize(),
        word + "1",
        word + "123",
        word + "!",
        word + "2024",
        word + "2025",
        word + "2026",
        "1" + word,
        word[::-1] if len(word) <= 32 else word,
    }
    # light leet
    leet = (
        word.lower()
        .replace("a", "4")
        .replace("e", "3")
        .replace("i", "1")
        .replace("o", "0")
        .replace("s", "5")
    )
    variants.add(leet)
    variants.add(leet.capitalize())
    return list(variants)


def crack(
    target_hash: str,
    wordlist: str,
    mode: str = "md5",
    rules: bool = True,
    max_candidates: int = 20_000,
) -> dict[str, Any]:
    """
    Dictionary attack against a single raw hash.

    wordlist: newline or comma separated candidates (paste your list).
    rules: apply john-style simple mangling (cap, leet, year suffix).
    """
    target = _norm_hash(target_hash)
    if not target:
        raise ValueError("target_hash is required")
    if not wordlist or not wordlist.strip():
        raise ValueError("wordlist is required (newline-separated passwords)")
    if len(wordlist) > MAX_WORDLIST_CHARS:
        raise ValueError(f"wordlist exceeds {MAX_WORDLIST_CHARS} characters")

    max_c = max(1, min(int(max_candidates), MAX_CANDIDATES))
    hash_fn = _hasher(mode)

    # parse words
    raw_words: list[str] = []
    for line in wordlist.replace(",", "\n").splitlines():
        w = line.strip()
        if w and not w.startswith("#"):
            raw_words.append(w)

    t0 = time.perf_counter()
    tried = 0
    seen: set[str] = set()
    found: str | None = None

    for word in raw_words:
        for cand in _rules_expand(word, rules):
            if cand in seen:
                continue
            seen.add(cand)
            tried += 1
            if hash_fn(cand) == target:
                found = cand
                break
            if tried >= max_c:
                break
        if found is not None or tried >= max_c:
            break

    elapsed = time.perf_counter() - t0
    rate = int(tried / elapsed) if elapsed > 0 else tried

    return {
        "cracked": found is not None,
        "plaintext": found,
        "mode": mode.lower(),
        "target": target,
        "candidates_tried": tried,
        "unique_candidates": len(seen),
        "rules": rules,
        "elapsed_ms": round(elapsed * 1000, 2),
        "rate_per_sec": rate,
        "capped": tried >= max_c and found is None,
        "note": None
        if found
        else (
            "Not found within candidate cap. Provide a larger wordlist or enable rules."
            if tried >= max_c
            else "Not found in wordlist."
        ),
    }
