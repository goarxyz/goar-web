"""
GraphQL engine — browser-adapted GraphQLmap-class workflow.

The existing Goar transport is used for every request.  This module preserves the
current scan, introspection, probe-list, and query callables while adding portable
request construction, GraphQL variables/operation names, bounded retries, route
selection, full response evidence, and explicit GraphQL error reporting.
"""

from __future__ import annotations

import json
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from .. import policy
from .._http import http_request, redact_url

# Full introspection query (GraphQL >14 style from GraphQLmap dump_schema).
INTROSPECTION_QUERY = """
query IntrospectionQuery {
  __schema {
    queryType { name }
    mutationType { name }
    subscriptionType { name }
    types { ...FullType }
    directives { name description locations args { ...InputValue } }
  }
}
fragment FullType on __Type {
  kind name description
  fields(includeDeprecated: true) {
    name description args { ...InputValue } type { ...TypeRef }
    isDeprecated deprecationReason
  }
  inputFields { ...InputValue }
  interfaces { ...TypeRef }
  enumValues(includeDeprecated: true) { name description isDeprecated deprecationReason }
  possibleTypes { ...TypeRef }
}
fragment InputValue on __InputValue { name description type { ...TypeRef } defaultValue }
fragment TypeRef on __Type {
  kind name ofType { kind name ofType { kind name ofType { kind name ofType { kind name ofType { kind name ofType { kind name } } } } } } }
}
""".strip()

SIMPLE_TYPES = "{__schema{types{name}}}"
SIMPLE_QUERY_TYPE = "{__schema{queryType{name}}}"

# Existing GraphQLmap-style/community probe inventory, with portable bounded
# request construction instead of a raw invalid batch body.
PROBES = [
    {"id": "introspection", "query": INTROSPECTION_QUERY, "tag": "introspection"},
    {"id": "types", "query": SIMPLE_TYPES, "tag": "introspection"},
    {"id": "queryType", "query": SIMPLE_QUERY_TYPE, "tag": "introspection"},
    {"id": "directive-skip", "query": '{__type(name:"Query"){name}}', "tag": "meta"},
    {"id": "batch-dup", "query": "{ __typename }", "tag": "batch", "batch_count": 2},
    {"id": "suggest-users", "query": "{users{id email password}}", "tag": "enum"},
    {"id": "suggest-user", "query": "{user(id:1){id email password token}}", "tag": "enum"},
    {"id": "suggest-me", "query": "{me{id email role admin}}", "tag": "enum"},
    {"id": "suggest-allUsers", "query": "{allUsers{id email}}", "tag": "enum"},
    {"id": "suggest-nodes", "query": '{nodes(ids:["1"]){id}}', "tag": "enum"},
    {"id": "depth-bomb", "query": "{__schema{types{fields{type{fields{type{name}}}}}}}", "tag": "dos"},
]

_SENSITIVE_TERMS = ("password", "secret", "token", "apikey", "api_key", "ssn", "credit", "admin", "role", "auth")
_SAFE_METHODS = {"GET", "POST"}


def _target(url: str) -> str:
    value = str(url or "").strip()
    if not value:
        raise ValueError("url is required")
    return value if value.startswith(("http://", "https://")) else "https://" + value


def _headers(raw: str | dict | None, user_agent: str) -> dict[str, str]:
    out = {"User-Agent": user_agent, "Accept": "application/json"}
    if raw in (None, ""):
        return out
    if isinstance(raw, dict):
        out.update({str(key): str(value) for key, value in raw.items()})
        return out
    text = str(raw).strip()
    if text.startswith("{"):
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValueError(f"headers must be JSON object or Header: value lines: {exc}") from exc
        if not isinstance(parsed, dict):
            raise ValueError("headers JSON must be an object")
        out.update({str(key): str(value) for key, value in parsed.items()})
        return out
    for line in text.splitlines():
        if ":" in line:
            key, _, value = line.partition(":")
            if key.strip():
                out[key.strip()] = value.strip()
    return out


def _variables(raw: str | dict | None) -> dict[str, Any]:
    if raw in (None, ""):
        return {}
    if isinstance(raw, dict):
        return raw
    try:
        value = json.loads(str(raw))
    except json.JSONDecodeError as exc:
        raise ValueError(f"variables must be a JSON object: {exc}") from exc
    if not isinstance(value, dict):
        raise ValueError("variables must be a JSON object")
    return value


def _route(value: str | bool | None) -> bool | None:
    if value in (None, "", "auto", "AUTO"):
        return None
    if value in (True, "proxy", "PROXY", "true", "True"):
        return True
    if value in (False, "direct", "DIRECT", "false", "False"):
        return False
    raise ValueError("route must be auto, proxy, or direct")


def _retry_statuses(raw: str) -> set[int]:
    return {int(item.strip()) for item in str(raw or "").split(",") if item.strip().isdigit()}


def _safe_headers(headers: dict[str, str]) -> dict[str, str]:
    return {
        key: ("[redacted]" if key.lower() in {"authorization", "cookie", "x-api-key"} else value)
        for key, value in headers.items()
    }


def _request_summary(response: dict[str, Any], index: int) -> dict[str, Any]:
    return {
        "attempt": index,
        "status": response.get("status"),
        "ok": response.get("ok"),
        "transport": response.get("transport"),
        "elapsed_ms": response.get("elapsed_ms"),
        "error": response.get("error"),
        "final_url": redact_url(response.get("final_url")),
    }


async def _gql_request(
    url: str,
    query: str,
    headers: dict[str, str],
    method: str = "POST",
    *,
    variables: dict[str, Any] | None = None,
    operation_name: str = "",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str | bool | None = "auto",
    batch_count: int = 0,
) -> dict[str, Any]:
    """Issue a GraphQL request through the established Goar transport."""
    target = _target(url)
    method_u = (method or "POST").upper()
    if method_u not in _SAFE_METHODS:
        raise ValueError("GraphQL method must be GET or POST")
    timeout = max(1000, min(int(timeout_ms or 8000), 120000))
    attempts_allowed = max(0, min(int(retries or 0), 5))
    retryable = _retry_statuses(retry_statuses)
    use_proxy = _route(route)
    values = variables or {}
    payload: dict[str, Any] = {"query": query}
    if values:
        payload["variables"] = values
    if operation_name:
        payload["operationName"] = operation_name
    attempts: list[dict[str, Any]] = []
    result: dict[str, Any] = {}
    requested_url = target
    for index in range(attempts_allowed + 1):
        if method_u == "GET":
            parsed = urlparse(target)
            params = dict(parse_qsl(parsed.query, keep_blank_values=True))
            params["query"] = query
            if values:
                params["variables"] = json.dumps(values, separators=(",", ":"))
            if operation_name:
                params["operationName"] = operation_name
            requested_url = urlunparse(parsed._replace(query=urlencode(params, doseq=True)))
            result = await http_request(requested_url, method="GET", headers=headers, timeout_ms=timeout, use_proxy=use_proxy)
        else:
            request_headers = {**headers, "Content-Type": headers.get("Content-Type", "application/json")}
            if batch_count > 1:
                body = json.dumps([payload for _ in range(min(int(batch_count), 20))], separators=(",", ":"))
            else:
                body = json.dumps(payload, separators=(",", ":"))
            result = await http_request(target, method="POST", headers=request_headers, body=body, timeout_ms=timeout, use_proxy=use_proxy)
        attempts.append(_request_summary(result, index + 1))
        if result.get("ok") or int(result.get("status") or 0) not in retryable:
            break
    result = dict(result)
    result.update({
        "attempts": attempts,
        "attempt_count": len(attempts),
        "request": {
            "url": redact_url(requested_url),
            "method": method_u,
            "headers": _safe_headers(headers),
            "operation_name": operation_name or None,
            "variables": values,
            "timeout_ms": timeout,
            "retries": attempts_allowed,
            "route": "auto" if use_proxy is None else ("proxy" if use_proxy else "direct"),
            "batch_count": min(int(batch_count or 0), 20) or None,
        },
        "final_url": redact_url(result.get("final_url") or requested_url),
    })
    return result


def _parse_graphql_response(response: dict[str, Any]) -> tuple[dict[str, Any] | list[Any] | None, list[Any], str]:
    body = str(response.get("body") or "")
    try:
        parsed = json.loads(body)
    except Exception:
        return None, [], body
    if isinstance(parsed, dict):
        errors = parsed.get("errors") if isinstance(parsed.get("errors"), list) else ([] if not parsed.get("errors") else [parsed.get("errors")])
        return parsed, errors, body
    if isinstance(parsed, list):
        errors: list[Any] = []
        for item in parsed:
            if isinstance(item, dict) and item.get("errors"):
                errors.extend(item["errors"] if isinstance(item["errors"], list) else [item["errors"]])
        return parsed, errors, body
    return None, [], body


def _schema_summary(schema: dict[str, Any]) -> dict[str, Any]:
    types = schema.get("types") or []
    visible = [entry for entry in types if isinstance(entry, dict) and not str(entry.get("name") or "").startswith("__")]
    type_rows = []
    sensitive: list[str] = []
    for entry in visible:
        name = str(entry.get("name") or "")
        fields = [str(field.get("name")) for field in (entry.get("fields") or []) if isinstance(field, dict) and field.get("name")]
        if name and (fields or entry.get("kind") in {"OBJECT", "INTERFACE"}):
            type_rows.append({"name": name, "kind": entry.get("kind"), "fields": fields, "field_count": len(fields)})
            for field in fields:
                if any(token in field.lower() for token in _SENSITIVE_TERMS):
                    sensitive.append(f"{name}.{field}")
    return {
        "query_type": (schema.get("queryType") or {}).get("name"),
        "mutation_type": (schema.get("mutationType") or {}).get("name"),
        "subscription_type": (schema.get("subscriptionType") or {}).get("name"),
        "type_count": len(visible),
        "types": type_rows,
        "sensitive_fields": sensitive,
        "directives": [item.get("name") for item in (schema.get("directives") or []) if isinstance(item, dict) and item.get("name")],
    }


def list_probes() -> dict[str, Any]:
    return {
        "ok": True,
        "count": len(PROBES),
        "probes": [{"id": probe["id"], "tag": probe["tag"]} for probe in PROBES],
        "source": "swisskyrepo/GraphQLmap + GraphQL introspection standard",
        "engine": "graphql",
        "equivalent": "GraphQLmap",
    }


async def scan(
    url: str,
    method: str = "POST",
    max_probes: int = 0,
    user_agent: str = "pyodide-security/graphqlmap/1.0",
    headers: str = "",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    probe_tags: str = "",
) -> dict[str, Any]:
    """Run selected existing GraphQL probes with complete per-probe request evidence."""
    target = _target(url)
    err = policy.check_url_for_active(target) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "engine": "graphql"}
    method_u = (method or "POST").upper()
    req_headers = _headers(headers, user_agent)
    selected_tags = {item.strip().lower() for item in str(probe_tags or "").split(",") if item.strip()}
    probes = [probe for probe in PROBES if not selected_tags or probe["tag"] in selected_tags]
    if max_probes and int(max_probes) > 0:
        probes = probes[: max(1, int(max_probes))]
    findings: list[dict[str, Any]] = []
    executions: list[dict[str, Any]] = []
    schema_types: list[str] = []
    for probe in probes:
        if not policy.can_request():
            break
        response = await _gql_request(
            target, probe["query"], req_headers, method=method_u,
            timeout_ms=timeout_ms, retries=retries, retry_statuses=retry_statuses,
            route=route, batch_count=int(probe.get("batch_count") or 0),
        )
        parsed, errors, body = _parse_graphql_response(response)
        status = int(response.get("status") or 0)
        entry = {
            "id": probe["id"], "tag": probe["tag"], "status": status,
            "ok_http": 200 <= status < 300, "graphql_error_count": len(errors),
            "has_data": bool(isinstance(parsed, dict) and parsed.get("data") is not None),
            "transport": response.get("transport"), "attempts": response.get("attempts") or [],
            "body_length": len(body), "final_url": response.get("final_url"),
        }
        if isinstance(parsed, dict):
            schema = (parsed.get("data") or {}).get("__schema") if isinstance(parsed.get("data"), dict) else None
            if isinstance(schema, dict):
                summary = _schema_summary(schema)
                schema_types = [row["name"] for row in summary["types"]]
                entry.update({"introspection_open": True, "type_count": summary["type_count"], "schema_summary": summary})
                findings.append({**entry, "severity": "high", "title": "GraphQL introspection enabled"})
            elif entry["has_data"] and probe["tag"] == "enum":
                findings.append({**entry, "severity": "medium", "title": f"GraphQL field probe hit: {probe['id']}"})
        if probe["tag"] == "batch" and isinstance(parsed, list) and len(parsed) >= 2:
            findings.append({**entry, "severity": "info", "title": "GraphQL batch query accepted"})
        if errors:
            entry["errors"] = errors
        executions.append(entry)
    return {
        "ok": True,
        "url": redact_url(target),
        "method": method_u,
        "tested": len(executions),
        "probes_requested": len(probes),
        "probe_tags": sorted(selected_tags) or ["all"],
        "findings": findings,
        "finding_count": len(findings),
        "executions": executions,
        "introspection_open": any(item.get("introspection_open") for item in executions),
        "schema_types_sample": schema_types[:100],
        "schema_type_count": len(schema_types),
        "request": {"headers": _safe_headers(req_headers), "timeout_ms": max(1000, min(int(timeout_ms or 8000), 120000)), "retries": max(0, min(int(retries or 0), 5)), "route": route or "auto"},
        "engine": "graphql",
        "equivalent": "GraphQLmap",
        "policy": policy.status(),
    }


async def introspect(
    url: str,
    method: str = "POST",
    headers: str = "",
    user_agent: str = "pyodide-security/graphqlmap/1.0",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    include_schema: bool = True,
) -> dict[str, Any]:
    """Perform full standard introspection and distinguish a disabled schema from transport failure."""
    target = _target(url)
    req_headers = _headers(headers, user_agent)
    response = await _gql_request(
        target, INTROSPECTION_QUERY, req_headers, method=method, timeout_ms=timeout_ms,
        retries=retries, retry_statuses=retry_statuses, route=route,
    )
    parsed, errors, body = _parse_graphql_response(response)
    schema = (parsed.get("data") or {}).get("__schema") if isinstance(parsed, dict) and isinstance(parsed.get("data"), dict) else None
    available = isinstance(schema, dict)
    summary = _schema_summary(schema) if available else None
    return {
        "ok": bool(response.get("ok")) and available,
        "introspection_available": available,
        "url": redact_url(target),
        "status": response.get("status"),
        "schema": schema if include_schema and available else None,
        "schema_summary": summary,
        "errors": errors,
        "error": response.get("error") or (None if available else ("introspection disabled or unavailable" if not errors else errors)),
        "body": body,
        "body_length": len(body),
        "attempts": response.get("attempts") or [],
        "attempt_count": response.get("attempt_count"),
        "request": response.get("request"),
        "final_url": response.get("final_url"),
        "transport": response.get("transport"),
        "engine": "graphql",
        "equivalent": "GraphQLmap / GraphQL introspection",
    }


async def query(
    url: str,
    gql: str = "{ __typename }",
    variables: str = "{}",
    operation_name: str = "",
    method: str = "POST",
    headers: str = "",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    batch_count: int = 0,
    user_agent: str = "pyodide-security/graphqlmap/1.0",
) -> dict[str, Any]:
    """Execute a GraphQL query or mutation with full response and GraphQL error evidence."""
    target = _target(url)
    if not str(gql or "").strip():
        raise ValueError("gql is required")
    req_headers = _headers(headers, user_agent)
    response = await _gql_request(
        target, str(gql), req_headers, method=method, variables=_variables(variables),
        operation_name=operation_name, timeout_ms=timeout_ms, retries=retries,
        retry_statuses=retry_statuses, route=route, batch_count=batch_count,
    )
    parsed, errors, body = _parse_graphql_response(response)
    return {
        "ok": bool(response.get("ok")),
        "graphql_ok": bool(response.get("ok")) and isinstance(parsed, (dict, list)) and not errors,
        "url": redact_url(target),
        "status": response.get("status"),
        "body": body,
        "body_length": len(body),
        "json": parsed,
        "data": parsed.get("data") if isinstance(parsed, dict) else None,
        "errors": errors,
        "error_count": len(errors),
        "attempts": response.get("attempts") or [],
        "attempt_count": response.get("attempt_count"),
        "request": response.get("request"),
        "final_url": response.get("final_url"),
        "transport": response.get("transport"),
        "engine": "graphql",
        "equivalent": "GraphQLmap",
    }
