"""GraphQL introspection + field walk + batching heuristics."""

from __future__ import annotations

import json
from typing import Any
from urllib.parse import urlparse

from .._http import http_request

INTROSPECTION_QUERY = """
query IntrospectionQuery {
  __schema {
    queryType { name }
    mutationType { name }
    subscriptionType { name }
    types {
      kind
      name
      description
      fields(includeDeprecated: true) {
        name
        description
        args { name type { kind name ofType { kind name ofType { kind name } } } }
        type { kind name ofType { kind name ofType { kind name } } }
      }
      enumValues { name }
    }
    directives { name locations }
  }
}
"""


async def introspect(
    url: str,
    method: str = "POST",
    headers: str = "",
    user_agent: str = "pyodide-security/graphql-engine",
) -> dict[str, Any]:
    if not url.startswith("http"):
        url = "https://" + url
    hdrs = {"User-Agent": user_agent, "Content-Type": "application/json", "Accept": "application/json"}
    if headers:
        for line in headers.splitlines():
            if ":" in line:
                k, _, v = line.partition(":")
                hdrs[k.strip()] = v.strip()

    body = json.dumps({"query": INTROSPECTION_QUERY})
    if method.upper() == "GET":
        from urllib.parse import urlencode, urlparse as up, urlunparse

        p = up(url)
        resp = await http_request(urlunparse(p._replace(query=urlencode({"query": INTROSPECTION_QUERY}))), headers=hdrs)
    else:
        resp = await http_request(url, method="POST", headers=hdrs, body=body)

    raw = resp.get("body") or ""
    data = None
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return {
            "ok": False,
            "status": resp.get("status"),
            "error": "non-JSON response",
            "body_preview": raw[:300],
            "url": url,
        }

    schema = (data.get("data") or {}).get("__schema")
    if not schema:
        return {
            "ok": False,
            "status": resp.get("status"),
            "error": data.get("errors") or "no __schema (introspection disabled?)",
            "url": url,
            "raw_keys": list(data.keys()),
        }

    types = schema.get("types") or []
    interesting = []
    for t in types:
        name = t.get("name") or ""
        if name.startswith("__"):
            continue
        fields = [f.get("name") for f in (t.get("fields") or []) if f.get("name")]
        if fields or t.get("kind") in ("OBJECT", "INTERFACE"):
            interesting.append(
                {
                    "name": name,
                    "kind": t.get("kind"),
                    "fields": fields[:50],
                    "field_count": len(fields),
                }
            )

    # sensitive field names
    sensitive_keywords = ("password", "secret", "token", "apiKey", "api_key", "ssn", "credit", "admin", "role", "auth")
    sensitive = []
    for t in interesting:
        for f in t["fields"]:
            if any(k.lower() in f.lower() for k in sensitive_keywords):
                sensitive.append(f"{t['name']}.{f}")

    return {
        "ok": True,
        "url": url,
        "status": resp.get("status"),
        "query_type": (schema.get("queryType") or {}).get("name"),
        "mutation_type": (schema.get("mutationType") or {}).get("name"),
        "subscription_type": (schema.get("subscriptionType") or {}).get("name"),
        "type_count": len(interesting),
        "types": interesting[:100],
        "sensitive_fields": sensitive[:50],
        "directives": [d.get("name") for d in (schema.get("directives") or [])],
        "engine": "graphql-class",
    }


async def query(
    url: str,
    gql: str,
    variables: str = "{}",
    user_agent: str = "pyodide-security/graphql-engine",
) -> dict[str, Any]:
    if not url.startswith("http"):
        url = "https://" + url
    try:
        vars_obj = json.loads(variables or "{}")
    except json.JSONDecodeError:
        vars_obj = {}
    body = json.dumps({"query": gql, "variables": vars_obj})
    resp = await http_request(
        url,
        method="POST",
        headers={"User-Agent": user_agent, "Content-Type": "application/json"},
        body=body,
    )
    try:
        data = json.loads(resp.get("body") or "")
    except json.JSONDecodeError:
        data = {"raw": (resp.get("body") or "")[:500]}
    return {"status": resp.get("status"), "response": data, "elapsed_ms": resp.get("elapsed_ms")}
