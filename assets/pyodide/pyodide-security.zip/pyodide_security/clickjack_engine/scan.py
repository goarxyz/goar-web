"""Browser-adapted X-Frame-Options and CSP frame-ancestors assessment."""
from __future__ import annotations
import html
import json
import re
from typing import Any
from urllib.parse import urljoin
from .._http import http_request, redact_url
from .. import policy

def _frame_ancestors(csp:str)->str:
    for part in str(csp or "").split(";"):
        if part.strip().lower().startswith("frame-ancestors"):
            return part.strip()
    return ""

def _headers(raw:str,user_agent:str)->dict[str,str]:
    output={"User-Agent":user_agent};text=str(raw or "").strip()
    if text.startswith("{"):
        parsed=json.loads(text)
        if not isinstance(parsed,dict):raise ValueError("headers JSON must be an object")
        output.update({str(key):str(value) for key,value in parsed.items()})
    else:
        for line in text.splitlines():
            if ":" in line:
                key,_,value=line.partition(":");output[key.strip()]=value.strip()
    return output

def _route(value:Any)->bool|None:
    if value in (None,"","auto","AUTO"):return None
    if value in (True,"proxy","PROXY","true","True"):return True
    if value in (False,"direct","DIRECT","false","False"):return False
    raise ValueError("route must be auto, proxy, or direct")
def _items(raw:str)->list[str]:return list(dict.fromkeys(item.strip() for item in str(raw or "").replace(",","\n").splitlines() if item.strip()))
def _safe_url(value:Any)->str:
    safe=redact_url(value)
    return re.sub(r"(?i)(%3f|%26)(apikey|api_key|key|token|access_token|authorization|secret|signature|sig)(%3d|=)[^&#]*",lambda match:match.group(1)+match.group(2)+match.group(3)+"[redacted]",safe)

def _assess(headers:dict[str,str],target:str,include_template:bool=False)->dict[str,Any]:
    xfo=headers.get("x-frame-options","").strip();enforced=headers.get("content-security-policy","");report=headers.get("content-security-policy-report-only","");ancestors=_frame_ancestors(enforced);report_ancestors=_frame_ancestors(report);xfo_l=xfo.lower();reasons=[];warnings=[];legacy="none";protection="none"
    if xfo_l=="deny":legacy="blocked";reasons.append("X-Frame-Options=DENY blocks framing in supporting browsers")
    elif xfo_l=="sameorigin":legacy="restricted";reasons.append("X-Frame-Options=SAMEORIGIN restricts cross-origin framing in supporting browsers")
    elif xfo_l.startswith("allow-from"):
        legacy="unreliable";warnings.append("X-Frame-Options ALLOW-FROM is obsolete and may fail open in modern browsers")
    elif xfo:legacy="invalid";warnings.append("X-Frame-Options has an unrecognized value")
    if ancestors:
        values=ancestors[len("frame-ancestors"):].strip().lower()
        if "'none'" in values:protection="blocked";reasons.append("enforced CSP frame-ancestors 'none' blocks framing")
        elif "*" in values:protection="none";warnings.append("enforced CSP frame-ancestors allows any ancestor")
        elif values:protection="restricted";reasons.append("enforced CSP frame-ancestors restricts permitted ancestors")
        else:protection="uncertain";warnings.append("enforced CSP frame-ancestors has no source expression")
        reasons.append("enforced frame-ancestors takes precedence over X-Frame-Options in supporting browsers")
    elif legacy in {"blocked","restricted"}:protection=legacy
    if report_ancestors:warnings.append("report-only frame-ancestors is not enforced")
    if not ancestors and legacy=="none":warnings.append("missing enforced CSP frame-ancestors and X-Frame-Options")
    vulnerable=protection in {"none","uncertain"};template=None
    if include_template:template='<!doctype html><meta charset="utf-8"><title>Authorized framing check template</title><iframe sandbox="allow-forms allow-scripts" src="'+html.escape(_safe_url(target),quote=True)+'" style="width:100%;height:500px;border:1px solid #888"></iframe>'
    return {"vulnerable":vulnerable,"framing_protection":protection,"legacy_xfo_protection":legacy,"x_frame_options":xfo or None,"csp_frame_ancestors":ancestors or None,"csp_report_only_frame_ancestors":report_ancestors or None,"reasons":reasons,"warnings":warnings,"iframe_test_template":template}

async def scan(url:str,user_agent:str="pyodide-security/clickjack/2.0",paths:str="/",max_paths:int=3,headers:str="",timeout_ms:int=8000,retries:int=0,retry_statuses:str="408,429,500,502,503,504",route:str="auto",stop_on_exposure:bool=False,include_test_template:bool=False)->dict[str,Any]:
    url=str(url or "").strip()
    if not url:return {"ok":False,"error":"url required","engine":"clickjack"}
    if not url.startswith(("http://","https://")):url="https://"+url
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err:return {"ok":False,"error":err,"engine":"clickjack"}
    selected=(_items(paths) or ["/"])[:max(1,min(int(max_paths or 3),20))];timeout=max(1000,min(int(timeout_ms or 8000),120000));retry_count=max(0,min(int(retries or 0),5));retryable={int(value.strip()) for value in str(retry_statuses or "").split(",") if value.strip().isdigit()};use_proxy=_route(route);request_headers=_headers(headers,user_agent);probes=[];attempts=[];first=None
    for path in selected:
        target=urljoin(url.rstrip("/")+"/",path.lstrip("/")) if path not in ("", "/") else url;response={}
        for index in range(retry_count+1):
            response=await http_request(target,headers=request_headers,timeout_ms=timeout,use_proxy=use_proxy)
            attempts.append({"path":path,"attempt":index+1,"status":response.get("status"),"error":response.get("error"),"transport":response.get("transport"),"final_url":_safe_url(response.get("final_url"))})
            if response.get("ok") or int(response.get("status") or 0) not in retryable:break
        hdrs={str(key).lower():str(value) for key,value in (response.get("headers") or {}).items()};assessment=_assess(hdrs,target,include_test_template);row={"path":path,"url":_safe_url(target),"final_url":_safe_url(response.get("final_url") or target),"status":response.get("status"),"transport":response.get("transport"),"error":response.get("error"),**assessment};probes.append(row)
        if first is None:first=row
        if stop_on_exposure and assessment["vulnerable"]:break
    first=first or {};safe_headers={key:("[redacted]" if key.lower() in {"authorization","cookie","x-api-key"} else value) for key,value in request_headers.items()};exposed=sum(1 for row in probes if row["vulnerable"])
    return {"ok":True,"url":_safe_url(url),"status":first.get("status"),"vulnerable":bool(first.get("vulnerable")),"framing_protection":first.get("framing_protection"),"x_frame_options":first.get("x_frame_options"),"csp_frame_ancestors":first.get("csp_frame_ancestors"),"csp_report_only_frame_ancestors":first.get("csp_report_only_frame_ancestors"),"reasons":first.get("reasons",[]),"warnings":first.get("warnings",[]),"iframe_test_template":first.get("iframe_test_template"),"probes":probes,"exposed_path_count":exposed,"attempts":attempts,"attempt_count":len(attempts),"request":{"paths":selected,"headers":safe_headers,"timeout_ms":timeout,"retries":retry_count,"route":"auto" if use_proxy is None else ("proxy" if use_proxy else "direct")},"engine":"clickjack","equivalent":"X-Frame-Options/CSP frame-ancestors check","coverage_note":"Observed response-header analysis only; browser iframe loading, cookie state and frame-buster execution are not emulated."}
