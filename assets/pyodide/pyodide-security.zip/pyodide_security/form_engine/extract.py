"""Browser-adapted passive HTML form extraction through shared Goar transport."""
from __future__ import annotations
import json
import re
from html.parser import HTMLParser
from typing import Any
from urllib.parse import urljoin, urlparse
from .._http import http_request, redact_url
from .. import policy

_TOKEN=re.compile(r"(?:csrf|xsrf|_token|authenticity|anti[-_]?forgery|requestverification)",re.I)
_SENSITIVE={"password","file"}
class _FormParser(HTMLParser):
    def __init__(self):
        super().__init__();self.forms=[];self._current=None;self._outside=[]
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if tag=="form":
            self._current={"id":attrs.get("id"),"name":attrs.get("name"),"action":attrs.get("action",""),"method":(attrs.get("method") or "GET").upper(),"enctype":attrs.get("enctype") or "application/x-www-form-urlencoded","target":attrs.get("target") or "_self","autocomplete":attrs.get("autocomplete"),"novalidate":"novalidate" in attrs,"rel":attrs.get("rel") or "","inputs":[]};return
        if tag not in {"input","textarea","select","button"}:return
        control={"tag":tag,"type":(attrs.get("type") or ("select" if tag=="select" else "textarea" if tag=="textarea" else "submit" if tag=="button" else "text")).lower(),"name":attrs.get("name"),"id":attrs.get("id"),"required":"required" in attrs,"disabled":"disabled" in attrs,"autocomplete":attrs.get("autocomplete"),"formaction":attrs.get("formaction"),"formmethod":attrs.get("formmethod"),"formenctype":attrs.get("formenctype"),"formtarget":attrs.get("formtarget"),"value_present":bool(attrs.get("value")),"value_preview":"[redacted]" if attrs.get("value") else ""}
        if self._current is not None:self._current["inputs"].append(control)
        elif attrs.get("form"):self._outside.append((attrs.get("form"),control))
    def handle_endtag(self,tag):
        if tag=="form" and self._current is not None:self.forms.append(self._current);self._current=None

def _form_summary(form:dict[str,Any],base_url:str="")->dict[str,Any]:
    action=urljoin(base_url,form.get("action") or "") if base_url else form.get("action") or "";method=(form.get("method") or "GET").upper();inputs=form.get("inputs") or [];names=[str(item.get("name") or item.get("id") or "") for item in inputs];token_fields=[name for name in names if _TOKEN.search(name)];types=[str(item.get("type") or "").lower() for item in inputs];risks=[]
    def risk(text:str,severity:str):risks.append({"issue":text,"severity":severity})
    base_origin=f"{urlparse(base_url).scheme}://{urlparse(base_url).netloc}" if base_url else "";action_origin=f"{urlparse(action).scheme}://{urlparse(action).netloc}" if action else ""
    if method not in {"GET","POST","DIALOG"}:risk("unusual form method "+method,"low")
    if method=="GET" and any(kind in _SENSITIVE for kind in types):risk("GET form contains password or file control","high")
    if method in {"POST","PUT","PATCH","DELETE"} and not token_fields:risk("state-changing form has no CSRF-token indicator","medium")
    if action_origin and base_origin and action_origin!=base_origin:risk("form action targets a different origin","medium")
    if form.get("novalidate"):risk("form disables browser validation","low")
    if "file" in types and "multipart/form-data" not in str(form.get("enctype") or "").lower():risk("file control without multipart/form-data enctype","low")
    return {**form,"action":action,"method":method,"input_count":len(inputs),"input_types":sorted(set(types)),"csrf_token_indicators":token_fields,"csrf_token_indicator_present":bool(token_fields),"sensitive_control_types":sorted(set(kind for kind in types if kind in _SENSITIVE)),"risks":risks,"risk_count":len(risks),"required_input_count":sum(1 for item in inputs if item.get("required"))}

def extract_html(html:str,base_url:str="")->list[dict[str,Any]]:
    parser=_FormParser()
    try:parser.feed(html or "")
    except Exception:pass
    ids={str(row.get("id")):row for row in parser.forms if row.get("id")}
    for identifier,control in parser._outside:
        if identifier in ids:ids[identifier]["inputs"].append(control)
    return [_form_summary(form,base_url) for form in parser.forms]

def _headers(raw:str,user_agent:str)->dict[str,str]:
    output={"User-Agent":user_agent};text=str(raw or "").strip()
    if text.startswith("{"):
        parsed=json.loads(text)
        if not isinstance(parsed,dict):raise ValueError("headers JSON must be an object")
        output.update({str(key):str(value) for key,value in parsed.items()})
    else:
        for line in text.splitlines():
            if ":" in line:
                key,_,value=line.partition(":");output[key.strip()]=value.strip()
    return output

def _route(value:Any)->bool|None:
    if value in (None,"","auto","AUTO"):return None
    if value in (True,"proxy","PROXY","true","True"):return True
    if value in (False,"direct","DIRECT","false","False"):return False
    raise ValueError("route must be auto, proxy, or direct")
def _items(raw:str)->list[str]:return list(dict.fromkeys(item.strip() for item in str(raw or "").replace(",","\n").splitlines() if item.strip()))
def _safe_url(value:Any)->str:
    safe=redact_url(value)
    return re.sub(r"(?i)(%3f|%26)(apikey|api_key|key|token|access_token|authorization|secret|signature|sig)(%3d|=)[^&#]*",lambda match:match.group(1)+match.group(2)+match.group(3)+"[redacted]",safe)

async def extract(url:str,user_agent:str="pyodide-security/form/2.0",paths:str="/",max_paths:int=3,headers:str="",timeout_ms:int=8000,retries:int=0,retry_statuses:str="408,429,500,502,503,504",route:str="auto",stop_on_risk:bool=False,include_inputs:bool=True)->dict[str,Any]:
    url=str(url or "").strip()
    if not url:return {"ok":False,"error":"url required","engine":"form"}
    if not url.startswith(("http://","https://")):url="https://"+url
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err:return {"ok":False,"error":err,"engine":"form"}
    selected=(_items(paths) or ["/"])[:max(1,min(int(max_paths or 3),20))];timeout=max(1000,min(int(timeout_ms or 8000),120000));retry_count=max(0,min(int(retries or 0),5));retryable={int(value.strip()) for value in str(retry_statuses or "").split(",") if value.strip().isdigit()};use_proxy=_route(route);request_headers=_headers(headers,user_agent);attempts=[];probes=[];all_forms=[]
    for path in selected:
        target=urljoin(url.rstrip("/")+"/",path.lstrip("/")) if path not in ("", "/") else url;response={}
        for index in range(retry_count+1):
            response=await http_request(target,headers=request_headers,timeout_ms=timeout,use_proxy=use_proxy)
            attempts.append({"path":path,"attempt":index+1,"status":response.get("status"),"error":response.get("error"),"transport":response.get("transport"),"final_url":_safe_url(response.get("final_url"))})
            if response.get("ok") or int(response.get("status") or 0) not in retryable:break
        forms=extract_html(str(response.get("body") or ""),target)
        if not include_inputs:
            forms=[{key:value for key,value in form.items() if key!="inputs"} for form in forms]
        all_forms.extend([{**form,"source_path":path} for form in forms]);probes.append({"path":path,"url":_safe_url(target),"final_url":_safe_url(response.get("final_url") or target),"status":response.get("status"),"form_count":len(forms),"risk_count":sum(form.get("risk_count",0) for form in forms),"transport":response.get("transport"),"error":response.get("error")})
        if stop_on_risk and any(form.get("risk_count") for form in forms):break
    risks=[{**risk,"form_action":form.get("action"),"source_path":form.get("source_path")} for form in all_forms for risk in form.get("risks",[])];counts={level:sum(1 for row in risks if row["severity"]==level) for level in ("high","medium","low","info")};safe_headers={key:("[redacted]" if key.lower() in {"authorization","cookie","x-api-key"} else value) for key,value in request_headers.items()}
    return {"ok":True,"url":_safe_url(url),"status":probes[0]["status"] if probes else None,"forms":all_forms,"count":len(all_forms),"issues":risks,"issue_count":len(risks),"severity_counts":counts,"probes":probes,"attempts":attempts,"attempt_count":len(attempts),"request":{"paths":selected,"headers":safe_headers,"timeout_ms":timeout,"retries":retry_count,"route":"auto" if use_proxy is None else ("proxy" if use_proxy else "direct")},"engine":"form","equivalent":"passive HTML form analysis","coverage_note":"Passive extraction only; no form is submitted and token validity, server-side CSRF validation, browser JavaScript behavior, cookies and authentication state are not tested."}

async def scan_url(url:str,**kw):return await extract(url,**kw)
