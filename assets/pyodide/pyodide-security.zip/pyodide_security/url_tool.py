"""URL risk analysis — phishing / SSRF / credential-in-URL indicators."""

from __future__ import annotations

import ipaddress
import re
from typing import Any
from urllib.parse import parse_qs, unquote, urlparse


_SHORTENERS = {
    "bit.ly",
    "t.co",
    "goo.gl",
    "tinyurl.com",
    "ow.ly",
    "is.gd",
    "buff.ly",
    "rebrand.ly",
}

_SUSPICIOUS_TLDS = {
    "zip",
    "mov",
    "tk",
    "ml",
    "ga",
    "cf",
    "gq",
    "xyz",
    "top",
    "work",
    "click",
    "country",
    "stream",
}


def analyze(url: str) -> dict[str, Any]:
    if not url or not url.strip():
        raise ValueError("url is required")
    raw = url.strip()
    # add scheme for parse if missing
    to_parse = raw if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", raw) else "https://" + raw
    p = urlparse(to_parse)

    findings: list[dict[str, str]] = []
    host = p.hostname or ""
    scheme = (p.scheme or "").lower()

    if scheme in ("javascript", "data", "vbscript"):
        findings.append(
            {
                "severity": "critical",
                "id": "dangerous-scheme",
                "message": f"Dangerous scheme: {scheme}",
            }
        )
    if scheme == "http":
        findings.append(
            {
                "severity": "medium",
                "id": "cleartext-http",
                "message": "Uses cleartext HTTP.",
            }
        )

    if p.username or p.password:
        findings.append(
            {
                "severity": "high",
                "id": "userinfo",
                "message": "URL embeds credentials (userinfo). Common phishing technique.",
            }
        )

    # IP host
    ip_info = None
    if host:
        try:
            ip = ipaddress.ip_address(host.strip("[]"))
            ip_info = {"version": ip.version, "is_private": ip.is_private, "is_loopback": ip.is_loopback}
            if ip.is_private or ip.is_loopback or ip.is_link_local:
                findings.append(
                    {
                        "severity": "high",
                        "id": "ssrf-literal",
                        "message": f"Host is non-public IP ({ip}) — SSRF risk if server-side fetched.",
                    }
                )
        except ValueError:
            pass

    # Homograph / punycode
    if host.startswith("xn--") or "xn--" in host:
        findings.append(
            {
                "severity": "high",
                "id": "punycode",
                "message": "Internationalized domain (punycode) — verify against lookalike brands.",
            }
        )

    # Mixed scripts in host labels
    if host and re.search(r"[^\x00-\x7f]", host):
        findings.append(
            {
                "severity": "high",
                "id": "non-ascii-host",
                "message": "Non-ASCII characters in hostname.",
            }
        )

    labels = host.split(".") if host else []
    tld = labels[-1].lower() if labels else ""
    if tld in _SUSPICIOUS_TLDS:
        findings.append(
            {
                "severity": "low",
                "id": "tld",
                "message": f"TLD .{tld} is frequently abused.",
            }
        )

    if host.lower() in _SHORTENERS:
        findings.append(
            {
                "severity": "medium",
                "id": "shortener",
                "message": "Known URL shortener — final destination hidden.",
            }
        )

    # @ in path after host already handled by userinfo; also raw @
    if "@" in raw.split("://", 1)[-1] and "@" in (p.netloc or ""):
        pass  # already flagged

    # open redirect style params
    qs = parse_qs(p.query, keep_blank_values=True)
    redirect_keys = {"url", "redirect", "next", "return", "returnurl", "continue", "dest", "destination", "r", "u"}
    for k, vals in qs.items():
        if k.lower() in redirect_keys:
            for v in vals:
                if re.match(r"https?://", v, re.I) or v.startswith("//"):
                    findings.append(
                        {
                            "severity": "medium",
                            "id": "open-redirect-param",
                            "message": f"Parameter “{k}” points at an absolute URL ({v[:80]}).",
                        }
                    )

    # long path / many subdomains
    if host.count(".") >= 4:
        findings.append(
            {
                "severity": "low",
                "id": "many-subdomains",
                "message": "Unusually deep subdomain chain.",
            }
        )

    # percent-encoded host tricks
    if "%" in (p.netloc or ""):
        findings.append(
            {
                "severity": "high",
                "id": "encoded-host",
                "message": "Percent-encoding in host/netloc.",
            }
        )

    risk = "low"
    if any(f["severity"] == "critical" for f in findings):
        risk = "critical"
    elif any(f["severity"] == "high" for f in findings):
        risk = "high"
    elif any(f["severity"] == "medium" for f in findings):
        risk = "medium"

    return {
        "url": raw,
        "normalized": to_parse,
        "scheme": scheme,
        "host": host,
        "port": p.port,
        "path": p.path,
        "query": p.query,
        "fragment": p.fragment,
        "username": p.username,
        "ip": ip_info,
        "decoded_path": unquote(p.path),
        "risk": risk,
        "findings": findings,
    }
