"""oathtool equivalent — RFC 4226 HOTP / RFC 6238 TOTP. Pure Python."""

from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import struct
import time
from typing import Any
from urllib.parse import quote


def _normalize_secret(secret: str) -> bytes:
    s = secret.strip().replace(" ", "").replace("-", "").upper()
    # allow raw hex
    if re_fullmatch_hex(s) and len(s) % 2 == 0 and len(s) >= 20:
        try:
            return bytes.fromhex(s)
        except ValueError:
            pass
    pad = (-len(s)) % 8
    try:
        return base64.b32decode(s + "=" * pad, casefold=True)
    except Exception as e:
        raise ValueError(f"secret must be base32 (or hex): {e}") from e


def re_fullmatch_hex(s: str) -> bool:
    return all(c in "0123456789abcdefABCDEF" for c in s)


def _dynamic_truncate(digest: bytes, digits: int) -> str:
    offset = digest[-1] & 0x0F
    code = struct.unpack(">I", digest[offset : offset + 4])[0] & 0x7FFFFFFF
    return str(code % (10 ** digits)).zfill(digits)


def _hmac_digest(key: bytes, msg: bytes, algorithm: str) -> bytes:
    name = algorithm.lower().replace("-", "")
    mapping = {"sha1": "sha1", "sha256": "sha256", "sha512": "sha512"}
    if name not in mapping:
        raise ValueError("algorithm must be sha1, sha256, or sha512")
    return hmac.new(key, msg, mapping[name]).digest()


def hotp(
    secret: str,
    counter: int,
    digits: int = 6,
    algorithm: str = "sha1",
) -> dict[str, Any]:
    digits = int(digits)
    if digits not in (6, 7, 8):
        raise ValueError("digits must be 6, 7, or 8")
    key = _normalize_secret(secret)
    msg = struct.pack(">Q", int(counter) & 0xFFFFFFFFFFFFFFFF)
    digest = _hmac_digest(key, msg, algorithm)
    code = _dynamic_truncate(digest, digits)
    return {
        "code": code,
        "counter": int(counter),
        "digits": digits,
        "algorithm": algorithm.lower(),
        "standard": "RFC 4226",
    }


def totp(
    secret: str,
    digits: int = 6,
    period: int = 30,
    algorithm: str = "sha1",
    for_time: int = 0,
) -> dict[str, Any]:
    period = int(period) or 30
    now = int(for_time) if int(for_time) > 0 else int(time.time())
    counter = now // period
    result = hotp(secret, counter, digits=digits, algorithm=algorithm)
    remaining = period - (now % period)
    result.update(
        {
            "period": period,
            "unix_time": now,
            "remaining_seconds": remaining,
            "standard": "RFC 6238",
        }
    )
    return result


def verify_totp(
    secret: str,
    code: str,
    digits: int = 6,
    period: int = 30,
    algorithm: str = "sha1",
    window: int = 1,
    for_time: int = 0,
) -> dict[str, Any]:
    period = int(period) or 30
    now = int(for_time) if int(for_time) > 0 else int(time.time())
    counter = now // period
    window = max(0, min(int(window), 10))
    target = str(code).strip().zfill(int(digits))
    matched_at = None
    for delta in range(-window, window + 1):
        cand = hotp(secret, counter + delta, digits=digits, algorithm=algorithm)["code"]
        if hmac.compare_digest(cand, target):
            matched_at = delta
            break
    return {
        "valid": matched_at is not None,
        "delta": matched_at,
        "window": window,
        "checked_time": now,
    }


def new_secret(
    issuer: str = "PyodideSec",
    account: str = "user@example.com",
    nbytes: int = 20,
    algorithm: str = "sha1",
    digits: int = 6,
    period: int = 30,
) -> dict[str, Any]:
    nbytes = max(10, min(int(nbytes), 64))
    raw = secrets.token_bytes(nbytes)
    b32 = base64.b32encode(raw).decode("ascii").rstrip("=")
    # group for readability
    grouped = " ".join(b32[i : i + 4] for i in range(0, len(b32), 4))
    label = quote(f"{issuer}:{account}")
    query = (
        f"secret={b32}&issuer={quote(issuer)}"
        f"&algorithm={algorithm.upper()}&digits={int(digits)}&period={int(period)}"
    )
    uri = f"otpauth://totp/{label}?{query}"
    return {
        "secret_base32": b32,
        "secret_grouped": grouped,
        "secret_hex": raw.hex(),
        "otpauth_uri": uri,
        "bytes": nbytes,
        "algorithm": algorithm.lower(),
        "digits": int(digits),
        "period": int(period),
    }
