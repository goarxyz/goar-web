
"""Katana-class web crawler for Pyodide."""

from .crawl import crawl
from .parse import extract_html, extract_html as extract, extract_js, extract_urls, extract_forms

__all__ = ["crawl", "extract", "extract_html", "extract_js", "extract_urls", "extract_forms"]
