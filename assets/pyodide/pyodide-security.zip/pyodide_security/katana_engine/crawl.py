"""
Katana-class crawler — depth-limited link/form/JS endpoint discovery.
"""
from __future__ import annotations

from typing import Any
from urllib.parse import urljoin, urlparse

from .._http import http_request
from .. import policy
from .parse import extract_html


async def crawl(
    url: str,
    depth: int = 2,
    max_urls: int = 40,
    same_host: bool = True,
    user_agent: str = "pyodide-security/katana/2.0",
) -> dict[str, Any]:
    err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "engine": "katana"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    root = urlparse(url)
    root_host = root.hostname or ""
    headers = {"User-Agent": user_agent}
    seen = set()
    queue = [(url, 0)]
    pages = []
    all_links = []
    all_forms = []
    all_js = []

    while queue and len(seen) < max_urls:
        if not policy.can_request():
            break
        cur, d = queue.pop(0)
        if cur in seen:
            continue
        seen.add(cur)
        resp = await http_request(cur, headers=headers)
        body = resp.get("body") or ""
        extracted = extract_html(body, cur)
        links = extracted.get("urls") or []
        forms = extracted.get("forms") or []
        js_eps = extracted.get("js_endpoints") or []
        pages.append({"url": cur, "status": resp.get("status"), "depth": d, "links": len(links), "forms": len(forms)})
        all_links.extend(links)
        all_forms.extend(forms)
        all_js.extend(js_eps)
        if d >= depth:
            continue
        for link in links:
            abs_u = urljoin(cur, link)
            p = urlparse(abs_u)
            if same_host and p.hostname and p.hostname != root_host:
                continue
            if abs_u not in seen and abs_u.startswith("http"):
                queue.append((abs_u, d + 1))

    # unique
    def uniq(seq):
        out = []; s = set()
        for x in seq:
            k = x if not isinstance(x, dict) else str(x)
            if k not in s:
                s.add(k); out.append(x)
        return out

    return {
        "ok": True,
        "url": url,
        "pages": pages,
        "page_count": len(pages),
        "links": uniq(all_links)[:500],
        "link_count": len(uniq(all_links)),
        "forms": uniq(all_forms)[:100],
        "form_count": len(uniq(all_forms)),
        "js_endpoints": uniq(all_js)[:200],
        "js_count": len(uniq(all_js)),
        "engine": "katana",
        "equivalent": "projectdiscovery/katana",
    }
