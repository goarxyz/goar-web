"""HTML / JS parsers for katana crawler."""

from __future__ import annotations

import re
from html.parser import HTMLParser
from typing import Any
from urllib.parse import urljoin

_HREF_RE = re.compile(
    r"""(?i)\b(?:href|src|action|data-url|data-href)\s*=\s*["']([^"']+)["']"""
)
_JS_URL_RE = re.compile(
    r"""(?ix)
    (?:fetch|axios\.(?:get|post)|\$\.(?:get|post))\s*\(\s*["']([^"']+)["']
    | (?:url|endpoint|href|src)\s*[:=]\s*["']([^"']+)["']
    | ["'](/api/[^"']+)["']
    | ["'](https?://[^"'\s]+)["']
    """
)


class _LinkParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.links: list[str] = []
        self.forms: list[dict[str, Any]] = []
        self._form: dict[str, Any] | None = None

    def handle_starttag(self, tag, attrs):
        ad = dict(attrs)
        if tag in ("a", "link", "area") and ad.get("href"):
            self.links.append(ad["href"])
        if tag in ("script", "img", "iframe", "source", "embed") and ad.get("src"):
            self.links.append(ad["src"])
        if tag == "form":
            self._form = {
                "action": ad.get("action") or "",
                "method": (ad.get("method") or "GET").upper(),
                "inputs": [],
            }
        if tag in ("input", "select", "textarea") and self._form is not None:
            name = ad.get("name")
            if name:
                self._form["inputs"].append(
                    {
                        "name": name,
                        "type": ad.get("type") or tag,
                        "value": ad.get("value") or "",
                    }
                )

    def handle_endtag(self, tag):
        if tag == "form" and self._form is not None:
            self.forms.append(self._form)
            self._form = None


def extract_urls(html: str) -> list[str]:
    urls: list[str] = []
    try:
        p = _LinkParser()
        p.feed(html or "")
        urls.extend(p.links)
    except Exception:
        pass
    for m in _HREF_RE.finditer(html or ""):
        urls.append(m.group(1))
    seen: set[str] = set()
    out: list[str] = []
    for u in urls:
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out


def extract_forms(html: str, base_url: str = "") -> list[dict[str, Any]]:
    try:
        p = _LinkParser()
        p.feed(html or "")
        forms = p.forms
    except Exception:
        forms = []
    for f in forms:
        action = f.get("action") or ""
        if base_url:
            f["action"] = urljoin(base_url, action) if action else base_url
    return forms


def extract_js_endpoints(text: str) -> list[str]:
    found: list[str] = []
    for m in _JS_URL_RE.finditer(text or ""):
        for g in m.groups():
            if g:
                found.append(g)
    seen: set[str] = set()
    out: list[str] = []
    for u in found:
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out


def extract_html(html: str, base_url: str = "") -> dict:
    """Registry-compatible extract: urls + forms + js endpoints."""
    return {
        "urls": extract_urls(html),
        "forms": extract_forms(html, base_url),
        "js_endpoints": extract_js_endpoints(html),
    }

def extract_js(text: str) -> list[str]:
    return extract_js_endpoints(text)
