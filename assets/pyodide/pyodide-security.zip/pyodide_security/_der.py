"""Minimal DER/ASN.1 decoder for X.509 and PKCS structures. Pure Python."""

from __future__ import annotations

from typing import Any


class DERError(ValueError):
    pass


def _read_len(data: bytes, i: int) -> tuple[int, int]:
    if i >= len(data):
        raise DERError("truncated length")
    b = data[i]
    i += 1
    if b < 0x80:
        return b, i
    n = b & 0x7F
    if n == 0 or n > 4 or i + n > len(data):
        raise DERError("invalid length")
    length = int.from_bytes(data[i : i + n], "big")
    return length, i + n


def parse_tlv(data: bytes, i: int = 0) -> tuple[int, bytes, int]:
    """Return (tag, content, next_index)."""
    if i >= len(data):
        raise DERError("truncated tag")
    tag = data[i]
    i += 1
    # multi-byte tags not needed for X.509 basics
    length, i = _read_len(data, i)
    if i + length > len(data):
        raise DERError("truncated content")
    return tag, data[i : i + length], i + length


def parse_all(data: bytes) -> list[tuple[int, bytes]]:
    out: list[tuple[int, bytes]] = []
    i = 0
    while i < len(data):
        tag, content, i = parse_tlv(data, i)
        out.append((tag, content))
    return out


def as_int(content: bytes) -> int:
    if not content:
        return 0
    return int.from_bytes(content, "big", signed=content[0] & 0x80 != 0)


def as_oid(content: bytes) -> str:
    if not content:
        return ""
    first = content[0]
    parts = [str(first // 40), str(first % 40)]
    val = 0
    for b in content[1:]:
        val = (val << 7) | (b & 0x7F)
        if not (b & 0x80):
            parts.append(str(val))
            val = 0
    return ".".join(parts)


def as_time(content: bytes) -> str:
    # UTCTime YYMMDDHHMMSSZ or GeneralizedTime
    s = content.decode("ascii", errors="replace")
    if len(s) >= 13 and s.endswith("Z") and len(s) == 13:
        yy = int(s[0:2])
        year = 1900 + yy if yy >= 50 else 2000 + yy
        return f"{year:04d}-{s[2:4]}-{s[4:6]}T{s[6:8]}:{s[8:10]}:{s[10:12]}Z"
    if len(s) >= 15 and s.endswith("Z"):
        return f"{s[0:4]}-{s[4:6]}-{s[6:8]}T{s[8:10]}:{s[10:12]}:{s[12:14]}Z"
    return s


def as_string(content: bytes) -> str:
    for enc in ("utf-8", "latin-1", "ascii"):
        try:
            return content.decode(enc)
        except UnicodeDecodeError:
            continue
    return content.hex()


# Common OIDs
OID_NAMES = {
    "2.5.4.3": "CN",
    "2.5.4.6": "C",
    "2.5.4.7": "L",
    "2.5.4.8": "ST",
    "2.5.4.10": "O",
    "2.5.4.11": "OU",
    "1.2.840.113549.1.1.1": "rsaEncryption",
    "1.2.840.113549.1.1.5": "sha1WithRSAEncryption",
    "1.2.840.113549.1.1.11": "sha256WithRSAEncryption",
    "1.2.840.113549.1.1.12": "sha384WithRSAEncryption",
    "1.2.840.113549.1.1.13": "sha512WithRSAEncryption",
    "1.2.840.10045.2.1": "ecPublicKey",
    "1.2.840.10045.4.3.2": "ecdsa-with-SHA256",
    "1.2.840.10045.4.3.3": "ecdsa-with-SHA384",
    "1.2.840.10045.3.1.7": "prime256v1",
    "1.3.132.0.34": "secp384r1",
    "2.5.29.15": "keyUsage",
    "2.5.29.17": "subjectAltName",
    "2.5.29.19": "basicConstraints",
    "2.5.29.14": "subjectKeyIdentifier",
    "2.5.29.35": "authorityKeyIdentifier",
    "2.5.29.37": "extKeyUsage",
    "1.3.6.1.5.5.7.3.1": "serverAuth",
    "1.3.6.1.5.5.7.3.2": "clientAuth",
}


def parse_name(content: bytes) -> dict[str, str]:
    """Parse RDNSequence into ordered dict-like list as flat dict (last wins)."""
    result: dict[str, str] = {}
    ordered: list[str] = []
    for tag, rdn in parse_all(content):
        if tag != 0x31:  # SET
            continue
        for atag, attr in parse_all(rdn):
            if atag != 0x30:
                continue
            parts = parse_all(attr)
            if len(parts) < 2:
                continue
            oid = as_oid(parts[0][1]) if parts[0][0] == 0x06 else ""
            val = as_string(parts[1][1])
            short = OID_NAMES.get(oid, oid)
            result[short] = val
            ordered.append(f"{short}={val}")
    result["_dn"] = ", ".join(ordered)
    return result


def parse_extensions(content: bytes) -> list[dict[str, Any]]:
    exts = []
    # extensions is SEQUENCE OF Extension
    # may be wrapped in context-specific [3]
    items = parse_all(content)
    for tag, body in items:
        if tag == 0x30:
            parts = parse_all(body)
            if not parts:
                continue
            oid = as_oid(parts[0][1]) if parts[0][0] == 0x06 else "?"
            critical = False
            val_idx = 1
            if len(parts) >= 2 and parts[1][0] == 0x01:
                critical = parts[1][1] != b"\x00"
                val_idx = 2
            raw = parts[val_idx][1] if len(parts) > val_idx else b""
            # OCTET STRING unwrap
            if parts[val_idx][0] == 0x04:
                raw = parts[val_idx][1]
            entry: dict[str, Any] = {
                "oid": oid,
                "name": OID_NAMES.get(oid, oid),
                "critical": critical,
            }
            if oid == "2.5.29.17":  # SAN
                entry["values"] = _parse_san(raw)
            elif oid == "2.5.29.19":
                entry["values"] = _parse_basic_constraints(raw)
            else:
                entry["raw_hex"] = raw[:64].hex() + ("…" if len(raw) > 64 else "")
            exts.append(entry)
    return exts


def _parse_san(raw: bytes) -> list[str]:
    out: list[str] = []
    try:
        for tag, content in parse_all(raw):
            # dNSName [2] IA5String, iPAddress [7], etc.
            if tag == 0x82:
                out.append(f"DNS:{content.decode('ascii', errors='replace')}")
            elif tag == 0x87:
                if len(content) == 4:
                    out.append("IP:" + ".".join(str(b) for b in content))
                else:
                    out.append("IP:" + content.hex())
            elif tag == 0x81:
                out.append(f"email:{content.decode('ascii', errors='replace')}")
            elif tag == 0x86:
                out.append(f"URI:{content.decode('ascii', errors='replace')}")
            else:
                out.append(f"[{tag:02x}]:{content[:32].hex()}")
    except DERError:
        out.append(raw[:48].hex())
    return out


def _parse_basic_constraints(raw: bytes) -> dict[str, Any]:
    try:
        ca = False
        path_len = None
        for tag, content in parse_all(raw):
            if tag == 0x01:
                ca = content != b"\x00"
            elif tag == 0x02:
                path_len = as_int(content)
        return {"ca": ca, "path_len": path_len}
    except DERError:
        return {"raw": raw.hex()}
