"""Browser-adapted fetch helpers — retrieve through Goar, then run existing local analyzers."""

from __future__ import annotations

import json
import re
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from ._http import http_request, redact_url
from .headers_tool import analyze as analyze_headers
from .secrets_tool import scan as secrets_scan
from .tech_engine.fingerprint import fingerprint_response
from .yara_engine.rules import scan as yara_scan


def _route(value: str | bool | None) -> bool | None:
    if value in (None, "", "auto", "AUTO"):
        return None
    if value in (True, "proxy", "PROXY", "true", "True"):
        return True
    if value in (False, "direct", "DIRECT", "false", "False"):
        return False
    raise ValueError("route must be auto, proxy, or direct")


def _headers(raw: str) -> dict[str, str]:
    out = {"User-Agent": "pyodide-security/fetch"}
    text = str(raw or "").strip()
    if not text:
        return out
    if text.startswith("{"):
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValueError(f"headers must be JSON or Header: value lines: {exc}") from exc
        if not isinstance(parsed, dict):
            raise ValueError("headers JSON must be an object")
        out.update({str(key): str(value) for key, value in parsed.items()})
        return out
    for line in text.splitlines():
        if ":" in line:
            key, _, value = line.partition(":")
            if key.strip():
                out[key.strip()] = value.strip()
    return out


def _safe_headers(headers: dict[str, Any]) -> dict[str, str]:
    sensitive = {"authorization", "cookie", "set-cookie", "x-api-key", "proxy-authorization"}
    return {str(key): "[redacted]" if str(key).lower() in sensitive else str(value) for key, value in headers.items()}


def _safe_text(value: Any) -> str:
    pattern = r'''(?im)(?:["'])?(apikey|api_key|access_token|authorization|proxy-authorization|cookie|secret|token|password)(?:["'])?\s*(=|:)\s*(?:["'])?[^\r\n,;<>{}"']+'''
    return re.sub(pattern, lambda match: f"{match.group(1)}{match.group(2)}[redacted]", str(value or ""))


def _query_url(url: str, raw: str) -> str:
    text = str(raw or "").strip()
    if not text:
        return url
    additions = parse_qsl(text.lstrip("?"), keep_blank_values=True)
    if not additions:
        raise ValueError("query_params must be URL query pairs")
    parsed = urlparse(url)
    replace = {key for key, _ in additions}
    merged = [(key, value) for key, value in parse_qsl(parsed.query, keep_blank_values=True) if key not in replace] + additions
    return urlunparse(parsed._replace(query=urlencode(merged, doseq=True)))


def _expected_statuses(raw: str) -> tuple[set[int], list[str]]:
    values: set[int] = set()
    display: list[str] = []
    for piece in str(raw or "").split(","):
        item = piece.strip()
        if not item:
            continue
        if "-" in item:
            left, right = item.split("-", 1)
            if left.strip().isdigit() and right.strip().isdigit():
                start, end = int(left), int(right)
                if 100 <= start <= end <= 599:
                    values.update(range(start, end + 1)); display.append(f"{start}-{end}")
        elif item.isdigit() and 100 <= int(item) <= 599:
            values.add(int(item)); display.append(item)
    return values, display


def _body_view(body: Any, mode: str, preview_chars: int) -> str | None:
    if mode == "none":
        return None
    text = _safe_text(body)
    return text if mode == "full" else text[:preview_chars]


async def fetch_analyze(
    url: str,
    method: str = "GET",
    headers: str = "",
    body: str = "",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    analyzers: str = "all",
    query_params: str = "",
    expected_status: str = "",
    response_body_mode: str = "full",
    response_preview_chars: int = 4000,
    analyzer_max_chars: int = 200000,
    include_response_headers: bool = True,
) -> dict[str, Any]:
    """Fetch complete content through Goar and run selected existing local analyzers safely."""
    url = str(url or "").strip()
    if not url:
        return {"ok": False, "error": "url required", "engine": "fetch+analyze"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    url = _query_url(url, query_params)
    method = (method or "GET").upper()
    if method not in {"GET", "HEAD", "OPTIONS", "POST", "PUT", "PATCH", "DELETE"}:
        raise ValueError(f"unsupported HTTP method: {method}")
    mode = str(response_body_mode or "full").lower()
    if mode not in {"full", "preview", "none"}:
        raise ValueError("response_body_mode must be full, preview, or none")
    hdrs = _headers(headers)
    timeout_ms = max(1000, min(int(timeout_ms or 8000), 120000))
    retries = max(0, min(int(retries or 0), 5))
    preview_chars = max(0, min(int(response_preview_chars or 4000), 200000))
    analyzer_limit = max(0, min(int(analyzer_max_chars or 200000), 2_000_000))
    retryable = {int(value.strip()) for value in str(retry_statuses or "").split(",") if value.strip().isdigit()}
    expected, expected_display = _expected_statuses(expected_status)
    selected = {item.strip().lower() for item in str(analyzers or "all").split(",") if item.strip()}
    if not selected or "all" in selected:
        selected = {"headers", "tech", "secrets", "yara"}
    unknown = selected - {"headers", "tech", "secrets", "yara"}
    if unknown:
        raise ValueError(f"unknown analyzers: {', '.join(sorted(unknown))}")
    attempts: list[dict[str, Any]] = []
    resp: dict[str, Any] = {}
    use_proxy = _route(route)
    for index in range(retries + 1):
        resp = await http_request(url, method=method, headers=hdrs, body=body or None, timeout_ms=timeout_ms, use_proxy=use_proxy)
        attempts.append({"attempt": index + 1, "status": resp.get("status"), "ok": resp.get("ok"), "transport": resp.get("transport"), "elapsed_ms": resp.get("elapsed_ms"), "error": _safe_text(resp.get("error")), "final_url": redact_url(resp.get("final_url"))})
        if resp.get("ok") or int(resp.get("status") or 0) not in retryable:
            break
    rh = resp.get("headers") or {}
    text = str(resp.get("body") or "")
    analysis_text = text[:analyzer_limit] if analyzer_limit else ""
    status = int(resp.get("status") or 0)
    status_match = not expected or status in expected
    out: dict[str, Any] = {
        "ok": bool(resp.get("ok")) and status_match,
        "url": redact_url(url),
        "final_url": redact_url(resp.get("final_url") or url),
        "status": status,
        "status_match": status_match,
        "expected_status": expected_display,
        "headers": _safe_headers(rh) if include_response_headers else None,
        "body": _body_view(text, mode, preview_chars),
        "body_length": len(text),
        "body_mode": mode,
        "body_preview": _body_view(text, "preview", min(500, preview_chars)),
        "via_proxy": resp.get("via_proxy"),
        "via_libcurl": resp.get("via_libcurl"),
        "via_wisp": resp.get("via_wisp"),
        "transport": resp.get("transport"),
        "elapsed_ms": resp.get("elapsed_ms"),
        "error": _safe_text(resp.get("error")),
        "request": {"url": redact_url(url), "method": method, "headers": _safe_headers(hdrs), "body": _safe_text(body) if body else "", "body_length": len(str(body or "")), "query_params": query_params or None, "timeout_ms": timeout_ms, "retries": retries, "retry_statuses": sorted(retryable), "route": "auto" if use_proxy is None else ("proxy" if use_proxy else "direct")},
        "attempts": attempts,
        "attempt_count": len(attempts),
        "analyzers": sorted(selected),
        "analyzer_input_chars": len(analysis_text),
        "analyzer_truncated": len(analysis_text) < len(text),
        "analyzer_errors": {},
        "engine": "fetch+analyze",
        "equivalent": "curl + local analyzers",
    }
    analyzer_jobs = {
        "headers": lambda: analyze_headers("\n".join(f"{key}: {value}" for key, value in rh.items())),
        "tech": lambda: fingerprint_response(status, rh, analysis_text),
        "secrets": lambda: secrets_scan(analysis_text),
        "yara": lambda: yara_scan(analysis_text),
    }
    for name in sorted(selected):
        try:
            out["security_headers" if name == "headers" else name] = analyzer_jobs[name]()
        except Exception as exc:  # preserve transfer result even when a local analyzer fails
            out["analyzer_errors"][name] = _safe_text(exc)
    return out
