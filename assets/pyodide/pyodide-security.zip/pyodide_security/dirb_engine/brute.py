"""Browser-adapted ffuf / Gobuster / dirsearch-class directory discovery via shared HTTP."""
from __future__ import annotations
import json, random, re, string
from typing import Any
from urllib.parse import urljoin, urlparse
from .. import policy
from .._http import http_request, redact_url
from .wordlists import get_wordlist, list_wordlists

_SENSITIVE={"authorization","cookie","set-cookie","x-api-key","proxy-authorization"}
def _route(v):
    if v in (None,"","auto","AUTO"): return None
    if v in (True,"proxy","PROXY","true","True"): return True
    if v in (False,"direct","DIRECT","false","False"): return False
    raise ValueError("route must be auto, proxy, or direct")
def _headers(raw,user_agent):
    out={"User-Agent":str(user_agent or "pyodide-security/dirb-engine")}; text=str(raw or "").strip()
    if text.startswith("{"):
        try: parsed=json.loads(text)
        except json.JSONDecodeError as exc: raise ValueError(f"headers must be JSON or Header: value lines: {exc}") from exc
        if not isinstance(parsed,dict): raise ValueError("headers JSON must be an object")
        out.update({str(k):str(v) for k,v in parsed.items()})
    else:
        for line in text.splitlines():
            if ":" in line:
                k,_,v=line.partition(":")
                if k.strip(): out[k.strip()]=v.strip()
    return out
def _safe_headers(h): return {str(k):("[redacted]" if str(k).lower() in _SENSITIVE else str(v)) for k,v in (h or {}).items()}
def _safe_text(v): return re.sub(r'''(?im)(?:["'])?(apikey|api_key|access_token|authorization|proxy-authorization|cookie|secret|token|password)(?:["'])?\s*(=|:)\s*(?:["'])?[^\r\n,;<>{}"']+''',lambda m:f"{m.group(1)}{m.group(2)}[redacted]",str(v or ""))
def _ranges(raw):
    vals=set()
    for x in str(raw or "").split(","):
        x=x.strip()
        if "-" in x:
            a,b=x.split("-",1)
            if a.strip().isdigit() and b.strip().isdigit(): vals.update(range(int(a),int(b)+1))
        elif x.isdigit(): vals.add(int(x))
    return vals
def _words(raw): return {int(x) for x in str(raw or "").split(",") if x.strip().isdigit()}
def _candidate_words(wordlist,custom,extensions,patterns,max_words,start_index,shuffle,seed):
    pack=get_wordlist(wordlist,0); words=[w.strip() for w in str(custom or "").splitlines() if w.strip() and not w.lstrip().startswith("#")]+list(pack.get("words") or [])
    seen=set(); words=[w for w in words if not (w in seen or seen.add(w))]
    words=words[max(0,int(start_index or 0)):]
    if shuffle: random.Random(int(seed or 0)).shuffle(words)
    words=words[:max(1,min(int(max_words or 120),500))]
    exts=[e.strip().lstrip(".") for e in str(extensions or "").split(",") if e.strip()]
    pats=[p.strip() for p in str(patterns or "").splitlines() if p.strip()] or ["{WORD}"]
    out=[]
    for w in words:
        base=[w]+([w+"."+e for e in exts] if exts and "." not in w.rsplit("/",1)[-1] else [])
        for val in base:
            for pat in pats: out.append(pat.replace("{WORD}",val))
    return out[:max(1,min(int(max_words or 120)*max(1,len(exts)+1)*max(1,len(pats)),1000))],pack
def _soft(status,length,baselines,tolerance): return any(status==b["status"] and abs(length-b["length"])<=tolerance for b in baselines)

async def brute(url:str,wordlist:str="common",custom_wordlist:str="",extensions:str="",threads_note:str="",max_words:int=120,follow_codes:str="200,201,204,301,302,307,401,403",user_agent:str="pyodide-security/dirb-engine",headers:str="",method:str="GET",body:str="",timeout_ms:int=8000,retries:int=0,retry_statuses:str="408,429,500,502,503,504",route:str="auto",exclude_codes:str="",include_lengths:str="",exclude_lengths:str="",match_regex:str="",filter_regex:str="",auto_calibrate:bool=True,baseline_requests:int=1,wildcard_tolerance:int=20,patterns:str="{WORD}",start_index:int=0,shuffle_words:bool=False,random_seed:int=0,max_results:int=200,stop_on_hit:bool=False,include_bodies:bool=False,preview_chars:int=500,include_attempts:bool=True)->dict[str,Any]:
    url=str(url or "").strip()
    if not url: return {"ok":False,"error":"url required","engine":"dirb"}
    if not url.startswith(("http://","https://")): url="https://"+url
    err=policy.check_url_for_active(url)
    if err:return {"ok":False,"error":err,"engine":"dirb"}
    base=url if url.endswith("/") else url+"/"; origin=f"{urlparse(url).scheme}://{urlparse(url).netloc}"; method=str(method or "GET").upper()
    if method not in {"GET","HEAD","OPTIONS","POST","PUT","PATCH","DELETE"}:raise ValueError("unsupported HTTP method: "+method)
    req_headers=_headers(headers,user_agent); timeout=max(1000,min(int(timeout_ms or 8000),120000)); retry_count=max(0,min(int(retries or 0),5)); retryable=_ranges(retry_statuses); want=_ranges(follow_codes); drop=_ranges(exclude_codes); keep_len=_words(include_lengths); drop_len=_words(exclude_lengths); tol=max(0,min(int(wildcard_tolerance or 20),1000000)); max_hits=max(1,min(int(max_results or 200),1000)); preview=max(0,min(int(preview_chars or 500),200000)); use_proxy=_route(route)
    try: matcher=re.compile(match_regex,re.I|re.S) if str(match_regex or "").strip() else None; filterer=re.compile(filter_regex,re.I|re.S) if str(filter_regex or "").strip() else None
    except re.error as exc: raise ValueError(f"regex is invalid: {exc}") from exc
    candidates,pack=_candidate_words(wordlist,custom_wordlist,extensions,patterns,max_words,start_index,shuffle_words,random_seed)
    attempts=[];baselines=[]
    for _ in range(max(0,min(int(baseline_requests or 1),5)) if auto_calibrate else 0):
        nonce="__goar_"+"".join(random.Random(int(random_seed or 0)+len(baselines)).choice(string.ascii_lowercase) for _ in range(12)); target=urljoin(base,nonce); resp=await http_request(target,method=method,headers=req_headers,body=body or None,timeout_ms=timeout,use_proxy=use_proxy); baselines.append({"status":int(resp.get("status") or 0),"length":len(str(resp.get("body") or "")),"url":redact_url(resp.get("final_url") or target)})
    hits=[];errors=0;ignored=0;stopped=None
    for w in candidates:
        if len(hits)>=max_hits:stopped="max_results";break
        if not policy.can_request():stopped="policy_budget";break
        target=urljoin(base,w.lstrip("/")); resp={}; per=[]
        for n in range(retry_count+1):
            resp=await http_request(target,method=method,headers=req_headers,body=body or None,timeout_ms=timeout,use_proxy=use_proxy); item={"path":"/"+w.lstrip("/"),"attempt":n+1,"status":resp.get("status"),"ok":resp.get("ok"),"transport":resp.get("transport"),"elapsed_ms":resp.get("elapsed_ms"),"error":_safe_text(resp.get("error")),"final_url":redact_url(resp.get("final_url") or target)};per.append(item)
            if resp.get("ok") or int(resp.get("status") or 0) not in retryable:break
        if include_attempts:attempts.extend(per)
        status=int(resp.get("status") or 0); text=str(resp.get("body") or ""); length=len(text)
        if not status:errors+=1;continue
        if _soft(status,length,baselines,tol) or status in drop or (keep_len and length not in keep_len) or length in drop_len or (matcher and not matcher.search(text)) or (filterer and filterer.search(text)) or (want and status not in want):ignored+=1;continue
        hit={"path":"/"+w.lstrip("/"),"url":redact_url(target),"status":status,"length":length,"words":len(text.split()),"lines":len(text.splitlines()),"redirect":redact_url(resp.get("final_url")) if resp.get("redirected") else None,"content_type":(resp.get("headers") or {}).get("content-type"),"headers":_safe_headers(resp.get("headers") or {}),"transport":resp.get("transport")}
        if include_bodies:hit["body_preview"]=_safe_text(text)[:preview]
        hits.append(hit)
        if stop_on_hit:stopped="stop_on_hit";break
    hits.sort(key=lambda h:(h["status"],h["path"]))
    return {"ok":True,"base":redact_url(base),"origin":origin,"wordlist":wordlist,"wordlist_words":len(pack.get("words") or []),"candidate_count":len(candidates),"tried":len(candidates)-max(0,len(candidates)-len(hits)-ignored-errors),"hits":hits,"hit_count":len(hits),"errors":errors,"ignored":ignored,"stopped_reason":stopped,"baseline_404":baselines,"attempts":attempts if include_attempts else None,"attempt_count":len(attempts),"request":{"method":method,"headers":_safe_headers(req_headers),"body":_safe_text(body) if body else "","timeout_ms":timeout,"retries":retry_count,"route":"auto" if use_proxy is None else ("proxy" if use_proxy else "direct"),"follow_codes":sorted(want),"exclude_codes":sorted(drop),"include_lengths":sorted(keep_len),"exclude_lengths":sorted(drop_len),"auto_calibrate":bool(auto_calibrate),"patterns":patterns,"shuffle_words":bool(shuffle_words),"random_seed":int(random_seed or 0)},"engine":"ffuf/gobuster-class","wordlists":list_wordlists()["wordlists"]}
