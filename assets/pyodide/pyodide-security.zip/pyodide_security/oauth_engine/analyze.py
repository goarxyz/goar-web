"""OAuth/OIDC metadata discovery and configuration checks."""
from __future__ import annotations
import json
import re
from typing import Any
from urllib.parse import urlparse, urlunparse
from .._http import http_request, redact_url
from .. import policy

OIDC_PATHS=[("openid", "openid-configuration"),("oauth", "oauth-authorization-server")]
_ENDPOINT_KEYS=("authorization_endpoint","token_endpoint","userinfo_endpoint","jwks_uri","registration_endpoint","revocation_endpoint","introspection_endpoint")


def _headers(raw: str, user_agent: str) -> dict[str,str]:
    out={"User-Agent":user_agent,"Accept":"application/json"}; text=str(raw or "").strip()
    if text.startswith("{"):
        parsed=json.loads(text)
        if not isinstance(parsed,dict): raise ValueError("headers JSON must be an object")
        out.update({str(k):str(v) for k,v in parsed.items()})
    else:
        for line in text.splitlines():
            if ":" in line:
                key,_,value=line.partition(":");out[key.strip()]=value.strip()
    return out


def _route(value: Any) -> bool | None:
    if value in (None,"","auto","AUTO"): return None
    if value in (True,"proxy","PROXY","true","True"): return True
    if value in (False,"direct","DIRECT","false","False"): return False
    raise ValueError("route must be auto, proxy, or direct")


def _safe_url(value: Any) -> str:
    safe=redact_url(value)
    return re.sub(r"(?i)(%3f|%26)(apikey|api_key|key|token|access_token|authorization|secret|signature|sig)(%3d|=)[^&#]*",lambda m:m.group(1)+m.group(2)+m.group(3)+"[redacted]",safe)


def _issuer(value: str) -> str:
    raw=str(value or "").strip()
    if not raw.startswith(("http://","https://")): raw="https://"+raw
    parsed=urlparse(raw); return urlunparse((parsed.scheme,parsed.netloc,parsed.path.rstrip("/"),"","",""))


def _well_known(issuer: str, suffix: str) -> str:
    parsed=urlparse(issuer); path=parsed.path.rstrip("/")
    # OIDC appends configuration to issuer path; RFC 8414 inserts before it.
    location=(path + "/.well-known/" + suffix) if suffix == "openid-configuration" else ("/.well-known/" + suffix + path)
    return urlunparse((parsed.scheme,parsed.netloc,location,"","",""))


def _metadata_summary(data: dict[str,Any]) -> dict[str,Any]:
    return {"issuer":data.get("issuer"),"endpoints":{key:data.get(key) for key in _ENDPOINT_KEYS if data.get(key)},"response_types_supported":data.get("response_types_supported") or [],"grant_types_supported":data.get("grant_types_supported") or [],"scopes_supported":data.get("scopes_supported") or [],"code_challenge_methods_supported":data.get("code_challenge_methods_supported") or [],"id_token_signing_alg_values_supported":data.get("id_token_signing_alg_values_supported") or [],"token_endpoint_auth_methods_supported":data.get("token_endpoint_auth_methods_supported") or [],"keys":list(data.keys())[:60]}


def _findings(data: dict[str,Any], issuer: str, kind: str, validate_issuer: bool) -> list[dict[str,str]]:
    found=[]; advertised=str(data.get("issuer") or "")
    if validate_issuer and advertised != issuer: found.append({"id":"issuer_mismatch","severity":"high","detail":"metadata issuer does not exactly match requested issuer"})
    if not advertised: found.append({"id":"missing_issuer","severity":"high","detail":"metadata has no issuer"})
    for key in _ENDPOINT_KEYS:
        value=str(data.get(key) or "")
        if value and urlparse(value).scheme.lower()!="https": found.append({"id":"non_https_endpoint","severity":"high","detail":key+" is not https"})
    if kind=="openid":
        for key in ("authorization_endpoint","jwks_uri","response_types_supported"):
            if not data.get(key): found.append({"id":"missing_required_metadata","severity":"medium","detail":key+" missing"})
    algorithms=data.get("id_token_signing_alg_values_supported") or data.get("token_endpoint_auth_signing_alg_values_supported") or []
    if "none" in [str(value).lower() for value in algorithms]: found.append({"id":"alg_none","severity":"high","detail":"supports none signing algorithm"})
    response_types=[str(value) for value in data.get("response_types_supported") or []]
    if "token" in response_types: found.append({"id":"implicit_flow","severity":"medium","detail":"implicit response type is advertised"})
    methods=[str(value).lower() for value in data.get("code_challenge_methods_supported") or []]
    if methods and "s256" not in methods: found.append({"id":"weak_pkce","severity":"medium","detail":"PKCE S256 is not advertised"})
    return found


async def analyze(url: str, user_agent: str="pyodide-security/oauth/2.0", include_openid: bool=True, include_oauth: bool=True, headers: str="", timeout_ms: int=8000, retries: int=0, retry_statuses: str="408,429,500,502,503,504", route: str="auto", validate_issuer: bool=True, include_metadata: bool=False)->dict[str,Any]:
    issuer=_issuer(url)
    if not issuer or not urlparse(issuer).netloc: return {"ok":False,"error":"url required","engine":"oauth"}
    err=policy.check_url_for_active(issuer) if hasattr(policy,"check_url_for_active") else None
    if err: return {"ok":False,"error":err,"engine":"oauth"}
    choices=[]
    if include_openid: choices.append(OIDC_PATHS[0])
    if include_oauth: choices.append(OIDC_PATHS[1])
    if not choices: return {"ok":False,"error":"select OIDC and/or OAuth metadata","engine":"oauth"}
    request_headers=_headers(headers,user_agent);use_proxy=_route(route);timeout=max(1000,min(int(timeout_ms or 8000),120000));retryable={int(x.strip()) for x in str(retry_statuses).split(",") if x.strip().isdigit()};configs={};metadata={};findings=[];attempts=[]
    for kind,suffix in choices:
        target=_well_known(issuer,suffix);response={}
        for n in range(max(0,min(int(retries or 0),5))+1):
            response=await http_request(target,headers=request_headers,timeout_ms=timeout,use_proxy=use_proxy)
            attempts.append({"kind":kind,"attempt":n+1,"url":_safe_url(target),"status":response.get("status"),"error":response.get("error"),"transport":response.get("transport"),"final_url":_safe_url(response.get("final_url"))})
            if response.get("ok") or int(response.get("status") or 0) not in retryable: break
        body=str(response.get("body") or ""); data=None
        try:data=json.loads(body)
        except Exception: pass
        if isinstance(data,dict):
            summary=_metadata_summary(data);configs[kind]={"url":_safe_url(target),"status":response.get("status"),"summary":summary};findings.extend([{"source":kind,**item} for item in _findings(data,issuer,kind,validate_issuer)])
            if include_metadata: metadata[kind]=summary
        else: configs[kind]={"url":_safe_url(target),"status":response.get("status"),"error":response.get("error") or "non-JSON metadata response","body_length":len(body)}
    safe_headers={key:("[redacted]" if key.lower() in {"authorization","cookie","x-api-key"} else value) for key,value in request_headers.items()}
    return {"ok":bool(configs) and any("summary" in value for value in configs.values()),"url":issuer,"configs":configs,"metadata":metadata if include_metadata else {},"findings":findings,"finding_count":len(findings),"attempts":attempts,"attempt_count":len(attempts),"request":{"headers":safe_headers,"timeout_ms":timeout,"retries":retries,"route":"auto" if use_proxy is None else ("proxy" if use_proxy else "direct"),"validate_issuer":bool(validate_issuer)},"engine":"oauth","equivalent":"OIDC discovery / RFC 8414 metadata"}


async def analyze_auth_url(url: str, **kw): return await analyze(url, **kw)
async def fetch_oidc(url: str, **kw): return await analyze(url, **kw)
