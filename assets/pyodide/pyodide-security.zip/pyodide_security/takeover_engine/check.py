"""Subdomain takeover checker — existing fingerprints plus shared DoH evidence."""
from __future__ import annotations
from typing import Any
from .._http import http_request,redact_url
from .. import policy
from ..subenum_engine.resolve import doh_resolve
from .fingerprints import list_fingerprints,match_body,match_cname
def _headers(raw,user_agent):
 h={'User-Agent':user_agent};t=str(raw or '').strip()
 if not t:return h
 import json
 if t.startswith('{'):
  x=json.loads(t)
  if not isinstance(x,dict):raise ValueError('headers JSON must be an object')
  h.update({str(k):str(v) for k,v in x.items()});return h
 for line in t.splitlines():
  if ':' in line:
   k,_,v=line.partition(':');h[k.strip()]=v.strip()
 return h
def _route(v):
 if v in (None,'','auto','AUTO'):return None
 if v in (True,'proxy','PROXY','true','True'):return True
 if v in (False,'direct','DIRECT','false','False'):return False
 raise ValueError('route must be auto, proxy, or direct')
async def check(host:str='',url:str='',cname:str='',user_agent:str='pyodide-security/takeover-engine/2.0',schemes:str='https,http',provider:str='cloudflare',headers:str='',timeout_ms:int=8000,retries:int=0,retry_statuses:str='408,429,500,502,503,504',route:str='auto',resolve_cname:bool=True)->dict[str,Any]:
 if not host and url:host=url
 host=(host or '').strip().replace('https://','').replace('http://','').split('/')[0]
 if not host:return {'ok':False,'error':'host required','engine':'takeover'}
 h=_headers(headers,user_agent);use_proxy=_route(route);timeout=max(1000,min(int(timeout_ms or 8000),120000));tries=max(0,min(int(retries or 0),5));retryable={int(x.strip()) for x in str(retry_statuses or '').split(',') if x.strip().isdigit()};err=None;resolved=None
 if not cname and resolve_cname:
  resolved=await doh_resolve(host,'CNAME',provider=provider,headers=headers,timeout_ms=timeout,retries=retries,retry_statuses=retry_statuses,route=route)
  values=[str(x.get('data') or '').rstrip('.') for x in resolved.get('answers') or []]
  cname=values[0] if values else ''
 results=[];body_hits=[]
 for scheme in [s.strip().lower() for s in schemes.split(',') if s.strip()]:
  target=f'{scheme}://{host}/';e=policy.check_url_for_active(target)
  if e:err=e;continue
  if not policy.can_request():break
  attempts=[];resp={}
  for i in range(tries+1):
   resp=await http_request(target,headers=h,timeout_ms=timeout,use_proxy=use_proxy);attempts.append({'attempt':i+1,'status':resp.get('status'),'ok':resp.get('ok'),'transport':resp.get('transport'),'elapsed_ms':resp.get('elapsed_ms'),'error':resp.get('error'),'final_url':redact_url(resp.get('final_url'))})
   if resp.get('ok') or int(resp.get('status') or 0) not in retryable:break
  body=str(resp.get('body') or '');hdrs=resp.get('headers') or {};hits=match_body(body,hdrs);body_hits.extend(hits);results.append({'url':target,'status':resp.get('status'),'error':resp.get('error'),'body_len':len(body),'server':hdrs.get('server') or hdrs.get('Server'),'hits':hits,'final_url':redact_url(resp.get('final_url') or target),'attempts':attempts,'transport':resp.get('transport')})
  if hits:break
 cname_hits=match_cname(cname) if cname else [];vulnerable=bool(body_hits);safe_headers={k:('[redacted]' if k.lower() in {'authorization','cookie','x-api-key'} else v) for k,v in h.items()}
 return {'ok':True,'host':host,'cname':cname or None,'cname_resolution':resolved,'vulnerable':vulnerable,'suspected':vulnerable or bool(cname_hits),'body_matches':body_hits,'cname_matches':cname_hits,'probes':results,'fingerprint_db':list_fingerprints()['count'],'request':{'headers':safe_headers,'timeout_ms':timeout,'retries':tries,'route':'auto' if use_proxy is None else ('proxy' if use_proxy else 'direct'),'schemes':schemes,'provider':provider},'engine':'takeover','version':'2.0','equivalent':'subjack / can-i-take-over-xyz / nuclei takeovers','policy':policy.status(),'error_policy':err}
async def check_many(hosts:str,user_agent:str='pyodide-security/takeover-engine/2.0',max_hosts:int=20,**kwargs:Any)->dict[str,Any]:
 items=[x.strip() for x in hosts.replace(',','\n').splitlines() if x.strip()][:max(1,min(int(max_hosts),50))];out=[]
 for h in items:
  if not policy.can_request():break
  out.append(await check(h,user_agent=user_agent,**kwargs))
 return {'ok':True,'total':len(out),'vulnerable_count':len([r for r in out if r.get('vulnerable')]),'results':out,'engine':'takeover'}
