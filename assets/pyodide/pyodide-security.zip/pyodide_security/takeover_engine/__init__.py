
from .check import check, check_many
from .fingerprints import list_fingerprints, match_body, match_cname

# registry / generic alias
scan = check

__all__ = ["check", "check_many", "scan", "list_fingerprints", "match_body", "match_cname"]
