"""
pyodide_security — max-breadth pure-Python security toolkit for Pyodide.
Live tools auto-route through Manus CORS proxy (host app auto-mints keys).
"""

from __future__ import annotations

import inspect
from pathlib import Path
from typing import Any

from . import (
    subenum_engine,
    
    wpscan_engine,
    cloud_engine,
    nosql_engine,
    graphql_engine,
    ssti_engine,
    cms_engine,
    jwt_engine,
    requests_bridge,
    api_engine,
    asn_engine,
    backup_engine,
    cipher_tool,
    clickjack_engine,
    cloud_engine,
    cms_engine,
    codec_tool,
    cookie_engine,
    cors_engine,
    crack_tool,
    crlf_engine,
    csp_engine,
    ct_engine,
    dns_engine,
    dirb_engine,
    emailsec_engine,
    favicon_engine,
    fetch_tool,
    form_engine,
    fuzzgen_engine,
    graphql_adv_engine,
    graphql_engine,
    har_engine,
    hash_tool,
    hashid_tool,
    headerfuzz_engine,
    headers_tool,
    homoglyph_engine,
    httpx_engine,
    inject_engine,
    intel_engine,
    internetdb_engine,
    jsrecon_engine,
    jwt_advanced,
    jwt_tool,
    katana_tool,
    mutator_engine,
    nikto_engine,
    nmap_tool,
    nosql_engine,
    nuclei_engine,
    oauth_engine,
    otp_tool,
    param_engine,
    password_tool,
    proto_pollution_engine,
    proxy_tool,
    rdap_engine,
    redirect_engine,
    redos_tool,
    repeater_engine,
    robots_engine,
    sast_tool,
    secrets_tool,
    smuggle_engine,
    sqlmap_tool,
    ssrf_engine,
    ssti_engine,
    subenum_tool,
    takeover_engine,
    tech_engine,
    upload_engine,
    url_tool,
    vhost_engine,
    waf_engine,
    wayback_engine,
    wellknown_engine,
    wpscan_engine,
    x509_tool,
    xss_engine,
    xxe_engine,
    yara_engine,
    policy,
    libcurl_bridge,
    network,
    simd_crypto,
    network_tools,
)
from ._http import proxy_status

__version__ = "8.1.0"
VERSION = __version__


def _discover_package_files() -> list[str]:
    root = Path(__file__).resolve().parent
    return sorted(str(p.relative_to(root)).replace("\\", "/") for p in root.rglob("*.py"))


PACKAGE_FILES = _discover_package_files()


def _tool(id_, group, title, equivalent, description, fn, params, is_async=False):
    return {
        "id": id_,
        "group": group,
        "title": title,
        "equivalent": equivalent,
        "description": description,
        "async": is_async,
        "params": params,
        "fn": fn,
    }


_TOOLS: list[dict] = [
    # ---- POLICY ----
    _tool("cms.detect_offline", "CMS", "Offline CMS", "CMSeeK", "Match headers/body against CMSeeK rules offline.", cms_engine.detect_offline, {
        "headers": {"type": "string", "default": ""},
        "body": {"type": "string", "default": ""},
    }),
    
    _tool("cms.list", "CMS", "List CMS", "CMSeeK catalog", "List CMSeeK CMS catalog.", cms_engine.list_cms, {
        "limit": {"type": "integer", "default": 0},
    }),
    
    _tool("cms.rules", "CMS", "List rules", "CMSeeK rules", "List CMSeeK detection rules.", cms_engine.list_rules, {
        "where": {"type": "string", "default": ""},
        "limit": {"type": "integer", "default": 0},
    }),
    
    _tool("ssti.engines", "SSTI", "List engines", "tplmap engines", "List tplmap template engines.", ssti_engine.list_engines, {}),
    
    _tool("ssti.payloads", "SSTI", "List payloads", "tplmap probes", "List SSTI render probes.", ssti_engine.list_payloads, {}),
    
    _tool("graphql.scan", "GraphQL", "GraphQL scan", "GraphQLmap", "Introspection, schema and bounded field probes through the unified Goar route stack.", graphql_engine.scan, {
        "url": {"type": "string", "required": True},
        "method": {"type": "string", "default": "POST", "enum": ["POST", "GET"]},
        "max_probes": {"type": "integer", "default": 0},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "probe_tags": {"type": "string", "default": "", "placeholder": "Optional: introspection,meta,batch,enum,dos"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
    
    _tool("graphql.probes", "GraphQL", "List probes", "GraphQLmap", "List GraphQL probes.", graphql_engine.list_probes, {}),
    
    _tool("cloud.enum", "Cloud", "Cloud enum", "cloud_enum", "Bounded AWS/Azure/GCP endpoint enumeration with provider-attempt evidence.", cloud_engine.enumerate, {
        "name": {"type": "string", "required": True},
        "providers": {"type": "string", "default": "aws,azure,gcp"},
        "max_mutations": {"type": "integer", "default": 20},
        "max_checks": {"type": "integer", "default": 40},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
    
    _tool("cloud.formats", "Cloud", "List formats", "cloud_enum", "Cloud URL formats + fuzz size.", cloud_engine.list_formats, {}),
    
    _tool("wpscan.paths", "WordPress", "List paths", "WPScan", "List WP interesting paths.", wpscan_engine.list_paths, {
        "limit": {"type": "integer", "default": 0},
    }),

    
    _tool("recon.subenum_sources", "Recon", "Subfinder sources", "subfinder", "List subfinder passive sources.", subenum_engine.list_sources, {}),
    _tool("subenum.wordlist", "Recon", "Subdomain wordlist", "SecLists", "SecLists top 5k subdomain wordlist.", subenum_engine.list_wordlist, {
        "limit": {"type": "integer", "default": 0},
    }),
    _tool("recon.subenum_crtsh", "Recon", "crt.sh", "subfinder/crtsh", "Passive certificate-transparency enumeration with certificate evidence.", subenum_engine.crtsh, {
        "domain": {"type": "string", "required": True},
        "service_base": {"type": "string", "default": "https://crt.sh"},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "max_results": {"type": "integer", "default": 5000},
        "include_wildcards": {"type": "boolean", "default": False},
    }, is_async=True),
    _tool("recon.subenum_brute", "Recon", "Subdomain brute", "SecLists", "HTTP probe wordlist.subdomain.", subenum_engine.brute, {
        "domain": {"type": "string", "required": True},
        "max_words": {"type": "integer", "default": 100},
    }, is_async=True),
    _tool("api.endpoints", "API", "List endpoints", "SecLists", "SecLists API endpoint wordlist.", api_engine.list_endpoints, {
        "limit": {"type": "integer", "default": 0},
    }),
    _tool("api.discover_seclists", "API", "Discover APIs", "SecLists", "Probe SecLists API endpoints.", api_engine.discover, {
        "url": {"type": "string", "required": True},
        "max_endpoints": {"type": "integer", "default": 40},
    }, is_async=True),
    _tool("recon.backup_scan", "Recon", "Backup files", "SecLists", "Sensitive/backup file discovery.", backup_engine.scan, {
        "url": {"type": "string", "required": True},
        "max_paths": {"type": "integer", "default": 50},
    }, is_async=True),
    _tool("backup.files", "Recon", "List backup paths", "SecLists", "Backup/sensitive path wordlist.", backup_engine.list_files, {
        "limit": {"type": "integer", "default": 0},
    }),
    _tool("recon.vhost_brute", "Recon", "VHost brute", "SecLists", "Virtual host Host-header brute.", vhost_engine.brute, {
        "url": {"type": "string", "required": True},
        "max_hosts": {"type": "integer", "default": 40},
    }, is_async=True),
    _tool("vhost.wordlist", "Recon", "VHost wordlist", "SecLists", "VHost namelist (top 8k).", vhost_engine.list_wordlist, {
        "limit": {"type": "integer", "default": 0},
    }),
    _tool("inject.xxe_scan", "Inject", "XXE scan", "PAT XXE", "Bounded XML entity probes with request controls, retries/routes, redacted evidence, and response-difference analysis.", xxe_engine.scan, {
        "url": {"type": "string", "required": True},
        "max_payloads": {"type": "integer", "default": 8},
        "content_type": {"type": "string", "default": "application/xml"},
        "method": {"type": "string", "default": "POST", "enum": ["POST", "PUT", "PATCH"]},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "baseline_body": {"type": "string", "default": "<ping/>", "widget": "textarea"},
        "custom_payloads": {"type": "string", "default": "", "widget": "textarea", "placeholder": "XML payloads separated by a line beginning < or by ---"},
        "include_default": {"type": "boolean", "default": True},
        "status_codes": {"type": "string", "default": ""},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "min_difference": {"type": "number", "default": 0.08},
        "max_findings": {"type": "integer", "default": 50},
        "include_response_body": {"type": "boolean", "default": False},
        "preview_chars": {"type": "integer", "default": 400},
        "include_attempts": {"type": "boolean", "default": False},
        "stop_on_finding": {"type": "boolean", "default": False},
    }, is_async=True),
    _tool("inject.xxe_payloads", "Inject", "XXE payloads", "PAT XXE", "List XXE payloads.", xxe_engine.list_payloads, {
        "limit": {"type": "integer", "default": 0},
    }),
    _tool("recon.httpx_probe", "Recon", "HTTPX probe", "httpx", "httpx-class status/title/server probe.", httpx_engine.probe, {
        "url": {"type": "string", "default": ""},
        "urls": {"type": "string", "default": ""},
    }, is_async=True),
    _tool("inject.cmd_ldap_scan", "Inject", "CMD/LDAP inject", "PAT", "Command/LDAP injection probes.", inject_engine.scan, {
        "url": {"type": "string", "required": True},
        "parameter": {"type": "string", "default": ""},
        "kind": {"type": "string", "default": "cmdi"},
        "max_payloads": {"type": "integer", "default": 15},
    }, is_async=True),
    _tool("inject.cmd_ldap_payloads", "Inject", "Inject payloads", "PAT", "List CMD/LDAP payloads.", inject_engine.list_payloads, {
        "kind": {"type": "string", "default": "cmdi"},
    }),

    
    _tool("wpscan.plugins", "WordPress", "List plugins", "SecLists", "WP plugin slug wordlist.", wpscan_engine.list_plugins, {
        "limit": {"type": "integer", "default": 0},
    }),
    _tool("wpscan.themes", "WordPress", "List themes", "SecLists", "WP theme slug wordlist.", wpscan_engine.list_themes, {
        "limit": {"type": "integer", "default": 0},
    }),
    _tool("nuclei.stats", "Nuclei", "Template stats", "nuclei-templates", "Template corpus severity/category stats.", nuclei_engine.stats, {}),

    _tool("policy.status", "Policy", "Policy status", "internal", "Request budget + active-scan gate.", policy.status, {}),
    _tool("policy.configure", "Policy", "Configure policy", "internal", "Set budget, active scanning, blocked hosts.", policy.configure, {
        "max_requests": {"type": "integer", "default": 80},
        "allow_active_scanning": {"type": "boolean"},
        "require_https_for_active": {"type": "boolean"},
        "extra_blocked_hosts": {"type": "array"},
        "reset_budget": {"type": "boolean", "default": False},
    }),
    _tool("policy.reset_budget", "Policy", "Reset request budget", "internal", "Zero the request counter.", policy.reset_budget, {}),
    # ---- PROXY ----
    _tool("proxy.configure", "Proxy", "Configure CORS proxy", "cors.manus.space", "Manual override (normally auto). Path-style /api/proxy/:url recommended.", proxy_tool.configure, {
        "api_key": {"type": "string", "required": True},
        "enabled": {"type": "boolean", "default": True},
        "base_url": {"type": "string", "default": "https://cors.manus.space/api/proxy"},
        "auth_mode": {"type": "string", "default": "both", "enum": ["header", "query", "both"]},
        "url_style": {"type": "string", "default": "path", "enum": ["path", "query"]},
        "extras": {"type": "object", "default": {}},
        "wisp_url": {"type": "string", "default": "wss://cors.manus.space/wisp/"},
    }),
    _tool("proxy.status", "Proxy", "Proxy status", "cors.manus.space", "Show proxy (key masked).", proxy_tool.status, {}),
    _tool("proxy.disable", "Proxy", "Disable proxy", "cors.manus.space", "Disable routing.", proxy_tool.disable, {}),
    _tool("proxy.generate", "Proxy", "Generate API key", "apiKey.generate", "Mint a same-origin proxy key without disclosing it in Files output.", proxy_tool.generate, {
        "origin": {"type": "string", "default": ""},
        "auto_configure": {"type": "boolean", "default": True},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
    }, is_async=True),
    _tool("proxy.test", "Proxy", "Test proxy", "cors.manus.space", "Bounded shared-route proxy probe with safe attempt evidence.", proxy_tool.test, {
        "target": {"type": "string", "default": "https://rondastore.org/"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
    }, is_async=True),

    # ---- REPEATER / FETCH ----
    
    _tool("network.ensure", "Network", "Ensure stack", "libcurl+wisp+cors", "Bootstrap and optionally verify libcurl/Wisp/Epoxy + Manus CORS for all engines.", network.ensure, {
        "wisp_url": {"type": "string", "default": "wss://cors.manus.space/wisp/"},
        "origin": {"type": "string", "default": ""},
        "force": {"type": "boolean", "default": False},
        "preferred": {"type": "boolean", "default": True},
        "epoxy_enabled": {"type": "boolean", "default": True},
        "transport_mode": {"type": "string", "default": "auto", "enum": ["auto", "libcurl", "proxy", "direct"]},
        "verify_target": {"type": "string", "default": ""},
        "verify_timeout_ms": {"type": "integer", "default": 8000},
        "verify_retries": {"type": "integer", "default": 0},
    }, is_async=True),
    _tool("network.status", "Network", "Stack status", "transport status", "libcurl/Wisp/Epoxy/CORS readiness.", network.status, {}),
    _tool("network.test", "Network", "Connectivity test", "probe transport", "Full route-aware HTTP probe through the unified stack with status-range and safe response evidence.", network.test, {
        "target": {"type": "string", "default": "https://rondastore.org/"},
        "method": {"type": "string", "default": "GET", "enum": ["GET", "HEAD", "OPTIONS", "POST", "PUT", "PATCH", "DELETE"]},
        "headers_json": {"type": "string", "default": "", "widget": "textarea"},
        "body": {"type": "string", "default": "", "widget": "textarea"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "expected_status": {"type": "string", "default": "", "placeholder": "Optional statuses/ranges, e.g. 200-299,304"},
        "include_body": {"type": "boolean", "default": True},
    }, is_async=True),

    _tool("proxy.ensure", "Proxy", "Ensure proxy ready", "cors.manus.space", "Idempotently mint/configure a proxy key; optional verification is explicit and safe.", proxy_tool.ensure, {
        "origin": {"type": "string", "default": ""},
        "force": {"type": "boolean", "default": False},
        "verify_target": {"type": "string", "default": ""},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
    }, is_async=True),
    _tool("proxy.is_ready", "Proxy", "Proxy ready?", "cors.manus.space", "True when key is configured and proxy enabled.", proxy_tool.is_ready, {}),

    # ---- LIBCURL / WISP ----
    _tool("libcurl.status", "Libcurl", "libcurl.js status", "libcurl+wisp", "Whether host libcurl.js + Wisp is ready.", libcurl_bridge.status, {}),
    _tool("libcurl.configure", "Libcurl", "Configure libcurl bridge", "libcurl+wisp", "Configure existing libcurl, Wisp, Epoxy and CORS transport preferences.", libcurl_bridge.configure, {
        "preferred": {"type": "boolean", "default": True},
        "wisp_url": {"type": "string", "default": "wss://cors.manus.space/wisp/"},
        "cors_base": {"type": "string", "default": "https://cors.manus.space/api/proxy"},
        "epoxy_enabled": {"type": "boolean", "default": True},
        "transport_mode": {"type": "string", "default": "auto", "enum": ["auto", "libcurl", "epoxy", "cors"]},
    }),
    _tool("libcurl.ensure", "Libcurl", "Ensure libcurl+Wisp", "libcurl+wisp", "Point the existing host libcurl/WASM bridge at Wisp, wait briefly for readiness, and report truthful transport state.", libcurl_bridge.ensure, {
        "wisp_url": {"type": "string", "default": "wss://cors.manus.space/wisp/"},
        "force_websocket": {"type": "boolean", "default": True},
        "wait_ms": {"type": "integer", "default": 0},
        "transport_mode": {"type": "string", "default": "auto", "enum": ["auto", "libcurl", "epoxy", "cors"]},
    }, is_async=True),
    _tool("libcurl.is_ready", "Libcurl", "libcurl ready?", "libcurl+wisp", "True when WASM loaded and websocket set.", libcurl_bridge.is_ready, {}),

    # ---- SIMD CRYPTO ----
    _tool("simd.status", "SIMD", "SIMD crypto status", "psec-simd-wheels", "cryptography/cffi wheel load state.", simd_crypto.status, {}),
    _tool("simd.ensure", "SIMD", "Load SIMD crypto wheels", "psec-simd-wheels", "Install cryptography stack from GitHub release or local EMFS.", simd_crypto.ensure, {
        "local_dir": {"type": "string", "default": ""},
        "use_github": {"type": "boolean", "default": True},
    }, is_async=True),
    _tool("simd.wheels", "SIMD", "Wheel URLs", "psec-simd-wheels", "Release wheel URLs and sha256.", simd_crypto.wheel_urls, {}),
    _tool("simd.is_ready", "SIMD", "Crypto ready?", "psec-simd-wheels", "True when cryptography import works.", simd_crypto.is_ready, {}),

    _tool("repeater.send", "Repeater", "Send request", "Burp Repeater", "Full raw HTTP replay through the Goar transport with complete evidence.", repeater_engine.send, {
        "url": {"type": "string", "required": True},
        "method": {"type": "string", "default": "GET", "enum": ["GET", "HEAD", "OPTIONS", "POST", "PUT", "PATCH", "DELETE"]},
        "headers": {"type": "string", "default": "", "widget": "textarea"},
        "body": {"type": "string", "default": "", "widget": "textarea"},
        "user_agent": {"type": "string", "default": "pyodide-security/repeater/2.0"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "query_params": {"type": "string", "default": "", "placeholder": "name=value&other=value"},
        "raw_request": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Optional HTTP request line, headers, and body; overrides matching fields"},
        "repeat_count": {"type": "integer", "default": 1},
        "expected_status": {"type": "string", "default": "", "placeholder": "Optional statuses/ranges, e.g. 200-299,304"},
        "response_body_mode": {"type": "string", "default": "full", "enum": ["full", "preview", "none"]},
        "response_preview_chars": {"type": "integer", "default": 4000},
        "label": {"type": "string", "default": ""},
    }, is_async=True),
    _tool("repeater.compare", "Repeater", "Compare requests", "Burp Repeater / Comparer", "Replay two independent request variants and compare response lines, words, or bytes through Goar.", repeater_engine.compare, {
        "url": {"type": "string", "required": True},
        "method": {"type": "string", "default": "GET", "enum": ["GET", "HEAD", "OPTIONS", "POST", "PUT", "PATCH", "DELETE"]},
        "url_a": {"type": "string", "default": "", "placeholder": "Optional A target; defaults to URL"},
        "url_b": {"type": "string", "default": "", "placeholder": "Optional B target; defaults to URL"},
        "method_a": {"type": "string", "default": "", "enum": ["", "GET", "HEAD", "OPTIONS", "POST", "PUT", "PATCH", "DELETE"]},
        "method_b": {"type": "string", "default": "", "enum": ["", "GET", "HEAD", "OPTIONS", "POST", "PUT", "PATCH", "DELETE"]},
        "headers_a": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "headers_b": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "body": {"type": "string", "default": "", "widget": "textarea"},
        "body_a": {"type": "string", "default": "", "widget": "textarea"},
        "body_b": {"type": "string", "default": "", "widget": "textarea"},
        "user_agent": {"type": "string", "default": "pyodide-security/repeater/2.0"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "compare_mode": {"type": "string", "default": "lines", "enum": ["lines", "words", "bytes"]},
        "include_headers": {"type": "boolean", "default": True},
    }, is_async=True),
    _tool("fetch.analyze", "Fetch", "Fetch + analyze", "curl | analyze", "Full fetch output plus selected headers, technology, secrets, and YARA analysis.", fetch_tool.fetch_analyze, {
        "url": {"type": "string", "required": True},
        "method": {"type": "string", "default": "GET", "enum": ["GET", "HEAD", "OPTIONS", "POST", "PUT", "PATCH", "DELETE"]},
        "headers": {"type": "string", "default": "", "widget": "textarea"},
        "body": {"type": "string", "default": "", "widget": "textarea"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "analyzers": {"type": "string", "default": "all", "enum": ["all", "headers", "tech", "secrets", "yara", "headers,tech", "headers,tech,secrets,yara"]},
        "query_params": {"type": "string", "default": "", "placeholder": "name=value&other=value"},
        "expected_status": {"type": "string", "default": "", "placeholder": "Optional statuses/ranges, e.g. 200-299,304"},
        "response_body_mode": {"type": "string", "default": "full", "enum": ["full", "preview", "none"]},
        "response_preview_chars": {"type": "integer", "default": 4000},
        "analyzer_max_chars": {"type": "integer", "default": 200000},
        "include_response_headers": {"type": "boolean", "default": True},
    }, is_async=True),

    # ---- NUCLEI / NIKTO / BACKUP / CMS / API ----
    _tool("nuclei.templates", "Nuclei", "List templates", "nuclei -tl", "Template catalog.", nuclei_engine.list_templates, {
        "tags": {"type": "string", "default": ""},
        "severity": {"type": "string", "default": ""},
        "query": {"type": "string", "default": ""},
    }),
    _tool("nuclei.scan", "Nuclei", "Template scan", "nuclei -u", "Bounded browser-adapted HTTP template execution with template/tag selection, request controls, redacted evidence, and deterministic caps.", nuclei_engine.scan, {
        "url": {"type": "string", "required": True},
        "tags": {"type": "string", "default": "", "placeholder": "Tags or categories, comma-separated"},
        "severity": {"type": "string", "default": "info,low,medium,high,critical"},
        "templates": {"type": "string", "default": "", "placeholder": "Template IDs, comma-separated"},
        "max_templates": {"type": "integer", "default": 50},
        "method": {"type": "string", "default": "", "enum": ["", "GET", "POST", "HEAD", "OPTIONS"]},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "body": {"type": "string", "default": "", "widget": "textarea"},
        "custom_paths": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Optional paths, one per line or comma-separated"},
        "max_requests": {"type": "integer", "default": 0},
        "status_codes": {"type": "string", "default": ""},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "include_response_body": {"type": "boolean", "default": False},
        "preview_chars": {"type": "integer", "default": 400},
        "include_attempts": {"type": "boolean", "default": False},
        "stop_on_finding": {"type": "boolean", "default": False},
    }, is_async=True),
    _tool("nikto.list_checks", "Nikto", "List checks", "nikto -list", "Enumerate nikto check database.", nikto_engine.list_checks, {
        "category": {"type": "string", "default": ""},
    }),
    _tool("nikto.scan", "Nikto", "Web checks", "nikto -h", "Bounded converted Nikto checks with tuning, request controls, filters, and safe evidence through Goar.", nikto_engine.scan, {
        "url": {"type": "string", "required": True},
        "max_tests": {"type": "integer", "default": 45},
        "tuning": {"type": "string", "default": "", "placeholder": "Nikto tuning, e.g. 58 or 58xb"},
        "user_agent": {"type": "string", "default": "Mozilla/5.0 (Nikto/pyodide-security)"},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "root": {"type": "string", "default": "", "placeholder": "Optional path prepended to test URIs"},
        "vhost": {"type": "string", "default": "", "placeholder": "Optional Host header override"},
        "include_test_ids": {"type": "string", "default": "", "placeholder": "Optional comma-separated Nikto test IDs"},
        "exclude_test_ids": {"type": "string", "default": "", "placeholder": "Optional comma-separated Nikto test IDs"},
        "ignore_statuses": {"type": "string", "default": "", "placeholder": "Ignore comma-separated HTTP statuses"},
        "ignore_body_regex": {"type": "string", "default": "", "placeholder": "Ignore matching response bodies"},
        "max_uri_expansions": {"type": "integer", "default": 3},
        "max_findings": {"type": "integer", "default": 100},
        "stop_on_finding": {"type": "boolean", "default": False},
        "include_bodies": {"type": "boolean", "default": False},
        "body_preview_chars": {"type": "integer", "default": 1000},
        "include_attempts": {"type": "boolean", "default": True},
        "shuffle_tests": {"type": "boolean", "default": True},
        "random_seed": {"type": "integer", "default": 0},
    }, is_async=True),
    _tool("backup.scan", "Backup", "Backup hunter", "dirsearch backups", "Bounded browser-adapted backup and sensitive-file discovery with filtering, retries/routes, redacted attempts, and structured evidence.", backup_engine.scan, {
        "url": {"type": "string", "required": True},
        "max_paths": {"type": "integer", "default": 70},
        "method": {"type": "string", "default": "GET", "enum": ["GET", "HEAD", "OPTIONS", "POST"]},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "body": {"type": "string", "default": "", "widget": "textarea"},
        "custom_paths": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Additional paths, one per line or comma-separated"},
        "include_default": {"type": "boolean", "default": True},
        "extensions": {"type": "string", "default": "", "placeholder": "e.g. bak,old,zip"},
        "status_codes": {"type": "string", "default": "200,403"},
        "exclude_statuses": {"type": "string", "default": ""},
        "min_length": {"type": "integer", "default": 0},
        "max_length": {"type": "integer", "default": 0},
        "match_regex": {"type": "string", "default": ""},
        "exclude_regex": {"type": "string", "default": ""},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "include_response_body": {"type": "boolean", "default": False},
        "preview_chars": {"type": "integer", "default": 400},
        "include_attempts": {"type": "boolean", "default": False},
        "stop_on_first": {"type": "boolean", "default": False},
    }, is_async=True),
    _tool("cms.detect", "CMS", "CMS detect", "CMSeeK", "Bundled CMSeeK header, generator, and source detection across bounded browser-adapted paths.", cms_engine.detect, {
        "url": {"type": "string", "required": True},
        "paths": {"type": "string", "default": "/", "widget": "textarea", "placeholder": "One optional path per line or comma-separated"},
        "max_paths": {"type": "integer", "default": 5},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "strict_cms": {"type": "string", "default": "", "placeholder": "Optional CMS IDs/names to keep"},
        "ignore_cms": {"type": "string", "default": "", "placeholder": "Optional CMS IDs/names to remove"},
        "stop_on_detection": {"type": "boolean", "default": False},
        "include_bodies": {"type": "boolean", "default": False},
    }, is_async=True),
    _tool("api.discover", "API", "API discover", "kiterunner lite", "Bounded route and OpenAPI/Swagger/OIDC manifest discovery through Goar transport.", api_engine.discover, {
        "url": {"type": "string", "required": True},
        "max_paths": {"type": "integer", "default": 30},
        "method": {"type": "string", "default": "GET", "enum": ["GET", "HEAD", "OPTIONS", "POST", "PUT", "PATCH", "DELETE"]},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "body": {"type": "string", "default": "", "widget": "textarea"},
        "custom_paths": {"type": "string", "default": "", "widget": "textarea", "placeholder": "One route per line"},
        "include_standard": {"type": "boolean", "default": True},
        "discover_manifests": {"type": "boolean", "default": True},
        "interesting_statuses": {"type": "string", "default": "200,201,202,204,301,302,307,308,401,403,405,500"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),

    # ---- DIRB / VHOST / HTTPX / TECH / FAVICON ----
    _tool("dirb.brute", "Dirb", "Path brute", "ffuf / gobuster", "Bounded directory/file discovery with wordlists, calibration, filters, retries, and safe shared-transport evidence.", dirb_engine.brute, {
        "url": {"type": "string", "required": True},
        "wordlist": {"type": "string", "default": "common", "enum": ["common", "api", "sensitive", "all"]},
        "custom_wordlist": {"type": "string", "default": "", "widget": "textarea"},
        "extensions": {"type": "string", "default": ""},
        "max_words": {"type": "integer", "default": 80},
        "follow_codes": {"type": "string", "default": "200,201,204,301,302,307,401,403"},
        "user_agent": {"type": "string", "default": "pyodide-security/dirb-engine"},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "method": {"type": "string", "default": "GET", "enum": ["GET", "HEAD", "OPTIONS", "POST", "PUT", "PATCH", "DELETE"]},
        "body": {"type": "string", "default": "", "widget": "textarea"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "exclude_codes": {"type": "string", "default": ""},
        "include_lengths": {"type": "string", "default": ""},
        "exclude_lengths": {"type": "string", "default": ""},
        "match_regex": {"type": "string", "default": ""},
        "filter_regex": {"type": "string", "default": ""},
        "auto_calibrate": {"type": "boolean", "default": True},
        "baseline_requests": {"type": "integer", "default": 1},
        "wildcard_tolerance": {"type": "integer", "default": 20},
        "patterns": {"type": "string", "default": "{WORD}", "widget": "textarea", "placeholder": "One pattern per line; use {WORD}"},
        "start_index": {"type": "integer", "default": 0},
        "shuffle_words": {"type": "boolean", "default": False},
        "random_seed": {"type": "integer", "default": 0},
        "max_results": {"type": "integer", "default": 200},
        "stop_on_hit": {"type": "boolean", "default": False},
        "include_bodies": {"type": "boolean", "default": False},
        "preview_chars": {"type": "integer", "default": 500},
        "include_attempts": {"type": "boolean", "default": True},
    }, is_async=True),
    _tool("dirb.wordlists", "Dirb", "List wordlists", "ffuf -w", "Wordlist sizes.", dirb_engine.list_wordlists, {}),
    _tool("vhost.brute", "VHost", "VHost brute", "Gobuster VHost", "Bounded Host-header VHost discovery with baseline, filtering, retries, route and safe evidence.", vhost_engine.brute, {
        "url": {"type": "string", "required": True},
        "domain": {"type": "string", "default": ""},
        "wordlist": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Optional custom candidates, one per line or comma-separated"},
        "max_words": {"type": "integer", "default": 30},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Optional Header: value lines or JSON object"},
        "user_agent": {"type": "string", "default": "pyodide-security/vhost/2.0"},
        "append_domain": {"type": "boolean", "default": True},
        "baseline_requests": {"type": "integer", "default": 2},
        "exclude_statuses": {"type": "string", "default": "", "placeholder": "Optional, e.g. 404,302"},
        "exclude_lengths": {"type": "string", "default": "", "placeholder": "Optional exact lengths/ranges, e.g. 1234,2000-2010"},
        "length_tolerance": {"type": "integer", "default": 0},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "include_preview": {"type": "boolean", "default": False},
        "preview_chars": {"type": "integer", "default": 200},
    }, is_async=True),
    _tool("httpx.probe", "HTTPX", "HTTP probe", "httpx", "Bounded multi-target/path HTTPX-style metadata, match, and transport evidence.", httpx_engine.probe, {
        "targets": {"type": "string", "required": True, "widget": "textarea", "placeholder": "One URL or host per line or comma-separated"},
        "paths": {"type": "string", "default": "/", "widget": "textarea", "placeholder": "One path per line or comma-separated"},
        "method": {"type": "string", "default": "GET", "enum": ["GET", "HEAD", "OPTIONS", "POST", "PUT", "PATCH", "DELETE"]},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "body": {"type": "string", "default": "", "widget": "textarea"},
        "max_targets": {"type": "integer", "default": 20},
        "max_requests": {"type": "integer", "default": 40},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "fallback_http": {"type": "boolean", "default": True},
        "status_codes": {"type": "string", "default": "", "placeholder": "Optional comma-separated match statuses"},
        "match_strings": {"type": "string", "default": "", "widget": "textarea", "placeholder": "All listed strings must occur in the response"},
        "include_preview": {"type": "boolean", "default": False},
        "preview_chars": {"type": "integer", "default": 500},
    }, is_async=True),
    _tool("tech.fingerprint", "Tech", "Fingerprint", "wappalyzer", "Tech from headers+body.", tech_engine.fingerprint_headers_body, {
        "headers": {"type": "string", "default": "", "widget": "textarea"},
        "body": {"type": "string", "required": True, "widget": "textarea"},
    }),
    _tool("favicon.hash", "Favicon", "Favicon hash", "Shodan favicon MMH3", "Bounded favicon discovery and MMH3 hashing with candidate controls, retries/routes, redacted evidence, and explicit byte-fidelity status.", favicon_engine.hash_url, {
        "url": {"type": "string", "required": True},
        "favicon_url": {"type": "string", "default": ""},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "max_candidates": {"type": "integer", "default": 5},
        "expected_statuses": {"type": "string", "default": "200"},
        "include_response_body": {"type": "boolean", "default": False},
        "preview_chars": {"type": "integer", "default": 400},
        "include_headers": {"type": "boolean", "default": False},
        "hash_all": {"type": "boolean", "default": False},
    }, is_async=True),
    _tool("headerfuzz.fuzz", "HeaderFuzz", "Secure header audit", "OWASP Secure Headers", "Bounded observed HTTP response-header audit with contextual policy findings and route evidence.", headerfuzz_engine.fuzz, {
        "url": {"type": "string", "required": True},
        "paths": {"type": "string", "default": "/", "widget": "textarea", "placeholder": "One optional path per line or comma-separated"},
        "max_tests": {"type": "integer", "default": 18},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "stop_on_issue": {"type": "boolean", "default": False},
        "include_headers": {"type": "boolean", "default": False},
    }, is_async=True),
    _tool("internetdb.lookup", "InternetDB", "Shodan InternetDB", "internetdb.shodan.io", "Bounded InternetDB lookup with optional host resolution, provider override, retries/routes, redacted evidence, and normalized JSON fields.", internetdb_engine.lookup_host, {
        "ip": {"type": "string", "required": False},
        "host": {"type": "string", "required": False},
        "resolve_host": {"type": "boolean", "default": True},
        "service_base": {"type": "string", "default": "https://internetdb.shodan.io"},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "include_response_body": {"type": "boolean", "default": False},
        "preview_chars": {"type": "integer", "default": 400},
        "include_headers": {"type": "boolean", "default": False},
        "max_vulns": {"type": "integer", "default": 200},
    }, is_async=True),

    # ---- SQLMAP ----
    _tool("sqlmap.payloads", "SQLMap", "List payloads", "sqlmap --technique", "BEUSTQ corpus from sqlmap XML.", sqlmap_tool.list_payloads, {
        "techniques": {"type": "string", "default": "error_based,boolean_blind"},
        "level": {"type": "integer", "default": 1},
        "risk": {"type": "integer", "default": 1},
        "limit": {"type": "integer", "default": 30},
        "search": {"type": "string", "default": ""},
        "offset": {"type": "integer", "default": 0},
        "include_vectors": {"type": "boolean", "default": True},
    }),
    _tool("sqlmap.tampers", "SQLMap", "List tampers", "sqlmap --tamper", "Tamper catalog.", sqlmap_tool.list_tampers, {
        "search": {"type": "string", "default": ""},
        "offset": {"type": "integer", "default": 0},
        "limit": {"type": "integer", "default": 200},
        "include_errors": {"type": "boolean", "default": True},
        "include_metadata": {"type": "boolean", "default": True},
    }),
    _tool("sqlmap.tamper", "SQLMap", "Apply tampers", "sqlmap --tamper", "Chain tampers.", sqlmap_tool.tamper, {
        "payload": {"type": "string", "required": True, "widget": "textarea"},
        "scripts": {"type": "string", "default": "space2comment,randomcase"},
        "strict": {"type": "boolean", "default": False},
        "stop_on_error": {"type": "boolean", "default": False},
        "seed": {"type": "integer", "default": 0},
        "max_length": {"type": "integer", "default": 20000},
    }),
    _tool("sqlmap.fingerprint", "SQLMap", "Fingerprint", "sqlmap DBMS/WAF", "DBMS+WAF from errors.", sqlmap_tool.fingerprint_errors, {
        "body": {"type": "string", "required": True, "widget": "textarea"},
        "headers": {"type": "string", "default": "", "widget": "textarea"},
        "status": {"type": "integer", "default": 0},
        "dbms_filter": {"type": "string", "default": ""},
        "waf_filter": {"type": "string", "default": ""},
        "max_evidence": {"type": "integer", "default": 5},
        "redact_evidence": {"type": "boolean", "default": True},
    }),
    _tool("sqlmap.discover", "SQLMap", "Discover points", "sqlmap -p", "Injection points.", sqlmap_tool.discover_points, {
        "url": {"type": "string", "required": True},
        "data": {"type": "string", "default": "", "widget": "textarea"},
        "cookie": {"type": "string", "default": ""},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header values are supplied by the caller"},
        "places": {"type": "string", "default": "GET,POST,COOKIE,UA,REFERER,HOST,HEADER,JSON"},
        "parameter_include": {"type": "string", "default": ""},
        "parameter_exclude": {"type": "string", "default": ""},
        "max_points": {"type": "integer", "default": 100},
        "redact_values": {"type": "boolean", "default": True},
    }),
    _tool("sqlmap.query", "SQLMap", "Enum query", "sqlmap queries", "Banner/users/dbs SQL.", sqlmap_tool.get_query, {
        "dbms": {"type": "string", "default": "MySQL"},
        "name": {"type": "string", "default": "banner"},
        "db": {"type": "string", "default": "mysql"},
        "table": {"type": "string", "default": "users"},
        "col": {"type": "string", "default": "id"},
        "query": {"type": "string", "default": "SELECT VERSION()"},
        "offset": {"type": "integer", "default": 0},
        "max_sql_chars": {"type": "integer", "default": 2000},
        "include_template": {"type": "boolean", "default": True},
        "safe_mode": {"type": "boolean", "default": True},
    }),
    _tool("sqlmap.enum_plan", "SQLMap", "Enumeration plan", "sqlmap enum", "DBMS enumeration sequence.", sqlmap_tool.enum_plan, {
        "dbms": {"type": "string", "default": "MySQL"},
        "steps": {"type": "string", "default": ""},
        "include_sql": {"type": "boolean", "default": True},
        "max_steps": {"type": "integer", "default": 30},
    }),
    _tool("sqlmap.scan", "SQLMap", "Live scan", "sqlmap -u", "Multi-technique SQLi (real sqlmap corpus).", sqlmap_tool.scan, {
        "url": {"type": "string", "required": True},
        "parameter": {"type": "string", "default": ""},
        "method": {"type": "string", "default": "GET"},
        "data": {"type": "string", "default": "", "widget": "textarea"},
        "techniques": {"type": "string", "default": "BEUSTQ"},
        "level": {"type": "integer", "default": 1},
        "risk": {"type": "integer", "default": 1},
        "dbms": {"type": "string", "default": ""},
        "sleeptime": {"type": "integer", "default": 3},
        "max_tests": {"type": "integer", "default": 40},
        "user_agent": {"type": "string", "default": "pyodide-security/sqlmap/1.0"},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "cookie": {"type": "string", "default": ""},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "tamper_scripts": {"type": "string", "default": "", "placeholder": "space2comment,randomcase"},
        "parameter_include": {"type": "string", "default": ""},
        "parameter_exclude": {"type": "string", "default": ""},
        "comparison": {"type": "string", "default": "auto", "enum": ["auto", "lengths", "text-only", "titles"]},
        "string_match": {"type": "string", "default": ""},
        "not_string": {"type": "string", "default": ""},
        "status_match": {"type": "integer", "default": 0},
        "include_attempts": {"type": "boolean", "default": True},
        "include_response_body": {"type": "boolean", "default": False},
        "preview_chars": {"type": "integer", "default": 400},
        "raw_request": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Optional raw HTTP request template"},
        "dry_run": {"type": "boolean", "default": False},
        "session_id": {"type": "string", "default": ""},
        "data_type": {"type": "string", "default": "form", "enum": ["form", "json", "multipart"]},
    }, is_async=True),

    # ---- XSS / INJECT / SSTI / CRLF / CORS / REDIRECT / SMUGGLE ----
    _tool("xss.payloads", "XSS", "List payloads", "dalfox", "XSS corpus.", xss_engine.list_payloads, {
        "context": {"type": "string", "default": ""},
        "risk": {"type": "integer", "default": 3},
    }),
    _tool("xss.scan", "XSS", "Reflection scan", "dalfox -u", "Live XSS canaries.", xss_engine.scan, {
        "url": {"type": "string", "required": True},
        "parameter": {"type": "string", "default": ""},
        "context": {"type": "string", "default": ""},
        "risk": {"type": "integer", "default": 1},
        "max_payloads": {"type": "integer", "default": 10},
        "min_efficiency": {"type": "integer", "default": 50},
        "method": {"type": "string", "default": "GET", "enum": ["GET", "POST", "PUT", "PATCH"]},
        "headers": {"type": "string", "default": "", "widget": "textarea"},
        "body": {"type": "string", "default": "", "widget": "textarea"},
        "data_type": {"type": "string", "default": "query", "enum": ["query", "form", "json"]},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "include_attempts": {"type": "boolean", "default": True},
        "stop_on_first": {"type": "boolean", "default": False},
    }, is_async=True),
    _tool("inject.payloads", "Inject", "List payloads", "LFI/SSTI/SSRF/XXE", "Non-SQLi corpora.", inject_engine.list_payloads, {
        "family": {"type": "string", "default": "all", "enum": ["all", "lfi", "ssti", "ssrf", "xxe", "cmdi", "crlf", "open_redirect"]},
    }),
    _tool("inject.scan", "Inject", "Live inject scan", "LFI/SSTI/CMDi", "Family probes.", inject_engine.scan, {
        "url": {"type": "string", "required": True},
        "parameter": {"type": "string", "default": ""},
        "family": {"type": "string", "default": "lfi", "enum": ["lfi", "ssti", "cmdi"]},
        "max_payloads": {"type": "integer", "default": 10},
    }, is_async=True),
    _tool("ssti.scan", "SSTI", "SSTI scan", "tplmap", "Multi-engine SSTI canaries.", ssti_engine.scan, {
        "url": {"type": "string", "required": True},
        "parameter": {"type": "string", "default": ""},
        "max_payloads": {"type": "integer", "default": 10},
    }, is_async=True),
    _tool("crlf.scan", "CRLF", "CRLF inject", "crlfuzz", "Bounded CRLF response-splitting probes with placements, retries/routes, baseline and safe evidence.", crlf_engine.scan, {
        "url": {"type": "string", "required": True},
        "max_tests": {"type": "integer", "default": 0},
        "max_variants": {"type": "integer", "default": 3},
        "user_agent": {"type": "string", "default": "pyodide-security/crlf-engine/2.0"},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "parameters": {"type": "string", "default": "", "placeholder": "Optional comma-separated query parameters"},
        "placements": {"type": "string", "default": "query,path", "placeholder": "query,path"},
        "include_tests": {"type": "boolean", "default": True},
        "include_body_echo": {"type": "boolean", "default": True},
        "preview_chars": {"type": "integer", "default": 200},
    }, is_async=True),
    _tool("cors.scan", "CORS", "CORS scan", "corsy", "Bounded CORScanner-style origin checks with shared headers, retry/route and safe evidence.", cors_engine.scan, {
        "url": {"type": "string", "required": True},
        "max_tests": {"type": "integer", "default": 0},
        "user_agent": {"type": "string", "default": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5) AppleWebKit/537.36"},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "custom_origins": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Optional origins, one per line or comma-separated"},
        "include_third_parties": {"type": "boolean", "default": True},
        "include_special_chars": {"type": "boolean", "default": True},
        "stop_on_first": {"type": "boolean", "default": False},
        "include_tests": {"type": "boolean", "default": True},
    }, is_async=True),
    _tool("cors.list_probes", "CORS", "List origin probes", "corsy", "Built-in CORS origin probe list.", cors_engine.list_probes, {
        "host": {"type": "string", "default": "example.com"},
    }),

    _tool("redirect.scan", "Redirect", "Open redirect", "openredirex", "Bounded browser-adapted open-redirect testing with query/body placements, payload controls, retries/routes, redacted request evidence, and confirmation markers.", redirect_engine.scan, {
        "url": {"type": "string", "required": True},
        "parameters": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Parameter names, one per line or comma-separated"},
        "max_params": {"type": "integer", "default": 8},
        "max_dests": {"type": "integer", "default": 4},
        "max_tests": {"type": "integer", "default": 0},
        "method": {"type": "string", "default": "GET", "enum": ["GET", "POST", "HEAD", "OPTIONS"]},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "body": {"type": "string", "default": "", "widget": "textarea"},
        "placement": {"type": "string", "default": "query", "enum": ["query", "body", "both"]},
        "custom_destinations": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Destination payloads, one per line or comma-separated"},
        "include_corpus": {"type": "boolean", "default": False},
        "status_codes": {"type": "string", "default": "200-399"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "include_response_body": {"type": "boolean", "default": False},
        "preview_chars": {"type": "integer", "default": 400},
        "include_attempts": {"type": "boolean", "default": False},
        "stop_on_finding": {"type": "boolean", "default": False},
    }, is_async=True),
    _tool("smuggle.detect", "Smuggle", "Desync detect", "smuggler", "CL.TE/TE.CL heuristics.", smuggle_engine.detect, {
        "url": {"type": "string", "required": True},
        "techniques": {"type": "string", "default": "CL.TE,TE.CL,TE.TE,CL.CL"},
        "max_payloads": {"type": "integer", "default": 10},
        "max_tests": {"type": "integer", "default": 0},
        "timeout_ms": {"type": "integer", "default": 10000},
    }, is_async=True),
    _tool("smuggle.list_payloads", "Smuggle", "List payloads", "smuggler.py", "Smuggling payload corpus + capability matrix.", smuggle_engine.list_payloads, {
        "host": {"type": "string", "default": "localhost"},
    }),

    _tool("smuggle.payloads", "Smuggle", "Smuggle payloads", "smuggler", "Payload samples + capability matrix.", smuggle_engine.list_payloads, {"host": {"type": "string", "default": "localhost"}}),

    # ---- NMAP ----
    _tool("nmap.top_ports", "Nmap", "Top ports", "nmap --top-ports", "Port database.", nmap_tool.top_ports, {"limit": {"type": "integer", "default": 50}}),
    _tool("nmap.services", "Nmap", "All services", "nmap-services", "Service map.", nmap_tool.all_services, {}),
    _tool("nmap.parse", "Nmap", "Parse output", "nmap -oX/-oG/-oN", "Parse nmap formats.", nmap_tool.parse, {
        "output": {"type": "string", "required": True, "widget": "textarea"},
    }),
    _tool("nmap.http_probe", "Nmap", "HTTP probe", "nmap -sV HTTP", "HTTP(S) connect probe.", nmap_tool.http_probe, {
        "host": {"type": "string", "required": True},
        "ports": {"type": "string", "default": "80,443,8080,8443,8000,8888,3000,5000"},
        "path": {"type": "string", "default": "/"},
        "top": {"type": "integer", "default": 0},
    }, is_async=True),
    _tool("nmap.nse_http", "Nmap", "NSE http", "nmap --script http-*", "HTTP NSE suite.", nmap_tool.nse_http, {
        "url": {"type": "string", "required": True},
        "scripts": {"type": "string", "default": "default"},
    }, is_async=True),

    # ---- CRAWL / JS / WAYBACK ----
    _tool("katana.extract", "Katana", "Extract HTML", "katana parse", "Links/forms/scripts.", katana_tool.extract, {
        "html": {"type": "string", "required": True, "widget": "textarea"},
        "base_url": {"type": "string", "required": True},
    }),
    _tool("katana.extract_js", "Katana", "Extract JS", "katana JS", "Endpoints from JS.", katana_tool.extract_js, {
        "js_text": {"type": "string", "required": True, "widget": "textarea"},
        "base_url": {"type": "string", "required": True},
    }),
    _tool("katana.crawl", "Katana", "Live crawl", "katana -u", "Depth crawl.", katana_tool.crawl, {
        "url": {"type": "string", "required": True},
        "depth": {"type": "integer", "default": 2},
        "max_urls": {"type": "integer", "default": 35},
        "include_subdomains": {"type": "boolean", "default": False},
        "parse_js": {"type": "boolean", "default": True},
    }, is_async=True),
    _tool("wayback.collect", "Wayback", "Collect URLs", "waybackurls / CDX", "Bounded Wayback CDX URL history with scope, filters, continuation and request evidence.", wayback_engine.collect, {
        "domain": {"type": "string", "required": True},
        "limit": {"type": "integer", "default": 150},
        "match_type": {"type": "string", "default": "domain", "enum": ["exact", "prefix", "host", "domain"]},
        "collapse": {"type": "boolean", "default": True},
        "include_subdomains": {"type": "boolean", "default": True},
        "date_from": {"type": "string", "default": "", "placeholder": "CDX timestamp or year, e.g. 2020"},
        "date_to": {"type": "string", "default": "", "placeholder": "CDX timestamp or year, e.g. 2021"},
        "filters": {"type": "string", "default": "", "widget": "textarea", "placeholder": "One CDX filter per line, e.g. !statuscode:404"},
        "status_codes": {"type": "string", "default": "", "placeholder": "Optional comma-separated CDX status codes"},
        "mimetypes": {"type": "string", "default": "", "placeholder": "Optional comma-separated MIME types"},
        "offset": {"type": "integer", "default": 0},
        "show_resume_key": {"type": "boolean", "default": False},
        "resume_key": {"type": "string", "default": ""},
        "service_base": {"type": "string", "default": "https://web.archive.org/cdx/search/cdx"},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 20000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
    _tool("jsrecon.analyze", "JSRecon", "JS analyze", "LinkFinder + gitleaks", "Bounded JavaScript discovery, endpoint extraction and safe gitleaks-rule analysis through Goar.", jsrecon_engine.analyze, {
        "url": {"type": "string", "required": True},
        "max_scripts": {"type": "integer", "default": 10},
        "scan_secrets": {"type": "boolean", "default": True},
        "user_agent": {"type": "string", "default": "pyodide-security/gitleaks/1.0"},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "discover_scripts": {"type": "boolean", "default": True},
        "max_endpoints": {"type": "integer", "default": 100},
        "endpoint_regex": {"type": "string", "default": ""},
        "max_body_chars": {"type": "integer", "default": 300000},
        "include_bodies": {"type": "boolean", "default": False},
        "preview_chars": {"type": "integer", "default": 1000},
        "redact_secrets": {"type": "boolean", "default": True},
    }, is_async=True),

    # ---- SUBENUM / TAKEOVER / DNS / RDAP / EMAIL ----
    _tool("subenum.sources", "Subenum", "List sources", "subfinder -ls", "Passive sources.", subenum_tool.list_sources, {}),
    _tool("subenum.crtsh", "Subenum", "crt.sh", "subfinder/crtsh", "Passive certificate-transparency enumeration with certificate evidence.", subenum_tool.crtsh, {
        "domain": {"type": "string", "required": True},
        "service_base": {"type": "string", "default": "https://crt.sh"},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "max_results": {"type": "integer", "default": 5000},
        "include_wildcards": {"type": "boolean", "default": False},
    }, is_async=True),
    _tool("subenum.doh", "Subenum", "DoH resolve", "dnsx", "DNS-over-HTTPS.", subenum_tool.doh_resolve, {
        "name": {"type": "string", "required": True},
        "record_type": {"type": "string", "default": "A"},
        "provider": {"type": "string", "default": "cloudflare", "enum": ["cloudflare", "google", "quad9"]},
    }, is_async=True),
    _tool("subenum.brute", "Subenum", "DoH brute", "puredns", "Bounded wordlist brute through the shared DoH route with normalized DNS evidence.", subenum_tool.brute, {
        "domain": {"type": "string", "required": True},
        "wordlist": {"type": "string", "default": "", "widget": "textarea"},
        "max_words": {"type": "integer", "default": 50},
        "record_type": {"type": "string", "default": "A"},
        "provider": {"type": "string", "default": "cloudflare", "enum": ["cloudflare", "google", "quad9"]},
        "service_base": {"type": "string", "default": ""},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
    _tool("subenum.mutate", "Subenum", "Permutations", "altdns", "Label permutations.", subenum_tool.mutate, {
        "subdomains": {"type": "string", "required": True, "widget": "textarea"},
        "domain": {"type": "string", "default": ""},
    }),
    _tool("subenum.enumerate", "Subenum", "Full enum", "subfinder", "All sources + optional brute.", subenum_tool.enumerate, {
        "domain": {"type": "string", "required": True},
        "sources": {"type": "string", "default": "all"},
        "use_brute": {"type": "boolean", "default": False},
        "resolve": {"type": "boolean", "default": True},
        "max_words": {"type": "integer", "default": 25},
        "provider": {"type": "string", "default": "cloudflare"},
    }, is_async=True),
    _tool("takeover.check", "Takeover", "Check takeover", "subjack", "CNAME and HTTP fingerprint takeover check with shared route evidence.", takeover_engine.check, {
        "host": {"type": "string", "required": True},
        "cname": {"type": "string", "default": ""},
        "schemes": {"type": "string", "default": "https,http"},
        "provider": {"type": "string", "default": "cloudflare", "enum": ["cloudflare", "google", "quad9"]},
        "resolve_cname": {"type": "boolean", "default": True},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
    _tool("takeover.check_many", "Takeover", "Bulk check", "subjack", "Bounded multi-host CNAME and HTTP fingerprint check.", takeover_engine.check_many, {
        "hosts": {"type": "string", "required": True, "widget": "textarea"},
        "max_hosts": {"type": "integer", "default": 20},
        "provider": {"type": "string", "default": "cloudflare", "enum": ["cloudflare", "google", "quad9"]},
        "schemes": {"type": "string", "default": "https,http"},
        "headers": {"type": "string", "default": "", "widget": "textarea"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),

    _tool("takeover.list", "Takeover", "List fingerprints", "subjack fingerprints", "Takeover signatures.", takeover_engine.list_fingerprints, {}),
    _tool("dns.resolve", "DNS", "Resolve all", "dnsx", "Multi-type DoH with normalized answer, authority, retry, and route evidence.", dns_engine.resolve_all, {
        "name": {"type": "string", "required": True},
        "types": {"type": "string", "default": "A,AAAA,CNAME,MX,NS,TXT,SOA,CAA"},
        "provider": {"type": "string", "default": "cloudflare", "enum": ["cloudflare", "google", "quad9"]},
        "service_base": {"type": "string", "default": ""},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
    _tool("dns.info", "DNS", "Domain info", "dnsrecon", "A/MX/NS/TXT DoH summary with shared provider evidence.", dns_engine.domain_info, {
        "domain": {"type": "string", "required": True},
        "provider": {"type": "string", "default": "cloudflare", "enum": ["cloudflare", "google", "quad9"]},
        "service_base": {"type": "string", "default": ""},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
    _tool("dns.reverse", "DNS", "Reverse PTR", "dig -x", "IPv4 PTR via DoH with shared provider evidence.", dns_engine.reverse_lookup, {
        "ip": {"type": "string", "required": True},
        "provider": {"type": "string", "default": "cloudflare", "enum": ["cloudflare", "google", "quad9"]},
        "service_base": {"type": "string", "default": ""},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
    _tool("emailsec.check", "EmailSec", "Email security", "checkdmarc", "SPF, DMARC and bounded DKIM discovery through the shared DoH route.", emailsec_engine.check, {
        "domain": {"type": "string", "required": True},
        "provider": {"type": "string", "default": "cloudflare", "enum": ["cloudflare", "google", "quad9"]},
        "max_tests": {"type": "integer", "default": 0},
        "timeout_ms": {"type": "integer", "default": 7000},
        "service_base": {"type": "string", "default": ""},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "selectors": {"type": "string", "default": "default,google,selector1,selector2,k1,s1,s2,dkim,mail,smtp"},
        "max_selectors": {"type": "integer", "default": 10},
    }, is_async=True),
    _tool("rdap.domain", "RDAP", "Domain RDAP", "RDAP RFC 9082", "Domain registration lookup with standard RDAP route, summary and full response evidence.", rdap_engine.domain_rdap, {
        "domain": {"type": "string", "required": True},
        "service_base": {"type": "string", "default": "https://rdap.org"},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
    _tool("rdap.ip", "RDAP", "IP RDAP", "RDAP RFC 9082", "IP network registration lookup with standard RDAP route, summary and full response evidence.", rdap_engine.ip_rdap, {
        "ip": {"type": "string", "required": True},
        "service_base": {"type": "string", "default": "https://rdap.org"},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),

    # ---- PARAM / WAF / WP / CLOUD / COOKIE / GRAPHQL ----
    _tool("param.list", "Param", "List common params", "arjun wordlist", "Common parameter wordlist.", param_engine.list_common, {
        "limit": {"type": "integer", "default": 0},
    }),
    _tool("param.discover", "Param", "Discover params", "arjun", "Bounded hidden-parameter discovery with GET, form, JSON, or XML request modes.", param_engine.discover, {
        "url": {"type": "string", "required": True},
        "wordlist": {"type": "string", "default": "", "widget": "textarea", "placeholder": "small, medium, large, or custom candidates"},
        "max_params": {"type": "integer", "default": 30},
        "max_tests": {"type": "integer", "default": 0},
        "method": {"type": "string", "default": "GET", "enum": ["GET", "POST", "POST-JSON", "POST-XML"]},
        "chunk_size": {"type": "integer", "default": 25},
        "max_chunks": {"type": "integer", "default": 4},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
    _tool("waf.detect", "WAF", "Detect WAF", "wafw00f", "Bounded wafw00f-style normal/active plugin fingerprinting with shared transport evidence.", waf_engine.detect, {
        "url": {"type": "string", "required": True},
        "findall": {"type": "boolean", "default": True},
        "active": {"type": "boolean", "default": True},
        "user_agent": {"type": "string", "default": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:130.0) Gecko/20100101 Firefox/130.0"},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "active_vectors": {"type": "string", "default": "xss,sqli,lfi", "placeholder": "xss,sqli,lfi,rce,xxe"},
        "include_attempts": {"type": "boolean", "default": True},
        "max_plugins": {"type": "integer", "default": 0},
    }, is_async=True),
    _tool("waf.bypass", "WAF", "Bypass variants", "waf transforms", "Payload mutations.", waf_engine.bypass_payloads, {
        "payload": {"type": "string", "required": True, "widget": "textarea"},
    }),
    _tool("wpscan.scan", "WPScan", "WordPress scan", "wpscan", "Users/plugins/xmlrpc/leaks.", wpscan_engine.scan, {
        "url": {"type": "string", "required": True},
        "max_paths": {"type": "integer", "default": 12},
        "max_plugins": {"type": "integer", "default": 8},
        "max_themes": {"type": "integer", "default": 4},
        "max_tests": {"type": "integer", "default": 0},
    }, is_async=True),
    _tool("cloud.bucket", "Cloud", "Check bucket", "S3Scanner / cloud_enum", "Bounded S3/GCS/Azure bucket check with direct-route evidence.", cloud_engine.check_bucket, {
        "name": {"type": "string", "required": False},
        "url": {"type": "string", "default": ""},
        "providers": {"type": "string", "default": "aws,azure,gcp"},
        "max_checks": {"type": "integer", "default": 12},
        "max_tests": {"type": "integer", "default": 0},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
    _tool("cloud.permute", "Cloud", "Bucket permute", "cloud_enum", "Bounded local cloud_enum-compatible bucket permutations; no network requests.", cloud_engine.permute_buckets, {
        "name": {"type": "string", "required": True},
        "max_mutations": {"type": "integer", "default": 50},
        "keywords": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Additional local keywords, one per line or comma-separated"},
        "mutation_words": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Optional local mutation words, one per line or comma-separated"},
        "strategy": {"type": "string", "default": "legacy", "enum": ["legacy", "upstream"]},
    }, is_async=True),
    _tool("cookie.scan", "Cookie", "Cookie security", "RFC 6265bis audit", "Bounded Set-Cookie security audit with prefix, scope, SameSite, and route evidence; cookie values are redacted.", cookie_engine.scan_url, {
        "url": {"type": "string", "required": True},
        "paths": {"type": "string", "default": "/", "widget": "textarea", "placeholder": "One optional path per line or comma-separated"},
        "max_paths": {"type": "integer", "default": 3},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "stop_on_cookie": {"type": "boolean", "default": False},
    }, is_async=True),
    _tool("cookie.analyze", "Cookie", "Analyze Set-Cookie", "cookie audit offline", "Offline Set-Cookie parse.", cookie_engine.analyze_header_block, {
        "headers": {"type": "string", "required": True, "widget": "textarea"},
    }),
    _tool("graphql.introspect", "GraphQL", "Introspect", "inql", "Full standard GraphQL schema introspection with explicit disabled/error evidence.", graphql_engine.introspect, {
        "url": {"type": "string", "required": True},
        "method": {"type": "string", "default": "POST", "enum": ["POST", "GET"]},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "include_schema": {"type": "boolean", "default": True},
    }, is_async=True),
    _tool("graphql.query", "GraphQL", "Query", "GraphQLmap", "Send GraphQL query or mutation with variables, operation name and full response evidence.", graphql_engine.query, {
        "url": {"type": "string", "required": True},
        "gql": {"type": "string", "required": True, "widget": "textarea", "default": "{ __typename }"},
        "variables": {"type": "string", "default": "{}", "widget": "textarea"},
        "operation_name": {"type": "string", "default": ""},
        "method": {"type": "string", "default": "POST", "enum": ["POST", "GET"]},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "batch_count": {"type": "integer", "default": 0},
    }, is_async=True),

    # ---- YARA ----
    _tool("yara.rules", "YARA", "List rules", "yara -L", "Filterable portable YARA rule catalog.", yara_engine.list_rules, {"tags": {"type": "string", "default": "", "placeholder": "Optional comma-separated tags"}}),
    _tool("yara.scan", "YARA", "Scan text", "yara", "Portable YARA text/regex/hex rules with common conditions and structured reports.", yara_engine.scan, {
        "text": {"type": "string", "required": True, "widget": "textarea"},
        "tags": {"type": "string", "default": "", "placeholder": "Optional comma-separated tags"},
        "rule_source": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Optional YARA rule source"},
        "include_builtin": {"type": "boolean", "default": True},
        "max_hits": {"type": "integer", "default": 50},
        "include_context": {"type": "boolean", "default": True},
        "report_format": {"type": "string", "default": "json", "placeholder": "json or sarif"},
        "source_name": {"type": "string", "default": "inline"},
    }),

    # ---- CRYPTO / UTILS ----
    _tool("hash.digest", "Hash", "Digest", "openssl dgst", "Hash digests.", hash_tool.digest, {
        "data": {"type": "string", "required": True, "widget": "textarea"},
        "algorithm": {"type": "string", "default": "sha256", "enum": hash_tool.ALGORITHMS},
        "encoding": {"type": "string", "default": "utf-8", "enum": ["utf-8", "hex", "base64"]},
    }),
    _tool("hash.multi", "Hash", "Multi-hash", "sha*sum", "All digests.", hash_tool.multi, {
        "data": {"type": "string", "required": True, "widget": "textarea"},
    }),
    _tool("hash.hmac", "Hash", "HMAC", "openssl dgst -hmac", "HMAC.", hash_tool.hmac_digest, {
        "data": {"type": "string", "required": True, "widget": "textarea"},
        "key": {"type": "string", "required": True},
        "algorithm": {"type": "string", "default": "sha256"},
    }),
    _tool("hashid.identify", "Hash", "Identify hash", "hashid", "Identify hash types.", hashid_tool.identify, {
        "hash_value": {"type": "string", "required": True, "widget": "textarea"},
    }),
    _tool("crack.hash", "Crack", "Dictionary crack", "john / hashcat", "Offline crack.", crack_tool.crack, {
        "target_hash": {"type": "string", "required": True},
        "wordlist": {"type": "string", "required": True, "widget": "textarea"},
        "mode": {"type": "string", "default": "md5", "enum": ["md5", "md4", "sha1", "sha256", "sha512", "ntlm", "hmac-sha256"]},
        "rules": {"type": "boolean", "default": True},
        "max_candidates": {"type": "integer", "default": 20000},
    }),
    _tool("jwt.inspect", "JWT", "Inspect", "jwt_tool", "Decode JWT.", jwt_tool.inspect, {
        "token": {"type": "string", "required": True, "widget": "textarea"},
    }),
    _tool("jwt.verify", "JWT", "Verify HMAC", "jose", "Verify HS*.", jwt_tool.verify_hmac, {
        "token": {"type": "string", "required": True, "widget": "textarea"},
        "secret": {"type": "string", "required": True},
    }),
    _tool("jwt.crack", "JWT", "Crack HS secret", "jwt_tool -C", "Brute HS secret.", jwt_tool.crack, {
        "token": {"type": "string", "required": True, "widget": "textarea"},
        "wordlist": {"type": "string", "required": True, "widget": "textarea"},
    }),
    _tool("jwt.verify_asymmetric", "JWT", "Verify RS/ES", "cryptography", "Verify RS256/ES256 with PEM public key (needs simd.ensure).", jwt_tool.verify_asymmetric, {
        "token": {"type": "string", "required": True},
        "public_key_pem": {"type": "string", "required": True, "widget": "textarea"},
    }),
    _tool("jwt.crypto_status", "JWT", "Crypto backend", "cryptography", "Whether SIMD cryptography is loaded for JWT.", jwt_tool.crypto_status, {}),

    _tool("jwt.forge_none", "JWT", "Forge alg=none", "jwt_tool none", "Unsigned token.", jwt_tool.forge_none, {
        "payload_json": {"type": "string", "required": True, "widget": "textarea", "default": '{"sub":"test","role":"admin"}'},
    }),
    _tool("cipher.encrypt", "Cipher", "Encrypt", "openssl enc", "AES-256-CTR+HMAC.", cipher_tool.encrypt, {
        "plaintext": {"type": "string", "required": True, "widget": "textarea"},
        "password": {"type": "string", "required": True},
        "iterations": {"type": "integer", "default": 120000},
    }),
    _tool("cipher.decrypt", "Cipher", "Decrypt", "openssl enc -d", "Decrypt PSEC.", cipher_tool.decrypt, {
        "payload": {"type": "string", "required": True, "widget": "textarea"},
        "password": {"type": "string", "required": True},
    }),
    _tool("x509.parse", "X.509", "Parse cert", "openssl x509", "Parse PEM cert.", x509_tool.parse, {
        "pem": {"type": "string", "required": True, "widget": "textarea"},
    }),
    _tool("secrets.scan", "Secrets", "Scan secrets", "gitleaks", "Gitleaks-compatible portable secret scan with configurable rules, source fetch, baseline, decode and reports.", secrets_tool.scan, {
        "text": {"type": "string", "default": "", "widget": "textarea"},
        "min_entropy": {"type": "number", "default": 3.5},
        "source_url": {"type": "string", "default": "", "placeholder": "Optional remote source URL via Goar transport"},
        "headers_json": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Optional JSON headers for source_url"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "max_source_bytes": {"type": "integer", "default": 1000000},
        "include_default_rules": {"type": "boolean", "default": True},
        "rules_json": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Optional custom rule JSON"},
        "allowlist": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Optional allowlist regexes, one per line"},
        "baseline_json": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Optional prior findings JSON"},
        "decode_depth": {"type": "integer", "default": 0},
        "redact": {"type": "boolean", "default": True},
        "report_format": {"type": "string", "default": "json", "placeholder": "json, sarif, or csv"},
    }),
    _tool("otp.totp", "OTP", "TOTP", "oathtool --totp", "RFC 6238.", otp_tool.totp, {
        "secret": {"type": "string", "required": True},
        "digits": {"type": "integer", "default": 6},
        "period": {"type": "integer", "default": 30},
    }),
    _tool("otp.hotp", "OTP", "HOTP", "oathtool --hotp", "RFC 4226.", otp_tool.hotp, {
        "secret": {"type": "string", "required": True},
        "counter": {"type": "integer", "required": True},
    }),
    _tool("otp.verify", "OTP", "Verify TOTP", "oathtool -w", "Verify window.", otp_tool.verify_totp, {
        "secret": {"type": "string", "required": True},
        "code": {"type": "string", "required": True},
        "window": {"type": "integer", "default": 1},
    }),
    _tool("otp.new", "OTP", "New secret", "oathtool keygen", "New base32 secret.", otp_tool.new_secret, {
        "issuer": {"type": "string", "default": "PyodideSec"},
        "account": {"type": "string", "default": "user@example.com"},
    }),
    _tool("headers.analyze", "HTTP", "Security headers", "securityheaders", "Header score.", headers_tool.analyze, {
        "headers": {"type": "string", "required": True, "widget": "textarea"},
    }),
    _tool("password.generate", "Password", "Generate", "pwgen", "CSPRNG passwords.", password_tool.generate, {
        "length": {"type": "integer", "default": 20},
        "count": {"type": "integer", "default": 5},
        "symbols": {"type": "boolean", "default": True},
    }),
    _tool("password.passphrase", "Password", "Passphrase", "diceware", "Word passphrase.", password_tool.passphrase, {
        "words": {"type": "integer", "default": 6},
    }),
    _tool("password.analyze", "Password", "Analyze", "zxcvbn", "Strength analysis.", password_tool.analyze, {
        "password": {"type": "string", "required": True},
    }),
    _tool("sast.scan", "SAST", "Python SAST", "bandit", "AST scan.", sast_tool.scan, {
        "code": {"type": "string", "required": True, "widget": "textarea"},
    }),
    _tool("codec.encode", "Codec", "Encode", "CyberChef", "Encode data.", codec_tool.encode, {
        "data": {"type": "string", "required": True, "widget": "textarea"},
        "format": {"type": "string", "default": "base64", "enum": codec_tool.ENCODE_FORMATS},
    }),
    _tool("codec.decode", "Codec", "Decode", "CyberChef", "Decode data.", codec_tool.decode, {
        "data": {"type": "string", "required": True, "widget": "textarea"},
        "format": {"type": "string", "default": "base64", "enum": codec_tool.DECODE_FORMATS},
    }),
    _tool("codec.detect", "Codec", "Detect chain", "CyberChef magic", "Peel encodings.", codec_tool.detect_chain, {
        "data": {"type": "string", "required": True, "widget": "textarea"},
    }),
    _tool("url.analyze", "URL", "URL risk", "urlscan heuristics", "URL risk score.", url_tool.analyze, {
        "url": {"type": "string", "required": True},
    }),
    _tool("redos.analyze", "ReDoS", "Regex risk", "static ReDoS", "Backtracking risk.", redos_tool.analyze, {
        "pattern": {"type": "string", "required": True, "widget": "textarea"},
    }),

    # ---- v6 MAX COVERAGE ----
    _tool("nosql.payloads", "NoSQL", "List payloads", "nosqli", "Mongo operator corpus.", nosql_engine.list_payloads, {}),
    _tool("nosql.scan", "NoSQL", "NoSQL scan", "nosqli", "Live NoSQL operator probes.", nosql_engine.scan, {
        "url": {"type": "string", "required": True},
        "parameter": {"type": "string", "default": ""},
        "max_payloads": {"type": "integer", "default": 10},
    }, is_async=True),
    _tool("pp.payloads", "ProtoPollution", "PP payloads", "ppmap", "Prototype pollution payloads.", proto_pollution_engine.list_payloads, {}),
    _tool("pp.detect", "ProtoPollution", "Detect in text", "static PP", "Find PP sinks/sources in code.", proto_pollution_engine.detect_in_text, {
        "text": {"type": "string", "required": True, "widget": "textarea"},
    }),
    _tool("pp.scan", "ProtoPollution", "PP scan", "ppmap", "Live prototype pollution probes.", proto_pollution_engine.scan, {
        "url": {"type": "string", "required": True},
        "parameter": {"type": "string", "default": ""},
        "techniques": {"type": "string", "default": "query,json"},
        "max_payloads": {"type": "integer", "default": 10},
    }, is_async=True),
    _tool("oauth.analyze", "OAuth", "Analyze auth URL", "OIDC / RFC 8414", "Bounded OIDC and OAuth metadata discovery with issuer/endpoint security evidence.", oauth_engine.analyze_auth_url, {
        "url": {"type": "string", "required": True},
        "include_openid": {"type": "boolean", "default": True},
        "include_oauth": {"type": "boolean", "default": True},
        "validate_issuer": {"type": "boolean", "default": True},
        "include_metadata": {"type": "boolean", "default": False},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
    _tool("oauth.oidc", "OAuth", "OIDC discovery", "OpenID Connect Discovery", "Bounded OpenID/OAuth metadata discovery with issuer, endpoint, PKCE, and request evidence.", oauth_engine.fetch_oidc, {
        "url": {"type": "string", "required": True},
        "include_openid": {"type": "boolean", "default": True},
        "include_oauth": {"type": "boolean", "default": True},
        "validate_issuer": {"type": "boolean", "default": True},
        "include_metadata": {"type": "boolean", "default": False},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
    _tool("csp.analyze", "CSP", "Analyze policy", "csp evaluator", "Offline CSP scoring.", csp_engine.analyze_policy, {
        "policy": {"type": "string", "required": True, "widget": "textarea"},
    }),
    _tool("csp.scan", "CSP", "CSP scan URL", "CSP evaluator", "Bounded enforced and report-only CSP collection with directive findings and route evidence.", csp_engine.scan_url, {
        "url": {"type": "string", "required": True},
        "paths": {"type": "string", "default": "/", "widget": "textarea", "placeholder": "One optional path per line or comma-separated"},
        "max_paths": {"type": "integer", "default": 3},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "stop_on_issue": {"type": "boolean", "default": False},
        "include_policies": {"type": "boolean", "default": True},
    }, is_async=True),
    _tool("clickjack.scan", "Clickjack", "Clickjack test", "OWASP clickjacking defense", "Bounded X-Frame-Options and enforced/report-only CSP frame-ancestors assessment with route evidence.", clickjack_engine.scan, {
        "url": {"type": "string", "required": True},
        "paths": {"type": "string", "default": "/", "widget": "textarea", "placeholder": "One optional path per line or comma-separated"},
        "max_paths": {"type": "integer", "default": 3},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "stop_on_exposure": {"type": "boolean", "default": False},
        "include_test_template": {"type": "boolean", "default": False},
    }, is_async=True),
    _tool("robots.scan", "Robots", "Robots/sitemap", "RFC 9309 / RFC 9116", "Bounded robots.txt, sitemap-reference, and security.txt collection with rule and route evidence.", robots_engine.scan, {
        "url": {"type": "string", "required": True},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "include_security_txt": {"type": "boolean", "default": True},
        "security_root_fallback": {"type": "boolean", "default": True},
        "include_sitemaps": {"type": "boolean", "default": True},
        "evaluate_path_value": {"type": "string", "default": "", "placeholder": "Optional path to evaluate against robots rules"},
        "agent": {"type": "string", "default": "*"},
        "include_raw": {"type": "boolean", "default": False},
    }, is_async=True),
    _tool("ct.search", "CT", "CT search", "crt.sh", "Certificate-transparency search with certificate metadata and shared Goar route evidence.", ct_engine.search, {
        "domain": {"type": "string", "required": True},
        "limit": {"type": "integer", "default": 200},
        "service_base": {"type": "string", "default": "https://crt.sh"},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "include_wildcards": {"type": "boolean", "default": False},
        "query_mode": {"type": "string", "default": "wildcard", "enum": ["wildcard", "identity", "certificate_id", "fingerprint"]},
        "query": {"type": "string", "default": "", "placeholder": "Identity, numeric crt.sh ID, or SHA-1/SHA-256 fingerprint"},
        "scope_domain": {"type": "string", "default": "", "placeholder": "Optional domain scope for identity/fingerprint results"},
        "exclude_expired": {"type": "boolean", "default": False},
        "issuer_contains": {"type": "string", "default": ""},
        "not_before_after": {"type": "string", "default": "", "placeholder": "ISO date/time lower bound"},
        "not_after_before": {"type": "string", "default": "", "placeholder": "ISO date/time upper bound"},
        "include_unscoped_names": {"type": "boolean", "default": False},
    }, is_async=True),
    _tool("asn.lookup", "ASN", "IP intel", "BGPView / IP-API", "ASN, prefix, geo and organization intelligence with provider-aware evidence.", asn_engine.lookup_ip, {
        "ip": {"type": "string", "required": True},
        "service": {"type": "string", "default": "auto", "enum": ["auto", "bgpview", "ip-api"]},
        "service_base": {"type": "string", "default": ""},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "include_prefixes": {"type": "boolean", "default": False},
    }, is_async=True),
    _tool("har.parse", "HAR", "Parse HAR", "HAR analyzer", "Parse HAR for secrets/auth/hosts.", har_engine.parse, {
        "har_json": {"type": "string", "required": True, "widget": "textarea"},
    }),
    _tool("mutator.mutate", "Mutator", "Mutate payload", "WAF evasion", "Evasion transforms.", mutator_engine.mutate, {
        "payload": {"type": "string", "required": True, "widget": "textarea"},
        "count": {"type": "integer", "default": 20},
    }),
    _tool("xxe.payloads", "XXE", "XXE payloads", "xxeinjector", "XXE corpus.", xxe_engine.list_payloads, {}),
    _tool("xxe.scan", "XXE", "XXE scan", "xxeinjector", "Bounded XML entity probes with request controls, retries/routes, redacted evidence, and response-difference analysis.", xxe_engine.scan, {
        "url": {"type": "string", "required": True},
        "max_payloads": {"type": "integer", "default": 6},
        "content_type": {"type": "string", "default": "application/xml"},
        "method": {"type": "string", "default": "POST", "enum": ["POST", "PUT", "PATCH"]},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "baseline_body": {"type": "string", "default": "<ping/>", "widget": "textarea"},
        "custom_payloads": {"type": "string", "default": "", "widget": "textarea", "placeholder": "XML payloads separated by a line beginning < or by ---"},
        "include_default": {"type": "boolean", "default": True},
        "status_codes": {"type": "string", "default": ""},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "min_difference": {"type": "number", "default": 0.08},
        "max_findings": {"type": "integer", "default": 50},
        "include_response_body": {"type": "boolean", "default": False},
        "preview_chars": {"type": "integer", "default": 400},
        "include_attempts": {"type": "boolean", "default": False},
        "stop_on_finding": {"type": "boolean", "default": False},
    }, is_async=True),
    _tool("ssrf.payloads", "SSRF", "SSRF payloads", "SSRFmap", "Cloud metadata + internal URLs.", ssrf_engine.list_payloads, {}),
    _tool("ssrf.scan", "SSRF", "SSRF scan", "SSRFmap", "Bounded browser-adapted SSRF indication probes with baseline comparison, request controls, retries/routes, and redacted evidence.", ssrf_engine.scan, {
        "url": {"type": "string", "required": True},
        "parameter": {"type": "string", "default": ""},
        "tags": {"type": "string", "default": ""},
        "max_targets": {"type": "integer", "default": 12},
        "max_payloads": {"type": "integer", "default": 12},
        "method": {"type": "string", "default": "GET", "enum": ["GET", "POST", "PUT", "PATCH", "HEAD", "OPTIONS"]},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "body": {"type": "string", "default": "", "widget": "textarea"},
        "placement": {"type": "string", "default": "query", "enum": ["query", "body", "both"]},
        "custom_targets": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Target URLs, one per line or comma-separated"},
        "include_default": {"type": "boolean", "default": True},
        "status_codes": {"type": "string", "default": ""},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "min_difference": {"type": "number", "default": 0.08},
        "include_response_body": {"type": "boolean", "default": False},
        "preview_chars": {"type": "integer", "default": 400},
        "include_attempts": {"type": "boolean", "default": False},
        "stop_on_finding": {"type": "boolean", "default": False},
    }, is_async=True),
    _tool("upload.bypass", "Upload", "Upload bypass names", "upload bypass", "Filename/CT polyglots.", upload_engine.generate, {
        "basename": {"type": "string", "default": "psec"},
        "include_polyglot": {"type": "boolean", "default": True},
    }),
    _tool("upload.probe", "Upload", "Live upload probe", "upload probe", "Multipart upload test (authorized only).", upload_engine.probe, {
        "url": {"type": "string", "required": True},
        "field_name": {"type": "string", "default": "file"},
        "filename": {"type": "string", "default": "psec.php.jpg"},
        "content_type": {"type": "string", "default": "image/jpeg"},
        "body_text": {"type": "string", "default": "GIF89a\n<?php echo \'psec\'; ?>\n"},
        "user_agent": {"type": "string", "default": "pyodide-security/upload-engine/2.0"},
        "headers": {"type": "string", "widget": "textarea", "default": "", "description": "JSON object or Name: Value lines; sensitive evidence is redacted."},
        "timeout_ms": {"type": "integer", "default": 8000, "minimum": 1000, "maximum": 120000},
        "retries": {"type": "integer", "default": 0, "minimum": 0, "maximum": 5},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "content_mode": {"type": "string", "default": "custom", "enum": ["custom", "benign_marker"]},
        "marker_text": {"type": "string", "default": "goar-upload-probe"},
        "expected_statuses": {"type": "string", "default": "200,201,202,204", "description": "Codes, ranges, or selectors such as 2xx."},
        "success_keywords": {"type": "string", "default": "upload,success,stored,saved,psec,file"},
        "include_response_body": {"type": "boolean", "default": True},
        "preview_chars": {"type": "integer", "default": 400, "minimum": 0, "maximum": 200000},
        "include_request_evidence": {"type": "boolean", "default": True},
    }, is_async=True),
    _tool("homoglyph.generate", "Homoglyph", "Homoglyph domains", "dnstwist lite", "Confusable domain variants.", homoglyph_engine.generate, {
        "domain": {"type": "string", "required": True},
        "max_variants": {"type": "integer", "default": 40},
    }),
    _tool("jwtadv.none", "JWTAdv", "Forge none", "jwt_tool none", "alg=none forge.", jwt_engine.forge_none, {
        "payload": {"type": "string", "required": True, "widget": "textarea", "default": "{\"sub\":\"admin\",\"role\":\"admin\"}"},
    }),
    _tool("jwtadv.hs", "JWTAdv", "Forge HS", "jwt_tool sign", "HS* sign.", jwt_engine.sign_hs, {
        "payload": {"type": "string", "required": True, "widget": "textarea", "default": "{\"sub\":\"admin\"}"},
        "secret": {"type": "string", "required": True},
        "alg": {"type": "string", "default": "HS256", "enum": ["HS256", "HS384", "HS512"]},
    }),
    _tool("jwtadv.kid", "JWTAdv", "Kid injection", "jwt_tool kid", "kid path injection token.", jwt_engine.kid_injection, {
        "payload": {"type": "string", "required": True, "widget": "textarea", "default": "{\"sub\":\"admin\"}"},
        "kid": {"type": "string", "default": "../../../../dev/null"},
        "secret": {"type": "string", "default": ""},
    }),
    _tool("jwtadv.jku", "JWTAdv", "JKU injection", "jwt_tool jku", "jku header attack token.", jwt_advanced.jku_header, {
        "payload": {"type": "string", "required": True, "widget": "textarea", "default": "{\"sub\":\"admin\"}"},
        "jku": {"type": "string", "default": "https://evil.example/jwks.json"},
    }),
    _tool("jwtadv.claims", "JWTAdv", "Admin claims", "jwt claims", "Privilege claim set + none token.", jwt_advanced.claim_set, {
        "sub": {"type": "string", "default": "admin"},
        "role": {"type": "string", "default": "admin"},
        "admin": {"type": "boolean", "default": True},
        "exp_offset": {"type": "integer", "default": 3600},
    }),
    _tool("graphql.adv", "GraphQL", "GraphQL attacks", "graphql-cop", "Bounded introspection/batch/alias/GET checks through the unified Goar route stack.", graphql_adv_engine.attack, {
        "url": {"type": "string", "required": True},
        "tests": {"type": "string", "default": "introspect,batch,alias,get,suggest,sensitive"},
        "max_aliases": {"type": "integer", "default": 50},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
    _tool("form.extract", "Form", "Extract forms HTML", "form analysis", "Offline form/CSRF analysis.", form_engine.extract_html, {
        "html": {"type": "string", "required": True, "widget": "textarea"},
        "base_url": {"type": "string", "default": ""},
    }),
    _tool("form.scan", "Form", "Scan forms", "HTML / OWASP CSRF guidance", "Passive bounded HTML form extraction with redacted control values, token indicators, and route evidence.", form_engine.scan_url, {
        "url": {"type": "string", "required": True},
        "paths": {"type": "string", "default": "/", "widget": "textarea", "placeholder": "One optional path per line or comma-separated"},
        "max_paths": {"type": "integer", "default": 3},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "stop_on_risk": {"type": "boolean", "default": False},
        "include_inputs": {"type": "boolean", "default": True},
    }, is_async=True),
    _tool("wellknown.scan", "WellKnown", "Well-known URIs", "RFC 8615 / IANA registry", "Bounded registered/custom `/.well-known/` collection with status, preview, and route evidence.", wellknown_engine.scan, {
        "url": {"type": "string", "required": True},
        "max_paths": {"type": "integer", "default": 20},
        "paths": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Optional registered/custom suffixes, one per line or comma-separated"},
        "include_bundled": {"type": "boolean", "default": True},
        "status_codes": {"type": "string", "default": "200,204,301,302,307,308,401,403"},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "stop_on_found": {"type": "boolean", "default": False},
        "include_body_preview": {"type": "boolean", "default": False},
        "body_preview_chars": {"type": "integer", "default": 300},
    }, is_async=True),
    _tool("intel.urlhaus", "Intel", "URLhaus lookup", "URLhaus Community API", "Malware URL POST lookup with parsed status and route evidence.", intel_engine.urlhaus_url, {
        "url": {"type": "string", "required": True},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
    _tool("intel.threatfox", "Intel", "ThreatFox search", "ThreatFox Community API", "IOC POST search with parsed types and route evidence.", intel_engine.threatfox_search, {
        "query": {"type": "string", "required": True},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
    _tool("intel.otx", "Intel", "OTX domain", "AlienVault OTX", "OTX general indicator lookup with pulse and route evidence.", intel_engine.otx_domain, {
        "domain": {"type": "string", "required": True},
        "api_key": {"type": "string", "default": "", "sensitive": True},
        "headers": {"type": "string", "default": "", "widget": "textarea", "placeholder": "Header: value lines or JSON object"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
    _tool("fuzzgen.generate", "FuzzGen", "Fuzz strings", "radamsa lite", "Boundary/format/unicode fuzz corpus.", fuzzgen_engine.generate, {
        "kinds": {"type": "string", "default": "all"},
        "max_items": {"type": "integer", "default": 50},
    }),

    _tool("requests.patch", "Requests", "Patch pyodide-http", "pyodide-http", "Patch requests/urllib for Pyodide.", requests_bridge.patch_pyodide_http, {}),
    _tool("requests.status", "Requests", "Requests bridge status", "pyodide-http", "pyodide-http + Manus status.", requests_bridge.status, {}),
    _tool("requests.get", "Requests", "Proxied request", "requests+manus", "Full browser-equivalent request through the Goar transport.", requests_bridge.get, {
        "url": {"type": "string", "required": True},
        "method": {"type": "string", "default": "GET", "enum": ["GET", "HEAD", "OPTIONS", "POST", "PUT", "PATCH", "DELETE"]},
        "headers_json": {"type": "string", "default": "", "widget": "textarea"},
        "params_json": {"type": "string", "default": "", "widget": "textarea"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "response_mode": {"type": "string", "default": "text", "enum": ["text", "json"]},
    }, is_async=True),
    _tool("requests.post", "Requests", "Proxied body request", "requests+manus", "Full body/JSON request through the Goar transport.", requests_bridge.post, {
        "url": {"type": "string", "required": True},
        "body": {"type": "string", "default": "", "widget": "textarea"},
        "content_type": {"type": "string", "default": "application/json"},
        "method": {"type": "string", "default": "POST", "enum": ["POST", "PUT", "PATCH", "DELETE"]},
        "headers_json": {"type": "string", "default": "", "widget": "textarea"},
        "params_json": {"type": "string", "default": "", "widget": "textarea"},
        "json_body": {"type": "string", "default": "", "widget": "textarea"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
        "response_mode": {"type": "string", "default": "text", "enum": ["text", "json"]},
    }, is_async=True),

    _tool("http.batch", "HTTP", "Batch request", "httpx batch probe", "Bounded multi-target request execution through the shared Goar transport.", network_tools.batch, {
        "urls": {"type": "string", "required": True, "widget": "textarea", "placeholder": "One absolute http(s) URL per line"},
        "method": {"type": "string", "default": "GET", "enum": ["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"]},
        "headers": {"type": "string", "default": "", "widget": "textarea"},
        "body": {"type": "string", "default": "", "widget": "textarea"},
        "max_requests": {"type": "integer", "default": 20},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
    _tool("http.diff", "HTTP", "Compare responses", "httpx response comparison", "Compare bounded response status and lengths for two targets through the shared transport.", network_tools.diff, {
        "url_a": {"type": "string", "required": True},
        "url_b": {"type": "string", "required": True},
        "method": {"type": "string", "default": "GET", "enum": ["GET", "HEAD"]},
        "headers": {"type": "string", "default": "", "widget": "textarea"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
    _tool("http.headers", "HTTP", "Security headers", "securityheaders-style audit", "Inspect response security headers with redacted transport evidence.", network_tools.headers, {
        "url": {"type": "string", "required": True},
        "request_headers": {"type": "string", "default": "", "widget": "textarea"},
        "timeout_ms": {"type": "integer", "default": 8000},
        "retries": {"type": "integer", "default": 0},
        "retry_statuses": {"type": "string", "default": "408,429,500,502,503,504"},
        "route": {"type": "string", "default": "auto", "enum": ["auto", "proxy", "direct"]},
    }, is_async=True),
]

_BY_ID = {t["id"]: t for t in _TOOLS}


def list_tools() -> list[dict]:
    return [
        {
            "id": t["id"],
            "group": t["group"],
            "title": t["title"],
            "equivalent": t.get("equivalent"),
            "description": t["description"],
            "async": bool(t.get("async")),
            "params": t["params"],
        }
        for t in _TOOLS
    ]


def describe_tool(tool_id: str) -> dict:
    t = _BY_ID.get(tool_id)
    if not t:
        return {"ok": False, "error": f"unknown tool: {tool_id}"}
    return {"ok": True, **{k: t[k] for k in ("id", "group", "title", "equivalent", "description", "async", "params")}}


def _coerce_kwargs(params_meta: dict, kwargs: dict) -> dict:
    clean: dict[str, Any] = {}
    for k, v in kwargs.items():
        if v is None:
            continue
        meta = params_meta.get(k) or {}
        typ = meta.get("type")
        if typ == "integer" and not isinstance(v, int):
            try:
                v = int(v)
            except (TypeError, ValueError):
                pass
        elif typ == "number" and not isinstance(v, (int, float)):
            try:
                v = float(v)
            except (TypeError, ValueError):
                pass
        elif typ == "boolean" and not isinstance(v, bool):
            if isinstance(v, str):
                v = v.strip().lower() in ("1", "true", "yes", "on")
            else:
                v = bool(v)
        if isinstance(v, str) and v == "" and not meta.get("required"):
            continue
        clean[k] = v
    return clean


_KW_ALIASES = {
    "max_checks": ("max_tests", "max_checks", "max_payloads"),
    "max_tests": ("max_tests", "max_checks"),
    "max_paths": ("max_paths", "max_endpoints", "max_words", "max_plugins"),
    "max_endpoints": ("max_endpoints", "max_paths"),
    "max_words": ("max_words", "max_paths", "max_hosts"),
    "max_hosts": ("max_hosts", "max_words"),
    "max_payloads": ("max_payloads", "max_variants", "max_dests", "max_targets", "max_tests"),
    "max_variants": ("max_variants", "max_payloads"),
    "parameter": ("parameter", "parameters"),
    "parameters": ("parameters", "parameter"),
    "domain": ("domain", "name", "host"),
    "name": ("name", "domain", "host"),
    "host": ("host", "name", "domain", "ip"),
    "query": ("query", "q", "url", "target", "ip", "asn", "indicator"),
    "targets": ("targets", "url", "urls"),
    "url": ("url", "targets", "urls", "target"),
    "urls": ("urls", "url", "targets"),
    "ip": ("ip", "query", "host"),
    "family": ("family", "kind"),
    "kind": ("kind", "family"),
}


def _bind_kwargs(fn, params_meta: dict, kwargs: dict) -> dict:
    clean = _coerce_kwargs(params_meta or {}, kwargs)
    try:
        sig = inspect.signature(fn)
    except (TypeError, ValueError):
        return clean
    params = sig.parameters
    if any(p.kind is inspect.Parameter.VAR_KEYWORD for p in params.values()):
        return clean
    bound: dict[str, Any] = {}
    used: set[str] = set()
    for key, val in list(clean.items()) + [(k, v) for k, v in kwargs.items() if k not in clean]:
        if val is None:
            continue
        if key in params and key not in used and key != "self":
            bound[key] = val
            used.add(key)
            continue
        for alt in _KW_ALIASES.get(key, ()):
            if alt in params and alt not in used:
                bound[alt] = val
                used.add(alt)
                break
    return bound


def run_tool(tool_id: str, **kwargs) -> dict:
    import time

    t = _BY_ID.get(tool_id)
    if not t:
        return {"ok": False, "tool": tool_id, "error": f"unknown tool: {tool_id}", "ms": 0.0}
    if t.get("async") or inspect.iscoroutinefunction(t["fn"]):
        return {"ok": False, "tool": tool_id, "error": "async tool — use run_tool_async", "ms": 0.0}
    clean = _bind_kwargs(t["fn"], t.get("params") or {}, kwargs)
    start = time.perf_counter()
    try:
        result = t["fn"](**clean)
        return {"ok": True, "tool": tool_id, "result": result, "ms": round((time.perf_counter() - start) * 1000, 3)}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "tool": tool_id, "error": f"{type(e).__name__}: {e}", "ms": round((time.perf_counter() - start) * 1000, 3)}


async def run_tool_async(tool_id: str, **kwargs) -> dict:
    import time

    t = _BY_ID.get(tool_id)
    if not t:
        return {"ok": False, "tool": tool_id, "error": f"unknown tool: {tool_id}", "ms": 0.0}
    if t["fn"] is None:
        return {"ok": False, "tool": tool_id, "error": "tool not available in this build", "ms": 0.0}
    clean = _bind_kwargs(t["fn"], t.get("params") or {}, kwargs)
    start = time.perf_counter()
    try:
        if inspect.iscoroutinefunction(t["fn"]):
            result = await t["fn"](**clean)
        else:
            result = t["fn"](**clean)
        return {"ok": True, "tool": tool_id, "result": result, "ms": round((time.perf_counter() - start) * 1000, 3)}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "tool": tool_id, "error": f"{type(e).__name__}: {e}", "ms": round((time.perf_counter() - start) * 1000, 3)}


def health() -> dict:
    import hashlib
    import sys

    sample = run_tool("hash.digest", data="pyodide-security", algorithm="sha256")
    expected = hashlib.sha256(b"pyodide-security").hexdigest()
    groups = sorted({t["group"] for t in _TOOLS})
    return {
        "ok": bool(sample.get("ok") and sample.get("result", {}).get("hex") == expected),
        "version": VERSION,
        "python": sys.version.split()[0],
        "tools": len(_TOOLS),
        "async_tools": sum(1 for t in _TOOLS if t.get("async")),
        "groups": groups,
        "group_count": len(groups),
        "package_files": len(PACKAGE_FILES),
        "nuclei_templates": len(nuclei_engine.TEMPLATES),
        "sqlmap_payloads": run_tool("sqlmap.payloads", level=5, risk=3).get("result", {}).get("corpus_total"),
        "xss_payloads": xss_engine.list_payloads()["total"],
        "yara_rules": yara_engine.list_rules()["total"],
        "takeover_fps": takeover_engine.list_fingerprints()["count"],
        "proxy": proxy_status(),
        "auto_proxy": True,
        "policy": policy.status(),
        "libcurl": libcurl_bridge.status(),
        "simd": simd_crypto.status(),
        "sample_sha256": sample.get("result", {}).get("hex"),
    }
