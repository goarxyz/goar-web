"""
Live prototype pollution scanner — ppmap-class.

Probes query-string and JSON body vectors, then checks whether the canary
appears reflected in a way that indicates server-side merge of attacker keys
into shared objects (or client-side indicators in returned HTML/JS).
"""

from __future__ import annotations

from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from .._http import http_request, redact_url
from .. import policy
from .payloads import CANARY, CANARY_VAL, list_payloads, render_json


async def scan(
    url: str,
    parameter: str = "",
    techniques: str = "query,json",
    max_payloads: int = 12,
    user_agent: str = "pyodide-security/pp-engine/2.0",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    include_attempts: bool = True,
) -> dict[str, Any]:
    err = policy.check_url_for_active(url)
    if err:
        return {"ok": False, "error": err, "engine": "pp"}

    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    p = urlparse(url)
    params = dict(parse_qsl(p.query, keep_blank_values=True))
    param = parameter or (next(iter(params)) if params else "q")
    headers = {"User-Agent": user_agent}
    want = {t.strip().lower() for t in techniques.split(",") if t.strip()}
    timeout = max(1000, min(int(timeout_ms or 8000), 120000))
    retry_count = max(0, min(int(retries or 0), 5))
    route_name = route if route in ("auto", "proxy", "direct") else "auto"
    use_proxy = True if route_name == "proxy" else False if route_name == "direct" else None
    retry_codes = {int(item.strip()) for item in str(retry_statuses or "").split(",") if item.strip().isdigit()}
    attempts: list[dict[str, Any]] = []

    async def request(target: str, method: str = "GET", request_headers: dict[str, str] | None = None, body: str | None = None) -> dict[str, Any]:
        response: dict[str, Any] = {}
        for _ in range(retry_count + 1):
            response = await http_request(target, method=method, headers=request_headers or headers, body=body, timeout_ms=timeout, use_proxy=use_proxy)
            attempts.append({"attempt": len(attempts) + 1, "url": redact_url(target), "status": response.get("status"), "ok": response.get("ok"), "transport": response.get("transport"), "elapsed_ms": response.get("elapsed_ms"), "error": str(response.get("error") or "")[:240]})
            if response.get("ok") or int(response.get("status") or 0) not in retry_codes:
                break
        return response

    # baseline
    base = await request(url)
    base_body = base.get("body") or ""
    base_status = int(base.get("status") or 0)

    pack = list_payloads("all")
    findings = []
    tests = []

    # --- query probes ---
    if "query" in want:
        for item in pack.get("query", [])[: max(1, min(int(max_payloads), 20))]:
            if not policy.can_request():
                break
            q = dict(params)
            q[item["key"]] = item["value"]
            # also try as the selected param value when key is complex
            if param and param not in item["key"]:
                q[param] = f"{item['key']}={item['value']}"
            test_url = urlunparse(p._replace(query=urlencode(q, doseq=True)))
            resp = await request(test_url)
            body = resp.get("body") or ""
            status = int(resp.get("status") or 0)
            reflected = CANARY in body or CANARY_VAL in body
            anomaly = status != base_status or abs(len(body) - len(base_body)) > max(50, len(base_body) * 0.05)
            # strong signal: canary key echoed as object property in JSON response
            json_pollution = f'"{CANARY}"' in body and CANARY_VAL in body
            conf = 0
            if json_pollution:
                conf = 85
            elif reflected and anomaly:
                conf = 60
            elif reflected:
                conf = 40
            elif anomaly:
                conf = 25
            entry = {
                "id": item["id"],
                "technique": "query",
                "key": item["key"],
                "status": status,
                "reflected_canary": reflected,
                "json_pollution_signal": json_pollution,
                "anomaly": anomaly,
                "confidence": conf,
                "error": resp.get("error"),
            }
            tests.append(entry)
            if conf >= 40:
                findings.append(entry)

    # --- JSON body probes ---
    if "json" in want:
        for item in pack.get("json", [])[: max(1, min(int(max_payloads), 15))]:
            if not policy.can_request():
                break
            body_payload = item.get("body") or render_json(item)
            hdrs = {**headers, "Content-Type": item.get("content_type") or "application/json"}
            resp = await request(url, method="POST", request_headers=hdrs, body=body_payload)
            body = resp.get("body") or ""
            status = int(resp.get("status") or 0)
            reflected = CANARY in body
            json_pollution = f'"{CANARY}"' in body and (CANARY_VAL in body or '"isAdmin"' in body or '"role"' in body)
            anomaly = status != base_status
            conf = 85 if json_pollution else (50 if reflected else (20 if anomaly else 0))
            entry = {
                "id": item["id"],
                "technique": "json",
                "status": status,
                "reflected_canary": reflected,
                "json_pollution_signal": json_pollution,
                "anomaly": anomaly,
                "confidence": conf,
                "error": resp.get("error"),
            }
            tests.append(entry)
            if conf >= 40:
                findings.append(entry)

    findings.sort(key=lambda x: -x["confidence"])
    return {
        "ok": True,
        "url": redact_url(url),
        "parameter": param,
        "baseline_status": base_status,
        "canary": CANARY,
        "tested": len(tests),
        "findings": findings,
        "tests": tests,
        "vulnerable": bool(findings) and findings[0]["confidence"] >= 60,
        "engine": "pp",
        "version": "2.0",
        "equivalent": "ppmap / PortSwigger prototype pollution",
        "note": (
            "Server-side PP confirmed only when canary appears as owned property in JSON. "
            "Client-side PP requires DOM XSS sink follow-up in browser."
        ),
        "policy": policy.status(),
        "request": {"timeout_ms": timeout, "retries": retry_count, "retry_statuses": sorted(retry_codes), "route": route_name, "headers": {"User-Agent": user_agent}},
        "attempts": attempts if include_attempts else [],
        "attempt_count": len(attempts),
    }
