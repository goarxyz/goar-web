"""
libcurl.js + Wisp + Epoxy transport bridge for Pyodide.

Transport priority (when host page is set up correctly):
  1. libcurl.js over Wisp WebSocket tunnel (wss://cors.manus.space/wisp/)
  2. Epoxy TLS sockets via Bare-Mux (when epoxy client is present)
  3. Falls through to Manus HTTP CORS proxy in _http.py

Host page bootstrap (required for libcurl path):

  <script src="libcurl.js"></script>
  <!-- optional epoxy / bare-mux -->
  <script type="module">
    import { BareMuxConnection } from "@mercuryworkshop/bare-mux";
    // or epoxy-transport package
    await libcurl.load_wasm("/libcurl.wasm");
    libcurl.set_websocket("wss://cors.manus.space/wisp/");
    // If using Bare-Mux + Epoxy:
    // await connection.setRemoteTransport(epoxyTransport);
  </script>

Official corsproxy endpoints:
  HTTP CORS:  https://cors.manus.space/api/proxy/:targetUrl
  Wisp:       wss://cors.manus.space/wisp/
  Docs:       compatible with Bare-Mux, Epoxy TLS, libcurl.js
"""

from __future__ import annotations

from typing import Any
from urllib.parse import urlparse
import time

_WISP_DEFAULT = "wss://cors.manus.space/wisp/"
_CORS_DEFAULT = "https://cors.manus.space/api/proxy"

_state: dict[str, Any] = {
    "preferred": True,           # prefer libcurl when ready
    "wisp_url": _WISP_DEFAULT,
    "cors_base": _CORS_DEFAULT,
    "epoxy_enabled": True,       # try epoxy/bare-mux if present
    "transport_mode": "auto",    # auto | libcurl | epoxy | cors
    "last_error": None,
    "last_transport": None,
    "last_action": None,
    "last_configured_at": None,
}


def _safe_url(value: Any) -> str:
    # Import at call time to avoid a transport-module import cycle.
    try:
        from ._http import redact_url
        return redact_url(value)
    except Exception:
        return str(value or "")


def _validate_endpoint(value: str, kind: str) -> str | None:
    raw = str(value or '').strip()
    if not raw:
        return f'{kind} URL is required'
    parsed = urlparse(raw)
    expected = 'wss' if kind == 'Wisp' else 'https'
    if parsed.scheme != expected or not parsed.netloc:
        return f'{kind} URL must be an absolute {expected}:// URL'
    if parsed.username or parsed.password:
        return f'{kind} URL must not contain embedded credentials'
    return None


def _mode_availability(st: dict[str, Any]) -> dict[str, bool]:
    return {
        'libcurl': bool(st.get('libcurl_ready') and st.get('wisp_url')),
        'epoxy': bool(st.get('epoxy_present') and st.get('epoxy_enabled')),
        'cors': True,
    }


def status() -> dict[str, Any]:
    libcurl_ready = False
    version = None
    websocket_url = None
    epoxy_present = False
    bare_mux_present = False

    try:
        from js import libcurl  # type: ignore

        libcurl_ready = bool(getattr(libcurl, "ready", False))
        try:
            version = libcurl.version
            if hasattr(version, "to_py"):
                version = version.to_py()
            elif not isinstance(version, (dict, str, type(None))):
                version = str(version)
        except Exception:
            version = None
        try:
            websocket_url = str(getattr(libcurl, "websocket_url", "") or "") or None
        except Exception:
            websocket_url = None
    except Exception as e:  # noqa: BLE001
        _state["last_error"] = f"libcurl: {type(e).__name__}: {e}"

    # Detect Epoxy / Bare-Mux globals if host injected them
    try:
        from js import Object, globalThis  # type: ignore

        g = globalThis
        for name in ("epoxy", "EpoxyClient", "EpoxyTransport", "epoxyTransport"):
            try:
                if getattr(g, name, None) is not None:
                    epoxy_present = True
                    break
            except Exception:
                pass
        for name in ("BareMux", "BareMuxConnection", "bare", "bareMux"):
            try:
                if getattr(g, name, None) is not None:
                    bare_mux_present = True
                    break
            except Exception:
                pass
    except Exception:
        pass

    transport = "unavailable"
    if libcurl_ready and websocket_url:
        transport = "libcurl+wisp"
        if epoxy_present:
            transport = "libcurl+wisp+epoxy"
    elif libcurl_ready:
        transport = "libcurl(no-wisp)"
    elif epoxy_present:
        transport = "epoxy-detected"

    result = {
        "available": bool(libcurl_ready and websocket_url),
        "libcurl_ready": libcurl_ready,
        "epoxy_present": epoxy_present,
        "bare_mux_present": bare_mux_present,
        "preferred": _state["preferred"],
        "wisp_url": _safe_url(websocket_url or _state["wisp_url"]),
        "default_wisp": _safe_url(_WISP_DEFAULT),
        "cors_base": _safe_url(_state["cors_base"]),
        "transport_mode": _state["transport_mode"],
        "last_transport": _state["last_transport"],
        "version": version,
        "last_error": _state["last_error"],
        "transport": transport,
        "note": (
            f"Active path: {transport}"
            if libcurl_ready
            else "libcurl.js not loaded — host must load WASM + set_websocket(Wisp); HTTP CORS fallback still available"
        ),
        "preferred_available": bool(_state.get("preferred") and (libcurl_ready and websocket_url or epoxy_present or _state.get("transport_mode") == "cors")),
        "epoxy_enabled": bool(_state.get("epoxy_enabled")),
        "last_action": _state.get("last_action"),
        "last_configured_at": _state.get("last_configured_at"),
    }
    result["mode_available"] = _mode_availability(result)
    result["selected_mode_available"] = bool(result["mode_available"].get(result["transport_mode"], result["transport_mode"] == "auto"))
    return result


def configure(
    preferred: bool | None = None,
    wisp_url: str = "",
    cors_base: str = "",
    epoxy_enabled: bool | None = None,
    transport_mode: str = "",
) -> dict[str, Any]:
    if preferred is not None:
        _state["preferred"] = bool(preferred)
    if epoxy_enabled is not None:
        _state["epoxy_enabled"] = bool(epoxy_enabled)
    if transport_mode:
        if transport_mode not in ("auto", "libcurl", "epoxy", "cors"):
            raise ValueError("transport_mode must be auto, libcurl, epoxy, or cors")
        _state["transport_mode"] = transport_mode
    if cors_base:
        err = _validate_endpoint(cors_base, 'CORS')
        if err:
            raise ValueError(err)
        _state["cors_base"] = cors_base.rstrip("/")
    if wisp_url:
        err = _validate_endpoint(wisp_url, 'Wisp')
        if err:
            raise ValueError(err)
        _state["wisp_url"] = wisp_url
        try:
            from js import libcurl  # type: ignore
            libcurl.set_websocket(wisp_url)
        except Exception:
            pass
    _state['last_action'] = 'configure'
    _state['last_configured_at'] = round(time.time(), 3)
    return status()


def is_ready() -> bool:
    mode = _state.get("transport_mode") or "auto"
    if mode == "cors":
        return False  # force HTTP CORS path in _http
    try:
        from js import libcurl  # type: ignore

        ready = bool(getattr(libcurl, "ready", False))
        has_ws = bool(getattr(libcurl, "websocket_url", None))
        return ready and has_ws
    except Exception:
        return False


async def ensure(
    wisp_url: str = "",
    force_websocket: bool = True,
    wait_ms: int = 0,
    transport_mode: str = "",
) -> dict[str, Any]:
    """
    Ensure libcurl.js is ready and pointed at the Wisp endpoint.
    Optionally detects Epoxy/Bare-Mux presence for status reporting.

    Does NOT load WASM — host page must call libcurl.load_wasm() first.
    """
    url = wisp_url or _state["wisp_url"] or _WISP_DEFAULT
    err = _validate_endpoint(url, 'Wisp')
    if err:
        return {'ok': False, 'error': err, 'status': status()}
    if transport_mode:
        if transport_mode not in ('auto', 'libcurl', 'epoxy', 'cors'):
            return {'ok': False, 'error': 'transport_mode must be auto, libcurl, epoxy, or cors', 'status': status()}
        _state['transport_mode'] = transport_mode
    wait_ms = max(0, min(int(wait_ms or 0), 15000))
    try:
        from js import libcurl  # type: ignore
    except Exception as e:  # noqa: BLE001
        return {
            "ok": False,
            "error": f"libcurl global not found: {e}",
            "hint": (
                "In the host page: load libcurl.js, then "
                "await libcurl.load_wasm('/libcurl.wasm'); "
                "libcurl.set_websocket('wss://cors.manus.space/wisp/');"
            ),
            "status": status(),
        }

    deadline = time.perf_counter() + wait_ms / 1000
    while not getattr(libcurl, 'ready', False) and time.perf_counter() < deadline:
        await __import__('asyncio').sleep(0.05)
    if not getattr(libcurl, "ready", False):
        _state['last_action'] = 'ensure:not-ready'
        return {
            "ok": False,
            "error": "libcurl.wasm not ready",
            "hint": "await libcurl.load_wasm('/path/to/libcurl.wasm') before ensure(); HTTP CORS fallback remains available",
            "wait_ms": wait_ms,
            "status": status(),
        }

    try:
        if force_websocket or not getattr(libcurl, "websocket_url", None):
            libcurl.set_websocket(url)
        _state["wisp_url"] = url
        _state['last_action'] = 'ensure:websocket-set'
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"set_websocket failed: {e}", "status": status()}

    st = status()
    _state['last_action'] = 'ensure:ready'
    return {
        "ok": True,
        "wisp_url": _safe_url(url),
        "wait_ms": wait_ms,
        "version": st.get("version"),
        "transport": st.get("transport"),
        "epoxy_present": st.get("epoxy_present"),
        "bare_mux_present": st.get("bare_mux_present"),
        "status": st,
    }


async def fetch(
    url: str,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    body: str | bytes | None = None,
    timeout_ms: int = 30000,
) -> dict[str, Any]:
    """
    HTTP request via libcurl.js (Wisp-backed, Epoxy-capable host).
    Return shape matches _http.http_request.
    """
    import time

    t0 = time.perf_counter()
    if not is_ready():
        return {
            "ok": False,
            "status": 0,
            "headers": {},
            "body": "",
            "url": _safe_url(url),
            "final_url": _safe_url(url),
            "error": "libcurl not ready — call await libcurl_bridge.ensure()",
            "elapsed_ms": int((time.perf_counter() - t0) * 1000),
            "via_libcurl": False,
            "via_proxy": False,
            "transport": "none",
        }

    try:
        from js import libcurl, Object  # type: ignore
        from pyodide.ffi import to_js  # type: ignore
    except Exception as e:  # noqa: BLE001
        return {
            "ok": False,
            "status": 0,
            "headers": {},
            "body": "",
            "url": _safe_url(url),
            "final_url": _safe_url(url),
            "error": f"js bridge import failed: {e}",
            "elapsed_ms": int((time.perf_counter() - t0) * 1000),
            "via_libcurl": False,
            "via_proxy": False,
            "transport": "none",
        }

    method_u = (method or "GET").upper()
    hdrs = {str(k): str(v) for k, v in (headers or {}).items()}

    # Build libcurl request options
    # libcurl.js HTTPSession / fetch-like API varies by version; support both styles
    try:
        opts: dict[str, Any] = {
            "method": method_u,
            "headers": hdrs,
        }
        if body is not None and method_u not in ("GET", "HEAD"):
            opts["body"] = body if isinstance(body, str) else body.decode("utf-8", errors="replace")

        # Timeout: libcurl.js may accept timeout in seconds or ms depending on version
        try:
            opts["timeout"] = max(1, int(timeout_ms / 1000))
        except Exception:
            pass

        js_opts = to_js(opts, dict_converter=Object.fromEntries)

        # Preferred: libcurl.fetch (0.7.x) or HTTPSession
        resp = None
        if hasattr(libcurl, "fetch"):
            resp = await libcurl.fetch(url, js_opts)
        elif hasattr(libcurl, "HTTPSession"):
            session = libcurl.HTTPSession()
            resp = await session.request(method_u, url, js_opts)
        else:
            # last resort: libcurl.Curl / perform — not fully portable
            return {
                "ok": False,
                "status": 0,
                "headers": {},
                "body": "",
                "url": url,
                "final_url": url,
                "error": "libcurl.js has no fetch/HTTPSession API",
                "elapsed_ms": int((time.perf_counter() - t0) * 1000),
                "via_libcurl": True,
                "via_proxy": False,
                "transport": "libcurl-unsupported",
            }

        # Normalize response
        status_code = int(getattr(resp, "status", 0) or getattr(resp, "status_code", 0) or 0)
        final_url = str(getattr(resp, "url", None) or url)

        # body
        text = ""
        try:
            if hasattr(resp, "text"):
                t = resp.text
                text = await t if hasattr(t, "__await__") else str(t or "")
            elif hasattr(resp, "body"):
                b = resp.body
                if hasattr(b, "__await__"):
                    b = await b
                text = b if isinstance(b, str) else str(b or "")
        except Exception as e:  # noqa: BLE001
            text = f""
            _state["last_error"] = f"body read: {e}"

        # headers
        out_headers: dict[str, str] = {}
        try:
            h = getattr(resp, "headers", None)
            if h is not None:
                if hasattr(h, "entries"):
                    it = h.entries()
                    # JS iterator
                    try:
                        while True:
                            nxt = it.next()
                            if getattr(nxt, "done", False):
                                break
                            val = nxt.value
                            out_headers[str(val[0])] = str(val[1])
                    except Exception:
                        pass
                elif hasattr(h, "to_py"):
                    out_headers = {str(k): str(v) for k, v in h.to_py().items()}
                elif isinstance(h, dict):
                    out_headers = {str(k): str(v) for k, v in h.items()}
        except Exception:
            pass

        transport = "libcurl+wisp"
        st = status()
        if st.get("epoxy_present"):
            transport = "libcurl+wisp+epoxy"
        _state["last_transport"] = transport

        return {
            "ok": status_code > 0 and status_code < 500,
            "status": status_code,
            "headers": out_headers,
            "body": text,
            "url": _safe_url(url),
            "final_url": _safe_url(final_url),
            "error": None if status_code else "empty status from libcurl",
            "elapsed_ms": int((time.perf_counter() - t0) * 1000),
            "via_libcurl": True,
            "via_proxy": False,
            "via_wisp": True,
            "transport": transport,
        }
    except Exception as e:  # noqa: BLE001
        _state["last_error"] = f"{type(e).__name__}: {e}"
        return {
            "ok": False,
            "status": 0,
            "headers": {},
            "body": "",
            "url": _safe_url(url),
            "final_url": _safe_url(url),
            "error": f"libcurl fetch failed: {e}",
            "elapsed_ms": int((time.perf_counter() - t0) * 1000),
            "via_libcurl": True,
            "via_proxy": False,
            "transport": "libcurl-error",
        }
