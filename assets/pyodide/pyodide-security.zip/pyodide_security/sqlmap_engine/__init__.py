"""sqlmap-class engine — real corpus from sqlmapproject/sqlmap + full tamper scripts."""

from .scan import scan, list_payloads
from .loader import stats, tests, errors, boundaries, manifest, upstream_manifest, conversion_coverage
from .agent import cleanup_payload, apply_boundary

from .fingerprint import fingerprint
from .tampers import list_tampers, tamper, apply_tampers, apply_tamper
from .inject import discover_points, build_request
from .queries import list_dbms, list_plugin_dbms, plugin_info, get_query, enum_plan
from .extract import (
    extract_length_boolean,
    extract_string_boolean,
    build_union_payload,
    find_column_count,
    extraction_plan,
)
from .detect import analyze_pair, confirm_boolean
from .workflow import normalize_options, parse_target_list, parse_config, parse_raw_request, plan_workflow, execute_workflow, session_snapshot
from .session import session_create, session_append, session_snapshot as session_store_snapshot, session_export, session_close, session_list


def fingerprint_errors(
    text: str = "",
    headers: str = "",
    status: int = 0,
    dbms_filter: str = "",
    waf_filter: str = "",
    max_evidence: int = 5,
    redact_evidence: bool = True,
):
    return fingerprint(text, headers, status, dbms_filter, waf_filter, max_evidence, redact_evidence)


def analyze_response(baseline: str = "", response: str = "", comparison: str = "auto", string_match: str = "", not_string: str = "", status_match: int = 0, max_body_chars: int = 20000, redact_evidence: bool = True):
    return analyze_pair(
        {"body": baseline}, {"body": response}, comparison=comparison,
        string_match=string_match, not_string=not_string,
        status_match=status_match, max_body_chars=max_body_chars,
        redact_evidence=redact_evidence,
    )


def extract_params(url: str = "", data: str = "", cookie: str = "", headers: dict[str, str] | None = None, places: str = "GET,POST,COOKIE,UA,REFERER,HOST,HEADER,JSON"):
    discovered = discover_points(url, data=data, cookie=cookie, headers=headers, places=places, redact_values=False)
    values = {point['parameter']: point.get('value', '') for point in discovered['points']}
    return {"params": list(values.keys()), "values": values, "points": discovered['points'], "count": discovered['count'], "engine": "sqlmap-injection-point-discovery"}


def probe_point(url: str = "", parameter: str = "", place: str = "GET", injected_value: str = "[SQLMAP_PAYLOAD]", data: str = "", cookie: str = "", headers: dict[str, str] | None = None, append: bool = True):
    return build_request(url, place, parameter, injected_value, method="POST" if place.upper() in ("POST", "JSON") else "GET", data=data, cookie=cookie, headers=headers, append=append)


def offline_toolkit():
    return {"stats": stats(), "manifest": manifest(), "tampers": list_tampers(), "note": "sqlmap detection corpus + tamper scripts loaded", "executed": False}


__all__ = [
    "scan", "list_payloads", "stats", "tests", "errors", "boundaries", "manifest", "upstream_manifest", "conversion_coverage",
    "cleanup_payload", "apply_boundary",
    "fingerprint", "fingerprint_errors",
    "list_tampers", "tamper", "apply_tampers", "apply_tamper",
    "discover_points", "build_request",
    "list_dbms", "list_plugin_dbms", "plugin_info", "get_query", "enum_plan",
    "extract_length_boolean", "extract_string_boolean",
    "build_union_payload", "find_column_count", "extraction_plan",
    "analyze_pair", "confirm_boolean", "analyze_response",
    "normalize_options", "parse_target_list", "parse_config", "parse_raw_request", "plan_workflow", "execute_workflow", "session_snapshot",
    "session_create", "session_append", "session_store_snapshot", "session_export", "session_close", "session_list",
    "extract_params", "probe_point", "offline_toolkit",
]
