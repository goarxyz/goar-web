"""Browser/Pyodide adaptation of SQLMap CLI/API workflow control.

This module does not execute SQL or shell commands. It normalizes a useful
subset of sqlmap.py/sqlmapapi.py options into deterministic in-memory plans
that the existing Files tools and agent can consume.
"""
from __future__ import annotations

import json
import re
import time
from typing import Any


NATIVE_GAPS = (
    "desktop CLI process management",
    "persistent SQLite session files",
    "unrestricted multi-target concurrency",
    "native Tor/local proxy sockets",
    "backend filesystem and OS takeover",
    "interactive SQL shell",
)


def _redact(value: Any) -> str:
    text = str(value or "")
    text = re.sub(r"(?i)(authorization|cookie|set-cookie|x-api-key|token|secret|password)(\s*[=:]\s*)[^,;}\n]+", r"\1\2[redacted]", text)
    text = re.sub(r"(?i)\b(?:secret|token|password)[_-][A-Za-z0-9._~-]+", "[redacted]", text)
    return text


def parse_target_list(target_text: str = "", max_targets: int = 100) -> dict[str, Any]:
    """Parse bounded newline/CSV target input without network access."""
    raw = str(target_text or "")[:200000]
    seen = set(); targets=[]
    for token in re.split(r'[\s,]+', raw):
        token = token.strip()
        if not token or token.startswith('#'):
            continue
        token = _redact(token)
        if token not in seen:
            seen.add(token); targets.append(token)
        if len(targets) >= max(1, min(int(max_targets or 100), 1000)):
            break
    return {'ok': True, 'targets': targets, 'count': len(targets), 'truncated': len(seen) >= max(1, min(int(max_targets or 100), 1000)), 'executed': False}


def normalize_options(options: dict[str, Any] | None = None, argv: list[str] | None = None) -> dict[str, Any]:
    """Normalize browser-safe SQLMap-like options without running a target."""
    src = dict(options or {})
    args = list(argv or [])
    aliases = {
        "-u": "url", "--url": "url", "-p": "parameter", "--parameter": "parameter",
        "--data": "data", "--cookie": "cookie", "--headers": "headers", "--technique": "techniques",
        "--level": "level", "--risk": "risk", "--dbms": "dbms", "--tamper": "tamper_scripts",
        "--timeout": "timeout_ms", "--retries": "retries", "--proxy": "route",
    }
    i = 0
    while i < len(args):
        key = aliases.get(args[i])
        if key and i + 1 < len(args):
            src[key] = args[i + 1]
            i += 2
        else:
            i += 1
    if isinstance(src.get('url'), str) and '\n' in src.get('url', ''):
        src['targets'] = parse_target_list(src['url'])['targets']
        src['url'] = src['targets'][0] if src['targets'] else ''
    src.setdefault("url", "")
    src.setdefault("parameter", "")
    src.setdefault("method", "POST" if src.get("data") else "GET")
    src.setdefault("techniques", "BEUSTQ")
    src.setdefault("level", 1)
    src.setdefault("risk", 1)
    src.setdefault("timeout_ms", 8000)
    src.setdefault("retries", 0)
    src.setdefault("route", "auto")
    src["level"] = max(1, min(int(src["level"] or 1), 5))
    src["risk"] = max(1, min(int(src["risk"] or 1), 3))
    src["timeout_ms"] = max(1000, min(int(src["timeout_ms"] or 8000), 120000))
    src["retries"] = max(0, min(int(src["retries"] or 0), 5))
    src["headers"] = _redact(src.get("headers", ""))
    src["cookie"] = _redact(src.get("cookie", ""))
    src["route"] = src["route"] if src["route"] in ("auto", "direct", "proxy") else "auto"
    return src


def parse_openapi_document(document: str | dict[str, Any] = "", max_operations: int = 200) -> dict[str, Any]:
    """Normalize a bounded OpenAPI JSON document into SQLMap-style request targets."""
    try:
        spec = document if isinstance(document, dict) else json.loads(str(document or "")[:200000])
    except (TypeError, ValueError):
        return {"ok": False, "error": "OpenAPI document must be valid JSON", "targets": [], "count": 0, "executed": False}
    if not isinstance(spec, dict) or not isinstance(spec.get("paths"), dict):
        return {"ok": False, "error": "OpenAPI document requires a paths object", "targets": [], "count": 0, "executed": False}
    servers = spec.get("servers") or [{}]
    base_urls = [str(x.get("url", "")).rstrip("/") for x in servers if isinstance(x, dict) and x.get("url")]
    if not base_urls:
        base_urls = [""]
    targets: list[dict[str, Any]] = []
    methods = {"get", "post", "put", "patch", "delete", "head", "options", "trace"}
    for path, item in spec["paths"].items():
        if not isinstance(item, dict):
            continue
        common = item.get("parameters") if isinstance(item.get("parameters"), list) else []
        for method, operation in item.items():
            if str(method).lower() not in methods or not isinstance(operation, dict):
                continue
            params = list(common) + (operation.get("parameters") if isinstance(operation.get("parameters"), list) else [])
            names = [str(p.get("name")) for p in params if isinstance(p, dict) and p.get("name") and p.get("in") in ("query", "path", "header", "cookie")]
            body_type = "json" if isinstance(operation.get("requestBody"), dict) else "form"
            for base in base_urls:
                targets.append({"url": f"{base}{path}", "method": str(method).upper(), "parameters": names, "data_type": body_type, "operation_id": str(operation.get("operationId", ""))})
                if len(targets) >= max(1, min(int(max_operations or 200), 1000)):
                    return {"ok": True, "targets": targets, "count": len(targets), "truncated": True, "executed": False}
    return {"ok": True, "targets": targets, "count": len(targets), "truncated": False, "executed": False}


def parse_config(config_text: str = "") -> dict[str, Any]:
    """Parse bounded SQLMap-style key=value configuration text."""
    values: dict[str, Any] = {}
    for line in str(config_text or "")[:100000].splitlines():
        line = line.strip()
        if not line or line.startswith(('#', ';', '[')) or '=' not in line:
            continue
        key, value = line.split('=', 1)
        key = key.strip().lstrip('-').replace('-', '_')
        value = value.strip().strip('"').strip("'")
        if key in ('level', 'risk', 'timeout_ms', 'retries', 'max_tests', 'sleeptime'):
            try:
                value = int(value)
            except ValueError:
                continue
        elif value.lower() in ('true', 'false'):
            value = value.lower() == 'true'
        values[key] = _redact(value) if key in ('headers', 'cookie', 'proxy', 'api_key', 'token') else value
    return {'ok': True, 'options': values, 'count': len(values), 'executed': False}


def parse_raw_request(raw: str = "") -> dict[str, Any]:
    """Parse a bounded raw HTTP request template without network access."""
    text = str(raw or "")[:200000]
    head, _, body = text.partition("\n\n")
    lines = [line.rstrip("\r") for line in head.splitlines() if line.strip()]
    if not lines:
        return {"ok": False, "error": "empty raw request", "executed": False}
    first = lines[0].split()
    method = first[0].upper() if first else "GET"
    target = first[1] if len(first) > 1 else "/"
    headers: dict[str, str] = {}
    for line in lines[1:]:
        if ":" in line:
            k, v = line.split(":", 1)
            headers[k.strip()] = _redact(v.strip())
    host = headers.get("Host", "")
    url = target if target.startswith("http") else (f"https://{host}{target}" if host else target)
    return {"ok": True, "method": method, "url": _redact(url), "headers": headers, "body": _redact(body[:100000]), "executed": False}


def plan_workflow(options: dict[str, Any] | None = None, argv: list[str] | None = None, raw_request: str = "", config_text: str = "") -> dict[str, Any]:
    """Build a deterministic, non-executing browser workflow plan."""
    parsed_config = parse_config(config_text) if config_text else None
    merged_options = {**(parsed_config or {}).get('options', {}), **(options or {})}
    cfg = normalize_options(merged_options, argv)
    request_template = parse_raw_request(raw_request) if raw_request else None
    if request_template and request_template.get('ok'):
        if not cfg.get('method') or cfg.get('method') == ('POST' if cfg.get('data') else 'GET'):
            cfg['method'] = request_template['method']
        if not cfg.get('url'):
            cfg['url'] = request_template['url']
        if not cfg.get('headers'):
            cfg['headers'] = request_template['headers']
        if not cfg.get('data'):
            cfg['data'] = request_template['body']
    stages = [
        {"name": "target", "status": "ready" if cfg.get("url") else "missing", "operation": "validate target"},
        {"name": "discover", "status": "planned", "operation": "discover request injection points"},
        {"name": "fingerprint", "status": "planned", "operation": "fingerprint DBMS/WAF from responses"},
        {"name": "detect", "status": "planned", "operation": "run selected bounded techniques"},
        {"name": "extract", "status": "planned", "operation": "extract only when explicitly selected"},
        {"name": "report", "status": "planned", "operation": "return redacted structured evidence"},
    ]
    if not cfg.get("url"):
        stages[1:5] = [{**stage, "status": "blocked"} for stage in stages[1:5]]
    return {
        "ok": bool(cfg.get("url")),
        "config": cfg,
        "request_template": request_template,
        "stages": stages,
        "session": {"id": f"goar-sqlmap-{int(time.time() * 1000)}", "persistent": False, "state": "planned"},
        "native_gaps": list(NATIVE_GAPS),
        "executed": False,
        "engine": "sqlmap-browser-workflow-adapter",
    }


def session_snapshot(plan: dict[str, Any] | None = None) -> dict[str, Any]:
    """Return a safe in-memory session snapshot for agent/UI state."""
    plan = dict(plan or {})
    session = dict(plan.get("session") or {})
    session["persistent"] = False
    session["state"] = session.get("state") or "planned"
    return {"session": session, "stages": list(plan.get("stages") or []), "executed": bool(plan.get("executed")), "native_gaps": list(NATIVE_GAPS)}


async def execute_workflow(options: dict[str, Any] | None = None, argv: list[str] | None = None, raw_request: str = "", config_text: str = "", dry_run: bool = True, max_tests: int = 40) -> dict[str, Any]:
    """Execute the converted scan stage only when explicitly requested.

    The default is a non-executing plan. Explicit execution delegates to the
    existing SQLMap scan callable, which owns the shared Goar transport chain.
    """
    plan = plan_workflow(options, argv, raw_request, config_text)
    if dry_run or not plan.get('ok'):
        return plan
    from .scan import scan
    from .session import session_append, session_create
    cfg = dict(plan['config'])
    sid = plan['session']['id']
    session_create(sid, cfg)
    allowed = ('url', 'parameter', 'method', 'data', 'techniques', 'level', 'risk', 'dbms', 'sleeptime', 'user_agent', 'headers', 'cookie', 'timeout_ms', 'retries', 'retry_statuses', 'route', 'tamper_scripts', 'parameter_include', 'parameter_exclude', 'comparison', 'string_match', 'not_string', 'status_match', 'include_attempts', 'include_response_body', 'preview_chars', 'raw_request', 'session_id', 'data_type')
    kwargs = {k: cfg[k] for k in allowed if k in cfg}
    kwargs['max_tests'] = max(1, min(int(max_tests or 40), 200))
    result = await scan(**kwargs)
    session_append(sid, {'stage': 'scan', 'result': result})
    return {**plan, 'executed': True, 'session': {**plan['session'], 'state': 'completed'}, 'result': result}
