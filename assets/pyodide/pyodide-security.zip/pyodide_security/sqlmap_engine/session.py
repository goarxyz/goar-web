"""Bounded in-memory SQLMap session/output adaptation for Pyodide workers."""
from __future__ import annotations

import json
import re
import time
from typing import Any


class SessionStore:
    """Deterministic worker-local session store; never writes to the host filesystem."""

    def __init__(self, max_sessions: int = 32, max_records: int = 500):
        self.max_sessions = max(1, min(int(max_sessions or 32), 256))
        self.max_records = max(1, min(int(max_records or 500), 5000))
        self._sessions: dict[str, dict[str, Any]] = {}

    @staticmethod
    def _safe(value: Any) -> Any:
        if isinstance(value, dict):
            return {str(k): SessionStore._safe(v) for k, v in value.items()}
        if isinstance(value, list):
            return [SessionStore._safe(v) for v in value[:100]]
        if isinstance(value, str):
            value = re.sub(r"(?i)(authorization|cookie|set-cookie|x-api-key|token|secret|password)(\s*[=:]\s*)[^,;}\n]+", r"\1\2[redacted]", value)
            value = re.sub(r"(?i)\b(?:secret|token|password)[_-][A-Za-z0-9._~-]+", "[redacted]", value)
            return value[:100000]
        return value

    def create(self, session_id: str, config: dict[str, Any] | None = None) -> dict[str, Any]:
        sid = str(session_id or f"goar-sqlmap-{int(time.time() * 1000)}")[:200]
        if len(self._sessions) >= self.max_sessions and sid not in self._sessions:
            oldest = next(iter(self._sessions))
            del self._sessions[oldest]
        self._sessions[sid] = {"id": sid, "config": self._safe(config or {}), "records": [], "created_ms": int(time.time() * 1000), "persistent": False}
        return self.snapshot(sid)

    def append(self, session_id: str, record: dict[str, Any]) -> dict[str, Any]:
        if session_id not in self._sessions:
            self.create(session_id)
        records = self._sessions[session_id]["records"]
        records.append(self._safe(record))
        del records[:-self.max_records]
        return self.snapshot(session_id)

    def snapshot(self, session_id: str) -> dict[str, Any]:
        if session_id not in self._sessions:
            return {"ok": False, "error": "unknown session", "persistent": False}
        return self._safe(self._sessions[session_id])

    def export_json(self, session_id: str) -> str:
        return json.dumps(self.snapshot(session_id), sort_keys=True, separators=(",", ":"))

    def close(self, session_id: str) -> dict[str, Any]:
        existed = str(session_id) in self._sessions
        self._sessions.pop(str(session_id), None)
        return {"ok": existed, "session_id": str(session_id), "persistent": False}

    def list_sessions(self) -> list[dict[str, Any]]:
        return [{"id": sid, "records": len(item["records"]), "persistent": False} for sid, item in self._sessions.items()]


_DEFAULT_STORE = SessionStore()


def session_create(session_id: str = "", config: dict[str, Any] | None = None) -> dict[str, Any]:
    return _DEFAULT_STORE.create(session_id, config)


def session_append(session_id: str, record: dict[str, Any]) -> dict[str, Any]:
    return _DEFAULT_STORE.append(session_id, record)


def session_snapshot(session_id: str) -> dict[str, Any]:
    return _DEFAULT_STORE.snapshot(session_id)


def session_export(session_id: str) -> str:
    return _DEFAULT_STORE.export_json(session_id)


def session_close(session_id: str) -> dict[str, Any]:
    return _DEFAULT_STORE.close(session_id)


def session_list() -> list[dict[str, Any]]:
    return _DEFAULT_STORE.list_sessions()
