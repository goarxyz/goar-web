"""Load sqlmap XML-derived payload/error/boundary data."""
from __future__ import annotations

import hashlib
import json
from functools import lru_cache
from pathlib import Path
from typing import Any

_DATA = Path(__file__).resolve().parent / "data" / "sqlmap_payloads.json"
_UPSTREAM = Path(__file__).resolve().parent / "data" / "upstream_file_manifest.json"


@lru_cache(maxsize=1)
def load() -> dict[str, Any]:
    return json.loads(_DATA.read_text(encoding="utf-8"))


def tests(
    techniques: str = "boolean_blind,error_based,time_blind,union_query,stacked_queries",
    level: int = 1,
    risk: int = 1,
    dbms: str = "",
    search: str = "",
    offset: int = 0,
    limit: int = 500,
) -> list[dict[str, Any]]:
    want = {t.strip().lower() for t in techniques.split(",") if t.strip()}
    out = []
    for t in load()["tests"]:
        if t["technique"] not in want:
            continue
        if int(t.get("level") or 1) > int(level):
            continue
        if int(t.get("risk") or 1) > int(risk):
            continue
        if search and search.lower() not in (str(t.get('title', '')) + ' ' + str(t.get('id', ''))).lower():
            continue
        if dbms:
            dlist = [d.lower() for d in (t.get("dbms") or [])]
            if dlist and dbms.lower() not in " ".join(dlist):
                # allow tests with no dbms constraint
                if dlist:
                    continue
        out.append(t)
    start = max(0, int(offset or 0))
    return out[start:start + max(1, min(int(limit or 500), 2000))]


@lru_cache(maxsize=1)
def upstream_manifest() -> dict[str, Any]:
    data = json.loads(_UPSTREAM.read_text(encoding="utf-8"))
    counts = {}
    for row in data.get("rows", []):
        status = row.get("status", "open")
        counts[status] = counts.get(status, 0) + 1
    return {"repository": data.get("repository"), "revision": data.get("revision"), "file_count": data.get("file_count", 0), "python_count": data.get("python_count", 0), "status_counts": counts, "rows": data.get("rows", [])}


def conversion_coverage(status: str = "", prefix: str = "", offset: int = 0, limit: int = 500) -> dict[str, Any]:
    rows = upstream_manifest().get("rows", [])
    if status:
        rows = [row for row in rows if row.get("status") == status]
    if prefix:
        rows = [row for row in rows if row.get("upstream_file", "").startswith(prefix)]
    start = max(0, int(offset or 0))
    bounded = rows[start:start + max(1, min(int(limit or 500), 2000))]
    return {"repository": upstream_manifest().get("repository"), "revision": upstream_manifest().get("revision"), "total": len(rows), "offset": start, "returned": len(bounded), "rows": bounded, "complete": all(row.get("status") in ("direct", "grouped", "asset", "reference", "native_adaptation") for row in rows)}


def manifest() -> dict[str, Any]:
    raw = _DATA.read_bytes()
    data = load()
    return {
        'path': str(_DATA),
        'sha256': hashlib.sha256(raw).hexdigest(),
        'bytes': len(raw),
        'tests': len(data.get('tests', [])),
        'errors': len(data.get('errors', [])),
        'boundaries': len(data.get('boundaries', [])),
        'source': 'sqlmapproject/sqlmap/data/xml adapted JSON',
        'upstream': {k: upstream_manifest()[k] for k in ('repository', 'revision', 'file_count', 'python_count', 'status_counts')},
    }


def errors() -> list[dict[str, Any]]:
    return list(load()["errors"])


def boundaries(level: int = 1) -> list[dict[str, Any]]:
    out = []
    for b in load()["boundaries"]:
        try:
            bl = int(b.get("level") or 1)
        except ValueError:
            bl = 1
        if bl <= int(level):
            out.append(b)
    return out


def stats() -> dict[str, Any]:
    data = load()
    by = {}
    for t in data["tests"]:
        by[t["technique"]] = by.get(t["technique"], 0) + 1
    return {
        "tests": len(data["tests"]),
        "by_technique": by,
        "errors": len(data["errors"]),
        "boundaries": len(data["boundaries"]),
        "source": "sqlmapproject/sqlmap data/xml/",
    }
