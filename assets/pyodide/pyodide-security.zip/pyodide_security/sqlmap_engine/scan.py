"""
SQL injection detection — converted from sqlmapproject/sqlmap.

Source: https://github.com/sqlmapproject/sqlmap

Ports:
  - data/xml/payloads/*.xml  → 363 tests (boolean, error, time, union, stacked, inline)
  - data/xml/errors.xml      → 174 DBMS error signatures
  - data/xml/boundaries.xml  → 53 prefix/suffix boundaries
  - lib/core/agent.py        → placeholder cleanup + boundary application

Technique detection:
  - error-based: errors.xml regexp match on response body
  - boolean-blind: true vs false payload response comparison (len/status/content)
  - time-based: response time delta vs sleeptime (best-effort in browser)
  - union: order-by / column-count heuristics

Full extraction (DB dump, file read, OS shell) is out of scope for WASM —
this engine focuses on detection parity with sqlmap's test payload corpus.
"""
from __future__ import annotations

import re
import time
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse
import json

from .._http import http_request, redact_url
from .. import policy
from .agent import apply_boundary, cleanup_payload
from .tampers import apply_tampers
from .loader import boundaries, errors, stats, tests
from .payloads import list_payloads as _corpus_list_payloads


# stype mapping from sqlmap
STYPE = {
    1: "boolean_blind",
    2: "error_based",
    3: "union_query",
    4: "stacked_queries",
    5: "time_blind",
    6: "inline_query",
}


def _json_paths(value: Any, prefix: str = "") -> list[str]:
    """Return deterministic dotted paths for scalar JSON leaves."""
    paths: list[str] = []
    if isinstance(value, dict):
        for key, child in value.items():
            path = f"{prefix}.{key}" if prefix else str(key)
            paths.extend(_json_paths(child, path))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            paths.extend(_json_paths(child, f"{prefix}[{index}]"))
    elif prefix:
        paths.append(prefix)
    return paths


def _json_set_path(value: Any, path: str, replacement: Any) -> bool:
    """Set a dotted JSON path, including list indexes, in place."""
    tokens = [x for x in re.split(r"\.|(?=\[)|(?<=\])", path) if x]
    current = value
    for index, token in enumerate(tokens):
        if token.startswith("[") and token.endswith("]"):
            if not isinstance(current, list):
                return False
            key: Any = int(token[1:-1])
        else:
            key = token
        if index == len(tokens) - 1:
            try:
                current[key] = replacement
                return True
            except (IndexError, KeyError, TypeError, ValueError):
                return False
        try:
            current = current[key]
        except (IndexError, KeyError, TypeError, ValueError):
            return False
    return False


def _inject_param(url: str, param: str, value: str, method: str, data: str, data_type: str = "form") -> tuple[str, str]:
    """Return (url, body) with param set to value for query/form/JSON bodies."""
    if method.upper() == "POST":
        dtype = str(data_type or '').lower()
        if dtype in ('multipart', 'multipart/form-data'):
            marker = re.compile(r'(name=["\']' + re.escape(str(param)) + r'["\'][^\r\n]*\r?\n\r?\n)(.*?)(?=\r?\n--)', re.I | re.S)
            replaced, count = marker.subn(lambda m: m.group(1) + str(value), str(data or ''), count=1)
            if count:
                return url, replaced
        if dtype in ('json', 'application/json') or str(data or '').lstrip().startswith(('{', '[')):
            try:
                obj = json.loads(data or '{}')
                if isinstance(obj, (dict, list)) and _json_set_path(obj, param, value):
                    return url, json.dumps(obj, separators=(',', ':'))
            except (TypeError, ValueError):
                pass
        q = dict(parse_qsl(data or "", keep_blank_values=True))
        if param not in q and data:
            q = dict(parse_qsl(data, keep_blank_values=True))
        q[param] = value
        return url, urlencode(q, doseq=True)
    p = urlparse(url)
    q = dict(parse_qsl(p.query, keep_blank_values=True))
    q[param] = value
    return urlunparse(p._replace(query=urlencode(q, doseq=True))), data or ""


def _match_errors(body: str) -> list[dict[str, str]]:
    hits = []
    for err in errors():
        try:
            if re.search(err["regexp"], body or "", re.I | re.S):
                hits.append({"dbms": err["dbms"], "fork": err.get("fork") or "", "regexp": err["regexp"]})
        except re.error:
            continue
    return hits


def _content_ratio(a: str, b: str) -> float:
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    # quick similarity: length + shared prefix
    la, lb = len(a), len(b)
    if la == 0 or lb == 0:
        return 0.0
    ratio_len = min(la, lb) / max(la, lb)
    n = min(200, la, lb)
    shared = sum(1 for i in range(n) if a[i] == b[i]) / max(n, 1)
    return 0.5 * ratio_len + 0.5 * shared


def _body_headers(headers: dict[str, str], data_type: str) -> dict[str, str]:
    """Return request headers with a safe body Content-Type default."""
    result = dict(headers)
    if not any(str(k).lower() == 'content-type' for k in result):
        dtype = str(data_type or '').lower()
        result['Content-Type'] = 'application/json' if dtype in ('json', 'application/json') else ('multipart/form-data' if dtype in ('multipart', 'multipart/form-data') else 'application/x-www-form-urlencoded')
    return result


def _parse_headers(raw: str | dict | None) -> dict[str, str]:
    if isinstance(raw, dict):
        return {str(k): str(v) for k, v in raw.items()}
    text = str(raw or "").strip()
    if not text:
        return {}
    if text.startswith("{"):
        import json
        value = json.loads(text)
        if not isinstance(value, dict):
            raise ValueError("headers JSON must be an object")
        return {str(k): str(v) for k, v in value.items()}
    result: dict[str, str] = {}
    for line in text.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            if key.strip():
                result[key.strip()] = value.strip()
    return result


def _redact_text(value: Any, limit: int = 400) -> str:
    text = str(value or "")
    text = re.sub(r"(?i)(authorization|cookie|set-cookie|x-api-key|api[_-]?key|token|secret|password)(\s*[=:]\s*)[^,;}\n]+", r"\1\2[redacted]", text)
    text = re.sub(r"(?i)(apikey|access_token|auth|token|secret|password)=([^&\s]+)", r"\1=[redacted]", text)
    text = re.sub(r"(?i)\b(?:secret|token|password)[_-][A-Za-z0-9._~-]+", "[redacted]", text)
    return text[: max(0, int(limit))]


async def _request_with_controls(
    target: str,
    method: str,
    headers: dict[str, str],
    body: str = "",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    attempts: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    try:
        retry_codes = {int(x.strip()) for x in str(retry_statuses or "").split(",") if x.strip().isdigit()}
    except Exception:
        retry_codes = {408, 429, 500, 502, 503, 504}
    use_proxy = True if route == "proxy" else False if route == "direct" else None
    last: dict[str, Any] = {}
    for index in range(max(0, min(int(retries or 0), 5)) + 1):
        last = await http_request(
            target,
            method=method,
            headers=headers,
            body=body if method.upper() not in ("GET", "HEAD") else None,
            timeout_ms=max(1000, min(int(timeout_ms or 8000), 120000)),
            use_proxy=use_proxy,
        )
        if attempts is not None:
            attempts.append({
                "attempt": index + 1,
                "method": method.upper(),
                "url": redact_url(target),
                "status": last.get("status"),
                "ok": last.get("ok"),
                "transport": last.get("transport"),
                "elapsed_ms": last.get("elapsed_ms"),
                "error": _redact_text(last.get("error"), 240),
            })
        status = int(last.get("status") or 0)
        if last.get("ok") or status not in retry_codes:
            break
    return last


async def scan(
    url: str,
    parameter: str = "",
    method: str = "GET",
    data: str = "",
    techniques: str = "BEUSTQ",
    level: int = 1,
    risk: int = 1,
    dbms: str = "",
    sleeptime: int = 3,
    max_tests: int = 40,
    user_agent: str = "pyodide-security/sqlmap/1.0",
    headers: str | dict[str, str] = "",
    cookie: str = "",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    tamper_scripts: str = "",
    parameter_include: str = "",
    parameter_exclude: str = "",
    comparison: str = "auto",
    string_match: str = "",
    not_string: str = "",
    status_match: int = 0,
    include_attempts: bool = True,
    include_response_body: bool = False,
    preview_chars: int = 400,
    raw_request: str = "",
    dry_run: bool = False,
    session_id: str = "",
    data_type: str = "form",
) -> dict[str, Any]:
    """
    Detect SQLi using real sqlmap payload corpus.

    techniques: sqlmap-style letter codes
      B = boolean_blind, E = error_based, U = union_query,
      S = stacked_queries, T = time_blind, Q = inline_query
    level / risk: sqlmap level (1-5) and risk (1-3)
    """
    if raw_request:
        from .workflow import parse_raw_request, plan_workflow
        parsed = parse_raw_request(raw_request)
        if not parsed.get('ok'):
            return {"ok": False, "error": parsed.get('error', 'invalid raw request'), "engine": "sqlmap", "executed": False}
        if not url:
            url = parsed.get('url', '')
        if not method or method.upper() == 'GET':
            method = parsed.get('method', method)
        if not headers:
            headers = parsed.get('headers', {})
        if not data:
            data = parsed.get('body', '')
    if dry_run:
        from .workflow import plan_workflow
        plan = plan_workflow({"url": url, "parameter": parameter, "method": method, "data": data, "headers": headers, "cookie": cookie, "techniques": techniques, "level": level, "risk": risk, "timeout_ms": timeout_ms, "retries": retries, "route": route,             "tamper_scripts": tamper_scripts, "data_type": data_type}, raw_request=raw_request)
        return {**plan, "engine": "sqlmap", "session_id": session_id or plan.get('session', {}).get('id')}

    err = policy.check_url_for_active(url)
    if err:
        return {"ok": False, "error": err, "engine": "sqlmap"}

    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    # map letter codes → technique names
    tech_map = {
        "B": "boolean_blind",
        "E": "error_based",
        "U": "union_query",
        "S": "stacked_queries",
        "T": "time_blind",
        "Q": "inline_query",
    }
    codes = (techniques or "BEUSTQ").upper()
    tech_names = [tech_map[c] for c in codes if c in tech_map]
    if not tech_names:
        tech_names = ["boolean_blind", "error_based", "time_blind"]

    request_headers = _parse_headers(headers)
    request_headers.setdefault("User-Agent", user_agent)
    if cookie:
        request_headers["Cookie"] = str(cookie)
    method = (method or "GET").upper()
    attempts: list[dict[str, Any]] = []
    include_codes = {x.strip() for x in str(parameter_include or "").split(",") if x.strip()}
    exclude_re = re.compile(parameter_exclude) if str(parameter_exclude or "").strip() else None

    # resolve parameter
    p = urlparse(url)
    params = dict(parse_qsl(p.query, keep_blank_values=True))
    if method == "POST":
        if str(data_type or '').lower() in ('json', 'application/json') or str(data or '').lstrip().startswith(('{', '[')):
            try:
                parsed_json = json.loads(data or '{}')
                json_candidates = _json_paths(parsed_json)
            except (TypeError, ValueError):
                json_candidates = []
            if json_candidates:
                params = {name: '1' for name in json_candidates}
            else:
                params = dict(parse_qsl(data or "", keep_blank_values=True)) or params
        else:
            params = dict(parse_qsl(data or "", keep_blank_values=True)) or params
    param = parameter or (next(iter(params)) if params else "id")
    candidates = [str(x) for x in params]
    if include_codes:
        candidates = [x for x in candidates if x in include_codes]
    if exclude_re:
        candidates = [x for x in candidates if not exclude_re.search(x)]
    if parameter and candidates and parameter not in candidates:
        return {"ok": False, "error": "parameter excluded by selection", "engine": "sqlmap", "parameter": parameter, "policy": policy.status()}
    if not parameter and candidates:
        param = candidates[0]
    if method == "POST" and str(data_type or '').lower() in ('json', 'application/json'):
        try:
            obj = json.loads(data or '{}')
            if isinstance(obj, (dict, list)):
                original = '1'
                for path in [param]:
                    parts = [x for x in re.split(r"\.|(?=\[)|(?<=\])", path) if x]
                    cur = obj
                    try:
                        for token in parts:
                            cur = cur[int(token[1:-1])] if token.startswith('[') else cur[token]
                        original = cur
                    except (IndexError, KeyError, TypeError, ValueError):
                        pass
            else:
                original = '1'
        except (TypeError, ValueError):
            original = '1'
    else:
        original = params.get(param, "1")

    # baseline
    base_url, base_body = _inject_param(url, param, original, method, data, data_type=data_type)
    t0 = time.time()
    if method == "POST":
        base = await _request_with_controls(
            base_url,
            method="POST",
            headers=_body_headers(request_headers, data_type),
            body=base_body,
            timeout_ms=timeout_ms, retries=retries, retry_statuses=retry_statuses, route=route, attempts=attempts,
        )
    else:
        base = await _request_with_controls(base_url, method="GET", headers=request_headers, timeout_ms=timeout_ms, retries=retries, retry_statuses=retry_statuses, route=route, attempts=attempts)
    base_elapsed = time.time() - t0
    base_text = base.get("body") or ""
    base_status = int(base.get("status") or 0)
    base_len = len(base_text)

    corpus = tests(
        techniques=",".join(tech_names),
        level=int(level),
        risk=int(risk),
        dbms=dbms,
    )
    # prioritize lower level/risk
    corpus.sort(key=lambda t: (t.get("level", 1), t.get("risk", 1)))
    corpus = corpus[: max(1, min(int(max_tests), 120))]

    bnds = boundaries(level=int(level))
    # always include empty boundary
    if not any(not (b.get("prefix") or b.get("suffix")) for b in bnds):
        bnds = [{"prefix": "", "suffix": "", "level": "1"}] + bnds
    bnds = bnds[: max(1, min(6, int(level) + 2))]

    findings: list[dict[str, Any]] = []
    tested = 0
    dbms_hits: dict[str, int] = {}

    for test in corpus:
        if not policy.can_request():
            break
        tech = test["technique"]
        payload_templates = test.get("payloads") or []
        if not payload_templates and test.get("vector"):
            payload_templates = [test["vector"]]
        if not payload_templates:
            continue

        for boundary in bnds:
            if not policy.can_request():
                break
            if tested >= int(max_tests):
                break

            prefix = boundary.get("prefix") or ""
            suffix = boundary.get("suffix") or ""
            raw = payload_templates[0]
            injected = apply_boundary(raw, prefix, suffix, original=str(original))
            if tamper_scripts:
                injected = apply_tampers(injected, tamper_scripts).get("payload", injected)

            test_url, test_body = _inject_param(url, param, injected, method, data, data_type=data_type)
            t1 = time.time()
            if method == "POST":
                resp = await _request_with_controls(
                    test_url,
                    method="POST",
                    headers=_body_headers(request_headers, data_type),
                    body=test_body,
                    timeout_ms=timeout_ms, retries=retries, retry_statuses=retry_statuses, route=route, attempts=attempts,
                )
            else:
                resp = await _request_with_controls(test_url, method="GET", headers=request_headers, timeout_ms=timeout_ms, retries=retries, retry_statuses=retry_statuses, route=route, attempts=attempts)
            elapsed = time.time() - t1
            body = resp.get("body") or ""
            status = int(resp.get("status") or 0)
            tested += 1

            evidence: list[str] = []
            confidence = 0
            dbms_found = None

            # --- error-based ---
            if tech == "error_based" or True:
                err_hits = _match_errors(body)
                # only count new errors not in baseline
                base_errs = {e["regexp"] for e in _match_errors(base_text)}
                new_errs = [e for e in err_hits if e["regexp"] not in base_errs]
                if new_errs:
                    evidence.append(f"error_signature:{new_errs[0]['dbms']}")
                    confidence = max(confidence, 90)
                    dbms_found = new_errs[0]["dbms"]
                    dbms_hits[dbms_found] = dbms_hits.get(dbms_found, 0) + 1

            # --- boolean-blind ---
            if tech == "boolean_blind":
                # true payload already sent; craft false counterpart
                false_raw = raw
                for a, b in (("1=1", "1=2"), ("1=1", "0=1"), ("AND", "AND NOT")):
                    if a in false_raw:
                        false_raw = false_raw.replace(a, b, 1)
                        break
                else:
                    false_raw = raw + " AND 1=2"
                false_inj = apply_boundary(false_raw, prefix, suffix, original=str(original))
                if tamper_scripts:
                    false_inj = apply_tampers(false_inj, tamper_scripts).get("payload", false_inj)
                false_url, false_body = _inject_param(url, param, false_inj, method, data, data_type=data_type)
                if policy.can_request():
                    if method == "POST":
                        fresp = await _request_with_controls(
                            false_url,
                            method="POST",
                            headers=_body_headers(request_headers, data_type),
                            body=false_body,
                            timeout_ms=timeout_ms, retries=retries, retry_statuses=retry_statuses, route=route, attempts=attempts,
                        )
                    else:
                        fresp = await _request_with_controls(false_url, method="GET", headers=request_headers, timeout_ms=timeout_ms, retries=retries, retry_statuses=retry_statuses, route=route, attempts=attempts)
                    tested += 1
                    fbody = fresp.get("body") or ""
                    # true response should differ from false
                    ratio_tf = _content_ratio(body, fbody)
                    ratio_base_true = _content_ratio(base_text, body)
                    ratio_base_false = _content_ratio(base_text, fbody)
                    forced_string = bool(string_match and string_match in body)
                    forced_not_string = bool(not_string and not_string not in fbody)
                    forced_status = bool(status_match and status == int(status_match))
                    if forced_string or forced_not_string or forced_status:
                        evidence.append("explicit_match_selector")
                        confidence = max(confidence, 80)
                    if (comparison or "auto").lower() == "lengths" and abs(len(body) - len(fbody)) > max(10, int(0.02 * base_len)):
                        evidence.append(f"length_compare:{len(body)}!={len(fbody)}")
                        confidence = max(confidence, 75)
                    if ratio_tf < 0.92 and abs(len(body) - len(fbody)) > max(10, int(0.02 * base_len)):
                        evidence.append(f"boolean_diff:true_false_ratio={ratio_tf:.2f}")
                        confidence = max(confidence, 75)
                    elif ratio_base_true > 0.95 and ratio_base_false < 0.90:
                        evidence.append("boolean_diff:true≈baseline,false≠baseline")
                        confidence = max(confidence, 70)

            # --- time-based ---
            if tech == "time_blind":
                # response time significantly above baseline + sleeptime*0.6
                threshold = base_elapsed + max(1.0, float(sleeptime) * 0.6)
                if elapsed >= threshold:
                    evidence.append(f"time_delay:{elapsed:.2f}s>=threshold:{threshold:.2f}s")
                    confidence = max(confidence, 65)
                    # retest once for confirmation
                    if policy.can_request() and confidence >= 65:
                        t2 = time.time()
                        if method == "POST":
                            r2 = await _request_with_controls(
                                test_url,
                                method="POST",
                                headers=_body_headers(request_headers, data_type),
                                body=test_body,
                                timeout_ms=timeout_ms, retries=retries, retry_statuses=retry_statuses, route=route, attempts=attempts,
                            )
                        else:
                            r2 = await _request_with_controls(test_url, method="GET", headers=request_headers, timeout_ms=timeout_ms, retries=retries, retry_statuses=retry_statuses, route=route, attempts=attempts)
                        e2 = time.time() - t2
                        tested += 1
                        if e2 >= threshold:
                            evidence.append(f"time_confirm:{e2:.2f}s")
                            confidence = max(confidence, 85)

            # --- union / stacked: look for status/length anomalies + errors ---
            if tech in ("union_query", "stacked_queries", "inline_query"):
                if status != base_status and status not in (0,):
                    evidence.append(f"status:{base_status}->{status}")
                    confidence = max(confidence, 40)
                if abs(len(body) - base_len) > max(80, int(base_len * 0.1)):
                    evidence.append(f"length:{base_len}->{len(body)}")
                    confidence = max(confidence, 45)

            if confidence >= 60 and evidence:
                findings.append({
                    "title": test.get("title"),
                    "technique": tech,
                    "stype": test.get("stype"),
                    "level": test.get("level"),
                    "risk": test.get("risk"),
                    "payload": injected[:200],
                    "boundary": {"prefix": prefix, "suffix": suffix},
                    "evidence": evidence,
                    "confidence": confidence,
                    "dbms": dbms_found,
                    "status": status,
                    "elapsed": round(elapsed, 3),
                })
                # for level 1, one solid finding per technique is enough to report
                if int(level) <= 1 and confidence >= 75:
                    break
        if tested >= int(max_tests):
            break

    findings.sort(key=lambda x: -x["confidence"])
    # primary dbms guess
    primary_dbms = None
    if dbms_hits:
        primary_dbms = max(dbms_hits, key=dbms_hits.get)

    return {
        "ok": True,
        "engine": "sqlmap",
        "session_id": session_id or "",
        "parameter": param,
        "method": method,
        "original": original,
        "level": int(level),
        "risk": int(risk),
        "techniques": tech_names,
        "baseline_status": base_status,
        "baseline_length": base_len,
        "baseline_elapsed": round(base_elapsed, 3),
        "tested": tested,
        "findings": findings,
        "finding_count": len(findings),
        "injectable": bool(findings),
        "dbms": primary_dbms,
        "dbms_hits": dbms_hits,
        "corpus_stats": stats(),
        "engine": "sqlmap",
        "version": "3.0-sqlmap",
        "equivalent": "sqlmapproject/sqlmap",
        "source": "https://github.com/sqlmapproject/sqlmap",
        "note": (
            "Detection uses real sqlmap payload/error/boundary XML. "
            "Data extraction, file R/W, and OS takeover are not ported (native sqlmap)."
        ),
        "policy": policy.status(),
        "request": {
            "method": method,
            "headers": {k: _redact_text(v, 180) for k, v in request_headers.items()},
            "timeout_ms": max(1000, min(int(timeout_ms or 8000), 120000)),
            "retries": max(0, min(int(retries or 0), 5)),
            "retry_statuses": sorted({int(x.strip()) for x in str(retry_statuses or '').split(',') if x.strip().isdigit()}),
            "route": route if route in ('auto', 'direct', 'proxy') else 'auto',
            "tamper_scripts": [x.strip() for x in str(tamper_scripts or '').split(',') if x.strip()],
            "comparison": comparison or 'auto',
        },
        "attempts": attempts if include_attempts else [],
        "response_preview": _redact_text(base_text, preview_chars) if include_response_body else None,
    }


def list_payloads(
    techniques: str = "error_based,boolean_blind",
    level: int = 1,
    risk: int = 1,
    limit: int = 30,
    search: str = "",
    offset: int = 0,
    include_vectors: bool = True,
) -> dict[str, Any]:
    # Preserve the historical comma-separated names while accepting SQLMap letter codes.
    normalized = str(techniques or "BEUSTQ")
    if "," in normalized:
        names = {x.strip().lower() for x in normalized.split(",") if x.strip()}
        code_map = {"b": "boolean_blind", "e": "error_based", "u": "union_query", "s": "stacked_queries", "t": "time_blind", "q": "inline_query"}
        normalized = "".join(k for k, v in code_map.items() if v in names)
    result = _corpus_list_payloads(normalized or "BEUSTQ", level=level, risk=risk, search=search, offset=offset, limit=limit, include_vectors=include_vectors)
    result["stats"] = stats()
    result["source"] = "sqlmap data/xml/payloads/"
    return result
