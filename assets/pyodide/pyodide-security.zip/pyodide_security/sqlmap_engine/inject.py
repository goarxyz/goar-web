"""Multi-place injection points — GET/POST/Cookie/Header/JSON (sqlmap -p model)."""

from __future__ import annotations

import json
import re
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from .._http import dump_cookie_header, parse_cookie_header


PLACES = ("GET", "POST", "COOKIE", "UA", "REFERER", "HOST", "HEADER", "JSON")


def discover_points(
    url: str,
    data: str = "",
    cookie: str = "",
    headers: dict[str, str] | None = None,
    places: str = "GET,POST,COOKIE,UA,REFERER,HOST,HEADER,JSON",
    parameter_include: str = "",
    parameter_exclude: str = "",
    max_points: int = 100,
    redact_values: bool = True,
) -> dict[str, Any]:
    """Discover injectable parameters across SQLMap-compatible request places.

    The original URL/data/cookie/headers arguments remain compatible. Additional
    controls are bounded and deterministic for browser/Pyodide execution.
    """
    headers = dict(headers or {})
    points: list[dict[str, Any]] = []
    selected_places = {p.strip().upper() for p in str(places or "").split(",") if p.strip()}
    if not selected_places:
        selected_places = set(PLACES)
    includes = {p.strip() for p in str(parameter_include or "").split(",") if p.strip()}
    exclude_re = re.compile(parameter_exclude) if str(parameter_exclude or "").strip() else None

    def add(point: dict[str, Any]) -> None:
        name = str(point.get("parameter") or "")
        place = str(point.get("place") or "").upper()
        if place not in selected_places or (includes and name not in includes) or (exclude_re and exclude_re.search(name)):
            return
        if redact_values and "value" in point:
            point = {**point, "value": "[redacted]"}
        if len(points) < max(1, min(int(max_points or 100), 500)):
            points.append(point)

    # GET
    for name, value in parse_qsl(urlparse(url).query, keep_blank_values=True):
        add({"place": "GET", "parameter": name, "value": value, "method": "GET"})

    # POST form body
    if data and not _looks_json(data):
        for name, value in parse_qsl(data, keep_blank_values=True):
            add({"place": "POST", "parameter": name, "value": value, "method": "POST"})

    # JSON body
    if data and _looks_json(data):
        try:
            obj = json.loads(data)
            for path, value in _walk_json(obj):
                if isinstance(value, (str, int, float, bool)) or value is None:
                    add({
                        "place": "JSON",
                        "parameter": path,
                        "value": "" if value is None else str(value),
                        "method": "POST",
                    })
        except json.JSONDecodeError:
            pass

    # Cookie
    for name, value in parse_cookie_header(cookie).items():
        add({"place": "COOKIE", "parameter": name, "value": value, "method": "GET"})

    # Common header places
    ua = headers.get("User-Agent") or headers.get("user-agent")
    if ua:
        add({"place": "UA", "parameter": "User-Agent", "value": ua, "method": "GET"})
    ref = headers.get("Referer") or headers.get("referer")
    if ref:
        add({"place": "REFERER", "parameter": "Referer", "value": ref, "method": "GET"})

    # Custom X- headers already present
    for k, v in headers.items():
        if k.lower().startswith("x-") and k.lower() not in ("x-requested-with",):
            add({"place": "HEADER", "parameter": k, "value": v, "method": "GET"})

    points.sort(key=lambda p: (p.get("place", ""), p.get("parameter", "")))
    return {
        "url": url,
        "points": points,
        "count": len(points),
        "places": sorted(selected_places),
        "parameter_include": sorted(includes),
        "parameter_exclude": parameter_exclude or None,
        "max_points": max(1, min(int(max_points or 100), 500)),
        "redacted": bool(redact_values),
        "engine": "sqlmap-injection-point-discovery",
    }


def _looks_json(s: str) -> bool:
    t = s.strip()
    return (t.startswith("{") and t.endswith("}")) or (t.startswith("[") and t.endswith("]"))


def _walk_json(obj: Any, prefix: str = "") -> list[tuple[str, Any]]:
    out: list[tuple[str, Any]] = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            path = f"{prefix}.{k}" if prefix else str(k)
            if isinstance(v, (dict, list)):
                out.extend(_walk_json(v, path))
            else:
                out.append((path, v))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            path = f"{prefix}[{i}]"
            if isinstance(v, (dict, list)):
                out.extend(_walk_json(v, path))
            else:
                out.append((path, v))
    return out


def _set_json_path(obj: Any, path: str, value: str) -> Any:
    """Set dotted/bracket path on a JSON structure; returns new structure."""
    # parse path tokens
    tokens = re.findall(r"[^.\[\]]+|\[\d+\]", path)
    if not tokens:
        return value

    def set_rec(cur: Any, toks: list[str]) -> Any:
        if not toks:
            return value
        t = toks[0]
        if t.startswith("[") and t.endswith("]"):
            idx = int(t[1:-1])
            assert isinstance(cur, list)
            cur = list(cur)
            while len(cur) <= idx:
                cur.append(None)
            cur[idx] = set_rec(cur[idx], toks[1:])
            return cur
        if isinstance(cur, dict):
            cur = dict(cur)
            cur[t] = set_rec(cur.get(t), toks[1:]) if len(toks) > 1 else value
            return cur
        # create dict path
        return {t: set_rec({}, toks[1:]) if len(toks) > 1 else value}

    return set_rec(obj, tokens)


def build_request(
    url: str,
    place: str,
    parameter: str,
    injected_value: str,
    method: str = "GET",
    data: str = "",
    cookie: str = "",
    headers: dict[str, str] | None = None,
    append: bool = True,
    original_value: str = "",
) -> dict[str, Any]:
    """
    Build a concrete HTTP request with injection applied.
    append=True → original+payload (sqlmap default); False → replace value.
    """
    headers = dict(headers or {})
    place = place.upper()
    base_val = original_value
    final_val = (base_val + injected_value) if append else injected_value

    out_url = url
    out_method = method.upper()
    out_data = data
    out_cookie = cookie
    out_headers = dict(headers)

    if place == "GET":
        p = urlparse(url)
        q = list(parse_qsl(p.query, keep_blank_values=True))
        found = False
        nq = []
        for k, v in q:
            if k == parameter and not found:
                nq.append((k, final_val))
                found = True
            else:
                nq.append((k, v))
        if not found:
            nq.append((parameter, final_val))
        out_url = urlunparse(p._replace(query=urlencode(nq)))
        out_method = "GET"
    elif place == "POST":
        out_method = "POST"
        content_type = " ".join(f"{k}:{v}" for k, v in out_headers.items()).lower()
        if "multipart/form-data" in content_type:
            marker = re.compile(r'(name=["\']' + re.escape(str(parameter)) + r'["\'][^\r\n]*\r?\n\r?\n)(.*?)(?=\r?\n--)', re.I | re.S)
            replaced, count = marker.subn(lambda m: m.group(1) + str(final_val), str(data or ""), count=1)
            if count:
                out_data = replaced
                return {
                    "url": out_url, "method": out_method, "data": out_data,
                    "headers": out_headers, "cookie": out_cookie, "place": place,
                    "parameter": parameter, "injected_value": final_val,
                }
        pairs = list(parse_qsl(data, keep_blank_values=True))
        found = False
        nq = []
        for k, v in pairs:
            if k == parameter and not found:
                nq.append((k, final_val))
                found = True
            else:
                nq.append((k, v))
        if not found:
            nq.append((parameter, final_val))
        out_data = urlencode(nq)
        out_headers.setdefault("Content-Type", "application/x-www-form-urlencoded")
    elif place == "JSON":
        out_method = "POST"
        try:
            obj = json.loads(data) if data else {}
        except json.JSONDecodeError:
            obj = {}
        # for append on JSON, combine with original leaf
        leaf = final_val
        obj = _set_json_path(obj, parameter, leaf)
        out_data = json.dumps(obj, separators=(",", ":"))
        out_headers["Content-Type"] = "application/json"
    elif place == "COOKIE":
        cookies = parse_cookie_header(cookie)
        cookies[parameter] = final_val
        out_cookie = dump_cookie_header(cookies)
        out_headers["Cookie"] = out_cookie
    elif place == "UA":
        out_headers["User-Agent"] = final_val
    elif place == "REFERER":
        out_headers["Referer"] = final_val
    elif place == "HOST":
        out_headers["Host"] = final_val
    elif place == "HEADER":
        out_headers[parameter] = final_val
    else:
        raise ValueError(f"unknown place {place}")

    if out_cookie and "Cookie" not in {k.title(): k for k in out_headers}:
        out_headers["Cookie"] = out_cookie

    return {
        "url": out_url,
        "method": out_method,
        "data": out_data,
        "headers": out_headers,
        "cookie": out_cookie,
        "place": place,
        "parameter": parameter,
        "injected_value": final_val,
    }
