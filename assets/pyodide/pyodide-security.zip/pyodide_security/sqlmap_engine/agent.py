"""
Payload agent — port of sqlmap lib/core/agent.py substitution logic.

Placeholders handled (from settings.py / agent.cleanupPayload):
  [RANDNUM], [RANDNUM1], ...  → random int
  [RANDSTR], [RANDSTR1], ...  → random alpha
  [SLEEPTIME]                 → sleep seconds
  [ORIGINAL] / [ORIGVALUE]    → original parameter value
  [GENERIC_SQL_COMMENT]       → comment terminator
  [DELIMITER]                 → ,
  [COLSTART] / [COLSTOP]      → union markers
  [INFERENCE]                 → left as-is for inference vectors (detection only)
"""
from __future__ import annotations

import random
import re
import string


def random_int(length: int = 4) -> int:
    return random.randint(10 ** (length - 1), 10 ** length - 1)


def random_str(length: int = 4) -> str:
    return "".join(random.choice(string.ascii_lowercase) for _ in range(length))


def cleanup_payload(
    payload: str,
    original: str = "1",
    sleeptime: int = 3,
    seed: int | None = None,
    max_length: int = 20000,
) -> str:
    """Port of agent.cleanupPayload / adjustLateValues essentials."""
    if not payload:
        return payload
    payload = str(payload)[:max(1, min(int(max_length or 20000), 200000))]
    rng = random.Random(seed) if seed is not None else random

    def _randnum(m: re.Match) -> str:
        return str(rng.randint(1000, 9999))

    def _randstr(m: re.Match) -> str:
        return "".join(rng.choice(string.ascii_lowercase) for _ in range(4))

    payload = re.sub(r"\[RANDNUM\d*\]", _randnum, payload, flags=re.I)
    payload = re.sub(r"\[RANDSTR\d*\]", _randstr, payload, flags=re.I)
    payload = payload.replace("[SLEEPTIME]", str(int(sleeptime)))
    payload = payload.replace("[ORIGINAL]", original)
    payload = payload.replace("[ORIGVALUE]", original)
    payload = payload.replace("[GENERIC_SQL_COMMENT]", "-- ")
    payload = payload.replace("[DELIMITER]", ",")
    payload = payload.replace("[COLSTART]", "")
    payload = payload.replace("[COLSTOP]", "")
    # Inference left for extraction phase — for detection use true condition
    payload = payload.replace("[INFERENCE]", "1=1")
    unresolved = sorted(set(re.findall(r"\[[A-Z][A-Z0-9_]*\]", payload)))
    return payload if not unresolved else payload + ""


def apply_boundary(payload: str, prefix: str, suffix: str, original: str = "1", seed: int | None = None, max_length: int = 20000) -> str:
    """Combine boundary prefix + payload + suffix around original value style."""
    prefix = cleanup_payload(prefix or "", original=original, seed=seed, max_length=max_length)
    suffix = cleanup_payload(suffix or "", original=original, seed=seed, max_length=max_length)
    payload = cleanup_payload(payload, original=original, seed=seed, max_length=max_length)
    # where=1 style: original + prefix + payload + suffix
    return f"{original}{prefix}{payload}{suffix}"
