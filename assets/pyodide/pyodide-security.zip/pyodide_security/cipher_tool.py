"""openssl enc-class encrypt/decrypt — AES-256-CTR + HMAC-SHA256 (encrypt-then-MAC).

Envelope format (v1), base64:
  magic(4) | ver(1) | kdf_iters(u32 BE) | salt(16) | nonce(16) | ciphertext | tag(32)
  magic = b'PSEC'
  keys: PBKDF2-HMAC-SHA256(password, salt, iters) -> 64 bytes (32 enc | 32 mac)
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import struct
from typing import Any

from ._aes import aes_ctr_crypt

MAGIC = b"PSEC"
VERSION = 1
DEFAULT_ITERS = 120_000


def _derive(password: str, salt: bytes, iterations: int) -> tuple[bytes, bytes]:
    if iterations < 10_000:
        raise ValueError("iterations must be >= 10000")
    if iterations > 2_000_000:
        raise ValueError("iterations too high for browser runtime")
    km = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt, int(iterations), dklen=64
    )
    return km[:32], km[32:]


def encrypt(
    plaintext: str,
    password: str,
    iterations: int = DEFAULT_ITERS,
) -> dict[str, Any]:
    if not password:
        raise ValueError("password is required")
    pt = plaintext.encode("utf-8")
    salt = secrets.token_bytes(16)
    nonce = secrets.token_bytes(16)
    enc_key, mac_key = _derive(password, salt, iterations)
    ct = aes_ctr_crypt(enc_key, nonce, pt)
    header = MAGIC + bytes([VERSION]) + struct.pack(">I", int(iterations)) + salt + nonce
    tag = hmac.new(mac_key, header + ct, "sha256").digest()
    blob = header + ct + tag
    return {
        "payload": base64.b64encode(blob).decode("ascii"),
        "algorithm": "AES-256-CTR-HMAC-SHA256",
        "kdf": "PBKDF2-HMAC-SHA256",
        "iterations": int(iterations),
        "salt_hex": salt.hex(),
        "ciphertext_bytes": len(ct),
    }


def decrypt(payload: str, password: str) -> dict[str, Any]:
    if not password:
        raise ValueError("password is required")
    try:
        blob = base64.b64decode(payload.strip())
    except Exception as e:
        raise ValueError(f"payload is not valid base64: {e}") from e
    if len(blob) < 4 + 1 + 4 + 16 + 16 + 32:
        raise ValueError("payload too short")
    if blob[:4] != MAGIC:
        raise ValueError("not a PSEC payload (bad magic)")
    ver = blob[4]
    if ver != VERSION:
        raise ValueError(f"unsupported version {ver}")
    iterations = struct.unpack(">I", blob[5:9])[0]
    salt = blob[9:25]
    nonce = blob[25:41]
    tag = blob[-32:]
    ct = blob[41:-32]
    header = blob[:41]
    enc_key, mac_key = _derive(password, salt, iterations)
    expected = hmac.new(mac_key, header + ct, "sha256").digest()
    if not hmac.compare_digest(expected, tag):
        return {
            "ok": False,
            "error": "authentication failed (wrong password or tampered ciphertext)",
        }
    pt = aes_ctr_crypt(enc_key, nonce, ct)
    try:
        text = pt.decode("utf-8")
    except UnicodeDecodeError:
        return {
            "ok": True,
            "plaintext_utf8": None,
            "plaintext_hex": pt.hex(),
            "bytes": len(pt),
        }
    return {
        "ok": True,
        "plaintext": text,
        "bytes": len(pt),
        "iterations": iterations,
    }


def kdf(
    password: str,
    salt: str = "",
    iterations: int = DEFAULT_ITERS,
    length: int = 32,
    hash_name: str = "sha256",
) -> dict[str, Any]:
    if not password:
        raise ValueError("password is required")
    length = max(16, min(int(length), 128))
    iterations = max(10_000, min(int(iterations), 2_000_000))
    salt_b = salt.encode("utf-8") if salt else secrets.token_bytes(16)
    if isinstance(salt, str) and salt and all(c in "0123456789abcdefABCDEF" for c in salt) and len(salt) % 2 == 0 and len(salt) >= 16:
        # if looks like hex salt, accept hex
        try:
            salt_b = bytes.fromhex(salt)
        except ValueError:
            salt_b = salt.encode("utf-8")
    dk = hashlib.pbkdf2_hmac(hash_name, password.encode("utf-8"), salt_b, iterations, dklen=length)
    return {
        "hex": dk.hex(),
        "base64": base64.b64encode(dk).decode("ascii"),
        "salt_hex": salt_b.hex() if isinstance(salt_b, bytes) else salt,
        "iterations": iterations,
        "length": length,
        "hash": hash_name,
        "kdf": "PBKDF2-HMAC",
    }
