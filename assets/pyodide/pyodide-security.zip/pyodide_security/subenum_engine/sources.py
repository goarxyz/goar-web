
"""
Subdomain enumeration sources — projectdiscovery/subfinder source catalog
+ SecLists DNS wordlist for brute.
"""

from __future__ import annotations

import gzip
import json
import re
from pathlib import Path
from typing import Any, Callable, Awaitable
from urllib.parse import quote, urlencode

from .._http import http_request, redact_url
from .. import policy

_DATA = Path(__file__).with_name("data")
_SOURCES_LIST = json.loads((_DATA / "subfinder_sources.json").read_text(encoding="utf-8"))
_WL: list[str] | None = None


def clean_domain(domain: str) -> str:
    d = (domain or "").strip().lower()
    d = re.sub(r"^https?://", "", d)
    d = d.split("/")[0].split("?")[0].split("#")[0]
    d = d.lstrip("*.")
    d = d.rstrip(".")
    return d


def is_sub(host: str, root: str) -> bool:
    host = clean_domain(host)
    root = clean_domain(root)
    return host == root or host.endswith("." + root)


def _wordlist() -> list[str]:
    global _WL
    if _WL is None:
        with gzip.open(_DATA / "subdomains-5k.txt.gz", "rt", encoding="utf-8") as f:
            _WL = [ln.strip() for ln in f.read().splitlines() if ln.strip()]
    return _WL


def list_sources() -> dict[str, Any]:
    return {
        "ok": True,
        "count": len(_SOURCES_LIST),
        "sources": list(_SOURCES_LIST),
        "source": "projectdiscovery/subfinder pkg/subscraping/sources",
        "engine": "subenum",
        "equivalent": "subfinder",
    }


def list_wordlist(limit: int = 0) -> dict[str, Any]:
    rows = _wordlist()
    out = rows[: int(limit)] if limit and limit > 0 else rows
    return {
        "ok": True,
        "count": len(rows),
        "returned": len(out),
        "words": out,
        "source": "SecLists/Discovery/DNS/subdomains-top1million-5000.txt",
        "engine": "subenum",
    }


def _safe_url(value: Any) -> str:
    """Keep user-visible URLs credential-safe even if a transport returns an encoded query tail."""
    cleaned = redact_url(value)
    return re.sub(r"(?i)((?:api(?:key|token)|token|key)(?:=|%3d))[^&%]+", r"\1[redacted]", cleaned)


def _safe_error(value: Any) -> str | None:
    text = str(value or "")
    if not text:
        return None
    return re.sub(r"(?i)(apikey|api_key|access_token|authorization|cookie|secret|token)=([^&#\\s]+)", lambda match: f"{match.group(1)}=[redacted]", text)


def _ct_date(value: Any) -> str:
    """Return a comparable ISO-like CT date prefix without claiming full X.509 parsing."""
    return str(value or "").strip().replace("T", " ")[:19]


def _ct_query(domain: str, query_mode: str, query: str, scope_domain: str, exclude_expired: bool) -> tuple[str, dict[str, str], str]:
    mode = str(query_mode or "wildcard").strip().lower()
    raw_query = str(query or "").strip()
    scope = clean_domain(scope_domain or domain)
    if mode not in {"wildcard", "identity", "certificate_id", "fingerprint"}:
        raise ValueError("query_mode must be wildcard, identity, certificate_id, or fingerprint")
    params: dict[str, str] = {"output": "json"}
    if mode == "wildcard":
        if not scope or "." not in scope:
            raise ValueError("a scoped domain is required for wildcard CT search")
        params["q"] = f"%.{scope}"
    elif mode == "identity":
        value = raw_query or domain
        if not value:
            raise ValueError("query is required for identity CT search")
        params["q"] = value
    elif mode == "certificate_id":
        value = raw_query or domain
        if not str(value).isdigit():
            raise ValueError("certificate_id query must be numeric")
        params["id"] = str(value)
    else:
        value = re.sub(r"[^0-9A-Fa-f]", "", raw_query or domain)
        if len(value) not in {40, 64}:
            raise ValueError("fingerprint query must contain 40 or 64 hexadecimal characters")
        params["q"] = value
    if exclude_expired:
        params["exclude"] = "expired"
    return mode, params, scope


async def crtsh(domain: str, user_agent: str = "pyodide-security/subfinder/2.0", service_base: str = "https://crt.sh", headers: str = "", timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = "408,429,500,502,503,504", route: str = "auto", max_results: int = 5000, include_wildcards: bool = False, query_mode: str = "wildcard", query: str = "", scope_domain: str = "", exclude_expired: bool = False, issuer_contains: str = "", not_before_after: str = "", not_after_before: str = "", include_unscoped_names: bool = False) -> dict[str, Any]:
    """Bounded crt.sh collector with reproducible CT query and filter evidence."""
    base = str(service_base or "https://crt.sh").strip().rstrip("/")
    if not base.startswith(("http://", "https://")):
        base = "https://" + base
    mode, params, scope = _ct_query(domain, query_mode, query, scope_domain, bool(exclude_expired))
    url = f"{base}/?{urlencode(params)}"
    err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "subdomains": [], "count": 0, "certificates": [], "certificate_count": 0, "engine": "subenum"}
    req_headers = {"User-Agent": user_agent, "Accept": "application/json"}
    raw_headers = str(headers or "").strip()
    if raw_headers.startswith("{"):
        try:
            parsed_headers = json.loads(raw_headers)
        except json.JSONDecodeError as exc:
            raise ValueError(f"headers must be JSON or Header: value lines: {exc}") from exc
        if not isinstance(parsed_headers, dict):
            raise ValueError("headers JSON must be an object")
        req_headers.update({str(k): str(v) for k, v in parsed_headers.items()})
    else:
        for line in raw_headers.splitlines():
            if ":" in line:
                key, _, value = line.partition(":")
                if key.strip(): req_headers[key.strip()] = value.strip()
    use_proxy = None if route in (None, "", "auto", "AUTO") else True if route in (True, "proxy", "PROXY", "true", "True") else False if route in (False, "direct", "DIRECT", "false", "False") else (_ for _ in ()).throw(ValueError("route must be auto, proxy, or direct"))
    timeout = max(1000, min(int(timeout_ms or 8000), 120000)); retry_count = max(0, min(int(retries or 0), 5)); retryable = {int(x.strip()) for x in str(retry_statuses or "").split(",") if x.strip().isdigit()}
    attempts: list[dict[str, Any]] = []; resp: dict[str, Any] = {}
    for index in range(retry_count + 1):
        resp = await http_request(url, headers=req_headers, timeout_ms=timeout, use_proxy=use_proxy)
        attempts.append({"attempt": index + 1, "status": resp.get("status"), "ok": resp.get("ok"), "transport": resp.get("transport"), "elapsed_ms": resp.get("elapsed_ms"), "error": _safe_error(resp.get("error")), "final_url": _safe_url(resp.get("final_url"))})
        if resp.get("ok") or int(resp.get("status") or 0) not in retryable: break
    body = resp.get("body") or ""; names: set[str] = set(); certificates: list[dict[str, Any]] = []; limit = max(1, min(int(max_results or 5000), 20000)); filtered_out = 0; issuer_filter = str(issuer_contains or "").strip().lower(); after = _ct_date(not_before_after); before = _ct_date(not_after_before); seen_ids: set[str] = set()
    try:
        data = json.loads(body)
        if isinstance(data, list):
            for row in data[:limit]:
                if not isinstance(row, dict): continue
                issuer = str(row.get("issuer_name") or "")
                not_before = _ct_date(row.get("not_before")); not_after = _ct_date(row.get("not_after"))
                if (issuer_filter and issuer_filter not in issuer.lower()) or (after and (not not_before or not_before < after)) or (before and (not not_after or not_after > before)):
                    filtered_out += 1; continue
                row_names: list[str] = []
                for part in str(row.get("name_value") or "").split("\n"):
                    wildcard = part.strip().startswith("*."); cleaned = clean_domain(part)
                    if not cleaned or (wildcard and not include_wildcards): continue
                    if scope and not is_sub(cleaned, scope) and not include_unscoped_names: continue
                    names.add(cleaned); row_names.append(cleaned)
                if not row_names and not include_unscoped_names:
                    filtered_out += 1; continue
                certificate_id = str(row.get("id") or "")
                dedup_key = certificate_id or f"{row.get('serial_number')}|{issuer}|{not_before}|{not_after}"
                if dedup_key in seen_ids: continue
                seen_ids.add(dedup_key)
                certificates.append({"id": row.get("id"), "names": sorted(set(row_names)), "issuer_name": issuer, "serial_number": row.get("serial_number"), "not_before": row.get("not_before"), "not_after": row.get("not_after"), "entry_timestamp": row.get("entry_timestamp"), "common_name": row.get("common_name")})
    except Exception:
        data = None
    safe_headers = {k: ("[redacted]" if k.lower() in {"authorization", "cookie", "x-api-key"} else v) for k, v in req_headers.items()}
    return {"ok": bool(resp.get("ok")) and isinstance(data, list), "domain": scope or clean_domain(domain), "source": "crtsh", "query_mode": mode, "count": len(names), "subdomains": sorted(names), "certificates": certificates, "certificate_count": len(certificates), "filtered_out": filtered_out, "status": resp.get("status"), "body_length": len(body), "error": _safe_error(resp.get("error")) or (None if isinstance(data, list) else "non-JSON crt.sh response"), "attempts": attempts, "attempt_count": len(attempts), "request": {"url": _safe_url(url), "query_mode": mode, "scope_domain": scope or None, "headers": safe_headers, "timeout_ms": timeout, "retries": retry_count, "route": "auto" if use_proxy is None else ("proxy" if use_proxy else "direct"), "include_wildcards": bool(include_wildcards), "include_unscoped_names": bool(include_unscoped_names), "exclude_expired": bool(exclude_expired), "issuer_contains": issuer_contains or None, "not_before_after": after or None, "not_after_before": before or None, "max_results": limit}, "final_url": _safe_url(resp.get("final_url") or url), "transport": resp.get("transport"), "engine": "subenum", "equivalent": "subfinder/crtsh"}


async def _source_stub(domain: str) -> dict[str, Any]:
    """Placeholder for sources that need API keys / non-HTTP in browser."""
    return {"ok": True, "subdomains": [], "count": 0, "error": "source requires API key or host-side adapter", "status": 0}


# subfinder source name -> callable (crtsh implemented; others stubbed honestly)
SOURCES: dict[str, Callable[..., Awaitable[dict[str, Any]]]] = {"crtsh": crtsh}
for _name in _SOURCES_LIST:
    if _name not in SOURCES:
        SOURCES[_name] = _source_stub


async def brute(
    domain: str,
    max_words: int = 100,
    user_agent: str = "pyodide-security/subfinder/2.0",
    **kwargs: Any,
) -> dict[str, Any]:
    """HTTP existence probe of wordlist.subdomain (browser-friendly)."""
    domain = clean_domain(domain)
    words = _wordlist()[: max(1, int(max_words))]
    found = []
    tested = 0
    headers = {"User-Agent": user_agent}
    for w in words:
        if not policy.can_request():
            break
        tested += 1
        host = f"{w}.{domain}"
        for scheme in ("https", "http"):
            url = f"{scheme}://{host}/"
            err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
            if err:
                continue
            resp = await http_request(url, headers=headers)
            st = resp.get("status") or 0
            if st:
                found.append({"host": host, "url": url, "status": st})
                break
    return {
        "ok": True,
        "domain": domain,
        "tested": tested,
        "tried": tested,
        "count": len(found),
        "found": found,
        "found_count": len(found),
        "wordlist_size": len(_wordlist()),
        "engine": "subenum",
        "source": "SecLists subdomains-top1million-5000",
    }
