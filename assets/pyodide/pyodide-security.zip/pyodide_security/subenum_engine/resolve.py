"""DNS-over-HTTPS multi-provider resolution, brute force, and mutations."""
from __future__ import annotations
import json,re
from typing import Any
from urllib.parse import quote
from .._http import http_request,redact_url
from .sources import clean_domain,is_sub
DEFAULT_WORDLIST="""www mail mx smtp pop imap webmail api app apps dev development staging stage test testing beta alpha admin administrator portal dashboard vpn remote git gitlab github ci cd jenkins cdn static assets img images media files upload uploads shop store cart blog news docs documentation wiki status monitor monitoring metrics grafana prometheus auth login sso oauth id identity accounts account ns ns1 ns2 dns dns1 ftp sftp ssh bastion jump db database mysql postgres redis mongo elastic kibana dev1 dev2 qa uat preprod prod production internal intranet m mobile app1 app2 api1 api2 v1 v2 graphql rest support help desk crm erp office owa exchange autodiscover sip cloud aws azure gcp s3 storage secure client clients partner partners old legacy backup bak demo sandbox edge gateway proxy cache wss ws mqtt chat push notify webhook webhooks payment payments billing invoice invoices report reports analytics tracking""".split()
PREFIXES=["dev","staging","test","prod","qa","uat","api","internal","old","new","backup","stage","demo"];SUFFIXES=["1","2","3","dev","test","old","bak","prod","staging","new","api"]
def _route(v):
 if v in (None,'','auto','AUTO'):return None
 if v in (True,'proxy','PROXY','true','True'):return True
 if v in (False,'direct','DIRECT','false','False'):return False
 raise ValueError('route must be auto, proxy, or direct')
def _safe_url(value):
 cleaned=redact_url(value)
 return re.sub(r'(?i)((?:api(?:key|token)|token|key)(?:=|%3d))[^&%]+',r'\1[redacted]',cleaned)
def _headers(raw):
 h={'Accept':'application/dns-json'};t=str(raw or '').strip()
 if not t:return h
 if t.startswith('{'):
  x=json.loads(t)
  if not isinstance(x,dict):raise ValueError('headers JSON must be an object')
  h.update({str(k):str(v) for k,v in x.items()});return h
 for line in t.splitlines():
  if ':' in line:
   k,_,v=line.partition(':');h[k.strip()]=v.strip()
 return h
async def doh_resolve(name:str,record_type:str='A',provider:str='cloudflare',headers:str='',timeout_ms:int=8000,retries:int=0,retry_statuses:str='408,429,500,502,503,504',route:str='auto',service_base:str='')->dict[str,Any]:
 name=name.strip().lower().rstrip('.');rtype=(record_type or 'A').upper();providers={'cloudflare':f'https://cloudflare-dns.com/dns-query?name={quote(name)}&type={quote(rtype)}','google':f'https://dns.google/resolve?name={quote(name)}&type={quote(rtype)}','quad9':f'https://dns.quad9.net:5053/dns-query?name={quote(name)}&type={quote(rtype)}'};url=(service_base.rstrip('/')+f'?name={quote(name)}&type={quote(rtype)}') if service_base else providers.get(provider,providers['cloudflare']);h=_headers(headers);timeout=max(1000,min(int(timeout_ms or 8000),120000));tries=max(0,min(int(retries or 0),5));retryable={int(x.strip()) for x in str(retry_statuses or '').split(',') if x.strip().isdigit()};attempts=[];resp={};use_proxy=_route(route)
 for i in range(tries+1):
  resp=await http_request(url,headers=h,timeout_ms=timeout,use_proxy=use_proxy);attempts.append({'attempt':i+1,'status':resp.get('status'),'ok':resp.get('ok'),'transport':resp.get('transport'),'elapsed_ms':resp.get('elapsed_ms'),'error':resp.get('error'),'final_url':_safe_url(resp.get('final_url'))})
  if resp.get('ok') or int(resp.get('status') or 0) not in retryable:break
 data=None;answers=[];authority=[];rcode=None;comment=None;body=str(resp.get('body') or '')
 try:
  data=json.loads(body);rcode=data.get('Status');comment=data.get('Comment')
  for source,dest in ((data.get('Answer') or [],answers),(data.get('Authority') or [],authority)):
   for ans in source:
    if isinstance(ans,dict):dest.append({'name':ans.get('name'),'type':ans.get('type'),'ttl':ans.get('TTL'),'data':ans.get('data')})
 except Exception:pass
 safe={k:('[redacted]' if k.lower() in {'authorization','cookie','x-api-key'} else v) for k,v in h.items()}
 return {'name':name,'type':rtype,'status':rcode,'http_status':resp.get('status'),'answers':answers,'authority':authority,'answer_count':len(answers),'ok':bool(resp.get('ok')) and rcode==0,'provider':provider,'comment':comment,'error':resp.get('error') or (None if data is not None else 'non-JSON DoH response'),'elapsed_ms':resp.get('elapsed_ms'),'body':body,'body_length':len(body),'attempts':attempts,'attempt_count':len(attempts),'request':{'url':_safe_url(url),'headers':safe,'timeout_ms':timeout,'retries':tries,'route':'auto' if use_proxy is None else ('proxy' if use_proxy else 'direct')},'final_url':_safe_url(resp.get('final_url') or url),'transport':resp.get('transport')}
async def brute(domain:str,wordlist:str='',provider:str='cloudflare',max_words:int=100,record_type:str='A',**kwargs:Any)->dict[str,Any]:
 domain=clean_domain(domain);words=[w.strip().lower() for w in (wordlist or '').replace(',','\n').splitlines() if w.strip() and not w.startswith('#')] or list(DEFAULT_WORDLIST);words=words[:max(1,min(int(max_words),300))];found=[];tried=0
 for w in words:
  w=re.sub(r'[^a-z0-9-]','',w)
  if not w:continue
  fqdn=f'{w}.{domain}';tried+=1;res=await doh_resolve(fqdn,record_type,provider=provider,**kwargs)
  if res.get('ok'):found.append({'host':fqdn,'records':res.get('answers')})
 return {'source':'doh-brute','domain':domain,'tried':tried,'found':found,'count':len(found),'provider':provider}
def mutate(subdomains:str,domain:str='')->dict[str,Any]:
 root=clean_domain(domain) if domain else '';seeds=[]
 for line in subdomains.replace(',','\n').splitlines():
  s=line.strip().lower().rstrip('.')
  if not s:continue
  if root and is_sub(s,root):
   label=s[:-(len(root)+1)] if s!=root else ''
   if label:seeds.append(label)
  elif '.' not in s:seeds.append(s)
  else:seeds.append(s.split('.')[0])
 out=set()
 for s in seeds[:100]:
  base=s.split('.')[0];out.add(base)
  for p in PREFIXES:out.update((f'{p}-{base}',f'{p}{base}',f'{base}-{p}'))
  for suf in SUFFIXES:out.update((f'{base}-{suf}',f'{base}{suf}'))
  if '-' in base:
   out.add(base.replace('-',''));parts=base.split('-')
   if len(parts)==2:out.add(f'{parts[1]}-{parts[0]}')
 fqdns=sorted({f'{label}.{root}' for label in out if label}) if root else sorted(out);return {'seeds':seeds[:100],'permutations':fqdns[:1000],'count':min(len(fqdns),1000),'domain':root or None}
