"""CSPRNG password/passphrase generation + zxcvbn-class strength analysis."""

from __future__ import annotations

import math
import re
import secrets
import string
from typing import Any

# Compact high-frequency English wordlist for diceware + dictionary matching
_WORDS = """
able about above abuse acid across actor actual adapt admit adult advice affair
afraid after again agent agree ahead alarm album alert alien align alike alive
allow alone along alter amber amend among angel anger angle ankle apple apply
arena argue arise armor aroma arrow artist ash aside asset atlas atom audit
avoid awake award aware awful axis bacon badge badly baker bases basic basis
beach beard beast began begin being below bench berry birth black blade blame
blank blast blaze bleak blend bless blind bliss block blood bloom blown blunt
board boast boats boost booth boots bound brain brand brass brave bread break
breed brick bride brief bring brisk broad broke brook brown brush buddy build
built bunch bunny burst buyer cabin cable camel canal candy canoe canvas cargo
carol carry carve cases catch cause cedar chain chair chalk chaos charm chart
chase cheap check cheek cheer chess chest chief child china chip choir chord
chunk churn cider cigar civic civil claim clamp clang clash clasp class clean
clear clerk click cliff climb cling clips cloak clock clone close cloth cloud
clown coast cocoa colon color comet comic coral could count court cover crack
craft crane crash crawl crazy cream creed creek crest crime crisp cross crowd
crown crude cruel crush crust cubic curry curve cycle daily dairy dance dated
dealt death debut delay delta demon dense depot depth diary digit dirty disco
ditch ditch dizzy doing donor doubt dough dozen draft drain drama drank drape
drawl drawn dread dream dress dried drift drill drink drive drone drool drown
drums drunk dryer dusty eager eagle early earth eight either elbow elder elect
elite empty enemy enjoy enter entry equal error event every exact exist extra
faint fairy faith false fancy fatal fault favor feast fence ferry fever fiber
field fiery fifth fifty fight final first fixed flame flash flask fleet flesh
flick fling float flock flood floor flora floss flour fluid flush flute focus
foggy force forge forth found frame fraud fresh fried front frost frown frozen
fruit fudge fully funny giant given glass globe glory glove going goose grade
grain grand grant grape graph grasp grass grave gravy great green greet grief
grill grind groan groom group grove grow growl grown guard guess guest guide
guild guilt habit happy harsh haste hasty heart heavy hedge hello help hence
hero hobby holly honey honor horse hotel hound house hover human humor hurry
ideal image imply inbox index inner input intro iron island issue ivory jeans
jelly jewel judge juice juicy jumbo jumpy kayak keeps kicks kings kneel knife
knock known label labor laden lance large laser later laugh layer learn leave
legal lemon level light limit linen liver lives local lodge logic loose lover
lower loyal lucky lunar lunch lying lyric magic major maker mango march match
maybe mayor medal media melon mercy merge merit merry metal meter micro midst
might minor minus model money month moral motor mount mouse mouth movie music
needs nerve never newer nicely night noble noise north novel nurse nylon oasis
occur ocean offer often olive omega onion opera orbit order other ought outer
owner oxide ozone paint panel panic pants paper party pasta patch pause peace
peach pearl pedal phase phone photo piano piece pilot pitch pixel place plain
plane plant plate plaza plot plow pluck point polar porch pound power press
price pride prime print prior prize proof proud prove proxy pulse punch pupil
queen query quest queue quick quiet quilt quote radar radio raise rally ranch
range rapid ratio reach react ready realm rebel refer reign relax repay reply
reset resin rifle right rigid rigor rinse rival river roast robot rocky rough
round route royal rugby rural salad salon sandy sauce scale scare scene scent
scope score scorn scout scrap screw scrub seize sense serve seven shade shaft
shake shall shame shape share shark sharp shave sheep sheer sheet shelf shell
shift shine shirt shock shoot shore short shout shove shown shrug siege sight
silly since sixth sixty skill skull slack slain slang slant slash slate slave
sleep sleet slice slick slide slime sling slope sloth slump small smart smash
smell smile smoke snack snail snake snare sneak snore snort solid solve sorry
sound south space spare spark speak spear speed spell spend spice spike spill
spine spite split spoil spoke spoon sport stack staff stage stain stair stake
stale stall stamp stand stare stark start state steak steal steam steel steep
steer stick stiff still stock stole stone stood stool store storm story stout
stove strap straw stray strip study stuff stump stunt style sugar suite sunny
super surge sushi swamp swarm swear sweat sweep sweet swell swift swing swirl
sword table taste taught teach tears teeth tempo thank their theme there these
thick thief thigh thing think third those three throw thumb tiger tight timber
tired title toast today token tooth topic torch total touch tough towel tower
toxic trace track trade trail train trait trash treat tree trend trial tribe
trick tried trips troop truck truly trunk trust truth tulip tumor twice twist
uncle under union unity until upper upset urban usage usual vague valid value
valve vapor vault venue verse video view viral virus visit vital vivid vocal
vodka voice voter voyage wage wagon waist walk wall warm warn waste watch water
weary weave wedge week weigh weird whale wheat wheel where which while white
whole whose widen width wield witch woman women world worry worse worst worth
would wound woven write wrong wrote yacht year yeast yield young youth zebra
""".split()

_COMMON = {
    "password", "password1", "123456", "12345678", "123456789", "qwerty",
    "abc123", "letmein", "admin", "welcome", "monkey", "dragon", "master",
    "login", "princess", "football", "iloveyou", "starwars", "passw0rd",
    "shadow", "sunshine", "trustno1", "hunter2", "baseball", "whatever",
    "qwertyuiop", "asdfghjkl", "zxcvbnm", "111111", "000000", "1q2w3e4r",
}

_AMBIGUOUS = set("0OIl1|`'\".,;:")


def generate(
    length: int = 20,
    upper: bool = True,
    lower: bool = True,
    digits: bool = True,
    symbols: bool = True,
    exclude_ambiguous: bool = True,
    count: int = 1,
) -> dict[str, Any]:
    length = max(8, min(int(length), 256))
    count = max(1, min(int(count), 32))
    alphabet = ""
    classes: list[str] = []
    if lower:
        classes.append(string.ascii_lowercase)
    if upper:
        classes.append(string.ascii_uppercase)
    if digits:
        classes.append(string.digits)
    if symbols:
        classes.append("!@#$%^&*()-_=+[]{}<>?")
    if not classes:
        raise ValueError("enable at least one character class")
    alphabet = "".join(classes)
    if exclude_ambiguous:
        alphabet = "".join(c for c in alphabet if c not in _AMBIGUOUS)
        classes = ["".join(c for c in s if c not in _AMBIGUOUS) for s in classes]
        classes = [s for s in classes if s]
    if not alphabet:
        raise ValueError("alphabet empty after excluding ambiguous characters")

    out: list[str] = []
    for _ in range(count):
        chars = [secrets.choice(s) for s in classes[:length]]
        while len(chars) < length:
            chars.append(secrets.choice(alphabet))
        for i in range(len(chars) - 1, 0, -1):
            j = secrets.randbelow(i + 1)
            chars[i], chars[j] = chars[j], chars[i]
        out.append("".join(chars))
    bits = length * math.log2(len(alphabet))
    return {
        "passwords": out,
        "length": length,
        "alphabet_size": len(alphabet),
        "entropy_bits": round(bits, 2),
        "generator": "secrets.SystemRandom / secrets.choice",
    }


def passphrase(
    words: int = 6,
    separator: str = "-",
    capitalize: bool = False,
    number_suffix: bool = True,
) -> dict[str, Any]:
    words = max(3, min(int(words), 12))
    chosen = [secrets.choice(_WORDS) for _ in range(words)]
    if capitalize:
        chosen = [w.capitalize() for w in chosen]
    phrase = separator.join(chosen)
    if number_suffix:
        phrase = f"{phrase}{separator}{secrets.randbelow(100):02d}"
    bits = words * math.log2(len(_WORDS)) + (math.log2(100) if number_suffix else 0)
    return {
        "passphrase": phrase,
        "words": words,
        "wordlist_size": len(_WORDS),
        "entropy_bits": round(bits, 2),
    }


def analyze(password: str) -> dict[str, Any]:
    """zxcvbn-inspired strength estimate with pattern detection."""
    pw = password or ""
    length = len(pw)
    classes = {
        "lower": bool(re.search(r"[a-z]", pw)),
        "upper": bool(re.search(r"[A-Z]", pw)),
        "digit": bool(re.search(r"\d", pw)),
        "symbol": bool(re.search(r"[^A-Za-z0-9]", pw)),
    }
    pool = (26 if classes["lower"] else 0) + (26 if classes["upper"] else 0)
    pool += (10 if classes["digit"] else 0) + (33 if classes["symbol"] else 0)
    pool = max(pool, 1)
    brute_bits = length * math.log2(pool) if length else 0.0

    issues: list[dict[str, str]] = []
    matched_patterns: list[str] = []
    score = 0.0

    # length contribution
    if length >= 20:
        score += 35
    elif length >= 16:
        score += 28
    elif length >= 12:
        score += 20
    elif length >= 8:
        score += 10
    else:
        issues.append({"severity": "critical", "message": "Shorter than 8 characters."})

    score += sum(classes.values()) * 8

    low = pw.lower()
    # dictionary / common
    if low in _COMMON or low.rstrip("0123456789!@#") in _COMMON:
        score -= 45
        issues.append({"severity": "critical", "message": "Matches a common password list entry."})
        matched_patterns.append("common_password")

    # wordlist substring
    for w in _WORDS:
        if len(w) >= 4 and w in low:
            score -= 8
            matched_patterns.append(f"dictionary:{w}")
            issues.append({"severity": "medium", "message": f"Contains dictionary word “{w}”."})
            break

    if re.search(r"(.)\1{2,}", pw):
        score -= 12
        matched_patterns.append("repeat")
        issues.append({"severity": "medium", "message": "Repeated characters."})

    seqs = (
        "0123456789",
        "abcdefghijklmnopqrstuvwxyz",
        "qwertyuiop",
        "asdfghjkl",
        "zxcvbnm",
    )
    for seq in seqs:
        for i in range(len(seq) - 3):
            chunk = seq[i : i + 4]
            if chunk in low or chunk[::-1] in low:
                score -= 15
                matched_patterns.append(f"sequence:{chunk}")
                issues.append({"severity": "high", "message": f"Sequential pattern “{chunk}”."})
                break

    if re.fullmatch(r"\d+", pw):
        score -= 25
        issues.append({"severity": "high", "message": "Digits only."})

    if re.search(r"(19|20)\d{2}", pw):
        score -= 6
        matched_patterns.append("year")
        issues.append({"severity": "low", "message": "Contains a year-like number."})

    # l33t-ish common
    deleet = (
        low.replace("0", "o")
        .replace("1", "i")
        .replace("3", "e")
        .replace("4", "a")
        .replace("5", "s")
        .replace("7", "t")
        .replace("@", "a")
        .replace("$", "s")
    )
    if deleet in _COMMON:
        score -= 30
        matched_patterns.append("leet_common")
        issues.append({"severity": "high", "message": "Leetspeak variant of a common password."})

    score = max(0, min(100, int(round(score))))
    label = (
        "strong"
        if score >= 80
        else "moderate"
        if score >= 55
        else "weak"
        if score >= 30
        else "very weak"
    )

    # adjusted entropy: reduce for patterns
    adj = brute_bits
    if "common_password" in matched_patterns:
        adj = min(adj, 20)
    elif matched_patterns:
        adj *= 0.65

    advice: list[str] = []
    if length < 16:
        advice.append("Use 16+ random characters or a 6-word diceware passphrase.")
    if sum(classes.values()) < 3 and length < 20:
        advice.append("Increase charset diversity or length.")
    if not advice and score >= 80:
        advice.append("Strong candidate. Store in a password manager; never reuse.")

    return {
        "length": length,
        "score": score,
        "label": label,
        "classes": classes,
        "bruteforce_entropy_bits": round(brute_bits, 2),
        "adjusted_entropy_bits": round(adj, 2),
        "patterns": matched_patterns,
        "issues": issues,
        "advice": advice,
    }
