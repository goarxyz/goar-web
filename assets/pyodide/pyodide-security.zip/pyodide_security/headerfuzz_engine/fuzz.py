"""Browser-adapted OWASP HTTP response-header audit through shared transport."""
from __future__ import annotations
import json
import re
from typing import Any
from urllib.parse import urljoin, urlparse
from .._http import http_request, redact_url
from .. import policy

REQUIRED=[("strict-transport-security","HSTS","high"),("content-security-policy","CSP","medium"),("x-content-type-options","X-Content-Type-Options","medium"),("x-frame-options","X-Frame-Options","medium"),("referrer-policy","Referrer-Policy","low"),("permissions-policy","Permissions-Policy","low"),("cross-origin-opener-policy","COOP","low"),("cross-origin-resource-policy","CORP","low")]

def _headers(raw:str,user_agent:str)->dict[str,str]:
    out={"User-Agent":user_agent};text=str(raw or "").strip()
    if text.startswith("{"):
        parsed=json.loads(text)
        if not isinstance(parsed,dict):raise ValueError("headers JSON must be an object")
        out.update({str(key):str(value) for key,value in parsed.items()})
    else:
        for line in text.splitlines():
            if ":" in line:
                key,_,value=line.partition(":");out[key.strip()]=value.strip()
    return out

def _route(value:Any)->bool|None:
    if value in (None,"","auto","AUTO"):return None
    if value in (True,"proxy","PROXY","true","True"):return True
    if value in (False,"direct","DIRECT","false","False"):return False
    raise ValueError("route must be auto, proxy, or direct")
def _items(raw:str)->list[str]:return list(dict.fromkeys(item.strip() for item in str(raw or "").replace(",","\n").splitlines() if item.strip()))
def _safe_url(value:Any)->str:
    safe=redact_url(value)
    return re.sub(r"(?i)(%3f|%26)(apikey|api_key|key|token|access_token|authorization|secret|signature|sig)(%3d|=)[^&#]*",lambda match:match.group(1)+match.group(2)+match.group(3)+"[redacted]",safe)
def _safe_response_headers(headers:dict[str,str])->dict[str,str]:return {key:("[redacted]" if key.lower() in {"set-cookie","authorization","cookie","x-api-key"} else value) for key,value in headers.items()}

def _audit(headers:dict[str,str],https:bool)->dict[str,Any]:
    present=[];missing=[];issues=[]
    def issue(label:str,severity:str,header:str=""):issues.append({"issue":label,"severity":severity,"header":header or None})
    for key,label,severity in REQUIRED:
        if key in headers:present.append({"header":label,"value":headers[key][:500]})
        else:missing.append({"header":label,"severity":severity});issue("missing "+label,severity,label)
    hsts=headers.get("strict-transport-security","").lower()
    if hsts:
        if not https:issue("HSTS observed on non-HTTPS URL","medium","HSTS")
        if "max-age" not in hsts:issue("HSTS missing max-age","high","HSTS")
        else:
            match=re.search(r"max-age\s*=\s*(\d+)",hsts)
            if match and int(match.group(1))<15552000:issue("HSTS max-age below six months","low","HSTS")
    csp=headers.get("content-security-policy","").lower()
    if csp:
        if "'unsafe-inline'" in csp:issue("CSP permits unsafe-inline","medium","CSP")
        if "'unsafe-eval'" in csp:issue("CSP permits unsafe-eval","medium","CSP")
        if "default-src *" in csp or "script-src *" in csp:issue("CSP has wildcard default/script source","medium","CSP")
        if "frame-ancestors" not in csp:issue("CSP lacks frame-ancestors","low","CSP")
    if headers.get("x-content-type-options","").lower() not in ("","nosniff"):issue("X-Content-Type-Options is not nosniff","medium","X-Content-Type-Options")
    xfo=headers.get("x-frame-options","").lower()
    if xfo and xfo not in {"deny","sameorigin"}:issue("X-Frame-Options has non-standard value","low","X-Frame-Options")
    ref=headers.get("referrer-policy","").lower()
    if ref in {"unsafe-url","no-referrer-when-downgrade"}:issue("Referrer-Policy may disclose excessive referrer data","low","Referrer-Policy")
    acao=headers.get("access-control-allow-origin","")
    if acao=="*" and headers.get("access-control-allow-credentials","").lower()=="true":issue("wildcard CORS origin with credentials","high","Access-Control-Allow-Origin")
    for key,label in (("server","Server"),("x-powered-by","X-Powered-By"),("x-aspnet-version","X-AspNet-Version"),("x-aspnetmvc-version","X-AspNetMvc-Version")):
        if key in headers:issue(label+" discloses: "+headers[key][:120],"info",label)
    counts={level:sum(1 for row in issues if row["severity"]==level) for level in ("high","medium","low","info")}
    return {"present":present,"missing":missing,"issues":issues,"issue_count":len(issues),"severity_counts":counts}

async def fuzz(url:str,user_agent:str="pyodide-security/headers/2.0",paths:str="/",max_paths:int=3,max_tests:int=0,headers:str="",timeout_ms:int=8000,retries:int=0,retry_statuses:str="408,429,500,502,503,504",route:str="auto",stop_on_issue:bool=False,include_headers:bool=False)->dict[str,Any]:
    url=str(url or "").strip()
    if not url:return {"ok":False,"error":"url required","engine":"headerfuzz"}
    if not url.startswith(("http://","https://")):url="https://"+url
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err:return {"ok":False,"error":err,"engine":"headerfuzz"}
    cap=max_tests if int(max_tests or 0)>0 else max_paths;selected=(_items(paths) or ["/"])[:max(1,min(int(cap or 3),20))];timeout=max(1000,min(int(timeout_ms or 8000),120000));retry_count=max(0,min(int(retries or 0),5));retryable={int(value.strip()) for value in str(retry_statuses or "").split(",") if value.strip().isdigit()};use_proxy=_route(route);request_headers=_headers(headers,user_agent);probes=[];attempts=[];all_issues=[];all_missing=[];all_present=[]
    for path in selected:
        target=urljoin(url.rstrip("/")+"/",path.lstrip("/")) if path not in ("", "/") else url;response={}
        for index in range(retry_count+1):
            response=await http_request(target,headers=request_headers,timeout_ms=timeout,use_proxy=use_proxy)
            attempts.append({"path":path,"attempt":index+1,"status":response.get("status"),"error":response.get("error"),"transport":response.get("transport"),"final_url":_safe_url(response.get("final_url"))})
            if response.get("ok") or int(response.get("status") or 0) not in retryable:break
        response_headers={str(key).lower():str(value) for key,value in (response.get("headers") or {}).items()};audit=_audit(response_headers,urlparse(target).scheme.lower()=="https");all_issues.extend([{**row,"path":path} for row in audit["issues"]]);all_missing.extend([{**row,"path":path} for row in audit["missing"]]);all_present.extend([{**row,"path":path} for row in audit["present"]]);probes.append({"path":path,"url":_safe_url(target),"final_url":_safe_url(response.get("final_url") or target),"status":response.get("status"),"headers":_safe_response_headers(response_headers) if include_headers else {},"issue_count":audit["issue_count"],"transport":response.get("transport"),"error":response.get("error")})
        if stop_on_issue and audit["issues"]:break
    severity_counts={level:sum(1 for row in all_issues if row["severity"]==level) for level in ("high","medium","low","info")};safe_headers={key:("[redacted]" if key.lower() in {"authorization","cookie","x-api-key"} else value) for key,value in request_headers.items()}
    return {"ok":True,"url":_safe_url(url),"status":probes[0]["status"] if probes else None,"present":all_present,"missing":all_missing,"issues":all_issues,"issue_count":len(all_issues),"severity_counts":severity_counts,"probes":probes,"attempts":attempts,"attempt_count":len(attempts),"request":{"paths":selected,"headers":safe_headers,"timeout_ms":timeout,"retries":retry_count,"route":"auto" if use_proxy is None else ("proxy" if use_proxy else "direct")},"engine":"headerfuzz","equivalent":"OWASP secure headers","coverage_note":"Evaluates observed response headers only; CSP, CORS and browser enforcement behavior are not fully emulated."}
