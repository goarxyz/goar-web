"""Browser-adapted robots.txt and security.txt collection through shared Goar transport."""
from __future__ import annotations
import json
import re
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urljoin, urlparse
from .._http import http_request, redact_url
from .. import policy

def parse_robots(text:str)->dict[str,Any]:
    agents={};current=[];has_rules=False;sitemaps=[];disallow=[];allow=[]
    for raw in str(text or "").splitlines():
        line=raw.split("#",1)[0].strip()
        if not line or ":" not in line:continue
        key,_,value=line.partition(":");key=key.strip().lower();value=value.strip()
        if key=="user-agent":
            if has_rules:current=[];has_rules=False
            current.extend(item.strip() for item in value.split(",") if item.strip())
            if not current:current=["*"]
            for agent in current:agents.setdefault(agent.lower(),{"allow":[],"disallow":[]})
        elif key in {"allow","disallow"}:
            if not current:continue
            has_rules=True
            for agent in current:agents.setdefault(agent.lower(),{"allow":[],"disallow":[]})[key].append(value)
            if value:(allow if key=="allow" else disallow).append(value)
        elif key in {"sitemap","sitemaps"}:
            if value:sitemaps.append(value)
    interesting=[path for path in disallow if any(token in path.lower() for token in ("admin","login","api","private","secret","backup","config","internal"))]
    return {"agents":agents,"sitemaps":list(dict.fromkeys(sitemaps)),"disallow_all":disallow,"allow_all":allow,"interesting_disallow":interesting}

def evaluate_path(parsed:dict[str,Any],path:str="/",agent:str="*")->dict[str,Any]:
    wanted=str(agent or "*").lower();groups=parsed.get("agents") or {};rules=[]
    for key,value in groups.items():
        if key=="*" or key in wanted or wanted in key:
            rules.extend(("allow",item) for item in value.get("allow",[]) if item);rules.extend(("disallow",item) for item in value.get("disallow",[]) if item)
    matches=[]
    for kind,pattern in rules:
        regex="^"+re.escape(pattern).replace(r"\*",".*").replace(r"\$","$")
        if re.search(regex,path):matches.append((len(pattern.rstrip("$")),kind,pattern))
    if not matches:return {"path":path,"agent":agent,"allowed":True,"matched_rule":None,"reason":"no matching rule"}
    matches.sort(key=lambda row:(row[0],row[1]=="allow"),reverse=True);_,kind,pattern=matches[0]
    return {"path":path,"agent":agent,"allowed":kind=="allow","matched_rule":pattern,"rule_type":kind}

def parse_security_txt(text:str,retrieved_url:str="")->dict[str,Any]:
    fields={}
    for raw in str(text or "").splitlines():
        line=raw.strip()
        if not line or line.startswith("#") or ":" not in line:continue
        key,_,value=line.partition(":");fields.setdefault(key.strip().lower(),[]).append(value.strip())
    issues=[]
    if not fields.get("contact"):issues.append({"issue":"missing required Contact","severity":"high"})
    expires=fields.get("expires",[])
    if len(expires)!=1:issues.append({"issue":"security.txt requires exactly one Expires","severity":"high"})
    elif expires:
        try:
            value=expires[0].replace("Z","+00:00");moment=datetime.fromisoformat(value)
            if moment.tzinfo is None:moment=moment.replace(tzinfo=timezone.utc)
            if moment<datetime.now(timezone.utc):issues.append({"issue":"security.txt Expires is in the past","severity":"medium"})
        except ValueError:issues.append({"issue":"invalid security.txt Expires timestamp","severity":"medium"})
    canonical=fields.get("canonical",[])
    if canonical and retrieved_url and retrieved_url not in canonical:issues.append({"issue":"retrieved URL is not listed by Canonical","severity":"low"})
    return {"fields":fields,"contact":fields.get("contact",[]),"expires":expires[0] if len(expires)==1 else None,"canonical":canonical,"valid":not any(row["severity"]=="high" for row in issues),"issues":issues,"issue_count":len(issues)}

def _headers(raw:str,user_agent:str)->dict[str,str]:
    output={"User-Agent":user_agent};text=str(raw or "").strip()
    if text.startswith("{"):
        parsed=json.loads(text)
        if not isinstance(parsed,dict):raise ValueError("headers JSON must be an object")
        output.update({str(key):str(value) for key,value in parsed.items()})
    else:
        for line in text.splitlines():
            if ":" in line:
                key,_,value=line.partition(":");output[key.strip()]=value.strip()
    return output

def _route(value:Any)->bool|None:
    if value in (None,"","auto","AUTO"):return None
    if value in (True,"proxy","PROXY","true","True"):return True
    if value in (False,"direct","DIRECT","false","False"):return False
    raise ValueError("route must be auto, proxy, or direct")
def _safe_url(value:Any)->str:
    safe=redact_url(value)
    return re.sub(r"(?i)(%3f|%26)(apikey|api_key|key|token|access_token|authorization|secret|signature|sig)(%3d|=)[^&#]*",lambda match:match.group(1)+match.group(2)+match.group(3)+"[redacted]",safe)

async def scan(url:str,user_agent:str="pyodide-security/robots/2.0",headers:str="",timeout_ms:int=8000,retries:int=0,retry_statuses:str="408,429,500,502,503,504",route:str="auto",include_security_txt:bool=True,security_root_fallback:bool=True,include_sitemaps:bool=True,evaluate_path_value:str="",agent:str="*",include_raw:bool=False)->dict[str,Any]:
    url=str(url or "").strip()
    if not url:return {"ok":False,"error":"url required","engine":"robots"}
    if not url.startswith(("http://","https://")):url="https://"+url
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err:return {"ok":False,"error":err,"engine":"robots"}
    origin=f"{urlparse(url).scheme}://{urlparse(url).netloc}/";robots_url=urljoin(origin,"robots.txt");timeout=max(1000,min(int(timeout_ms or 8000),120000));retry_count=max(0,min(int(retries or 0),5));retryable={int(value.strip()) for value in str(retry_statuses or "").split(",") if value.strip().isdigit()};use_proxy=_route(route);request_headers=_headers(headers,user_agent);attempts=[]
    async def fetch(label:str,target:str)->dict[str,Any]:
        response={}
        for index in range(retry_count+1):
            response=await http_request(target,headers=request_headers,timeout_ms=timeout,use_proxy=use_proxy)
            attempts.append({"endpoint":label,"attempt":index+1,"status":response.get("status"),"error":response.get("error"),"transport":response.get("transport"),"final_url":_safe_url(response.get("final_url"))})
            if response.get("ok") or int(response.get("status") or 0) not in retryable:break
        return response
    robots_response=await fetch("robots",robots_url);robots_body=str(robots_response.get("body") or "");robots_status=int(robots_response.get("status") or 0);parsed=parse_robots(robots_body) if robots_status==200 else {};state="available" if robots_status==200 else ("unavailable" if 400<=robots_status<500 else ("unreachable" if 500<=robots_status<600 else "unknown"));security=None;security_probes=[]
    if include_security_txt:
        wellknown=urljoin(origin,".well-known/security.txt");well_response=await fetch("security-well-known",wellknown);security_probes.append({"url":_safe_url(wellknown),"final_url":_safe_url(well_response.get("final_url") or wellknown),"status":well_response.get("status"),"transport":well_response.get("transport"),"error":well_response.get("error")})
        selected_response,selected_url=well_response,wellknown
        if security_root_fallback and int(well_response.get("status") or 0)!=200:
            root=urljoin(origin,"security.txt");root_response=await fetch("security-root",root);security_probes.append({"url":_safe_url(root),"final_url":_safe_url(root_response.get("final_url") or root),"status":root_response.get("status"),"transport":root_response.get("transport"),"error":root_response.get("error")})
            if int(root_response.get("status") or 0)==200:selected_response,selected_url=root_response,root
        if int(selected_response.get("status") or 0)==200:
            security=parse_security_txt(str(selected_response.get("body") or ""),selected_url);security.update({"url":_safe_url(selected_url),"status":selected_response.get("status"),"raw":str(selected_response.get("body") or "") if include_raw else ""})
        else:security={"exists":False,"url":_safe_url(selected_url),"status":selected_response.get("status"),"issues":[],"issue_count":0}
    evaluated=evaluate_path(parsed,evaluate_path_value,agent) if evaluate_path_value and parsed else None;safe_headers={key:("[redacted]" if key.lower() in {"authorization","cookie","x-api-key"} else value) for key,value in request_headers.items()}
    return {"ok":True,"url":_safe_url(robots_url),"status":robots_status,"exists":robots_status==200,"robots_access_state":state,**parsed,"raw_length":len(robots_body),"raw":robots_body if include_raw else "","sitemaps":parsed.get("sitemaps",[]) if include_sitemaps else [],"security_txt":security,"security_probes":security_probes,"path_evaluation":evaluated,"attempts":attempts,"attempt_count":len(attempts),"request":{"headers":safe_headers,"timeout_ms":timeout,"retries":retry_count,"route":"auto" if use_proxy is None else ("proxy" if use_proxy else "direct")},"engine":"robots","equivalent":"RFC 9309 robots.txt / RFC 9116 security.txt","coverage_note":"Observed endpoint collection and parsing only; it does not crawl sitemaps, enforce robots access, follow redirect chains, cache, or verify security.txt signatures."}
