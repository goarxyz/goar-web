"""Portable API route discovery — SecLists plus Kiterunner-class route evidence."""

from __future__ import annotations

import gzip
import json
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

from .. import policy
from .._http import http_request, redact_url

_PATH = Path(__file__).with_name("data") / "api-endpoints.txt.gz"
_EPS: list[str] | None = None
_MANIFEST_PATHS = (
    "openapi.json", "swagger.json", "api-docs", "v2/api-docs",
    "v3/api-docs", ".well-known/openid-configuration",
)
_DEFAULT_INTERESTING = {200, 201, 202, 204, 301, 302, 307, 308, 401, 403, 405, 500}


def _eps() -> list[str]:
    global _EPS
    if _EPS is None:
        with gzip.open(_PATH, "rt", encoding="utf-8") as handle:
            _EPS = [line.strip() for line in handle.read().splitlines() if line.strip()]
    return _EPS


def _target(url: str) -> str:
    value = str(url or "").strip()
    if not value:
        raise ValueError("url is required")
    value = value if value.startswith(("http://", "https://")) else "https://" + value
    return value if value.endswith("/") else value + "/"


def _headers(raw: str | dict | None, user_agent: str) -> dict[str, str]:
    result = {"User-Agent": user_agent, "Accept": "application/json, application/yaml, */*"}
    if raw in (None, ""):
        return result
    if isinstance(raw, dict):
        result.update({str(key): str(value) for key, value in raw.items()})
        return result
    text = str(raw).strip()
    if text.startswith("{"):
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValueError(f"headers must be JSON or Header: value lines: {exc}") from exc
        if not isinstance(parsed, dict):
            raise ValueError("headers JSON must be an object")
        result.update({str(key): str(value) for key, value in parsed.items()})
        return result
    for line in text.splitlines():
        if ":" in line:
            key, _, value = line.partition(":")
            if key.strip():
                result[key.strip()] = value.strip()
    return result


def _safe_headers(headers: dict[str, str]) -> dict[str, str]:
    return {key: ("[redacted]" if key.lower() in {"authorization", "cookie", "x-api-key"} else value) for key, value in headers.items()}


def _route(value: str | bool | None) -> bool | None:
    if value in (None, "", "auto", "AUTO"):
        return None
    if value in (True, "proxy", "PROXY", "true", "True"):
        return True
    if value in (False, "direct", "DIRECT", "false", "False"):
        return False
    raise ValueError("route must be auto, proxy, or direct")


def _int_set(raw: str, default: set[int]) -> set[int]:
    parsed = {int(item.strip()) for item in str(raw or "").split(",") if item.strip().isdigit()}
    return parsed or set(default)


def _paths(raw: str, include_standard: bool, limit: int) -> tuple[list[str], str]:
    custom = [item.strip().lstrip("/") for item in str(raw or "").replace(",", "\n").splitlines() if item.strip()]
    source = "custom" if custom and not include_standard else ("SecLists+custom" if custom else "SecLists")
    merged = (list(_eps()) if include_standard else []) + custom
    seen: set[str] = set()
    output: list[str] = []
    for item in merged:
        if item and item not in seen:
            seen.add(item)
            output.append(item)
        if len(output) >= limit:
            break
    return output, source


def _classify_manifest(path: str, body: str) -> dict[str, Any] | None:
    try:
        payload = json.loads(body)
    except Exception:
        return None
    if not isinstance(payload, dict):
        return None
    if payload.get("openapi") or payload.get("swagger"):
        routes = []
        for route, config in (payload.get("paths") or {}).items():
            if not isinstance(config, dict):
                continue
            methods = sorted(method.upper() for method, details in config.items() if isinstance(details, dict) and method.lower() in {"get", "post", "put", "patch", "delete", "head", "options"})
            if methods:
                routes.append({"path": route, "methods": methods})
        return {"kind": "openapi", "version": payload.get("openapi") or payload.get("swagger"), "title": ((payload.get("info") or {}).get("title")), "route_count": len(routes), "routes": routes[:200]}
    if "issuer" in payload and ("jwks_uri" in payload or "authorization_endpoint" in payload):
        return {"kind": "oidc", "issuer": payload.get("issuer"), "authorization_endpoint": payload.get("authorization_endpoint"), "token_endpoint": payload.get("token_endpoint"), "jwks_uri": payload.get("jwks_uri")}
    return None


def list_endpoints(limit: int = 0) -> dict[str, Any]:
    rows = _eps()
    out = rows[: int(limit)] if limit and int(limit) > 0 else rows
    return {"ok": True, "count": len(rows), "returned": len(out), "endpoints": out, "source": "SecLists/Discovery/Web-Content/api/api-endpoints.txt", "engine": "api", "equivalent": "SecLists API endpoints"}


async def _request(
    url: str, method: str, headers: dict[str, str], body: str, timeout_ms: int,
    retries: int, retry_statuses: set[int], use_proxy: bool | None,
) -> dict[str, Any]:
    attempts: list[dict[str, Any]] = []
    response: dict[str, Any] = {}
    for index in range(retries + 1):
        response = await http_request(url, method=method, headers=headers, body=body or None, timeout_ms=timeout_ms, use_proxy=use_proxy)
        attempts.append({"attempt": index + 1, "status": response.get("status"), "ok": response.get("ok"), "transport": response.get("transport"), "elapsed_ms": response.get("elapsed_ms"), "error": response.get("error"), "final_url": redact_url(response.get("final_url"))})
        if response.get("ok") or int(response.get("status") or 0) not in retry_statuses:
            break
    response = dict(response)
    response["attempts"] = attempts
    response["attempt_count"] = len(attempts)
    response["final_url"] = redact_url(response.get("final_url") or url)
    return response


async def discover(
    url: str,
    max_endpoints: int = 40,
    user_agent: str = "pyodide-security/api-discover/2.0",
    max_paths: int | None = None,
    method: str = "GET",
    headers: str = "",
    body: str = "",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    custom_paths: str = "",
    include_standard: bool = True,
    discover_manifests: bool = True,
    interesting_statuses: str = "200,201,202,204,301,302,307,308,401,403,405,500",
) -> dict[str, Any]:
    """Discover bounded API routes and local API manifests with reproducible request evidence."""
    target = _target(url)
    err = policy.check_url_for_active(target) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "engine": "api"}
    method_u = (method or "GET").upper()
    if method_u not in {"GET", "HEAD", "OPTIONS", "POST", "PUT", "PATCH", "DELETE"}:
        raise ValueError("unsupported HTTP method")
    limit = max(1, min(int(max_paths if max_paths is not None else max_endpoints or 40), 250))
    timeout = max(1000, min(int(timeout_ms or 8000), 120000))
    retry_count = max(0, min(int(retries or 0), 5))
    retryable = _int_set(retry_statuses, {408, 429, 500, 502, 503, 504})
    interesting = _int_set(interesting_statuses, _DEFAULT_INTERESTING)
    req_headers = _headers(headers, user_agent)
    use_proxy = _route(route)
    paths, source = _paths(custom_paths, bool(include_standard), limit)
    manifests = list(_MANIFEST_PATHS) if discover_manifests else []
    manifest_set = set(manifests)
    targets: list[tuple[str, str]] = [("manifest", item) for item in manifests] + [("candidate", item) for item in paths]
    found: list[dict[str, Any]] = []
    manifest_results: list[dict[str, Any]] = []
    executions: list[dict[str, Any]] = []
    for kind, endpoint in targets:
        if not policy.can_request():
            break
        request_url = urljoin(target, endpoint.lstrip("/"))
        response = await _request(request_url, method_u, req_headers, body, timeout, retry_count, retryable, use_proxy)
        status = int(response.get("status") or 0)
        response_body = str(response.get("body") or "")
        response_headers = response.get("headers") or {}
        content_type = response_headers.get("content-type") or response_headers.get("Content-Type") or ""
        entry = {
            "kind": kind, "endpoint": endpoint, "url": redact_url(request_url), "final_url": response.get("final_url"),
            "status": status, "ok": bool(response.get("ok")), "content_type": content_type,
            "body_length": len(response_body), "json_like": response_body.lstrip()[:1] in ("{", "["),
            "transport": response.get("transport"), "attempts": response.get("attempts") or [],
        }
        executions.append(entry)
        if kind == "manifest":
            parsed = _classify_manifest(endpoint, response_body)
            if parsed:
                manifest_results.append({**entry, "manifest": parsed})
        if status in interesting:
            found.append(entry)
    return {
        "ok": True,
        "url": redact_url(target),
        "method": method_u,
        "tested": len(executions),
        "candidate_paths_requested": len(paths),
        "manifest_paths_requested": len(manifests),
        "found": found,
        "found_count": len(found),
        "manifests": manifest_results,
        "manifest_count": len(manifest_results),
        "executions": executions,
        "endpoint_db": len(_eps()),
        "source": source,
        "request": {"headers": _safe_headers(req_headers), "body": body or "", "timeout_ms": timeout, "retries": retry_count, "route": "auto" if use_proxy is None else ("proxy" if use_proxy else "direct"), "interesting_statuses": sorted(interesting)},
        "engine": "api",
        "equivalent": "Kiterunner lite / SecLists API endpoints",
        "policy": policy.status(),
    }
