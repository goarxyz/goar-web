"""Passive intel aggregator — CT + InternetDB + RDAP pointers."""
from __future__ import annotations
from typing import Any

async def lookup(target: str)->dict[str,Any]:
    from ..ct_engine import search as ct_search
    from ..rdap_engine import domain_rdap
    from ..internetdb_engine import lookup as idb
    out={"ok":True,"target":target,"engine":"intel"}
    # heuristic ip vs domain
    parts=target.strip().split(".")
    is_ip=len(parts)==4 and all(p.isdigit() and 0<=int(p)<=255 for p in parts if p.isdigit())
    try:
        if is_ip:
            out["internetdb"]=await idb(target)
        else:
            out["ct"]=await ct_search(target)
            out["rdap"]=await domain_rdap(target)
    except Exception as e:
        out["error"]=str(e)
    return out


async def urlhaus_url(url: str = "", query: str = "", headers: str = "", timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = "408,429,500,502,503,504", route: str = "auto"):
    url = str(url or query or "").strip()
    if not url: return {"ok": False, "error": "url required", "engine": "intel", "source": "urlhaus"}
    from .._http import http_request, redact_url
    from urllib.parse import quote
    import json as _json
    request_headers={"Content-Type":"application/x-www-form-urlencoded","Accept":"application/json"}; raw=str(headers or "").strip()
    if raw.startswith("{"):
        extra=_json.loads(raw)
        if not isinstance(extra,dict): raise ValueError("headers JSON must be an object")
        request_headers.update({str(k):str(v) for k,v in extra.items()})
    else:
        for line in raw.splitlines():
            if ":" in line:
                k,_,v=line.partition(":");request_headers[k.strip()]=v.strip()
    use_proxy=None if route in (None,"","auto","AUTO") else True if route in (True,"proxy","PROXY","true","True") else False if route in (False,"direct","DIRECT","false","False") else (_ for _ in ()).throw(ValueError("route must be auto, proxy, or direct"))
    endpoint="https://urlhaus-api.abuse.ch/v1/url/"; timeout=max(1000,min(int(timeout_ms or 8000),120000));retryable={int(x.strip()) for x in str(retry_statuses).split(",") if x.strip().isdigit()};attempts=[];resp={}
    for i in range(max(0,min(int(retries or 0),5))+1):
        resp=await http_request(endpoint,method="POST",headers=request_headers,body=f"url={quote(url)}",timeout_ms=timeout,use_proxy=use_proxy)
        attempts.append({"attempt":i+1,"status":resp.get("status"),"error":resp.get("error"),"transport":resp.get("transport"),"final_url":redact_url(resp.get("final_url"))})
        if resp.get("ok") or int(resp.get("status") or 0) not in retryable:break
    body=str(resp.get("body") or "")
    try:data=_json.loads(body)
    except Exception:data=None
    safe={k:("[redacted]" if k.lower() in {"authorization","cookie","x-api-key"} else v) for k,v in request_headers.items()}
    return {"ok":bool(resp.get("ok")) and isinstance(data,dict),"url":url,"status":resp.get("status"),"data":data,"summary":{"query_status":(data or {}).get("query_status"),"threat":(data or {}).get("threat"),"url_status":(data or {}).get("url_status"),"host":(data or {}).get("host")},"body":body,"body_length":len(body),"error":resp.get("error") or (None if isinstance(data,dict) else "non-JSON URLhaus response"),"attempts":attempts,"attempt_count":len(attempts),"request":{"endpoint":redact_url(endpoint),"headers":safe,"timeout_ms":timeout,"retries":retries,"route":"auto" if use_proxy is None else ("proxy" if use_proxy else "direct")},"final_url":redact_url(resp.get("final_url") or endpoint),"transport":resp.get("transport"),"engine":"intel","source":"urlhaus","equivalent":"URLhaus Community API"}

async def threatfox_search(query: str, headers: str = "", timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = "408,429,500,502,503,504", route: str = "auto"):
    from .._http import http_request, redact_url
    import json as _json
    query=str(query or "").strip()
    if not query:return {"ok":False,"error":"query required","engine":"intel","source":"threatfox"}
    request_headers={"Content-Type":"application/json","Accept":"application/json"};raw=str(headers or "").strip()
    if raw.startswith("{"):
        extra=_json.loads(raw)
        if not isinstance(extra,dict):raise ValueError("headers JSON must be an object")
        request_headers.update({str(k):str(v) for k,v in extra.items()})
    else:
        for line in raw.splitlines():
            if ":" in line:
                k,_,v=line.partition(":");request_headers[k.strip()]=v.strip()
    use_proxy=None if route in (None,"","auto","AUTO") else True if route in (True,"proxy","PROXY","true","True") else False if route in (False,"direct","DIRECT","false","False") else (_ for _ in ()).throw(ValueError("route must be auto, proxy, or direct"))
    endpoint="https://threatfox-api.abuse.ch/api/v1/";timeout=max(1000,min(int(timeout_ms or 8000),120000));retryable={int(x.strip()) for x in str(retry_statuses).split(",") if x.strip().isdigit()};attempts=[];resp={}
    for i in range(max(0,min(int(retries or 0),5))+1):
        resp=await http_request(endpoint,method="POST",headers=request_headers,body=_json.dumps({"query":"search_ioc","search_term":query}),timeout_ms=timeout,use_proxy=use_proxy)
        attempts.append({"attempt":i+1,"status":resp.get("status"),"error":resp.get("error"),"transport":resp.get("transport"),"final_url":redact_url(resp.get("final_url"))})
        if resp.get("ok") or int(resp.get("status") or 0) not in retryable:break
    body=str(resp.get("body") or "")
    try:data=_json.loads(body)
    except Exception:data=None
    rows=(data or {}).get("data") or [];safe={k:("[redacted]" if k.lower() in {"authorization","cookie","x-api-key"} else v) for k,v in request_headers.items()}
    return {"ok":bool(resp.get("ok")) and isinstance(data,dict),"query":query,"status":resp.get("status"),"data":data,"summary":{"query_status":(data or {}).get("query_status"),"count":len(rows) if isinstance(rows,list) else 0,"ioc_types":sorted({str(x.get("ioc_type")) for x in rows if isinstance(x,dict) and x.get("ioc_type")})},"body":body,"body_length":len(body),"error":resp.get("error") or (None if isinstance(data,dict) else "non-JSON ThreatFox response"),"attempts":attempts,"attempt_count":len(attempts),"request":{"endpoint":redact_url(endpoint),"headers":safe,"timeout_ms":timeout,"retries":retries,"route":"auto" if use_proxy is None else ("proxy" if use_proxy else "direct")},"final_url":redact_url(resp.get("final_url") or endpoint),"transport":resp.get("transport"),"engine":"intel","source":"threatfox","equivalent":"ThreatFox Community API"}

async def otx_domain(domain: str, api_key: str = "", headers: str = "", timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = "408,429,500,502,503,504", route: str = "auto"):
    from .._http import http_request, redact_url
    from urllib.parse import quote
    import json as _json
    domain = str(domain or "").strip().lower().rstrip(".")
    if not domain: return {"ok": False, "error": "domain required", "engine": "intel", "source": "otx"}
    request_headers = {"Accept": "application/json"}
    if api_key: request_headers["X-OTX-API-KEY"] = str(api_key)
    raw = str(headers or "").strip()
    if raw.startswith("{"):
        extra = _json.loads(raw)
        if not isinstance(extra, dict): raise ValueError("headers JSON must be an object")
        request_headers.update({str(k): str(v) for k, v in extra.items()})
    else:
        for line in raw.splitlines():
            if ":" in line:
                k, _, v = line.partition(":"); request_headers[k.strip()] = v.strip()
    use_proxy = None if route in (None, "", "auto", "AUTO") else True if route in (True, "proxy", "PROXY", "true", "True") else False if route in (False, "direct", "DIRECT", "false", "False") else (_ for _ in ()).throw(ValueError("route must be auto, proxy, or direct"))
    url = f"https://otx.alienvault.com/api/v1/indicators/domain/{quote(domain)}/general"; timeout = max(1000, min(int(timeout_ms or 8000), 120000)); retryable = {int(x.strip()) for x in str(retry_statuses).split(",") if x.strip().isdigit()}; attempts=[]; resp={}
    for i in range(max(0, min(int(retries or 0), 5)) + 1):
        resp = await http_request(url, headers=request_headers, timeout_ms=timeout, use_proxy=use_proxy)
        attempts.append({"attempt": i + 1, "status": resp.get("status"), "error": resp.get("error"), "transport": resp.get("transport"), "final_url": redact_url(resp.get("final_url"))})
        if resp.get("ok") or int(resp.get("status") or 0) not in retryable: break
    body = str(resp.get("body") or "")
    try: data = _json.loads(body)
    except Exception: data = None
    pulses = (data or {}).get("pulse_info") or {}; safe_headers = {k: ("[redacted]" if k.lower() in {"authorization", "cookie", "x-api-key", "x-otx-api-key"} else v) for k, v in request_headers.items()}
    return {"ok": bool(resp.get("ok")) and isinstance(data, dict), "domain": domain, "status": resp.get("status"), "data": data, "summary": {"pulse_count": pulses.get("count"), "pulses": pulses.get("pulses") or [], "reputation": (data or {}).get("reputation")}, "body": body, "body_length": len(body), "error": resp.get("error") or (None if isinstance(data, dict) else "non-JSON OTX response"), "attempts": attempts, "attempt_count": len(attempts), "request": {"url": redact_url(url), "headers": safe_headers, "timeout_ms": timeout, "retries": retries, "route": "auto" if use_proxy is None else ("proxy" if use_proxy else "direct")}, "final_url": redact_url(resp.get("final_url") or url), "transport": resp.get("transport"), "engine": "intel", "source": "otx", "equivalent": "OTX DirectConnect general indicator"}
