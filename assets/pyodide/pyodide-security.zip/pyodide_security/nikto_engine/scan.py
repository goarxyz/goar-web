"""
Nikto web server scanner — browser-adapted from sullo/nikto.

Preserves the bundled converted db_tests/db_variables corpus while routing every
request through Goar's shared transport. Native plugins, sockets, TLS controls,
interactive update/reporting, and destructive workflows are intentionally not
simulated.
"""
from __future__ import annotations

import gzip
import json
import random
import re
from functools import lru_cache
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

from .._http import http_request, redact_url
from .. import policy

_DATA = Path(__file__).resolve().parent / "data" / "nikto.json.gz"
_SENSITIVE = {"authorization", "cookie", "set-cookie", "x-api-key", "proxy-authorization"}


@lru_cache(maxsize=1)
def _load() -> dict:
    return json.loads(gzip.decompress(_DATA.read_bytes()))


def _expand_uri(uri: str, variables: dict, max_expansions: int = 3) -> list[str]:
    """Expand converted Nikto URI macros with a strict per-test bound."""
    if "@" not in uri:
        return [uri]
    results = [uri]
    for var, values in variables.items():
        next_results = []
        for value in results:
            if var in value:
                next_results.extend(value.replace(var, item) for item in values[:8])
            else:
                next_results.append(value)
        results = next_results[: max(1, min(int(max_expansions or 3), 20))]
    return results


def _safe_headers(headers: dict[str, Any]) -> dict[str, str]:
    return {str(key): "[redacted]" if str(key).lower() in _SENSITIVE else str(value) for key, value in headers.items()}


def _safe_text(value: Any) -> str:
    pattern = r'''(?im)(?:["'])?(apikey|api_key|access_token|authorization|proxy-authorization|cookie|secret|token|password)(?:["'])?\s*(=|:)\s*(?:["'])?[^\r\n,;<>{}"']+'''
    return re.sub(pattern, lambda match: f"{match.group(1)}{match.group(2)}[redacted]", str(value or ""))


def _headers(raw: str, user_agent: str, vhost: str) -> dict[str, str]:
    out = {"User-Agent": str(user_agent or "Mozilla/5.0 (Nikto/pyodide-security)")}
    text = str(raw or "").strip()
    if text.startswith("{"):
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValueError(f"headers must be JSON or Header: value lines: {exc}") from exc
        if not isinstance(parsed, dict):
            raise ValueError("headers JSON must be an object")
        out.update({str(key): str(value) for key, value in parsed.items()})
    else:
        for line in text.splitlines():
            if ":" in line:
                key, _, value = line.partition(":")
                if key.strip():
                    out[key.strip()] = value.strip()
    if str(vhost or "").strip():
        out["Host"] = str(vhost).strip()
    return out


def _route(value: str | bool | None) -> bool | None:
    if value in (None, "", "auto", "AUTO"):
        return None
    if value in (True, "proxy", "PROXY", "true", "True"):
        return True
    if value in (False, "direct", "DIRECT", "false", "False"):
        return False
    raise ValueError("route must be auto, proxy, or direct")


def _codes(raw: str) -> set[int]:
    return {int(value.strip()) for value in str(raw or "").split(",") if value.strip().isdigit() and 100 <= int(value.strip()) <= 599}


def _rule_match(kind: str, pattern: str, status: int, body: str, headers: dict[str, Any]) -> bool:
    source = ""
    upper = kind.upper()
    if upper == "CODE":
        return str(status) == str(pattern).strip()
    if upper == "HEADER":
        source = "\n".join(f"{key}: {value}" for key, value in headers.items())
    elif upper == "COOKIE":
        source = str(headers.get("Set-Cookie") or headers.get("set-cookie") or "")
    else:
        source = body or ""
    try:
        return bool(re.search(pattern, source, re.I | re.S))
    except re.error:
        return pattern.lower() in source.lower()


def _match_response(match_rule: str, status: int, body: str, headers: dict[str, Any] | None = None) -> bool:
    """Evaluate converted Nikto BODY/HEADER/COOKIE/CODE and negated match DSL."""
    if not match_rule:
        return status == 200
    headers = headers or {}
    for part in str(match_rule).split("&&"):
        token = part.strip()
        if not token:
            continue
        negate = token.startswith("!")
        if negate:
            token = token[1:].strip()
        kind, separator, pattern = token.partition(":")
        matched = _rule_match(kind if separator else "BODY", pattern if separator else token, status, body, headers)
        if negate:
            matched = not matched
        if not matched:
            return False
    return True


def _tuning_allowed(test: dict[str, Any], tuning: str) -> bool:
    raw = str(tuning or "").strip().lower()
    if not raw:
        return True
    value = str(test.get("tuning", "")).lower()
    include, marker, exclude = raw.partition("x")
    if marker:
        if include and not any(item in value for item in include):
            return False
        return not any(item in value for item in exclude)
    return any(item in value for item in raw)


def _id_set(raw: str) -> set[str]:
    return {item.strip() for item in str(raw or "").split(",") if item.strip()}


def list_tests(limit: int = 20, tuning: str = "") -> dict[str, Any]:
    data = _load(); tests = [test for test in data["tests"] if _tuning_allowed(test, tuning)]
    return {"total": len(data["tests"]), "selected": len(tests), "variables": len(data["variables"]), "sample": tests[: max(1, min(int(limit), 50))], "source": "sullo/nikto program/databases/db_tests"}


async def scan(
    url: str,
    max_tests: int = 80,
    tuning: str = "",
    user_agent: str = "Mozilla/5.0 (Nikto/pyodide-security)",
    headers: str = "",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    root: str = "",
    vhost: str = "",
    include_test_ids: str = "",
    exclude_test_ids: str = "",
    ignore_statuses: str = "",
    ignore_body_regex: str = "",
    max_uri_expansions: int = 3,
    max_findings: int = 100,
    stop_on_finding: bool = False,
    include_bodies: bool = False,
    body_preview_chars: int = 1000,
    include_attempts: bool = True,
    shuffle_tests: bool = True,
    random_seed: int = 0,
) -> dict[str, Any]:
    """Run a bounded converted Nikto test selection through shared Goar transport."""
    url = str(url or "").strip()
    if not url:
        return {"ok": False, "error": "url required", "engine": "nikto"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    err = policy.check_url_for_active(url)
    if err:
        return {"ok": False, "error": err, "engine": "nikto"}
    base = url.rstrip("/") + "/"
    root_path = "/" + str(root or "").strip("/") if str(root or "").strip("/") else ""
    base = urljoin(base, root_path.lstrip("/") + "/") if root_path else base
    request_headers = _headers(headers, user_agent, vhost)
    timeout = max(1000, min(int(timeout_ms or 8000), 120000)); retry_count = max(0, min(int(retries or 0), 5)); retryable = _codes(retry_statuses)
    test_limit = max(1, min(int(max_tests or 80), 500)); finding_limit = max(1, min(int(max_findings or 100), 1000)); preview = max(0, min(int(body_preview_chars or 1000), 200000)); include_ids = _id_set(include_test_ids); exclude_ids = _id_set(exclude_test_ids)
    data = _load(); variables = data["variables"]
    tests = [test for test in data["tests"] if _tuning_allowed(test, tuning) and (not include_ids or str(test.get("id")) in include_ids) and str(test.get("id")) not in exclude_ids]
    if bool(shuffle_tests) and len(tests) > test_limit:
        cve = [test for test in tests if test.get("cve")]; other = [test for test in tests if not test.get("cve")]
        random.Random(int(random_seed or 0)).shuffle(other); tests = (cve + other)[:test_limit]
    else:
        tests = tests[:test_limit]
    findings: list[dict[str, Any]] = []; attempts: list[dict[str, Any]] = []; tested = 0; stopped_reason = None; ignored = 0
    ignore_pattern = str(ignore_body_regex or "").strip()
    try:
        ignored_body = re.compile(ignore_pattern, re.I | re.S) if ignore_pattern else None
    except re.error as exc:
        raise ValueError(f"ignore_body_regex is invalid: {exc}") from exc
    for test in tests:
        if tested >= test_limit or len(findings) >= finding_limit:
            stopped_reason = "max_tests" if tested >= test_limit else "max_findings"; break
        if not policy.can_request():
            stopped_reason = "policy_budget"; break
        for uri in _expand_uri(str(test.get("uri") or "/"), variables, max_uri_expansions):
            if tested >= test_limit or len(findings) >= finding_limit:
                stopped_reason = "max_tests" if tested >= test_limit else "max_findings"; break
            if not policy.can_request():
                stopped_reason = "policy_budget"; break
            target = urljoin(base, uri.lstrip("/")); method = str(test.get("method") or "GET").upper(); response: dict[str, Any] = {}; per_request = []
            for retry_index in range(retry_count + 1):
                response = await http_request(target, method=method, headers=request_headers, timeout_ms=timeout, use_proxy=_route(route))
                attempt = {"test_id": test.get("id"), "uri": uri, "attempt": retry_index + 1, "status": response.get("status"), "ok": response.get("ok"), "transport": response.get("transport"), "elapsed_ms": response.get("elapsed_ms"), "error": _safe_text(response.get("error")), "final_url": redact_url(response.get("final_url") or target)}
                per_request.append(attempt)
                if response.get("ok") or int(response.get("status") or 0) not in retryable:
                    break
            if include_attempts:
                attempts.extend(per_request)
            tested += 1; status = int(response.get("status") or 0); body = str(response.get("body") or ""); response_headers = response.get("headers") or {}
            if status in _codes(ignore_statuses) or (ignored_body is not None and ignored_body.search(body)):
                ignored += 1; continue
            if _match_response(str(test.get("match") or ""), status, body, response_headers):
                finding = {"id": test.get("id"), "cve": test.get("cve") or "", "tuning": test.get("tuning") or "", "uri": uri, "url": redact_url(target), "status": status, "description": test.get("description") or "", "match": test.get("match") or "", "response_headers": _safe_headers(response_headers), "body_length": len(body), "transport": response.get("transport"), "final_url": redact_url(response.get("final_url") or target)}
                if include_bodies:
                    finding["body_preview"] = _safe_text(body)[:preview]
                findings.append(finding)
                if stop_on_finding:
                    stopped_reason = "stop_on_finding"; break
        if stopped_reason == "stop_on_finding":
            break
    return {"ok": True, "url": redact_url(url), "base_url": redact_url(base), "tested": tested, "available_tests": len(data["tests"]), "selected_tests": len(tests), "findings": findings, "finding_count": len(findings), "ignored": ignored, "stopped_reason": stopped_reason, "db_tests": len(data["tests"]), "variables": len(variables), "attempts": attempts if include_attempts else None, "attempt_count": len(attempts), "request": {"headers": _safe_headers(request_headers), "timeout_ms": timeout, "retries": retry_count, "retry_statuses": sorted(retryable), "route": "auto" if _route(route) is None else ("proxy" if _route(route) else "direct"), "root": root_path or None, "vhost": vhost or None, "tuning": tuning or None, "include_test_ids": sorted(include_ids), "exclude_test_ids": sorted(exclude_ids), "max_uri_expansions": max(1, min(int(max_uri_expansions or 3), 20)), "shuffle_tests": bool(shuffle_tests), "random_seed": int(random_seed or 0)}, "engine": "nikto", "version": "3.0-nikto", "equivalent": "sullo/nikto", "source": "https://github.com/sullo/nikto", "policy": policy.status()}
