"""Browser-adapted Set-Cookie security analysis through shared Goar transport."""
from __future__ import annotations
import json
import re
from typing import Any
from urllib.parse import urljoin, urlparse
from .._http import http_request, redact_url
from .. import policy


def parse_set_cookie(raw:str)->dict[str,Any]:
    parts=[part.strip() for part in str(raw or "").split(";")]
    if not parts or "=" not in parts[0]:return {"name":"","value_preview":"","value_length":0,"flags":{},"invalid":True}
    name,_,value=parts[0].partition("=");flags={}
    for part in parts[1:]:
        key,sep,item=part.partition("=");flags[key.lower().strip()]=item.strip() if sep else True
    return {"name":name.strip(),"value_preview":"[redacted]" if value else "","value_length":len(value or ""),"flags":flags,"httponly":"httponly" in flags,"secure":"secure" in flags,"samesite":str(flags.get("samesite","")).lower() or None,"path":flags.get("path"),"domain":flags.get("domain"),"max-age":flags.get("max-age"),"expires":flags.get("expires"),"partitioned":"partitioned" in flags,"invalid":not bool(name.strip())}

def analyze_cookies(set_cookie_headers:list[str],request_url:str="")->dict[str,Any]:
    cookies=[parse_set_cookie(header) for header in set_cookie_headers if header];issues=[];host=(urlparse(request_url).hostname or "").lower();https=urlparse(request_url).scheme.lower()=="https"
    for cookie in cookies:
        name=cookie.get("name") or "";flags=cookie.get("flags") or {};same=cookie.get("samesite")
        def issue(label:str,severity:str):issues.append({"cookie":name or "[unnamed]","issue":label,"severity":severity})
        if cookie.get("invalid"):issue("invalid or nameless cookie", "high")
        if not cookie.get("httponly"):issue("missing HttpOnly","medium")
        if not cookie.get("secure"):issue("missing Secure","medium")
        if not same:issue("missing SameSite","low")
        elif same not in {"strict","lax","none"}:issue("invalid SameSite value","medium")
        elif same=="none" and not cookie.get("secure"):issue("SameSite=None without Secure","high")
        if name.startswith("__Secure-") and not cookie.get("secure"):issue("__Secure- prefix without Secure","high")
        if name.startswith("__Host-"):
            if not cookie.get("secure"):issue("__Host- prefix without Secure","high")
            if cookie.get("domain"):issue("__Host- prefix with Domain","high")
            if cookie.get("path")!="/":issue("__Host- prefix without Path=/","high")
        if cookie.get("secure") and not https:issue("Secure cookie observed on non-HTTPS URL","high")
        domain=str(cookie.get("domain") or "").lstrip(".").lower()
        if domain and host and domain!=host:issue("Domain scope extends beyond request host","low")
        if not cookie.get("path"):issue("missing explicit Path scope","low")
        if cookie.get("partitioned") and not cookie.get("secure"):issue("Partitioned without Secure","high")
    by_severity={level:sum(1 for item in issues if item["severity"]==level) for level in ("high","medium","low")}
    return {"cookies":cookies,"count":len(cookies),"issues":issues,"issue_count":len(issues),"severity_counts":by_severity,"request_host":host or None,"https":https}

def _headers(raw:str,user_agent:str)->dict[str,str]:
    out={"User-Agent":user_agent};text=str(raw or "").strip()
    if text.startswith("{"):
        parsed=json.loads(text)
        if not isinstance(parsed,dict):raise ValueError("headers JSON must be an object")
        out.update({str(key):str(value) for key,value in parsed.items()})
    else:
        for line in text.splitlines():
            if ":" in line:
                key,_,value=line.partition(":");out[key.strip()]=value.strip()
    return out

def _route(value:Any)->bool|None:
    if value in (None,"","auto","AUTO"):return None
    if value in (True,"proxy","PROXY","true","True"):return True
    if value in (False,"direct","DIRECT","false","False"):return False
    raise ValueError("route must be auto, proxy, or direct")

def _items(raw:str)->list[str]:return list(dict.fromkeys(item.strip() for item in str(raw or "").replace(",","\n").splitlines() if item.strip()))
def _safe_url(value:Any)->str:
    safe=redact_url(value)
    return re.sub(r"(?i)(%3f|%26)(apikey|api_key|key|token|access_token|authorization|secret|signature|sig)(%3d|=)[^&#]*",lambda match:match.group(1)+match.group(2)+match.group(3)+"[redacted]",safe)
def _set_cookie_lines(headers:dict[str,Any])->list[str]:
    output=[]
    for key,value in headers.items():
        if str(key).lower()=="set-cookie":
            if isinstance(value,(list,tuple)):output.extend(str(item) for item in value)
            else:output.extend(line for line in str(value).splitlines() if line.strip())
    return output

async def analyze(url:str,user_agent:str="pyodide-security/cookie/2.0",paths:str="/",max_paths:int=3,headers:str="",timeout_ms:int=8000,retries:int=0,retry_statuses:str="408,429,500,502,503,504",route:str="auto",stop_on_cookie:bool=False)->dict[str,Any]:
    url=str(url or "").strip()
    if not url:return {"ok":False,"error":"url required","engine":"cookie"}
    if not url.startswith(("http://","https://")):url="https://"+url
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err:return {"ok":False,"error":err,"engine":"cookie"}
    selected=(_items(paths) or ["/"])[:max(1,min(int(max_paths or 3),20))];timeout=max(1000,min(int(timeout_ms or 8000),120000));retry_count=max(0,min(int(retries or 0),5));retryable={int(value.strip()) for value in str(retry_statuses or "").split(",") if value.strip().isdigit()};use_proxy=_route(route);request_headers=_headers(headers,user_agent);all_lines=[];probes=[];attempts=[]
    for path in selected:
        target=urljoin(url.rstrip("/")+"/",path.lstrip("/")) if path not in ("", "/") else url;response={}
        for index in range(retry_count+1):
            response=await http_request(target,headers=request_headers,timeout_ms=timeout,use_proxy=use_proxy)
            attempts.append({"path":path,"attempt":index+1,"status":response.get("status"),"error":response.get("error"),"transport":response.get("transport"),"final_url":_safe_url(response.get("final_url"))})
            if response.get("ok") or int(response.get("status") or 0) not in retryable:break
        lines=_set_cookie_lines(response.get("headers") or {});all_lines.extend(lines);probes.append({"path":path,"url":_safe_url(target),"final_url":_safe_url(response.get("final_url") or target),"status":response.get("status"),"set_cookie_count":len(lines),"transport":response.get("transport"),"error":response.get("error")})
        if stop_on_cookie and lines:break
    result=analyze_cookies(all_lines,url);safe_headers={key:("[redacted]" if key.lower() in {"authorization","cookie","x-api-key"} else value) for key,value in request_headers.items()}
    result.update({"ok":True,"url":_safe_url(url),"probes":probes,"attempts":attempts,"attempt_count":len(attempts),"request":{"paths":selected,"headers":safe_headers,"timeout_ms":timeout,"retries":retry_count,"route":"auto" if use_proxy is None else ("proxy" if use_proxy else "direct")},"engine":"cookie","equivalent":"Set-Cookie security audit","coverage_note":"Audits observed Set-Cookie lines only; it does not emulate a browser cookie jar, third-party policy, partition storage, or authenticated state transitions."});return result

async def scan_url(url:str,**kw):return await analyze(url,**kw)
def analyze_header_block(headers:str="")->dict:
    lines=[]
    for line in str(headers or "").splitlines():
        if ":" in line and line.split(":",1)[0].strip().lower()=="set-cookie":lines.append(line.split(":",1)[1].strip())
        elif line.strip() and "set-cookie" not in line.lower():lines.append(line.strip())
    result=analyze_cookies(lines);result.update({"ok":True,"engine":"cookie","mode":"offline"});return result
