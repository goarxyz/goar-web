"""openssl dgst / *sum equivalent — multi-algorithm digests + HMAC."""

from __future__ import annotations

import base64
import hashlib
import hmac
from typing import Any

from ._md4 import md4, ntlm_hash

ALGORITHMS = [
    "md4",
    "md5",
    "sha1",
    "sha224",
    "sha256",
    "sha384",
    "sha512",
    "sha3_224",
    "sha3_256",
    "sha3_384",
    "sha3_512",
    "blake2b",
    "blake2s",
    "ntlm",
]

_WEAK = frozenset({"md4", "md5", "sha1", "ntlm"})


def _digest_bytes(algorithm: str, data: bytes) -> bytes:
    name = algorithm.lower().replace("-", "_")
    if name == "md4":
        return md4(data)
    if name == "ntlm":
        # NTLM expects unicode password; if raw bytes given, hash as-is via md4 of utf-16le interpretation
        try:
            text = data.decode("utf-8")
            return ntlm_hash(text)
        except UnicodeDecodeError:
            return md4(data)
    if name not in hashlib.algorithms_available and name not in (
        "sha3_224",
        "sha3_256",
        "sha3_384",
        "sha3_512",
        "blake2b",
        "blake2s",
        "md5",
        "sha1",
        "sha224",
        "sha256",
        "sha384",
        "sha512",
    ):
        raise ValueError(f"unsupported algorithm: {algorithm}")
    return hashlib.new(name, data).digest()


def _parse_input(data: str, encoding: str) -> bytes:
    enc = (encoding or "utf-8").lower()
    if enc in ("utf-8", "utf8", "text"):
        return data.encode("utf-8")
    if enc == "hex":
        cleaned = "".join(data.split())
        if cleaned.startswith(("0x", "0X")):
            cleaned = cleaned[2:]
        return bytes.fromhex(cleaned)
    if enc in ("base64", "b64"):
        pad = (-len(data.strip())) % 4
        return base64.b64decode(data.strip() + "=" * pad)
    raise ValueError("encoding must be utf-8, hex, or base64")


def digest(data: str, algorithm: str = "sha256", encoding: str = "utf-8") -> dict[str, Any]:
    raw = _parse_input(data, encoding)
    name = algorithm.lower().replace("-", "_")
    d = _digest_bytes(name, raw)
    return {
        "algorithm": name,
        "input_bytes": len(raw),
        "hex": d.hex(),
        "base64": base64.b64encode(d).decode("ascii"),
        "bits": len(d) * 8,
        "broken_for_collisions": name in _WEAK,
    }


def multi(data: str, encoding: str = "utf-8") -> dict[str, Any]:
    raw = _parse_input(data, encoding)
    digests = {}
    for alg in ALGORITHMS:
        digests[alg] = _digest_bytes(alg, raw).hex()
    return {"input_bytes": len(raw), "digests": digests}


def hmac_digest(
    data: str,
    key: str,
    algorithm: str = "sha256",
    encoding: str = "utf-8",
) -> dict[str, Any]:
    name = algorithm.lower().replace("-", "_")
    if name in ("md4", "ntlm"):
        raise ValueError("HMAC not supported for md4/ntlm in this tool; use sha256+")
    raw = _parse_input(data, encoding)
    key_b = key.encode("utf-8")
    d = hmac.new(key_b, raw, name).digest()
    return {
        "algorithm": f"hmac-{name}",
        "hex": d.hex(),
        "base64": base64.b64encode(d).decode("ascii"),
        "bits": len(d) * 8,
    }


def compare(a: str, b: str) -> dict[str, Any]:
    """Timing-safe compare of two strings (UTF-8)."""
    ab, bb = a.encode("utf-8"), b.encode("utf-8")
    if len(ab) != len(bb):
        # still run a compare on equal-length material to avoid trivial timing oracle on content
        hmac.compare_digest(ab[:1] or b"\x00", ab[:1] or b"\x00")
        return {"equal": False, "len_a": len(ab), "len_b": len(bb), "timing_safe": True}
    return {
        "equal": hmac.compare_digest(ab, bb),
        "len_a": len(ab),
        "len_b": len(bb),
        "timing_safe": True,
    }
