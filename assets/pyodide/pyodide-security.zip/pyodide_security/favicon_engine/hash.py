"""Browser-adapted Shodan-style favicon hashing with fidelity and evidence controls."""
from __future__ import annotations

import base64
import hashlib
import json
import re
import struct
from typing import Any
from urllib.parse import urljoin

from .. import policy
from .._http import http_request, redact_url

_SENSITIVE = re.compile(r"(?i)(authorization|cookie|set-cookie|x-api-key|api[_-]?key|token|secret|password)")
_LINK = re.compile(r"(?is)<link\b[^>]*\brel\s*=\s*['\"][^'\"]*\bicon\b[^'\"]*['\"][^>]*>")
_HREF = re.compile(r"(?is)\bhref\s*=\s*['\"]([^'\"]+)")


def _mmh3_32(data: bytes, seed: int = 0) -> int:
    c1, c2 = 0xcc9e2d51, 0x1b873593
    length, value, index = len(data), seed, 0
    while index + 4 <= length:
        block = struct.unpack_from("<I", data, index)[0]
        block = (block * c1) & 0xffffffff
        block = ((block << 15) | (block >> 17)) & 0xffffffff
        block = (block * c2) & 0xffffffff
        value ^= block
        value = ((value << 13) | (value >> 19)) & 0xffffffff
        value = (value * 5 + 0xe6546b64) & 0xffffffff
        index += 4
    block = 0
    tail = data[index:]
    if len(tail) >= 3:
        block ^= tail[2] << 16
    if len(tail) >= 2:
        block ^= tail[1] << 8
    if len(tail) >= 1:
        block ^= tail[0]
        block = (block * c1) & 0xffffffff
        block = ((block << 15) | (block >> 17)) & 0xffffffff
        block = (block * c2) & 0xffffffff
        value ^= block
    value ^= length
    value ^= value >> 16
    value = (value * 0x85ebca6b) & 0xffffffff
    value ^= value >> 13
    value = (value * 0xc2b2ae35) & 0xffffffff
    value ^= value >> 16
    return value - 0x100000000 if value >= 0x80000000 else value


def hash_bytes(data: bytes) -> dict[str, Any]:
    encoded = base64.encodebytes(data)
    return {"mmh3": _mmh3_32(encoded), "sha256": hashlib.sha256(data).hexdigest(), "md5": hashlib.md5(data).hexdigest(), "length": len(data)}


def _parse_headers(raw: str | dict[str, Any] | None, user_agent: str) -> dict[str, str]:
    headers = {"User-Agent": user_agent}
    if isinstance(raw, dict):
        headers.update({str(k): str(v) for k, v in raw.items()})
        return headers
    text = str(raw or "").strip()
    if text.startswith("{"):
        try:
            value = json.loads(text)
            if isinstance(value, dict):
                headers.update({str(k): str(v) for k, v in value.items()})
        except (TypeError, ValueError):
            pass
    else:
        for line in text.splitlines():
            if ":" in line:
                key, value = line.split(":", 1)
                if key.strip():
                    headers[key.strip()] = value.strip()
    return headers


def _redact_headers(headers: dict[str, str]) -> dict[str, str]:
    return {key: "[redacted]" if _SENSITIVE.search(key) else value for key, value in headers.items()}


def _route(value: str) -> tuple[str, bool | None]:
    value = str(value or "auto").lower()
    return ("proxy", True) if value == "proxy" else ("direct", False) if value == "direct" else ("auto", None)


def _codes(raw: str) -> set[int]:
    return {int(item.strip()) for item in str(raw or "").split(",") if item.strip().isdigit()}


def _candidate_urls(page_url: str, explicit: str, html: str, max_candidates: int) -> tuple[list[str], bool]:
    rows = [urljoin(page_url, explicit)] if explicit else []
    for match in _LINK.finditer(html or ""):
        href = _HREF.search(match.group(0))
        if href:
            rows.append(urljoin(page_url, href.group(1)))
    rows.append(urljoin(page_url, "/favicon.ico"))
    ordered = list(dict.fromkeys(rows))
    limit = max(1, min(int(max_candidates or 5), 30))
    return ordered[:limit], len(ordered) > limit


async def _request(url: str, headers: dict[str, str], timeout_ms: int, retries: int, retry_codes: set[int], route: str, attempts: list[dict[str, Any]], stage: str) -> dict[str, Any]:
    route_name, use_proxy = _route(route)
    response: dict[str, Any] = {}
    for number in range(max(0, min(int(retries or 0), 5)) + 1):
        response = await http_request(url, headers=headers, timeout_ms=max(1000, min(int(timeout_ms or 8000), 120000)), use_proxy=use_proxy)
        attempts.append({"stage": stage, "attempt": number + 1, "url": redact_url(url), "status": int(response.get("status") or 0), "ok": bool(response.get("ok")), "elapsed_ms": response.get("elapsed_ms"), "transport": response.get("transport"), "error": str(response.get("error") or "")[:240]})
        if response.get("ok") or int(response.get("status") or 0) not in retry_codes:
            break
    return response


async def hash(url: str, user_agent: str = "pyodide-security/favicon/3.0", headers: str | dict[str, Any] = "", timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = "408,429,500,502,503,504", route: str = "auto", favicon_url: str = "", max_candidates: int = 5, expected_statuses: str = "200", include_response_body: bool = False, preview_chars: int = 400, include_headers: bool = False, hash_all: bool = False) -> dict[str, Any]:
    url = str(url or "").strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    error = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if error:
        return {"ok": False, "error": error, "engine": "favicon-browser-adapted", "policy": policy.status()}
    request_headers = _parse_headers(headers, user_agent)
    retry_codes = _codes(retry_statuses) or {408, 429, 500, 502, 503, 504}
    accepted = _codes(expected_statuses) or {200}
    attempts: list[dict[str, Any]] = []
    page = await _request(url, request_headers, timeout_ms, retries, retry_codes, route, attempts, "page")
    candidates, truncated = _candidate_urls(url, favicon_url, str(page.get("body") or ""), max_candidates)
    results: list[dict[str, Any]] = []
    for candidate in candidates:
        if not policy.can_request():
            break
        response = await _request(candidate, request_headers, timeout_ms, retries, retry_codes, route, attempts, "favicon")
        raw = response.get("body") or ""
        data = raw.encode("utf-8", "replace") if isinstance(raw, str) else bytes(raw)
        status = int(response.get("status") or 0)
        if status not in accepted or len(data) <= 0:
            continue
        item = hash_bytes(data)
        item.update({"url": redact_url(candidate), "favicon_url": redact_url(candidate), "status": status, "content_type": next((str(v) for k, v in (response.get("headers") or {}).items() if str(k).lower() == "content-type"), None), "transport": response.get("transport"), "elapsed_ms": response.get("elapsed_ms"), "hash_compatibility": "text-transport-fallback", "compatibility_note": "The shared browser transport may expose decoded text rather than original bytes. MMH3 is exact only when the text round-trip preserves source bytes."})
        if include_response_body:
            item["body_preview"] = str(raw)[:max(0, min(int(preview_chars or 400), 5000))]
        if include_headers:
            item["response_headers"] = {str(k): str(v) for k, v in (response.get("headers") or {}).items()}
        results.append(item)
        if not hash_all:
            break
    output: dict[str, Any] = {"ok": bool(results), "url": redact_url(url), "results": results, "result_count": len(results), "candidates": [redact_url(value) for value in candidates], "candidates_truncated": truncated, "attempts": attempts, "attempt_count": len(attempts), "request": {"url": redact_url(url), "headers": _redact_headers(request_headers), "timeout_ms": max(1000, min(int(timeout_ms or 8000), 120000)), "retries": max(0, min(int(retries or 0), 5)), "route": _route(route)[0], "expected_statuses": sorted(accepted)}, "engine": "favicon-browser-adapted", "equivalent": "Shodan favicon MMH3", "limitations": ["Byte fidelity depends on the shared browser transport exposing original response bytes; this conversion reports text-fallback compatibility instead of claiming a universally exact remote favicon hash."], "policy": policy.status()}
    if results:
        output.update(results[0])
    else:
        output["error"] = "favicon not found with accepted status"
    return output


async def hash_url(url: str, user_agent: str = "pyodide-security/favicon/3.0", **kwargs: Any) -> dict[str, Any]:
    return await hash(url, user_agent=user_agent, **kwargs)
