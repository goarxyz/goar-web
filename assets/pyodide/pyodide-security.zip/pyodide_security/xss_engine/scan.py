"""
XSS scanner — 1:1 conversion of s0md3v/XSStrike core flow.

Ports:
  - config.py payloads, tags, eventHandlers, functions, fillings
  - htmlParser context detection (script / attribute / html)
  - checker efficiency scoring (partial ratio without fuzzywuzzy)
  - generator context-aware vectors
  - modes/scan.py probe → parse → generate → test loop

Source: https://github.com/s0md3v/XSStrike
"""
from __future__ import annotations

import json
import re
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from .._http import http_request, redact_url
from .. import policy
from ._xsstrike_payloads import (
    XSSCHECKER,
    MIN_EFFICIENCY,
    BAD_TAGS,
    TAGS,
    FILLINGS,
    E_FILLINGS,
    L_FILLINGS,
    J_FILLINGS,
    EVENT_HANDLERS,
    FUNCTIONS,
    PAYLOADS,
)


def _partial_ratio(a: str, b: str) -> int:
    """Lightweight stand-in for fuzzywuzzy.fuzz.partial_ratio (0-100)."""
    a, b = (a or "").lower(), (b or "").lower()
    if not a or not b:
        return 0
    if a in b or b in a:
        return 100
    # longest common substring ratio
    best = 0
    for i in range(len(a)):
        for j in range(i + 1, len(a) + 1):
            sub = a[i:j]
            if sub in b:
                best = max(best, len(sub))
    return int(100 * best / max(len(a), 1))


def _escaped(pos: int, string: str) -> bool:
    if pos <= 0:
        return False
    return string[pos - 1] == "\\"


def html_parser(response_text: str, checker: str = XSSCHECKER) -> dict[int, dict]:
    """
    Port of XSStrike core/htmlParser.htmlParser — returns occurrences map.
    """
    response = response_text or ""
    reflections = response.count(checker)
    position_and_context: dict[int, dict] = {}
    clean = re.sub(r"<!--[\s\S]*?-->", "", response)

    # script contexts
    scripts = re.findall(r"(?i)<script[^>]*>([\s\S]*?)</script>", clean)
    for script in scripts:
        for m in re.finditer(re.escape(checker), script):
            pos = m.start()
            quote = ""
            for i, ch in enumerate(script[pos : pos + 80]):
                if ch in ("/", "'", "`", '"') and not _escaped(i, script[pos : pos + 80]):
                    quote = ch
                    break
            position_and_context[pos] = {
                "context": "script",
                "details": {"quote": quote},
                "score": {},
            }

    # attribute contexts
    for m in re.finditer(r"<[^>]*?(" + re.escape(checker) + r")[^>]*?>", clean):
        match = m.group(0)
        pos = m.start(1)
        if any(abs(pos - p) < 3 for p in position_and_context):
            continue
        parts = re.split(r"\s+", match)
        tag = parts[0][1:].lower() if parts else ""
        Type, quote, name, value = "", "", "", ""
        for part in parts[1:]:
            if checker not in part:
                continue
            if "=" in part:
                qm = re.search(r"=([\'`\"])?", part)
                quote = qm.group(1) if qm and qm.group(1) else ""
                nv = part.split("=", 1)
                name, value = nv[0], nv[1] if len(nv) > 1 else ""
                Type = "name" if checker == name else "value"
            else:
                Type = "flag"
                name = part
        position_and_context[pos] = {
            "context": "attribute",
            "details": {"tag": tag, "type": Type, "quote": quote, "name": name, "value": value},
            "score": {},
        }

    # html body contexts
    if len(position_and_context) < reflections:
        for m in re.finditer(re.escape(checker), clean):
            pos = m.start()
            if any(abs(pos - p) < 3 for p in position_and_context):
                continue
            # bad context?
            bad = False
            for bt in BAD_TAGS:
                if re.search(rf"<{bt}[^>]*>[^<]*{re.escape(checker)}", clean[max(0, pos - 200) : pos + 50], re.I):
                    bad = True
                    break
            position_and_context[pos] = {
                "context": "html",
                "details": {"bad": bad},
                "score": {"<": 100, ">": 100},
            }

    return position_and_context


def generate_vectors(occurrences: dict) -> list[dict[str, Any]]:
    """Port of XSStrike generator — context-aware vectors from real config."""
    vectors: list[dict[str, Any]] = []
    seen = set()

    # always include raw config payloads
    for p in PAYLOADS:
        if p not in seen:
            seen.add(p)
            vectors.append({"payload": p, "context": "config", "efficiency_hint": 90})

    for pos, occ in occurrences.items():
        ctx = occ.get("context")
        details = occ.get("details") or {}

        if ctx == "html" and not details.get("bad"):
            for tag in TAGS:
                for event, allowed in EVENT_HANDLERS.items():
                    if tag not in allowed:
                        continue
                    for func in FUNCTIONS:
                        for fill in FILLINGS[:2]:
                            payload = f"<{tag}{fill}{event}={func}>"
                            if payload not in seen:
                                seen.add(payload)
                                vectors.append({"payload": payload, "context": "html", "efficiency_hint": 80})

        if ctx == "attribute":
            quote = details.get("quote") or ""
            name = (details.get("name") or "").lower()
            # break out of attribute
            for func in FUNCTIONS:
                for q in (quote, '"', "'", ""):
                    if q:
                        payload = f"{q} onmouseover={func} {q}"
                    else:
                        payload = f" onmouseover={func} "
                    if payload not in seen:
                        seen.add(payload)
                        vectors.append({"payload": payload, "context": "attribute", "efficiency_hint": 75})
            if name in ("href", "src", "action"):
                payload = "javascript:confirm(1)"
                if payload not in seen:
                    seen.add(payload)
                    vectors.append({"payload": payload, "context": "attribute-js", "efficiency_hint": 70})

        if ctx == "script":
            quote = details.get("quote") or ""
            for func in FUNCTIONS:
                for jf in J_FILLINGS:
                    payload = f"{quote}{jf}{func}//"
                    if payload not in seen:
                        seen.add(payload)
                        vectors.append({"payload": payload, "context": "script", "efficiency_hint": 85})

    return vectors


def efficiency_check(response_text: str, payload: str, checker: str = XSSCHECKER) -> int:
    """Port of checker.py efficiency idea — reflection fidelity."""
    check = f"st4r7s{payload}3nd"
    body = (response_text or "").lower()
    if "st4r7s" not in body:
        # fallback: direct payload reflection
        if payload.lower() in body:
            return _partial_ratio(payload, payload)
        return 0
    # find reflection windows
    best = 0
    for m in re.finditer("st4r7s", body):
        window = body[m.start() : m.start() + len(check) + 20]
        best = max(best, _partial_ratio(check.lower(), window))
    return best


_SAFE_METHODS = {"GET", "POST", "PUT", "PATCH"}


def _parse_headers(raw: str | dict | None, user_agent: str) -> dict[str, str]:
    out = {"User-Agent": str(user_agent or "pyodide-security/xsstrike/1.0")}
    if raw in (None, ""):
        return out
    if isinstance(raw, dict):
        out.update({str(key): str(value) for key, value in raw.items()})
        return out
    text = str(raw).strip()
    if text.startswith("{"):
        try:
            value = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValueError(f"headers must be a JSON object or Header: value lines: {exc}") from exc
        if not isinstance(value, dict):
            raise ValueError("headers JSON must be an object")
        out.update({str(key): str(value) for key, value in value.items()})
        return out
    for line in text.splitlines():
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        if key.strip():
            out[key.strip()] = value.strip()
    return out


def _safe_headers(headers: dict[str, str]) -> dict[str, str]:
    sensitive = {"authorization", "cookie", "set-cookie", "x-api-key", "proxy-authorization"}
    return {key: "[redacted]" if key.lower() in sensitive else value for key, value in headers.items()}


def _route(value: str | bool | None) -> bool | None:
    if value in (None, "", "auto", "AUTO"):
        return None
    if value in (True, "proxy", "PROXY", "true", "True"):
        return True
    if value in (False, "direct", "DIRECT", "false", "False"):
        return False
    raise ValueError("route must be auto, proxy, or direct")


def _retry_statuses(raw: str) -> set[int]:
    return {int(item.strip()) for item in str(raw or "").split(",") if item.strip().isdigit()}


def _inject_request(target: str, body: str, data_type: str, parameter: str, value: str) -> tuple[str, str, str]:
    mode = str(data_type or "query").lower()
    parsed = urlparse(target)
    if mode == "query":
        pairs = list(parse_qsl(parsed.query, keep_blank_values=True))
        selected = parameter or (pairs[0][0] if pairs else "q")
        replaced = False
        updated: list[tuple[str, str]] = []
        for key, item in pairs:
            if key == selected and not replaced:
                updated.append((key, value)); replaced = True
            else:
                updated.append((key, item))
        if not replaced:
            updated.append((selected, value))
        return urlunparse(parsed._replace(query=urlencode(updated, doseq=True))), body, selected
    if mode == "form":
        pairs = list(parse_qsl(body or "", keep_blank_values=True))
        selected = parameter or (pairs[0][0] if pairs else "q")
        replaced = False
        updated = []
        for key, item in pairs:
            if key == selected and not replaced:
                updated.append((key, value)); replaced = True
            else:
                updated.append((key, item))
        if not replaced:
            updated.append((selected, value))
        return target, urlencode(updated, doseq=True), selected
    if mode == "json":
        try:
            value_map = json.loads(body or "{}")
        except json.JSONDecodeError as exc:
            raise ValueError(f"JSON request body is invalid: {exc}") from exc
        if not isinstance(value_map, dict):
            raise ValueError("JSON request body must be an object")
        selected = parameter or (next(iter(value_map), "q"))
        value_map[selected] = value
        return target, json.dumps(value_map, separators=(",", ":")), selected
    raise ValueError("data_type must be query, form, or json")


async def _request_with_retries(target: str, method: str, headers: dict[str, str], body: str, timeout_ms: int, retries: int, retryable: set[int], use_proxy: bool | None) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    response: dict[str, Any] = {}
    attempts: list[dict[str, Any]] = []
    for index in range(retries + 1):
        response = await http_request(target, method=method, headers=headers, body=body or None, timeout_ms=timeout_ms, use_proxy=use_proxy)
        attempts.append({"attempt": index + 1, "status": response.get("status"), "ok": response.get("ok"), "transport": response.get("transport"), "elapsed_ms": response.get("elapsed_ms"), "error": response.get("error")})
        if response.get("ok") or int(response.get("status") or 0) not in retryable:
            break
    return response, attempts


async def scan(
    url: str,
    parameter: str = "",
    context: str = "",
    risk: int = 1,
    max_payloads: int = 8,
    min_efficiency: int = MIN_EFFICIENCY,
    user_agent: str = "pyodide-security/xsstrike/1.0",
    method: str = "GET",
    headers: str | dict = "",
    body: str = "",
    data_type: str = "query",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    include_attempts: bool = True,
    stop_on_first: bool = False,
) -> dict[str, Any]:
    target = str(url or "").strip()
    err = policy.check_url_for_active(target)
    if err:
        return {"ok": False, "error": err, "engine": "xss"}
    if not target.startswith(("http://", "https://")):
        target = "https://" + target
    method_u = str(method or "GET").upper()
    if method_u not in _SAFE_METHODS:
        raise ValueError("method must be GET, POST, PUT, or PATCH")
    mode = str(data_type or "query").lower()
    if mode == "query" and method_u != "GET":
        method_u = "GET"
    if mode in {"form", "json"} and method_u == "GET":
        method_u = "POST"
    timeout = max(1000, min(int(timeout_ms or 8000), 120000))
    retry_count = max(0, min(int(retries or 0), 5))
    use_proxy = _route(route)
    req_headers = _parse_headers(headers, user_agent)
    if mode == "json":
        req_headers.setdefault("Content-Type", "application/json")
    elif mode == "form":
        req_headers.setdefault("Content-Type", "application/x-www-form-urlencoded")

    probe_url, probe_body, selected = _inject_request(target, body, mode, parameter, XSSCHECKER)
    probe_response, probe_attempts = await _request_with_retries(probe_url, method_u, req_headers, probe_body, timeout, retry_count, _retry_statuses(retry_statuses), use_proxy)
    response_body = str(probe_response.get("body") or "")
    reflected = XSSCHECKER in response_body
    occurrences = html_parser(response_body, XSSCHECKER) if reflected else {}

    vectors = generate_vectors(occurrences) or [{"payload": payload, "context": "config", "efficiency_hint": 90} for payload in PAYLOADS]
    requested_context = str(context or "").strip().lower()
    if requested_context and requested_context not in {"all", "auto"}:
        filtered = [vector for vector in vectors if str(vector.get("context") or "").lower() == requested_context]
        if filtered:
            vectors = filtered
    cap = max(1, min(int(max_payloads or 8), 80))
    findings: list[dict[str, Any]] = []
    executions: list[dict[str, Any]] = []
    for vector in vectors[:cap]:
        if not policy.can_request():
            break
        payload = str(vector["payload"])
        test_url, test_body, _ = _inject_request(target, body, mode, selected, f"st4r7s{payload}3nd")
        response, attempts = await _request_with_retries(test_url, method_u, req_headers, test_body, timeout, retry_count, _retry_statuses(retry_statuses), use_proxy)
        efficiency = efficiency_check(str(response.get("body") or ""), payload)
        execution = {"payload": payload, "context": vector.get("context"), "efficiency": efficiency, "status": response.get("status"), "transport": response.get("transport"), "final_url": redact_url(response.get("final_url") or test_url), "attempts": attempts if include_attempts else [], "error": response.get("error")}
        executions.append(execution)
        if efficiency >= max(0, min(int(min_efficiency), 100)):
            findings.append({"payload": payload, "efficiency": efficiency, "context": vector.get("context"), "status": response.get("status"), "parameter": selected, "transport": response.get("transport")})
            if stop_on_first:
                break
    findings.sort(key=lambda item: -item["efficiency"])
    return {
        "ok": True,
        "url": redact_url(target),
        "parameter": selected,
        "method": method_u,
        "data_type": mode,
        "risk": max(1, min(int(risk or 1), 5)),
        "reflected_checker": reflected,
        "occurrences": {str(key): value for key, value in occurrences.items()},
        "occurrence_count": len(occurrences),
        "tested": len(executions),
        "findings": findings,
        "finding_count": len(findings),
        "executions": executions,
        "probe": {"status": probe_response.get("status"), "transport": probe_response.get("transport"), "attempts": probe_attempts if include_attempts else [], "body_length": len(response_body), "error": probe_response.get("error")},
        "request": {"headers": _safe_headers(req_headers), "body_length": len(str(body or "")), "timeout_ms": timeout, "retries": retry_count, "retry_statuses": sorted(_retry_statuses(retry_statuses)), "route": "auto" if use_proxy is None else ("proxy" if use_proxy else "direct"), "context": requested_context or "auto", "stop_on_first": bool(stop_on_first)},
        "min_efficiency": max(0, min(int(min_efficiency), 100)),
        "payload_db": len(PAYLOADS),
        "engine": "xss",
        "version": "3.1-xsstrike-portable",
        "equivalent": "s0md3v/XSStrike",
        "source": "https://github.com/s0md3v/XSStrike",
        "policy": policy.status(),
    }


def list_payloads() -> dict[str, Any]:
    return {
        "count": len(PAYLOADS),
        "payloads": list(PAYLOADS),
        "functions": list(FUNCTIONS),
        "tags": list(TAGS),
        "event_handlers": EVENT_HANDLERS,
        "source": "XSStrike core/config.py",
    }
