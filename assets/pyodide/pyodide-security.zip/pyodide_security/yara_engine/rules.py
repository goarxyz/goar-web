"""Portable YARA-family rule engine for text and byte-like content.

This preserves the existing built-in catalog and adds a bounded browser/Pyodide
subset of YARA rule source: metadata, tags, quoted/regex/hex strings, and common
boolean conditions. Unsupported native grammar is reported per rule rather than
silently accepted.
"""
from __future__ import annotations

import json
import re
from typing import Any

RULES: list[dict[str, Any]] = [
    {"id":"aws_akid","name":"AWS Access Key","tags":["secrets","aws"],"regex":r"AKIA[0-9A-Z]{16}"},
    {"id":"aws_secret","name":"AWS Secret heuristic","tags":["secrets","aws"],"regex":r"(?i)aws(.{0,20})?(secret|access).{0,20}['\"][0-9a-zA-Z/+]{40}['\"]"},
    {"id":"github_pat","name":"GitHub PAT","tags":["secrets","github"],"regex":r"ghp_[A-Za-z0-9]{36}"},
    {"id":"slack_token","name":"Slack token","tags":["secrets","slack"],"regex":r"xox[baprs]-[0-9a-zA-Z-]{10,}"},
    {"id":"private_key","name":"Private key header","tags":["secrets","crypto"],"regex":r"-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----"},
    {"id":"jwt","name":"JWT","tags":["secrets","jwt"],"regex":r"eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+"},
    {"id":"webshell_eval","name":"PHP eval webshell","tags":["webshell","php"],"regex":r"(?i)(eval|assert)\s*\(\s*(base64_decode|gzinflate|str_rot13)"},
    {"id":"webshell_cmd","name":"PHP command exec","tags":["webshell","php"],"regex":r"(?i)(system|passthru|shell_exec|exec)\s*\(\s*\$_(GET|POST|REQUEST)"},
    {"id":"xss_script","name":"Script tag","tags":["web","xss"],"regex":r"(?i)<script[^>]*>"},
    {"id":"sqli_union","name":"UNION SELECT","tags":["web","sqli"],"regex":r"(?i)union(\s+all)?\s+select"},
]


def _tag_filter(tags: str) -> set[str]:
    return {tag.strip().lower() for tag in str(tags or "").replace(";", ",").split(",") if tag.strip()}


def list_rules(tags: str = "") -> dict[str, Any]:
    selected = _tag_filter(tags)
    rules = [rule for rule in RULES if not selected or selected.intersection({tag.lower() for tag in rule.get("tags", [])})]
    return {"ok": True, "count": len(rules), "total": len(RULES), "tags": sorted(selected), "rules": rules, "engine": "goar-pysec-yara", "equivalent": "YARA portable rule catalog"}


def _hex_to_regex(value: str) -> str:
    tokens = re.findall(r"[0-9A-Fa-f?]{2}|\[[0-9]+(?:-[0-9]+)?\]", value or "")
    out = []
    for token in tokens:
        if token.startswith("["):
            body = token[1:-1]
            if "-" in body:
                low, high = body.split("-", 1)
                out.append(f".{{{int(low)},{int(high)}}}")
            else:
                out.append(f".{{{int(body)}}}")
        elif token == "??":
            out.append(".")
        elif "?" in token:
            high, low = token[0], token[1]
            chars = "[0-9a-fA-F]"
            if high == "?":
                out.append(f"{chars}{re.escape(low)}")
            else:
                out.append(f"{re.escape(high)}{chars}")
        else:
            out.append(re.escape(bytes.fromhex(token).decode("latin1")))
    return "".join(out)


def _parse_rule_source(source: str) -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
    """Parse a bounded YARA source subset into executable portable rules."""
    parsed: list[dict[str, Any]] = []
    errors: list[dict[str, str]] = []
    pattern = re.compile(r"(?:private\s+|global\s+)?rule\s+([A-Za-z_][\w]*)\s*(?::\s*([^\{]+))?\s*\{([\s\S]*?)\}", re.I)
    for match in pattern.finditer(source or ""):
        rule_id, tag_text, body = match.group(1), match.group(2) or "", match.group(3)
        strings: dict[str, dict[str, Any]] = {}
        section = re.search(r"strings\s*:\s*([\s\S]*?)(?=\n\s*(?:meta|condition)\s*:|\Z)", body, re.I)
        if section:
            for raw in section.group(1).splitlines():
                line = raw.strip()
                item = re.match(r"\$(\w+)\s*=\s*(?:\"((?:\\.|[^\"])*)\"|/((?:\\.|[^/])*)/([a-zA-Z]*)|\{([^}]+)\})\s*([A-Za-z\s]*)", line)
                if not item:
                    continue
                name, literal, regex_value, regex_flags, hex_value, modifiers = item.groups()
                flags = re.I if ("nocase" in (regex_flags or "") or "nocase" in modifiers.lower()) else 0
                if literal is not None:
                    value = bytes(literal, "utf-8").decode("unicode_escape")
                    expression = re.escape(value)
                    if "wide" in modifiers.lower():
                        expression = "".join(re.escape(ch) + "\\x00?" for ch in value)
                elif regex_value is not None:
                    expression = regex_value
                else:
                    expression = _hex_to_regex(hex_value or "")
                try:
                    strings[name] = {"regex": re.compile(expression, flags | re.S), "modifiers": modifiers or ""}
                except re.error as exc:
                    errors.append({"rule": rule_id, "error": f"invalid string ${name}: {exc}"})
        condition_match = re.search(r"condition\s*:\s*([\s\S]*)$", body, re.I)
        condition = (condition_match.group(1).strip() if condition_match else "any of them").split("//", 1)[0].strip().lower()
        if not strings:
            errors.append({"rule": rule_id, "error": "no supported strings section"})
            continue
        supported = condition in ("any of them", "all of them", "true") or bool(re.fullmatch(r"\d+\s+of\s+them", condition)) or bool(re.fullmatch(r"\$\w+(?:\s+(?:and|or)\s+\$\w+)*", condition))
        if not supported:
            errors.append({"rule": rule_id, "error": f"unsupported portable condition: {condition}"})
            continue
        parsed.append({"id": rule_id, "name": rule_id, "tags": [tag for tag in tag_text.split() if tag], "strings": strings, "condition": condition, "meta": {}})
    return parsed, errors


def _matches_for_rule(rule: dict[str, Any], text: str) -> tuple[bool, list[dict[str, Any]]]:
    if "regex" in rule:
        expression = re.compile(str(rule["regex"]), re.S)
        matches = [{"identifier": "$match", "offset": item.start(), "length": len(item.group(0)), "match": item.group(0)[:240]} for item in expression.finditer(text)]
        return bool(matches), matches
    by_id: dict[str, list[dict[str, Any]]] = {}
    for name, spec in rule.get("strings", {}).items():
        found = []
        for item in spec["regex"].finditer(text):
            found.append({"identifier": "$" + name, "offset": item.start(), "length": len(item.group(0)), "match": item.group(0)[:240]})
        by_id[name] = found
    condition = rule.get("condition", "any of them")
    counts = {name: bool(found) for name, found in by_id.items()}
    if condition == "true":
        valid = True
    elif condition == "all of them":
        valid = all(counts.values())
    elif condition == "any of them":
        valid = any(counts.values())
    elif re.fullmatch(r"\d+\s+of\s+them", condition):
        valid = sum(counts.values()) >= int(condition.split()[0])
    else:
        tokens = re.findall(r"\$(\w+)|\b(and|or)\b", condition)
        current: bool | None = None
        operator = "and"
        for ident, op in tokens:
            if op:
                operator = op
                continue
            value = counts.get(ident, False)
            current = value if current is None else (current and value if operator == "and" else current or value)
        valid = bool(current)
    all_matches = [match for values in by_id.values() for match in values]
    return valid, all_matches


def _sarif(matches: list[dict[str, Any]], source: str) -> dict[str, Any]:
    rules: dict[str, Any] = {}
    results = []
    for hit in matches:
        rules.setdefault(hit["id"], {"id": hit["id"], "name": hit["name"], "shortDescription": {"text": hit["name"]}})
        results.append({"ruleId": hit["id"], "message": {"text": hit["name"]}, "locations": [{"physicalLocation": {"artifactLocation": {"uri": source}, "region": {"charOffset": hit["offset"], "charLength": hit.get("length", 0)}}}]})
    return {"version": "2.1.0", "$schema": "https://json.schemastore.org/sarif-2.1.0.json", "runs": [{"tool": {"driver": {"name": "Goar Pysec YARA portable", "rules": list(rules.values())}}, "results": results}]}


def scan(
    text: str = "",
    tags: str = "",
    rule_source: str = "",
    include_builtin: bool = True,
    max_hits: int = 50,
    include_context: bool = True,
    report_format: str = "json",
    source_name: str = "inline",
) -> dict[str, Any]:
    if text is None or not str(text):
        raise ValueError("text is required")
    text = str(text)
    wanted_tags = _tag_filter(tags)
    rules: list[dict[str, Any]] = []
    if include_builtin:
        rules.extend(rule for rule in RULES if not wanted_tags or wanted_tags.intersection({tag.lower() for tag in rule.get("tags", [])}))
    custom, parse_errors = _parse_rule_source(rule_source)
    rules.extend(rule for rule in custom if not wanted_tags or wanted_tags.intersection({tag.lower() for tag in rule.get("tags", [])}))
    limit = max(1, min(int(max_hits), 5000))
    hits = []
    for rule in rules:
        if len(hits) >= limit:
            break
        valid, matches = _matches_for_rule(rule, text)
        if not valid:
            continue
        if not matches:
            matches = [{"identifier": "$condition", "offset": 0, "length": 0, "match": ""}]
        for match in matches:
            if len(hits) >= limit:
                break
            item = {"id": rule["id"], "name": rule.get("name", rule["id"]), "tags": rule.get("tags", []), **match}
            if include_context:
                left = max(0, int(match["offset"]) - 80)
                right = min(len(text), int(match["offset"]) + max(1, int(match.get("length") or 1)) + 80)
                item["context"] = text[left:right]
            hits.append(item)
    result: dict[str, Any] = {"ok": True, "engine": "goar-pysec-yara", "source": source_name or "inline", "hit_count": len(hits), "hits": hits, "rule_db": len(RULES), "rules_active": len(rules), "custom_rules": len(custom), "parse_errors": parse_errors, "tags": sorted(wanted_tags), "truncated": len(hits) >= limit}
    if str(report_format or "json").lower() == "sarif":
        result["sarif"] = _sarif(hits, source_name or "inline")
    return result
