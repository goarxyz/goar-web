"""Browser-adapted ASN/IP intelligence lookup — BGPView and IP-API branches."""
from __future__ import annotations
import ipaddress,json
from typing import Any
from urllib.parse import quote
from .._http import http_request,redact_url
from .. import policy

def _headers(raw,user_agent):
 h={"User-Agent":user_agent,"Accept":"application/json"}; text=str(raw or '').strip()
 if not text:return h
 if text.startswith('{'):
  v=json.loads(text)
  if not isinstance(v,dict):raise ValueError('headers JSON must be an object')
  h.update({str(k):str(x) for k,x in v.items()});return h
 for line in text.splitlines():
  if ':' in line:
   k,_,v=line.partition(':');h[k.strip()]=v.strip()
 return h

def _route(v):
 if v in (None,'','auto','AUTO'):return None
 if v in (True,'proxy','PROXY','true','True'):return True
 if v in (False,'direct','DIRECT','false','False'):return False
 raise ValueError('route must be auto, proxy, or direct')

async def _request(url,headers,timeout_ms,retries,retry_statuses,use_proxy):
 timeout=max(1000,min(int(timeout_ms or 8000),120000));tries=max(0,min(int(retries or 0),5));retryable={int(x.strip()) for x in str(retry_statuses or '').split(',') if x.strip().isdigit()};attempts=[];resp={}
 for i in range(tries+1):
  resp=await http_request(url,headers=headers,timeout_ms=timeout,use_proxy=use_proxy)
  attempts.append({'attempt':i+1,'status':resp.get('status'),'ok':resp.get('ok'),'transport':resp.get('transport'),'elapsed_ms':resp.get('elapsed_ms'),'error':resp.get('error'),'final_url':redact_url(resp.get('final_url'))})
  if resp.get('ok') or int(resp.get('status') or 0) not in retryable:break
 resp=dict(resp);resp.update(attempts=attempts,attempt_count=len(attempts),final_url=redact_url(resp.get('final_url') or url),request={'url':redact_url(url),'headers':{k:('[redacted]' if k.lower() in {'authorization','cookie','x-api-key'} else v) for k,v in headers.items()},'timeout_ms':timeout,'retries':tries,'route':'auto' if use_proxy is None else ('proxy' if use_proxy else 'direct')});return resp

def _summary(data,kind):
 if not isinstance(data,dict):return None
 if kind=='ip-api':return {k:data.get(k) for k in ('query','status','as','asname','isp','org','country','countryCode','city','lat','lon')}
 if kind=='asn':return {k:data.get(k) for k in ('asn','name','description_short','description_long','country_code','rir_allocation_date','website')}
 return {k:data.get(k) for k in ('ip','ptr_record','prefixes','rir','country_code')}

async def lookup(ip:str='',asn:str='',host:str='',query:str='',user_agent:str='pyodide-security/asn/2.0',service:str='auto',service_base:str='',headers:str='',timeout_ms:int=8000,retries:int=0,retry_statuses:str='408,429,500,502,503,504',route:str='auto',include_prefixes:bool=False)->dict[str,Any]:
 q=(query or host or '').strip()
 if not ip and q:
  try:ip=str(ipaddress.ip_address(q))
  except ValueError:pass
 if not asn and q.upper().startswith('AS'):asn=q
 if not ip and not asn and host:ip=host
 if asn: asn=''.join(c for c in asn.upper().replace('AS','') if c.isdigit())
 if not ip and not asn and not q:return {'ok':False,'error':'ip or asn required','engine':'asn'}
 choice=(service or 'auto').lower();use_ip_api=choice=='ip-api' or (choice=='auto' and not (ip or asn))
 if use_ip_api:
  base=(service_base or 'https://ip-api.com').rstrip('/');url=f'{base}/json/{quote(q or ip)}?fields=status,message,query,as,asname,isp,org,country,countryCode,city,lat,lon'
  kind='ip-api'
 else:
  base=(service_base or 'https://api.bgpview.io').rstrip('/');kind='asn' if asn else 'ip';value=asn or ip;url=f'{base}/{kind}/{quote(value)}'
 err=policy.check_url_for_active(url) if hasattr(policy,'check_url_for_active') else None
 if err:return {'ok':False,'error':err,'engine':'asn'}
 resp=await _request(url,_headers(headers,user_agent),timeout_ms,retries,retry_statuses,_route(route));body=str(resp.get('body') or '')
 try:raw=json.loads(body)
 except Exception:raw=None
 data=(raw.get('data') if isinstance(raw,dict) and 'data' in raw else raw) if isinstance(raw,dict) else None
 if kind=='ip' and isinstance(data,dict) and not include_prefixes:data={k:v for k,v in data.items() if k!='prefixes'}
 return {'ok':bool(resp.get('ok')) and isinstance(data,dict),'query':q or ip or ('AS'+asn),'ip':ip or None,'asn':asn or None,'provider':kind,'status':resp.get('status'),'data':data,'summary':_summary(data,kind),'body':body,'body_length':len(body),'error':resp.get('error') or (None if isinstance(data,dict) else 'non-JSON provider response'),'attempts':resp['attempts'],'attempt_count':resp['attempt_count'],'request':resp['request'],'final_url':resp['final_url'],'transport':resp.get('transport'),'engine':'asn','equivalent':'BGPView / IP-API'}

async def lookup_ip(ip:str='',**kw):return await lookup(ip=ip,**kw)
