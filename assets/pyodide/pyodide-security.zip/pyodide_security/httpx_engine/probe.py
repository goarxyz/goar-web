"""Browser-adapted HTTPX-class HTTP metadata and bounded path probe."""
from __future__ import annotations

import hashlib
import json
import re
from typing import Any
from urllib.parse import urljoin, urlparse

from .._http import http_request, redact_url
from .. import policy

CDN_HEADERS = {"cf-ray":"cloudflare","x-served-by":"fastly","x-amz-cf-id":"cloudfront","x-azure-ref":"azure","x-vercel-id":"vercel","x-sucuri-id":"sucuri","x-cdn":"cdn"}
TECH_HINTS = [(r"wp-content|wordpress","wordpress"),(r"drupal","drupal"),(r"joomla","joomla"),(r"laravel","laravel"),(r"react","react"),(r"next\.js|__next","nextjs"),(r"nginx","nginx"),(r"apache","apache")]


def _title(body: str) -> str:
    match = re.search(r"<title[^>]*>(.*?)</title>", body or "", re.I | re.S)
    return re.sub(r"\s+", " ", match.group(1)).strip()[:200] if match else ""


def _hdr(headers: dict, *names: str) -> str:
    lower = {str(k).lower(): str(v) for k, v in headers.items()}
    return next((lower[n.lower()] for n in names if n.lower() in lower), "")


def _items(*values: str) -> list[str]:
    out: list[str] = []
    for value in values:
        for item in str(value or "").replace(",", chr(10)).splitlines():
            item = item.strip()
            if item and item not in out: out.append(item)
    return out


def _headers(raw: str, user_agent: str) -> dict[str, str]:
    out={"User-Agent":user_agent}; text=str(raw or "").strip()
    if text.startswith("{"):
        parsed=json.loads(text)
        if not isinstance(parsed,dict): raise ValueError("headers JSON must be an object")
        out.update({str(k):str(v) for k,v in parsed.items()})
    else:
        for line in text.splitlines():
            if ":" in line:
                key,_,value=line.partition(":");out[key.strip()]=value.strip()
    return out


def _route(value: Any) -> bool | None:
    if value in (None,"","auto","AUTO"): return None
    if value in (True,"proxy","PROXY","true","True"): return True
    if value in (False,"direct","DIRECT","false","False"): return False
    raise ValueError("route must be auto, proxy, or direct")


def _safe_url(value: Any) -> str:
    safe=redact_url(value)
    return re.sub(r"(?i)(%3f|%26)(apikey|api_key|key|token|access_token|authorization|secret|signature|sig)(%3d|=)[^&#]*",lambda m:m.group(1)+m.group(2)+m.group(3)+"[redacted]",safe)


def _target_with_path(target: str, path: str) -> str:
    parsed=urlparse(target); path=str(path or "/").strip()
    if path in ("", "/") and parsed.path not in ("", "/"): return target
    return urljoin(target.rstrip("/")+"/", path.lstrip("/"))


async def probe(
    url: str = "", urls: str = "", targets: str = "", paths: str = "/", user_agent: str = "pyodide-security/httpx/3.0", method: str = "GET", headers: str = "", body: str = "", timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = "408,429,500,502,503,504", route: str = "auto", max_targets: int = 20, max_requests: int = 40, fallback_http: bool = True, status_codes: str = "", match_strings: str = "", include_preview: bool = False, preview_chars: int = 500,
) -> dict[str, Any]:
    """Probe bounded target/path pairs through the shared Goar request chain."""
    raw_targets=_items(url,urls,targets); cap_targets=max(1,min(int(max_targets or 20),100)); raw_targets=raw_targets[:cap_targets]
    if not raw_targets: return {"ok":False,"error":"url, urls, or targets required","engine":"httpx"}
    path_items=_items(paths) or ["/"]; cap_requests=max(1,min(int(max_requests or 40),200)); req_headers=_headers(headers,user_agent); use_proxy=_route(route); timeout=max(1000,min(int(timeout_ms or 8000),120000)); retryable={int(x.strip()) for x in str(retry_statuses).split(",") if x.strip().isdigit()}; wanted={int(x.strip()) for x in str(status_codes).split(",") if x.strip().isdigit()}; needles=_items(match_strings); results=[]; attempted=0
    for raw_target in raw_targets:
        explicit_scheme=raw_target.startswith(("http://","https://")); base=raw_target if explicit_scheme else "https://"+raw_target
        for path in path_items:
            if attempted>=cap_requests: break
            candidate=_target_with_path(base,path); err=policy.check_url_for_active(candidate) if hasattr(policy,"check_url_for_active") else None
            if err: results.append({"url":_safe_url(candidate),"error":err,"failed":True,"matched":False}); continue
            attempts=[]; resp={}; candidates=[candidate]
            if fallback_http and not explicit_scheme and candidate.startswith("https://"): candidates.append("http://"+candidate[8:])
            for attempt_url in candidates:
                for number in range(max(0,min(int(retries or 0),5))+1):
                    if attempted>=cap_requests: break
                    attempted+=1;resp=await http_request(attempt_url,method=str(method or "GET").upper(),headers=req_headers,body=body or None,timeout_ms=timeout,use_proxy=use_proxy)
                    attempts.append({"attempt":len(attempts)+1,"url":_safe_url(attempt_url),"status":resp.get("status"),"error":resp.get("error"),"transport":resp.get("transport"),"final_url":_safe_url(resp.get("final_url"))})
                    if resp.get("ok") or int(resp.get("status") or 0) not in retryable: break
                if resp.get("status"): break
            text=str(resp.get("body") or ""); response_headers=resp.get("headers") or {}; lower={str(k).lower():str(v) for k,v in response_headers.items()}; cdn=next((name for key,name in CDN_HEADERS.items() if key in lower),None); blob=text[:5000]+" "+" ".join(lower.values()); tech=[name for rx,name in TECH_HINTS if re.search(rx,blob,re.I)]; status=int(resp.get("status") or 0); has_needles=all(needle.lower() in text.lower() for needle in needles); matched=bool(status) and (not wanted or status in wanted) and has_needles
            results.append({"url":_safe_url(candidate),"final_url":_safe_url(resp.get("final_url") or candidate),"path":path,"status_code":status,"title":_title(text),"webserver":_hdr(response_headers,"server"),"content_type":_hdr(response_headers,"content-type"),"location":_hdr(response_headers,"location"),"content_length":len(text),"word_count":len(re.findall(r"\S+",text)),"line_count":text.count("\n")+(1 if text else 0),"cdn":cdn,"tech":tech,"hash":hashlib.sha256(text.encode("utf-8","replace")).hexdigest()[:16],"body_preview":text[:max(0,min(int(preview_chars or 500),10000))] if include_preview else "","failed":not bool(status),"matched":matched,"match_status_codes":sorted(wanted),"match_strings":needles,"error":resp.get("error"),"attempts":attempts,"transport":resp.get("transport"),"via_libcurl":resp.get("via_libcurl"),"via_proxy":resp.get("via_proxy"),"elapsed_ms":resp.get("elapsed_ms")})
        if attempted>=cap_requests: break
    safe_headers={key:("[redacted]" if key.lower() in {"authorization","cookie","x-api-key"} else value) for key,value in req_headers.items()}; return {"ok":True,"count":len(results),"matched_count":sum(1 for item in results if item.get("matched")),"attempted_requests":attempted,"truncated":attempted>=cap_requests,"results":results,"request":{"method":str(method or "GET").upper(),"headers":safe_headers,"timeout_ms":timeout,"retries":retries,"route":"auto" if use_proxy is None else ("proxy" if use_proxy else "direct"),"paths":path_items,"fallback_http":bool(fallback_http)},"engine":"httpx","equivalent":"projectdiscovery/httpx"}
