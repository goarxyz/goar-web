from .lookup import lookup, lookup_host
__all__=["lookup","lookup_host"]
