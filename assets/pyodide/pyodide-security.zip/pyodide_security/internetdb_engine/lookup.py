"""Browser-adapted Shodan InternetDB lookup through the shared Goar transport."""
from __future__ import annotations

import ipaddress
import json
import re
from typing import Any
from urllib.parse import quote

from .. import policy
from .._http import http_request, redact_url

_SENSITIVE = re.compile(r"(?i)(authorization|cookie|set-cookie|x-api-key|api[_-]?key|token|secret|password)")


def _parse_headers(raw: str | dict[str, Any] | None) -> dict[str, str]:
    if isinstance(raw, dict):
        return {str(k): str(v) for k, v in raw.items()}
    text = str(raw or "").strip()
    if not text:
        return {}
    if text.startswith("{"):
        try:
            value = json.loads(text)
            return {str(k): str(v) for k, v in value.items()} if isinstance(value, dict) else {}
        except (TypeError, ValueError):
            return {}
    result: dict[str, str] = {}
    for line in text.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            if key.strip():
                result[key.strip()] = value.strip()
    return result


def _redact_headers(headers: dict[str, str]) -> dict[str, str]:
    return {key: "[redacted]" if _SENSITIVE.search(key) else value for key, value in headers.items()}


def _codes(raw: str) -> set[int]:
    return {int(item.strip()) for item in str(raw or "").split(",") if item.strip().isdigit()}


def _route(route: str) -> tuple[str, bool | None]:
    value = str(route or "auto").lower()
    if value == "proxy":
        return "proxy", True
    if value == "direct":
        return "direct", False
    return "auto", None


async def _request(url: str, headers: dict[str, str], timeout_ms: int, retries: int, retry_codes: set[int], route: str, attempts: list[dict[str, Any]], stage: str) -> dict[str, Any]:
    route_name, use_proxy = _route(route)
    response: dict[str, Any] = {}
    for number in range(max(0, min(int(retries or 0), 5)) + 1):
        response = await http_request(url, headers=headers, timeout_ms=max(1000, min(int(timeout_ms or 8000), 120000)), use_proxy=use_proxy)
        attempts.append({"stage": stage, "attempt": number + 1, "url": redact_url(url), "status": int(response.get("status") or 0), "ok": bool(response.get("ok")), "elapsed_ms": response.get("elapsed_ms"), "transport": response.get("transport"), "error": str(response.get("error") or "")[:240]})
        if response.get("ok") or int(response.get("status") or 0) not in retry_codes:
            break
    return response


async def _resolve(host: str, headers: dict[str, str], timeout_ms: int, retries: int, retry_codes: set[int], route: str, attempts: list[dict[str, Any]]) -> tuple[str | None, dict[str, Any] | None]:
    url = "https://dns.google/resolve?name=" + quote(host, safe="") + "&type=A"
    response = await _request(url, headers, timeout_ms, retries, retry_codes, route, attempts, "resolve")
    try:
        payload = json.loads(str(response.get("body") or ""))
    except (TypeError, ValueError):
        payload = {}
    for item in payload.get("Answer") or []:
        data = str(item.get("data") or "")
        try:
            return str(ipaddress.ip_address(data)), response
        except ValueError:
            continue
    return None, response


async def lookup(ip: str, user_agent: str = "pyodide-security/internetdb/3.0", headers: str | dict[str, Any] = "", timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = "408,429,500,502,503,504", route: str = "auto", service_base: str = "https://internetdb.shodan.io", include_response_body: bool = False, preview_chars: int = 400, include_headers: bool = False, max_vulns: int = 200) -> dict[str, Any]:
    value = str(ip or "").strip()
    if not value:
        return {"ok": False, "error": "ip required", "engine": "internetdb-browser-adapted"}
    try:
        ip_value = str(ipaddress.ip_address(value))
    except ValueError:
        return {"ok": False, "error": "valid IPv4 or IPv6 address required", "engine": "internetdb-browser-adapted"}
    base = str(service_base or "https://internetdb.shodan.io").strip().rstrip("/")
    if not base.startswith(("http://", "https://")):
        return {"ok": False, "error": "service_base must use http or https", "engine": "internetdb-browser-adapted"}
    url = base + "/" + quote(ip_value, safe=":")
    error = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if error:
        return {"ok": False, "error": error, "engine": "internetdb-browser-adapted", "policy": policy.status()}
    request_headers = _parse_headers(headers)
    request_headers.setdefault("User-Agent", user_agent)
    request_headers.setdefault("Accept", "application/json")
    retry_codes = _codes(retry_statuses) or {408, 429, 500, 502, 503, 504}
    attempts: list[dict[str, Any]] = []
    response = await _request(url, request_headers, timeout_ms, retries, retry_codes, route, attempts, "lookup")
    body = str(response.get("body") or "")
    try:
        data = json.loads(body)
    except (TypeError, ValueError):
        data = None
    if not isinstance(data, dict):
        data = {}
    vulns = list(data.get("vulns") or [])[:max(0, min(int(max_vulns or 200), 1000))]
    result: dict[str, Any] = {"ok": bool(response.get("ok")) and bool(data), "ip": ip_value, "ports": list(data.get("ports") or []), "cpes": list(data.get("cpes") or []), "hostnames": list(data.get("hostnames") or []), "tags": list(data.get("tags") or []), "vulns": vulns, "vuln_count": len(data.get("vulns") or []), "status": int(response.get("status") or 0), "body_length": len(body), "error": str(response.get("error") or "") or (None if data else "non-JSON InternetDB response"), "attempts": attempts, "attempt_count": len(attempts), "request": {"url": redact_url(url), "headers": _redact_headers(request_headers), "timeout_ms": max(1000, min(int(timeout_ms or 8000), 120000)), "retries": max(0, min(int(retries or 0), 5)), "route": _route(route)[0]}, "final_url": redact_url(str(response.get("final_url") or url)), "transport": response.get("transport"), "engine": "internetdb-browser-adapted", "equivalent": "Shodan InternetDB", "limitations": ["InternetDB is a remote provider; browser-adapted lookup preserves bounded JSON handling and route evidence, but provider availability, caching, rate limits, pagination, and native client behavior are not claimed."], "policy": policy.status()}
    if include_response_body:
        result["body_preview"] = body[:max(0, min(int(preview_chars or 400), 5000))]
    if include_headers:
        result["response_headers"] = {str(k): str(v) for k, v in (response.get("headers") or {}).items()}
    return result


async def lookup_host(ip: str = "", host: str = "", resolve_host: bool = True, **kwargs: Any) -> dict[str, Any]:
    value = str(ip or host or "").strip()
    try:
        ipaddress.ip_address(value)
        return await lookup(value, **kwargs)
    except ValueError:
        if not host or not resolve_host:
            return {"ok": False, "error": "host requires resolve_host or an IP address", "engine": "internetdb-browser-adapted"}
    headers = _parse_headers(kwargs.get("headers", ""))
    headers.setdefault("User-Agent", str(kwargs.get("user_agent") or "pyodide-security/internetdb/3.0"))
    retry_codes = _codes(str(kwargs.get("retry_statuses") or "")) or {408, 429, 500, 502, 503, 504}
    attempts: list[dict[str, Any]] = []
    resolved, response = await _resolve(str(host).strip(), headers, int(kwargs.get("timeout_ms") or 8000), int(kwargs.get("retries") or 0), retry_codes, str(kwargs.get("route") or "auto"), attempts)
    if not resolved:
        return {"ok": False, "host": host, "error": "host did not resolve to an IPv4 address", "resolution_attempts": attempts, "engine": "internetdb-browser-adapted"}
    result = await lookup(resolved, **kwargs)
    result["host"] = host
    result["resolved_ip"] = resolved
    result["resolution_attempts"] = attempts
    result["resolution_status"] = int((response or {}).get("status") or 0)
    return result
