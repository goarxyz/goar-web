"""Browser-adapted RFC 8615 well-known URI collection through shared Goar transport."""
from __future__ import annotations
import json
import re
from pathlib import Path
from typing import Any
from urllib.parse import urlparse
from .._http import http_request, redact_url
from .. import policy
_PATHS=json.loads(Path(__file__).with_name("paths.json").read_text())
def list_paths()->dict[str,Any]:return {"ok":True,"count":len(_PATHS),"paths":_PATHS,"source":"bundled IANA well-known + common corpus","engine":"wellknown"}
def _headers(raw:str,user_agent:str)->dict[str,str]:
    output={"User-Agent":user_agent};text=str(raw or "").strip()
    if text.startswith("{"):
        parsed=json.loads(text)
        if not isinstance(parsed,dict):raise ValueError("headers JSON must be an object")
        output.update({str(key):str(value) for key,value in parsed.items()})
    else:
        for line in text.splitlines():
            if ":" in line:
                key,_,value=line.partition(":");output[key.strip()]=value.strip()
    return output
def _route(value:Any)->bool|None:
    if value in (None,"","auto","AUTO"):return None
    if value in (True,"proxy","PROXY","true","True"):return True
    if value in (False,"direct","DIRECT","false","False"):return False
    raise ValueError("route must be auto, proxy, or direct")
def _items(raw:str)->list[str]:return list(dict.fromkeys(item.strip() for item in str(raw or "").replace(",","\n").splitlines() if item.strip()))
def _path(value:str)->str:
    item=str(value or "").strip()
    if not item:return ""
    if item.startswith("/.well-known/"):return item
    return "/.well-known/"+item.lstrip("/")
def _safe_url(value:Any)->str:
    safe=redact_url(value)
    return re.sub(r"(?i)(%3f|%26)(apikey|api_key|key|token|access_token|authorization|secret|signature|sig)(%3d|=)[^&#]*",lambda match:match.group(1)+match.group(2)+match.group(3)+"[redacted]",safe)
def _codes(raw:str)->set[int]:return {int(value.strip()) for value in str(raw or "").replace(" ","").split(",") if value.strip().isdigit()}
def _safe_preview(value:str,limit:int)->str:
    text=str(value or "")[:max(0,min(int(limit or 300),2000))]
    text=re.sub(r"(?i)\b(apikey|api_key|access_token|token|authorization|secret|password)\s*[:=]\s*([^\s&<\"']+)",lambda match:match.group(1)+"=[redacted]",text)
    return re.sub(r"(?i)(name\s*=\s*[\"'](?:csrf|xsrf|_token|token)[^\"']*[\"']\s+value\s*=\s*[\"'])[^\"']*",r"\1[redacted]",text)

async def scan(url:str,max_paths:int=20,user_agent:str="pyodide-security/wellknown/2.0",paths:str="",include_bundled:bool=True,status_codes:str="200,204,301,302,307,308,401,403",headers:str="",timeout_ms:int=8000,retries:int=0,retry_statuses:str="408,429,500,502,503,504",route:str="auto",stop_on_found:bool=False,include_body_preview:bool=False,body_preview_chars:int=300)->dict[str,Any]:
    url=str(url or "").strip()
    if not url:return {"ok":False,"error":"url required","engine":"wellknown"}
    if not url.startswith(("http://","https://")):url="https://"+url
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err:return {"ok":False,"error":err,"engine":"wellknown"}
    parsed=urlparse(url);origin=f"{parsed.scheme}://{parsed.netloc}";selected=[]
    if include_bundled:selected.extend(_path(item) for item in _PATHS)
    selected.extend(_path(item) for item in _items(paths));selected=list(dict.fromkeys(item for item in selected if item));limit=max(0,min(int(max_paths or 0),100));selected=selected if limit==0 else selected[:limit]
    found_statuses=_codes(status_codes) or {200};retryable=_codes(retry_statuses);timeout=max(1000,min(int(timeout_ms or 8000),120000));retry_count=max(0,min(int(retries or 0),5));use_proxy=_route(route);request_headers=_headers(headers,user_agent);found=[];probes=[];attempts=[]
    for path in selected:
        target=origin+path;response={}
        for index in range(retry_count+1):
            response=await http_request(target,headers=request_headers,timeout_ms=timeout,use_proxy=use_proxy)
            attempts.append({"path":path,"attempt":index+1,"status":response.get("status"),"error":response.get("error"),"transport":response.get("transport"),"final_url":_safe_url(response.get("final_url"))})
            if response.get("ok") or int(response.get("status") or 0) not in retryable:break
        status=int(response.get("status") or 0);hdrs={str(key).lower():str(value) for key,value in (response.get("headers") or {}).items()};body=str(response.get("body") or "");row={"path":path,"url":_safe_url(target),"final_url":_safe_url(response.get("final_url") or target),"status":status,"status_class":f"{status//100}xx" if status else None,"content_type":hdrs.get("content-type"),"length":len(body),"preview":_safe_preview(body,body_preview_chars) if include_body_preview else "","transport":response.get("transport"),"error":response.get("error")};probes.append(row)
        if status in found_statuses:found.append(row)
        if stop_on_found and status in found_statuses:break
    safe_headers={key:("[redacted]" if key.lower() in {"authorization","cookie","x-api-key"} else value) for key,value in request_headers.items()}
    return {"ok":True,"url":origin,"tested":len(probes),"found":found,"found_count":len(found),"path_db":len(_PATHS),"selected_paths":selected,"probes":probes,"attempts":attempts,"attempt_count":len(attempts),"request":{"headers":safe_headers,"timeout_ms":timeout,"retries":retry_count,"route":"auto" if use_proxy is None else ("proxy" if use_proxy else "direct"),"status_codes":sorted(found_statuses)},"engine":"wellknown","equivalent":"RFC 8615 / bundled well-known corpus","coverage_note":"Observed GET collection only; it does not synchronize the IANA registry, validate endpoint-specific protocol formats, authenticate, or infer well-known resource semantics."}
