"""
Manus CORS proxy configuration + on-the-fly key generation + ensure bootstrap.

All live tools go through `_http.http_request`. When the proxy is enabled and a
key is present, every request is routed:

  https://cors.manus.space/api/proxy?url=<target>&apikey=<key>

Key generation requires a same-origin host endpoint:
  POST {origin}/api/manus-key  →  { "key": "...", "id": "...", ... }

Wisp is NOT implemented in pure Pyodide (needs a WebSocket binary bridge on the
host). If the host exposes a Wisp gateway, configure base_url / a custom
transport — the extension point is configure(base_url=...).
"""

from __future__ import annotations

import json
import re
from typing import Any
from urllib.parse import urlparse

from ._http import (
    configure_proxy,
    disable_proxy,
    http_request,
    proxy_status,
    proxy_test,
    is_proxy_ready,
    redact_url,
)

__all__ = [
    "configure",
    "status",
    "disable",
    "test",
    "generate",
    "ensure",
    "is_ready",
]


def configure(
    api_key: str = "",
    enabled: bool = True,
    base_url: str = "https://cors.manus.space/api/proxy",
    auth_mode: str = "both",
    url_style: str = "path",
    extras: dict | None = None,
    wisp_url: str = "wss://cors.manus.space/wisp/",
) -> dict:
    """
    Configure corsproxy backend.

    url_style: "path" (recommended /api/proxy/:targetUrl) or "query" (?url=)
    extras: optional global flags e.g. {"render": "true", "ttl": "60"}
    wisp_url: published for Bare-Mux / libcurl.js clients (not used by pure Python)
    """
    return configure_proxy(
        api_key=api_key,
        enabled=enabled,
        base_url=base_url or "https://cors.manus.space/api/proxy",
        auth_mode=auth_mode or "both",
        url_style=url_style or "path",
        extras=extras,
        wisp_url=wisp_url or "wss://cors.manus.space/wisp/",
    )


def status() -> dict:
    st = proxy_status()
    st["ready"] = is_proxy_ready()
    st["backend"] = "manus-cors"
    st["wisp_url"] = st.get("wisp_url") or "wss://cors.manus.space/wisp/"
    try:
        from . import libcurl_bridge
        ls = libcurl_bridge.status()
        st["wisp_ready"] = bool(ls.get("available"))
        st["wisp_transport"] = ls.get("transport")
    except Exception:
        st["wisp_ready"] = False
        st["wisp_transport"] = "unavailable"
    st["wisp_note"] = (
        "Wisp endpoint is configured for Bare-Mux, Epoxy TLS, and libcurl.js clients; readiness requires a host-loaded client and opened tunnel. "
        "Pure Python/Pyodide tools use the HTTP CORS path (/api/proxy/:targetUrl)."
    )
    return st


def disable() -> dict:
    return disable_proxy()


def is_ready() -> bool:
    return is_proxy_ready()


def _safe_text(value: Any, limit: int = 400) -> str:
    text = str(value or "")[:max(0, min(int(limit), 2000))]
    return re.sub(r"(?i)(apikey|api_key|access_token|authorization|cookie|secret|token)=([^&#\\s]+)", lambda match: f"{match.group(1)}=[redacted]", text)


def _status_set(raw: str | list[int] | None) -> set[int]:
    if isinstance(raw, list):
        return {int(item) for item in raw}
    return {int(part.strip()) for part in str(raw or "").split(",") if part.strip().isdigit()}


def _origin_base(origin: str = "") -> tuple[str, str | None]:
    base = str(origin or "").strip().rstrip("/")
    if not base:
        try:
            from js import location  # type: ignore
            base = str(location.origin or "").strip().rstrip("/")
        except Exception:
            base = ""
    if not base:
        return "", "origin required (pass origin= or run under browser Pyodide with location.origin)"
    parsed = urlparse(base)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return "", "origin must be an absolute http:// or https:// origin"
    if parsed.username or parsed.password:
        return "", "origin must not contain embedded credentials"
    return f"{parsed.scheme}://{parsed.netloc}", None


async def _request_with_retries(url: str, method: str, headers: dict[str, str], body: str | None, timeout_ms: int, retries: int, retryable: set[int], use_proxy: bool | None) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    timeout_ms = max(1000, min(int(timeout_ms or 8000), 120000))
    retries = max(0, min(int(retries or 0), 5))
    result: dict[str, Any] = {}
    attempts: list[dict[str, Any]] = []
    for index in range(retries + 1):
        result = await http_request(url, method=method, headers=headers, body=body, timeout_ms=timeout_ms, use_proxy=use_proxy)
        attempts.append({"attempt": index + 1, "status": result.get("status"), "ok": result.get("ok"), "transport": result.get("transport"), "elapsed_ms": result.get("elapsed_ms"), "error": _safe_text(result.get("error"), 200)})
        if result.get("ok") or int(result.get("status") or 0) not in retryable:
            break
    return result, attempts


async def test(target: str = "https://rondastore.org/", timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = "408,429,500,502,503,504") -> dict:
    retryable = _status_set(retry_statuses)
    response, attempts = await _request_with_retries(target, "GET", {}, None, timeout_ms, retries, retryable, True)
    return {
        "ok": bool(response.get("status") and response.get("status") not in (0, 401, 403) and not response.get("error")),
        "target": redact_url(target), "status": response.get("status"), "via_proxy": response.get("via_proxy"),
        "transport": response.get("transport"), "elapsed_ms": response.get("elapsed_ms"), "error": _safe_text(response.get("error"), 300),
        "body_preview": _safe_text(response.get("body"), 200), "attempts": attempts, "attempt_count": len(attempts), "proxy": proxy_status(),
    }


async def generate(
    origin: str = "",
    auto_configure: bool = True,
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
) -> dict[str, Any]:
    """Mint and optionally configure a same-origin proxy key without exposing it."""
    if is_proxy_ready():
        return {"ok": True, "reused_configured_key": True, "configured": proxy_status(), "backend": "manus-cors", "request_count": 0}
    base, origin_error = _origin_base(origin)
    if origin_error:
        return {"ok": False, "error": origin_error, "hint": "Host app must implement POST /api/manus-key returning JSON with a key field.", "backend": "manus-cors"}
    retryable = _status_set(retry_statuses)
    endpoint = f"{base}/api/manus-key"
    response, attempts = await _request_with_retries(endpoint, "POST", {"Accept": "application/json", "Content-Type": "application/json"}, "{}", timeout_ms, retries, retryable, False)
    status_code = int(response.get("status") or 0)
    evidence = {"endpoint": redact_url(endpoint), "status": status_code, "transport": response.get("transport"), "elapsed_ms": response.get("elapsed_ms"), "attempts": attempts, "attempt_count": len(attempts)}
    if status_code >= 400 or not status_code:
        return {"ok": False, "error": _safe_text(response.get("error") or f"generate HTTP {status_code}"), "body_length": len(str(response.get("body") or "")), "hint": "Ensure the same-origin host exposes POST /api/manus-key returning JSON with a key field.", "request": evidence, "backend": "manus-cors"}
    try:
        data = json.loads(response.get("body") or "{}")
    except json.JSONDecodeError:
        return {"ok": False, "error": "non-JSON from /api/manus-key", "body_length": len(str(response.get("body") or "")), "request": evidence, "backend": "manus-cors"}
    key = data.get("key") or data.get("apiKey") or data.get("api_key")
    if not key:
        return {"ok": False, "error": _safe_text(data.get("error") or "no key in response"), "response_keys": sorted(str(item) for item in data.keys())[:20] if isinstance(data, dict) else [], "request": evidence, "backend": "manus-cors"}
    configured = None
    if auto_configure:
        configured = configure_proxy(api_key=str(key), enabled=True, auth_mode="both")
    return {"ok": True, "key_received": True, "configured": bool(auto_configure), "configured_status": configured or proxy_status(), "id": data.get("id"), "label": data.get("label"), "createdAt": data.get("createdAt") or data.get("created_at"), "request": evidence, "proxy": proxy_status(), "backend": "manus-cors", "note": "The raw proxy key is intentionally never returned in Files output."}


# Prevent thundering-herd re-mint
_ensure_lock = False
_ensure_result: dict[str, Any] | None = None


async def ensure(
    origin: str = "",
    force: bool = False,
    verify_target: str = "",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
) -> dict[str, Any]:
    """
    Make sure a working proxy key is configured.

    - If already ready → return status immediately
    - Otherwise attempt generate() once and configure
    - Subsequent callers share the result (no repeated mint storms)

    Call this at the start of any workflow that needs reliable external network.
    All engines that use http_request automatically benefit once ensure() succeeds.
    """
    global _ensure_lock, _ensure_result

    if is_proxy_ready() and not force:
        return {
            "ok": True,
            "already_ready": True,
            "proxy": proxy_status(),
            "backend": "manus-cors",
        }

    if _ensure_lock and _ensure_result is not None and not force:
        return _ensure_result

    _ensure_lock = True
    try:
        gen = await generate(origin=origin, auto_configure=True, timeout_ms=timeout_ms, retries=retries, retry_statuses=retry_statuses)
        if not gen.get("ok"):
            _ensure_result = {
                "ok": False,
                "error": gen.get("error") or "key generation failed",
                "detail": gen,
                "backend": "manus-cors",
                "hint": (
                    "Host must expose POST /api/manus-key returning {key: '...'}. "
                    "Without a key, live tools can only hit same-origin or CORS-open targets."
                ),
            }
            return _ensure_result

        # Explicit optional connectivity check only; do not contact an unapproved target by default.
        if verify_target:
            try:
                t = await test(target=verify_target, timeout_ms=timeout_ms, retries=retries, retry_statuses=retry_statuses)
                gen["connectivity"] = {"ok": bool(t.get("ok")), "status": t.get("status"), "error": t.get("error"), "attempts": t.get("attempts"), "target": t.get("target")}
            except Exception as e:  # noqa: BLE001
                gen["connectivity"] = {"ok": False, "error": _safe_text(e)}
        else:
            gen["connectivity"] = {"ok": None, "skipped": True, "reason": "no verify_target supplied"}

        _ensure_result = {
            "ok": True,
            "already_ready": False,
            "generated": True,
            "proxy": proxy_status(),
            "backend": "manus-cors",
            "connectivity": gen.get("connectivity"),
            "key_id": gen.get("id"),
            "request": gen.get("request"),
        }
        return _ensure_result
    finally:
        _ensure_lock = False
