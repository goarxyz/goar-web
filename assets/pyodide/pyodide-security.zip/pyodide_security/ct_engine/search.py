"""Certificate Transparency search via the existing crt.sh adapter."""
from __future__ import annotations
from typing import Any
from ..subenum_engine.sources import crtsh as _crtsh, clean_domain
from .._http import redact_url

async def search(domain: str, user_agent: str='pyodide-security/ct/2.0', limit: int=200, service_base: str='https://crt.sh', headers: str='', timeout_ms: int=8000, retries: int=0, retry_statuses: str='408,429,500,502,503,504', route: str='auto', include_wildcards: bool=False, query_mode: str='wildcard', query: str='', scope_domain: str='', exclude_expired: bool=False, issuer_contains: str='', not_before_after: str='', not_after_before: str='', include_unscoped_names: bool=False)->dict[str,Any]:
    """Bounded CT-oriented view of the existing crt.sh adapter with complete evidence."""
    normalized=clean_domain(domain)
    result=await _crtsh(normalized,user_agent=user_agent,service_base=service_base,headers=headers,timeout_ms=timeout_ms,retries=retries,retry_statuses=retry_statuses,route=route,max_results=max(1,min(int(limit or 200),20000)),include_wildcards=include_wildcards,query_mode=query_mode,query=query,scope_domain=scope_domain,exclude_expired=exclude_expired,issuer_contains=issuer_contains,not_before_after=not_before_after,not_after_before=not_after_before,include_unscoped_names=include_unscoped_names)
    certificates=result.get('certificates') or []
    return {'ok':result.get('ok',False),'domain':result.get('domain') or normalized,'query_mode':result.get('query_mode') or query_mode,'subdomains':result.get('subdomains') or [],'subdomain_count':result.get('count',0),'certs_sample':certificates[:max(1,min(int(limit or 200),20000))],'cert_count':result.get('certificate_count',0),'certificates':certificates,'filtered_out':result.get('filtered_out',0),'status':result.get('status'),'body_length':result.get('body_length',0),'error':result.get('error'),'attempts':result.get('attempts') or [],'attempt_count':result.get('attempt_count'),'request':result.get('request'),'final_url':redact_url(result.get('final_url') or ''),'transport':result.get('transport'),'engine':'ct','equivalent':'crt.sh CT'}
