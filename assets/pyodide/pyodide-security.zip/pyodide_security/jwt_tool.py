"""jwt_tool-class JWT inspector / HMAC verifier / HS* secret cracker."""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
from typing import Any

from .crack_tool import MAX_CANDIDATES


def _b64url_decode(data: str) -> bytes:
    pad = (-len(data)) % 4
    return base64.urlsafe_b64decode(data + ("=" * pad))


def _b64url_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _split(token: str) -> tuple[str, str, str]:
    parts = token.strip().split(".")
    if len(parts) != 3:
        raise ValueError("JWT must have three base64url segments (header.payload.sig)")
    return parts[0], parts[1], parts[2]


def inspect(token: str) -> dict[str, Any]:
    h_b64, p_b64, s_b64 = _split(token)
    try:
        header = json.loads(_b64url_decode(h_b64))
    except Exception as e:
        raise ValueError(f"invalid JWT header: {e}") from e
    try:
        payload = json.loads(_b64url_decode(p_b64))
    except Exception as e:
        raise ValueError(f"invalid JWT payload: {e}") from e

    alg = str(header.get("alg", ""))
    findings: list[dict[str, str]] = []

    if alg.lower() == "none" or alg == "":
        findings.append(
            {
                "severity": "critical",
                "id": "alg-none",
                "message": "Algorithm is 'none' or empty — signature not required.",
            }
        )
    if alg.upper() in ("HS256", "HS384", "HS512") and header.get("jwk"):
        findings.append(
            {
                "severity": "high",
                "id": "embedded-jwk",
                "message": "Header embeds a JWK; verify the consumer does not trust it blindly.",
            }
        )
    if alg.upper().startswith("HS") is False and alg.upper().startswith("RS"):
        findings.append(
            {
                "severity": "info",
                "id": "asymmetric",
                "message": f"Asymmetric alg {alg}: signature verify requires public key (not done here).",
            }
        )
    if alg.upper() == "HS256":
        findings.append(
            {
                "severity": "info",
                "id": "hs256",
                "message": "HMAC-SHA256 — crackable offline if secret is weak (use jwt.crack).",
            }
        )

    now = int(time.time())
    time_checks: dict[str, Any] = {}
    for claim in ("exp", "nbf", "iat"):
        if claim in payload:
            try:
                val = int(payload[claim])
            except (TypeError, ValueError):
                findings.append(
                    {
                        "severity": "medium",
                        "id": f"bad-{claim}",
                        "message": f"Claim {claim} is not an integer timestamp.",
                    }
                )
                continue
            time_checks[claim] = val
            if claim == "exp" and val < now:
                findings.append(
                    {
                        "severity": "high",
                        "id": "expired",
                        "message": f"Token expired at {val} (now {now}).",
                    }
                )
            if claim == "nbf" and val > now + 60:
                findings.append(
                    {
                        "severity": "medium",
                        "id": "not-before",
                        "message": f"Token not valid before {val} (now {now}).",
                    }
                )

    sig_bytes = _b64url_decode(s_b64) if s_b64 else b""
    return {
        "header": header,
        "payload": payload,
        "signature_b64url": s_b64,
        "signature_hex": sig_bytes.hex(),
        "signature_len_bytes": len(sig_bytes),
        "algorithm": alg,
        "signing_input": f"{h_b64}.{p_b64}",
        "time_checks": time_checks,
        "now": now,
        "findings": findings,
    }


def verify_hmac(token: str, secret: str) -> dict[str, Any]:
    h_b64, p_b64, s_b64 = _split(token)
    header = json.loads(_b64url_decode(h_b64))
    alg = str(header.get("alg", "HS256")).upper()
    hash_name = {"HS256": "sha256", "HS384": "sha384", "HS512": "sha512"}.get(alg)
    if not hash_name:
        raise ValueError(f"verify_hmac only supports HS256/384/512, got {alg}")

    signing_input = f"{h_b64}.{p_b64}".encode("ascii")
    expected = hmac.new(secret.encode("utf-8"), signing_input, hash_name).digest()
    actual = _b64url_decode(s_b64)
    ok = hmac.compare_digest(expected, actual)
    return {
        "valid": ok,
        "algorithm": alg,
        "expected_sig_b64url": _b64url_encode(expected),
        "secret_length": len(secret),
    }


def crack(
    token: str,
    wordlist: str,
    max_candidates: int = 20_000,
) -> dict[str, Any]:
    """Brute HS* secret from a wordlist (offline)."""
    h_b64, p_b64, s_b64 = _split(token)
    header = json.loads(_b64url_decode(h_b64))
    alg = str(header.get("alg", "HS256")).upper()
    hash_name = {"HS256": "sha256", "HS384": "sha384", "HS512": "sha512"}.get(alg)
    if not hash_name:
        raise ValueError(f"jwt.crack only supports HS*, got {alg}")

    signing_input = f"{h_b64}.{p_b64}".encode("ascii")
    actual = _b64url_decode(s_b64)
    max_c = max(1, min(int(max_candidates), MAX_CANDIDATES))

    words = []
    for line in wordlist.replace(",", "\n").splitlines():
        w = line.strip()
        if w and not w.startswith("#"):
            words.append(w)

    t0 = time.perf_counter()
    tried = 0
    found = None
    for secret in words:
        tried += 1
        sig = hmac.new(secret.encode("utf-8"), signing_input, hash_name).digest()
        if hmac.compare_digest(sig, actual):
            found = secret
            break
        if tried >= max_c:
            break

    elapsed = time.perf_counter() - t0
    return {
        "cracked": found is not None,
        "secret": found,
        "algorithm": alg,
        "candidates_tried": tried,
        "elapsed_ms": round(elapsed * 1000, 2),
        "capped": tried >= max_c and found is None,
    }


def forge_none(payload_json: str) -> dict[str, Any]:
    """Create an unsigned alg=none token (for defensive testing of consumers)."""
    try:
        payload = json.loads(payload_json)
    except json.JSONDecodeError as e:
        raise ValueError(f"payload must be JSON object: {e}") from e
    header = {"alg": "none", "typ": "JWT"}
    h = _b64url_encode(json.dumps(header, separators=(",", ":")).encode())
    p = _b64url_encode(json.dumps(payload, separators=(",", ":")).encode())
    token = f"{h}.{p}."
    return {"token": token, "warning": "Unsigned token for testing only."}


def verify_asymmetric(token: str, public_key_pem: str) -> dict[str, Any]:
    """
    Verify RS256/RS384/RS512/ES256 signatures using cryptography when available
    (load via simd.ensure / psec-simd-wheels). Falls back to clear error if not loaded.
    """
    h_b64, p_b64, s_b64 = _split(token)
    header = json.loads(_b64url_decode(h_b64))
    payload = json.loads(_b64url_decode(p_b64))
    alg = str(header.get("alg") or "").upper()
    msg = f"{h_b64}.{p_b64}".encode()
    sig = _b64url_decode(s_b64)

    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding, rsa, ec
        from cryptography.hazmat.primitives.asymmetric.utils import Prehashed
        from cryptography.exceptions import InvalidSignature
    except ImportError:
        return {
            "ok": False,
            "error": "cryptography not installed — run await simd.ensure() first",
            "alg": alg,
            "hint": "https://github.com/KkDevAu/psec-simd-wheels/releases/latest",
        }

    try:
        key = serialization.load_pem_public_key(public_key_pem.encode() if isinstance(public_key_pem, str) else public_key_pem)
    except Exception as e:
        return {"ok": False, "error": f"invalid public key PEM: {e}", "alg": alg}

    hash_map = {
        "RS256": hashes.SHA256(),
        "RS384": hashes.SHA384(),
        "RS512": hashes.SHA512(),
        "ES256": hashes.SHA256(),
        "ES384": hashes.SHA384(),
        "ES512": hashes.SHA512(),
    }
    if alg not in hash_map:
        return {"ok": False, "error": f"unsupported alg for asymmetric verify: {alg}", "alg": alg}

    try:
        if alg.startswith("RS"):
            if not isinstance(key, rsa.RSAPublicKey):
                return {"ok": False, "error": "PEM is not an RSA public key", "alg": alg}
            key.verify(sig, msg, padding.PKCS1v15(), hash_map[alg])
        elif alg.startswith("ES"):
            if not isinstance(key, ec.EllipticCurvePublicKey):
                return {"ok": False, "error": "PEM is not an EC public key", "alg": alg}
            key.verify(sig, msg, ec.ECDSA(hash_map[alg]))
        else:
            return {"ok": False, "error": f"unsupported alg: {alg}", "alg": alg}
        return {
            "ok": True,
            "valid": True,
            "alg": alg,
            "header": header,
            "payload": payload,
            "engine": "cryptography",
        }
    except InvalidSignature:
        return {
            "ok": True,
            "valid": False,
            "alg": alg,
            "header": header,
            "payload": payload,
            "engine": "cryptography",
            "message": "signature invalid",
        }
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}", "alg": alg}


def crypto_status() -> dict[str, Any]:
    try:
        import cryptography
        return {
            "available": True,
            "version": getattr(cryptography, "__version__", "?"),
            "capabilities": ["RS256", "RS384", "RS512", "ES256", "ES384", "ES512", "HS*"],
        }
    except ImportError:
        return {
            "available": False,
            "capabilities": ["HS* (pure python)", "inspect", "crack"],
            "hint": "await simd.ensure() to load cryptography SIMD wheels",
        }
