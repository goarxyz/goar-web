"""CORS scanner — converted from chenjj/CORScanner (common/corscheck.py)."""
from __future__ import annotations
import json
from pathlib import Path
from typing import Any
from urllib.parse import urlparse
from .._http import http_request
from .. import policy
from .. import libcurl_bridge

_ORIGINS_PATH = Path(__file__).resolve().parent / "origins.json"

def _load_third_party_origins() -> list[str]:
    try:
        data = json.loads(_ORIGINS_PATH.read_text(encoding="utf-8"))
        return list(data.get("origins") or [])
    except Exception:
        return ["https://evil.com", "https://attacker.com"]

def _registered_domain(host: str) -> str:
    host = (host or "").lower().split(":")[0]
    parts = host.split(".")
    return ".".join(parts[-2:]) if len(parts) >= 2 else host

async def _check_cors_policy(url: str, test_origin: str, test_name: str, user_agent: str, extra_headers: dict[str,str], timeout_ms: int, retries: int, retryable: set[int], use_proxy: bool | None):
    headers = {"Origin": test_origin, "Cache-Control": "no-cache", "User-Agent": user_agent}; headers.update(extra_headers)
    attempts=[]; resp={}
    for attempt in range(retries + 1):
        resp = await http_request(url, headers=headers, timeout_ms=timeout_ms, use_proxy=use_proxy)
        attempts.append({"attempt":attempt+1,"status":resp.get("status"),"ok":resp.get("ok"),"transport":resp.get("transport"),"elapsed_ms":resp.get("elapsed_ms"),"error":str(resp.get("error") or "")[:200]})
        if resp.get("ok") or int(resp.get("status") or 0) not in retryable: break
    if resp.get("error") and not resp.get("status"):
        return None
    hdrs = {str(k).lower(): str(v) for k, v in (resp.get("headers") or {}).items()}
    acao = hdrs.get("access-control-allow-origin", "")
    acac = hdrs.get("access-control-allow-credentials", "")
    if test_origin != "null":
        try:
            parsed = urlparse(acao)
            resp_origin = (parsed.scheme + "://" + parsed.netloc.split(":")[0]) if parsed.scheme else acao
        except Exception:
            resp_origin = acao
    else:
        resp_origin = acao
    if test_origin.lower() == resp_origin.lower() or acao.strip() == test_origin:
        credentials = "true" if acac.lower() == "true" else "false"
        return {"url": url, "type": test_name, "credentials": credentials, "origin": test_origin,
                "acao": acao, "status_code": resp.get("status"),
                "severity": "critical" if credentials == "true" else "high", "attempts": attempts, "request_headers": {k:("[redacted]" if k.lower() in {"authorization","cookie","x-api-key"} else v) for k,v in headers.items()}}
    if acao.strip() == "*":
        return {"url": url, "type": test_name + "_wildcard", "credentials": "true" if acac.lower()=="true" else "false",
                "origin": test_origin, "acao": "*", "status_code": resp.get("status"),
                "severity": "critical" if acac.lower()=="true" else "medium", "attempts": attempts, "request_headers": {k:("[redacted]" if k.lower() in {"authorization","cookie","x-api-key"} else v) for k,v in headers.items()}}
    return None

async def scan(url: str, user_agent: str = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5) AppleWebKit/537.36", stop_on_first: bool = False, max_tests: int = 0, headers: str = "", timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = "408,429,500,502,503,504", route: str = "auto", custom_origins: str = "", include_third_parties: bool = True, include_special_chars: bool = True, include_tests: bool = True):
    err = policy.check_url_for_active(url)
    if err:
        return {"ok": False, "error": err, "engine": "cors"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    parsed = urlparse(url)
    host = parsed.hostname or ""
    scheme = parsed.scheme or "https"
    reg = _registered_domain(host)
    transport = {"libcurl_ready": libcurl_bridge.is_ready(), "note": "libcurl ready" if libcurl_bridge.is_ready() else "libcurl not ready — Origin may be incomplete"}
    raw = str(headers or "").strip(); extra = {}
    if raw.startswith("{"):
        parsed_headers=json.loads(raw)
        if not isinstance(parsed_headers,dict): raise ValueError("headers JSON must be an object")
        extra={str(k):str(v) for k,v in parsed_headers.items()}
    else:
        for line in raw.splitlines():
            if ":" in line:
                k,_,v=line.partition(":")
                if k.strip(): extra[k.strip()]=v.strip()
    timeout=max(1000,min(int(timeout_ms or 8000),120000)); retry_count=max(0,min(int(retries or 0),5)); retryable={int(x.strip()) for x in str(retry_statuses or "").split(",") if x.strip().isdigit()}; use_proxy=None if route in ("","auto",None) else (True if route=="proxy" else False if route=="direct" else (_ for _ in ()).throw(ValueError("route must be auto, proxy, or direct")))
    findings, tests_run = [], []

    async def run_test(name, origin):
        if int(max_tests or 0) > 0 and len(tests_run) >= int(max_tests):
            return False
        if not policy.can_request():
            return False
        tests_run.append(name)
        result = await _check_cors_policy(url, origin, name, user_agent, extra, timeout, retry_count, retryable, use_proxy)
        if result:
            findings.append(result)
            return True
        return False

    # CORScanner test suite names
    await run_test("reflect_origin", "https://evil.com")
    if not (stop_on_first and findings):
        await run_test("prefix_match", f"https://{host}.evil.com")
        await run_test("suffix_match", f"https://evil{host}")
        await run_test("trust_null", "null")
        await run_test("include_match", f"https://evil{reg}")
        await run_test("trust_any_subdomain", f"https://any.{host}")
        if scheme == "https":
            await run_test("https_trust_http", f"http://{host}")
        if include_third_parties:
            for origin in _load_third_party_origins()[:12]:
                if not policy.can_request(): break
                await run_test("custom_third_parties", origin)
        for origin in [x.strip() for x in str(custom_origins or "").replace("\n", ",").split(",") if x.strip()]:
            if not policy.can_request(): break
            await run_test("custom_origin", origin)
        for char in (['_', '-', '"', '{', '}', '+', '^', '%60', '!', '~'][:8] if include_special_chars else []):
            if not policy.can_request():
                break
            await run_test("special_characters_bypass", f"{scheme}://{host.split(':')[0]}{char}.evil.com")

    return {"ok": True, "url": url, "host": host, "vulnerable": bool(findings),
            "findings": findings, "finding_count": len(findings), "tests_run": tests_run if include_tests else None, "attempt_count": sum(len(x.get("attempts") or []) for x in findings),
            "request": {"headers": {k:("[redacted]" if k.lower() in {"authorization","cookie","x-api-key"} else v) for k,v in extra.items()}, "timeout_ms":timeout,"retries":retry_count,"route":"auto" if use_proxy is None else ("proxy" if use_proxy else "direct")}, "transport": transport, "engine": "cors", "version": "3.0-corscanner",
            "equivalent": "chenjj/CORScanner", "source": "https://github.com/chenjj/CORScanner",
            "policy": policy.status()}

def list_probes(host: str = "example.com"):
    reg = _registered_domain(host)
    probes = [
        {"id": "reflect_origin", "origin": "https://evil.com"},
        {"id": "prefix_match", "origin": f"https://{host}.evil.com"},
        {"id": "suffix_match", "origin": f"https://evil{host}"},
        {"id": "trust_null", "origin": "null"},
        {"id": "include_match", "origin": f"https://evil{reg}"},
        {"id": "trust_any_subdomain", "origin": f"https://any.{host}"},
        {"id": "https_trust_http", "origin": f"http://{host}"},
    ]
    for o in _load_third_party_origins()[:5]:
        probes.append({"id": "custom_third_parties", "origin": o})
    return {"count": len(probes), "probes": probes, "source": "CORScanner"}
