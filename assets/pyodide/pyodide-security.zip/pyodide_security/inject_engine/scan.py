"""
Injection engine — CMD/LDAP from PayloadsAllTheThings + generic probes.
"""

from __future__ import annotations

import gzip
import json
from pathlib import Path
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from .._http import http_request, redact_url
from .. import policy

_DATA = Path(__file__).with_name("data")


def _load(name: str) -> list[str]:
    p = _DATA / name
    if not p.exists():
        return []
    with gzip.open(p, "rt", encoding="utf-8") as f:
        return json.load(f)


def list_payloads(kind: str = "cmdi") -> dict[str, Any]:
    kind = (kind or "cmdi").lower()
    file = {"cmdi": "cmdi.json.gz", "ldap": "ldap.json.gz", "command": "cmdi.json.gz"}.get(kind, "cmdi.json.gz")
    rows = _load(file)
    return {
        "ok": True,
        "kind": kind,
        "count": len(rows),
        "payloads": rows,
        "source": "PayloadsAllTheThings Command Injection / LDAP Injection",
        "engine": "inject",
    }


async def scan(
    url: str,
    parameter: str = "",
    kind: str = "cmdi",
    max_payloads: int = 15,
    user_agent: str = "pyodide-security/inject/2.0",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    include_attempts: bool = True,
) -> dict[str, Any]:
    err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "engine": "inject"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    p = urlparse(url)
    params = dict(parse_qsl(p.query, keep_blank_values=True))
    param = parameter or (next(iter(params)) if params else "q")
    kind = (kind or "cmdi").lower()
    file = "ldap.json.gz" if kind == "ldap" else "cmdi.json.gz"
    payloads = _load(file)[: max(1, int(max_payloads))]

    headers = {"User-Agent": user_agent}
    timeout = max(1000, min(int(timeout_ms or 8000), 120000))
    retry_count = max(0, min(int(retries or 0), 5))
    route_name = route if route in ("auto", "proxy", "direct") else "auto"
    use_proxy = True if route_name == "proxy" else False if route_name == "direct" else None
    retry_codes = {int(item.strip()) for item in str(retry_statuses or "").split(",") if item.strip().isdigit()}
    attempts: list[dict[str, Any]] = []

    async def request(target: str) -> dict[str, Any]:
        response: dict[str, Any] = {}
        for index in range(retry_count + 1):
            response = await http_request(target, headers=headers, timeout_ms=timeout, use_proxy=use_proxy)
            attempts.append({"attempt": len(attempts) + 1, "url": redact_url(target), "status": response.get("status"), "ok": response.get("ok"), "transport": response.get("transport"), "elapsed_ms": response.get("elapsed_ms"), "error": str(response.get("error") or "")[:240]})
            if response.get("ok") or int(response.get("status") or 0) not in retry_codes:
                break
        return response

    base = await request(url)
    base_body = (base.get("body") or "").lower()
    findings = []
    tested = 0
    sigs = ("uid=", "gid=", "root:", "command not found", "syntax error", "sh:", "bin/bash", "objectclass", "ldap")
    for pl in payloads:
        if not policy.can_request():
            break
        tested += 1
        inj = dict(params)
        inj[param] = pl
        test_url = urlunparse((p.scheme, p.netloc, p.path, p.params, urlencode(inj), p.fragment))
        resp = await request(test_url)
        body = (resp.get("body") or "").lower()
        hits = [s for s in sigs if s in body and s not in base_body]
        if hits:
            findings.append({"payload": pl, "signals": hits, "status": resp.get("status")})
    return {
        "ok": True,
        "url": redact_url(url),
        "parameter": param,
        "kind": kind,
        "tested": tested,
        "findings": findings,
        "finding_count": len(findings),
        "engine": "inject",
        "source": "PayloadsAllTheThings",
        "request": {"timeout_ms": timeout, "retries": retry_count, "retry_statuses": sorted(retry_codes), "route": route_name, "headers": {"User-Agent": user_agent}},
        "attempts": attempts if include_attempts else [],
        "attempt_count": len(attempts),
    }
