"""Nmap-services database (top 5000 by frequency from nmap/nmap-services)."""
from __future__ import annotations
import gzip, json
from pathlib import Path
from typing import Any

_DB=None
def _db():
    global _DB
    if _DB is None:
        with gzip.open(Path(__file__).with_name("services.json.gz"),"rt",encoding="utf-8") as f:
            _DB=json.load(f)
    return _DB

def list_services(proto: str="", limit: int=0)->dict[str,Any]:
    rows=_db()
    if proto:
        rows=[r for r in rows if r["proto"]==proto.lower()]
    out=rows[:int(limit)] if limit and limit>0 else rows
    return {"ok":True,"count":len(rows),"returned":len(out),"services":out,
            "source":"nmap/nmap-services","engine":"nmap","equivalent":"nmap"}

def top_ports(n: int=100, proto: str="tcp")->dict[str,Any]:
    rows=[r for r in _db() if r["proto"]==(proto or "tcp").lower()][:max(1,int(n))]
    return {"ok":True,"ports":[r["port"] for r in rows],"services":rows,"count":len(rows),"engine":"nmap"}

def lookup_port(port: int, proto: str="tcp")->dict[str,Any]:
    port=int(port); proto=(proto or "tcp").lower()
    hits=[r for r in _db() if r["port"]==port and r["proto"]==proto]
    return {"ok":True,"port":port,"proto":proto,"matches":hits,"engine":"nmap"}


def lookup(port: int=0, proto: str="tcp", **kw):
    """Return the single service shape consumed by the browser HTTP probe."""
    port = int(port or 0)
    proto = (proto or "tcp").lower()
    rows = [row for row in _db() if row.get("port") == port and row.get("proto") == proto]
    row = rows[0] if rows else {}
    service = str(row.get("name") or "unknown")
    tls_ports = {443, 465, 563, 636, 8443, 9443, 10443, 2083, 2087, 4443, 6443}
    return {
        "port": port,
        "proto": proto,
        "service": service,
        "tls": port in tls_ports or service in {"https", "ssl", "tls"},
        "product": None,
        "version": None,
        "frequency": row.get("freq"),
    }


def guess_from_banner(port: int, banner: str = "") -> dict[str, Any]:
    """Combine service-db defaults with lightweight HTTP banner identification."""
    meta = lookup(port)
    text = str(banner or "")
    product = None
    version = None
    for line in text.splitlines():
        if line.lower().startswith("server:"):
            product = line.split(":", 1)[1].strip() or None
            if product and "/" in product:
                product, version = product.split("/", 1)
            break
    return {**meta, "product": product or meta.get("product"), "version": version or meta.get("version")}
