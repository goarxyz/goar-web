"""
WAF detection — 1:1 conversion of EnableSecurity/wafw00f.

Loads real plugin modules from plugins/*.py and calls is_waf(self) with
matchHeader / matchCookie / matchContent / matchStatus / matchReason
implemented exactly as wafw00f/main.py.
"""
from __future__ import annotations

import importlib.util
import re
from pathlib import Path
from typing import Any

from .._http import http_request, redact_url
from .. import policy

_PLUGIN_DIR = Path(__file__).resolve().parent / "plugins"

# Attack strings from wafw00f.main.WAFW00F
_XSS = r'<script>alert("XSS");</script>'
_SQLI = r'UNION SELECT ALL FROM information_schema AND " or SLEEP(5) or "'
_LFI = r'../../etc/passwd'
_RCE = r'/bin/cat /etc/passwd; ping 127.0.0.1; curl google.com'
_XXE = r'<!ENTITY xxe SYSTEM "file:///etc/shadow">]><pwn>&hack;</pwn>'


class _RespObj:
    """Minimal requests.Response-like object for plugin matchers."""

    def __init__(self, status: int, headers: dict, body: str, reason: str = ""):
        self.status_code = int(status or 0)
        # preserve original header names but also allow case-insensitive get
        self.headers = _CIHeaders(headers or {})
        self.text = body or ""
        self.reason = reason or ""
        self.content = (body or "").encode("utf-8", errors="replace")


class _CIHeaders(dict):
    def get(self, key, default=None):
        if key in self:
            return super().get(key, default)
        lk = str(key).lower()
        for k, v in self.items():
            if str(k).lower() == lk:
                return v
        return default


def _load_plugins() -> dict[str, Any]:
    """Port of wafw00f.manager.load_plugins"""
    plugin_dict = {}
    if not _PLUGIN_DIR.is_dir():
        return plugin_dict
    for path in sorted(_PLUGIN_DIR.glob("*.py")):
        if path.name == "__init__.py":
            continue
        name = path.stem
        spec = importlib.util.spec_from_file_location(f"waf_plugins.{name}", path)
        if not spec or not spec.loader:
            continue
        mod = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(mod)
        except Exception:
            continue
        if hasattr(mod, "NAME") and hasattr(mod, "is_waf"):
            plugin_dict[name] = mod
    return plugin_dict


class WAFW00F:
    """Port of wafw00f.main.WAFW00F matcher + identwaf surface."""

    def __init__(self):
        self.rq: _RespObj | None = None
        self.attackres: _RespObj | None = None
        plugins = _load_plugins()
        self.wafdetections: dict[str, Any] = {}
        for mod in plugins.values():
            self.wafdetections[mod.NAME] = mod.is_waf
        # priority list if available
        try:
            from .wafprio import wafdetectionsprio
            checklist = list(wafdetectionsprio)
            checklist += list(set(self.wafdetections.keys()) - set(checklist))
        except Exception:
            checklist = list(self.wafdetections.keys())
        self.checklist = checklist
        self.plugin_count = len(self.wafdetections)
        self.attempts: list[dict[str, Any]] = []

    def matchHeader(self, headermatch, attack=False):
        r = self.attackres if attack else self.rq
        if r is None:
            return False
        header, match = headermatch
        headerval = r.headers.get(header)
        if headerval:
            if header.lower() == "set-cookie":
                headervals = headerval.split(", ")
            else:
                headervals = [headerval]
            for hv in headervals:
                if re.search(match, hv, re.I):
                    return True
        return False

    def matchStatus(self, statuscode, attack=True):
        r = self.attackres if attack else self.rq
        if r is None:
            return False
        return r.status_code == statuscode

    def matchCookie(self, match, attack=False):
        return self.matchHeader(("Set-Cookie", match), attack=attack)

    def matchReason(self, reasoncode, attack=True):
        r = self.attackres if attack else self.rq
        if r is None:
            return False
        return str(r.reason) == reasoncode

    def matchContent(self, regex, attack=True):
        r = self.attackres if attack else self.rq
        if r is None:
            return False
        return bool(re.search(regex, r.text, re.I))

    async def _fetch(self, url: str, headers: dict | None = None, path_q: str = "", timeout_ms: int = 8000, retries: int = 0, retryable: set[int] | None = None, use_proxy: bool | None = None) -> _RespObj:
        target = url
        if path_q:
            sep = "&" if "?" in url else "?"
            # path_q may be full query or path
            if path_q.startswith("?"):
                target = url.rstrip("/") + path_q
            elif path_q.startswith("/"):
                target = url.rstrip("/") + path_q
            else:
                target = url + sep + path_q
        resp = {}; retryable = retryable or set()
        for index in range(max(0, min(int(retries or 0), 5)) + 1):
            resp = await http_request(target, headers=headers or {}, timeout_ms=max(1000, min(int(timeout_ms or 8000), 120000)), use_proxy=use_proxy)
            safe_error = re.sub(r'(?im)(token|secret|api[_-]?key|authorization|cookie)(\s*[=:]\s*)[^\s,;]+', lambda m: f'{m.group(1)}{m.group(2)}[redacted]', str(resp.get("error") or ""))[:200]
            self.attempts.append({"url": redact_url(target), "attempt": index + 1, "status": resp.get("status"), "ok": resp.get("ok"), "transport": resp.get("transport"), "elapsed_ms": resp.get("elapsed_ms"), "error": safe_error})
            if resp.get("ok") or int(resp.get("status") or 0) not in retryable: break
        return _RespObj(
            status=int(resp.get("status") or 0),
            headers=resp.get("headers") or {},
            body=resp.get("body") or "",
        )


async def detect(
    url: str,
    findall: bool = True,
    active: bool = True,
    user_agent: str = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:130.0) Gecko/20100101 Firefox/130.0",
    headers: str = "", timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = "408,429,500,502,503,504", route: str = "auto", active_vectors: str = "xss,sqli,lfi", include_attempts: bool = True, max_plugins: int = 0,
) -> dict[str, Any]:
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    eng = WAFW00F()
    raw_headers = str(headers or '').strip()
    request_headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'User-Agent': user_agent, 'Accept-Language': 'en-US,en;q=0.5'}
    if raw_headers.startswith('{'):
        parsed_headers = __import__('json').loads(raw_headers)
        if not isinstance(parsed_headers, dict): raise ValueError('headers JSON must be an object')
        request_headers.update({str(k): str(v) for k, v in parsed_headers.items()})
    else:
        for line in raw_headers.splitlines():
            if ':' in line:
                key, _, value = line.partition(':')
                if key.strip(): request_headers[key.strip()] = value.strip()
    timeout = max(1000, min(int(timeout_ms or 8000), 120000)); retry_count = max(0, min(int(retries or 0), 5)); retryable = {int(x.strip()) for x in str(retry_statuses or '').split(',') if x.strip().isdigit()}
    use_proxy = None if route in ('', 'auto', None) else (True if route == 'proxy' else False if route == 'direct' else (_ for _ in ()).throw(ValueError('route must be auto, proxy, or direct')))
    eng.rq = await eng._fetch(url, headers=request_headers, timeout_ms=timeout, retries=retry_count, retryable=retryable, use_proxy=use_proxy)
    selected = {x.strip().lower() for x in str(active_vectors or '').split(',') if x.strip()}
    vector_map = {'xss': _XSS, 'sqli': _SQLI, 'lfi': _LFI, 'rce': _RCE, 'xxe': _XXE}
    if active and policy.check_url_for_active(url) is None and policy.can_request() and selected:
        q = '&'.join(f'{name}={vector_map[name]}' for name in selected if name in vector_map)
        eng.attackres = await eng._fetch(url, headers=request_headers, path_q=q, timeout_ms=timeout, retries=retry_count, retryable=retryable, use_proxy=use_proxy)
    else:
        eng.attackres = eng.rq

    detected: list[dict[str, Any]] = []
    for wafvendor in eng.checklist[:max(1, int(max_plugins))] if int(max_plugins or 0) > 0 else eng.checklist:
        fn = eng.wafdetections.get(wafvendor)
        if not fn:
            continue
        try:
            if fn(eng):
                detected.append({"name": wafvendor, "matched": True})
                if not findall:
                    break
        except Exception as e:
            continue

    # generic behavioral signals
    generic = []
    if eng.rq and eng.attackres and eng.rq.status_code != eng.attackres.status_code:
        generic.append(
            f"Status differs normal vs attack: {eng.rq.status_code} → {eng.attackres.status_code}"
        )

    return {
        "ok": True,
        "url": redact_url(url),
        "detected": bool(detected),
        "wafs": detected,
        "primary": detected[0] if detected else None,
        "match_count": len(detected),
        "generic_waf_signals": generic,
        "generic_detected": bool(generic),
        "baseline_status": eng.rq.status_code if eng.rq else 0,
        "server": (eng.rq.headers.get("Server") if eng.rq else None),
        "plugin_count": eng.plugin_count, "checked_plugins": min(eng.plugin_count, int(max_plugins)) if int(max_plugins or 0) > 0 else eng.plugin_count,
        "attempts": eng.attempts if include_attempts else None, "attempt_count": len(eng.attempts),
        "request": {"headers": {k: ('[redacted]' if k.lower() in {'authorization','cookie','x-api-key'} else v) for k, v in request_headers.items()}, "timeout_ms": timeout, "retries": retry_count, "route": 'auto' if use_proxy is None else ('proxy' if use_proxy else 'direct'), "active_vectors": sorted(selected)},
        "engine": "waf",
        "version": "4.0-wafw00f-1to1",
        "equivalent": "EnableSecurity/wafw00f",
        "source": "https://github.com/EnableSecurity/wafw00f",
        "note": "Executes real plugin is_waf() functions with 1:1 matchHeader/Content/Cookie/Status",
        "policy": policy.status(),
    }


def list_signatures() -> dict[str, Any]:
    eng = WAFW00F()
    return {
        "total": eng.plugin_count,
        "wafs": list(eng.wafdetections.keys()),
        "source": "EnableSecurity/wafw00f plugins/*.py (bundled)",
        "equivalent": "wafw00f",
    }
