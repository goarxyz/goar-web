"""
HTTP request smuggling helpers — converted from defparam/smuggler.

Source: https://github.com/defparam/smuggler
Ports mutation gadgets from configs/default.py, exhaustive.py, doubles.py.

HONEST LIMIT: Browser / libcurl.js / fetch cannot open raw TCP sockets or
send malformed HTTP framing the way smuggler.py does via EasySSL. This module
therefore:
  1. Exposes the full mutation corpus (1:1 from upstream configs)
  2. Attempts best-effort probes over http_request (normalized HTTP)
  3. Reports capability matrix so operators know what is / is not testable in WASM
"""
from __future__ import annotations

from typing import Any
from urllib.parse import urlparse

from .._http import http_request
from .. import policy
from .mutations import MUTATIONS


def list_mutations(config: str = "all") -> dict[str, Any]:
    cfg = (config or "all").lower()
    items = MUTATIONS
    if cfg != "all":
        items = [m for m in MUTATIONS if m["id"].startswith(cfg + ":")]
    return {
        "count": len(items),
        "config_filter": cfg,
        "mutations": items,
        "source": "defparam/smuggler configs/default.py + exhaustive.py + doubles.py",
        "equivalent": "defparam/smuggler",
    }


def capability_matrix() -> dict[str, Any]:
    return {
        "raw_tcp": False,
        "malformed_framing": False,
        "te_cl_desync": False,
        "http_request_normalized": True,
        "mutation_corpus": True,
        "note": (
            "Full CL.TE / TE.CL desync detection requires raw socket control "
            "(smuggler EasySSL). In Pyodide we ship the complete mutation list "
            "for offline analysis and export to native smuggler, plus limited "
            "behavioral probes over normalized HTTP."
        ),
        "equivalent": "defparam/smuggler",
        "source": "https://github.com/defparam/smuggler",
    }


async def scan(
    url: str,
    max_mutations: int = 20,
    user_agent: str = "pyodide-security/smuggler/1.0",
) -> dict[str, Any]:
    err = policy.check_url_for_active(url)
    if err:
        return {"ok": False, "error": err, "engine": "smuggle"}

    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    headers = {"User-Agent": user_agent}
    base = await http_request(url, headers=headers)
    base_status = int(base.get("status") or 0)
    base_len = len(base.get("body") or "")

    # Best-effort: send requests that *mention* TE/CL confusion via headers
    # (libcurl may normalize — results are advisory only)
    probes = []
    findings = []
    tested = 0
    for mut in MUTATIONS[: max(1, min(int(max_mutations), 60))]:
        if not policy.can_request():
            break
        # Use unusual header values inspired by the gadget (not raw framing)
        gadget = mut["gadget"]
        hdrs = {
            **headers,
            "X-Smuggle-Gadget": mut["id"],
            "Transfer-Encoding": "chunked" if "chunked" in gadget.lower() else "identity",
            "Content-Length": "0",
        }
        # duplicate TE style
        if "space" in mut["id"] or "tab" in mut["id"] or "prefix" in mut["id"]:
            hdrs["Transfer-Encoding"] = "chunked"
            hdrs["X-Transfer-Encoding"] = gadget[:80]
        resp = await http_request(url, method="POST", headers=hdrs, body="")
        st = int(resp.get("status") or 0)
        bl = len(resp.get("body") or "")
        tested += 1
        entry = {
            "mutation": mut["id"],
            "status": st,
            "length": bl,
            "delta_status": st != base_status,
            "delta_length": abs(bl - base_len) > max(50, int(base_len * 0.05)),
            "error": resp.get("error"),
        }
        probes.append(entry)
        if entry["delta_status"] or entry["delta_length"]:
            findings.append(entry)

    return {
        "ok": True,
        "url": url,
        "baseline_status": base_status,
        "tested": tested,
        "findings": findings,
        "probes": probes,
        "mutation_db": len(MUTATIONS),
        "capabilities": capability_matrix(),
        "engine": "smuggle",
        "version": "3.0-smuggler",
        "equivalent": "defparam/smuggler",
        "source": "https://github.com/defparam/smuggler",
        "note": "Mutation corpus is 1:1 from upstream; live desync confirmation needs native smuggler",
        "policy": policy.status(),
    }
