"""Fuzz string generator — lengths, boundary, naughty strings sample."""
from __future__ import annotations
from typing import Any

NAUGHTY=[
    ""," ","%","_","*","'","\"","`","\\","<",">","&",
    "../","..\\","%00","%0a","%0d","${7*7}","{{7*7}}","#{7*7}",
    "1;DROP TABLE users","' OR '1'='1","\" OR \"\"=\"",
    "<script>alert(1)</script>","../../../../etc/passwd",
    "0","-1","9999999999","true","false","null","undefined",
    "NaN","Infinity","[]","{}","()","admin","root",
]

def generate(kinds: str="naughty,lengths", max_len: int=1024)->dict[str,Any]:
    out=[]
    kinds_set={k.strip() for k in kinds.split(",")}
    if "naughty" in kinds_set:
        out.extend({"id":f"naughty-{i}","value":v} for i,v in enumerate(NAUGHTY))
    if "lengths" in kinds_set:
        for n in (0,1,2,8,16,32,64,128,255,256,512,1023,1024,2048,4096):
            if n>max_len: break
            out.append({"id":f"len-{n}","value":"A"*n})
    if "fmt" in kinds_set:
        out.extend({"id":f"fmt-{i}","value":v} for i,v in enumerate(["%s","%x","%n","%p","%s%S%S%s"]))
    return {"ok":True,"count":len(out),"payloads":out,"engine":"fuzzgen","equivalent":"big-list-of-naughty-strings sample"}
