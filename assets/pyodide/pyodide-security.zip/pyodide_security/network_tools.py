"""Additive commercial network tools built on the shared Goar transport.

These tools are intentionally bounded and return machine-readable evidence. They do
not claim raw-socket or connection-reuse behavior that browser/Pyodide cannot prove.
"""
from __future__ import annotations

import json
import re
from typing import Any

from ._http import http_request, redact_url
from . import policy

_RETRY_DEFAULT = {408, 429, 500, 502, 503, 504}
_SENSITIVE = re.compile(r"(?i)(authorization|cookie|set-cookie|x-api-key|api[_-]?key|token|secret|password)")


def _parse_headers(raw: str | dict[str, Any] | None) -> dict[str, str]:
    if isinstance(raw, dict):
        return {str(k): str(v) for k, v in raw.items()}
    text = str(raw or "").strip()
    if not text:
        return {}
    try:
        parsed = json.loads(text)
        if isinstance(parsed, dict):
            return {str(k): str(v) for k, v in parsed.items()}
    except (TypeError, ValueError):
        pass
    out: dict[str, str] = {}
    for line in text.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            if key.strip():
                out[key.strip()] = value.strip()
    return out


def _safe_headers(headers: dict[str, str]) -> dict[str, str]:
    return {key: "[redacted]" if _SENSITIVE.search(key) else value for key, value in headers.items()}


def _limits(timeout_ms: int, retries: int, retry_statuses: str, route: str) -> tuple[int, int, set[int], str, bool | None]:
    timeout = max(1000, min(int(timeout_ms or 8000), 120000))
    retry_count = max(0, min(int(retries or 0), 5))
    codes = {int(item.strip()) for item in str(retry_statuses or "").split(",") if item.strip().isdigit()} or set(_RETRY_DEFAULT)
    route_name = route if route in ("auto", "proxy", "direct") else "auto"
    return timeout, retry_count, codes, route_name, True if route_name == "proxy" else False if route_name == "direct" else None


async def _request(url: str, method: str, headers: dict[str, str], body: str | None, timeout: int, retries: int, retry_codes: set[int], use_proxy: bool | None, attempts: list[dict[str, Any]]) -> dict[str, Any]:
    response: dict[str, Any] = {}
    for number in range(retries + 1):
        response = await http_request(url, method=method, headers=headers, body=body, timeout_ms=timeout, use_proxy=use_proxy)
        attempts.append({"attempt": number + 1, "url": redact_url(url), "method": method, "status": response.get("status"), "ok": response.get("ok"), "transport": response.get("transport"), "elapsed_ms": response.get("elapsed_ms"), "error": str(response.get("error") or "")[:240]})
        if response.get("ok") or int(response.get("status") or 0) not in retry_codes:
            break
    return response


def _url_list(urls: str | list[str]) -> list[str]:
    values = urls if isinstance(urls, list) else str(urls or "").replace(",", "\n").splitlines()
    out = []
    for value in values:
        url = str(value).strip()
        if url and url.startswith(("http://", "https://")):
            out.append(url)
    return list(dict.fromkeys(out))[:50]


async def batch(urls: str, method: str = "GET", headers: str = "", body: str = "", timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = "408,429,500,502,503,504", route: str = "auto", max_requests: int = 20) -> dict[str, Any]:
    targets = _url_list(urls)[: max(1, min(int(max_requests or 20), 50))]
    if not targets:
        return {"ok": False, "error": "at least one absolute http(s) URL is required", "engine": "network-additive"}
    error = policy.check_url_for_active(targets[0]) if hasattr(policy, "check_url_for_active") else None
    if error:
        return {"ok": False, "error": error, "engine": "network-additive"}
    timeout, retry_count, retry_codes, route_name, use_proxy = _limits(timeout_ms, retries, retry_statuses, route)
    request_headers = _parse_headers(headers)
    attempts: list[dict[str, Any]] = []
    rows = []
    method_name = str(method or "GET").upper()
    if method_name not in {"GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"}:
        method_name = "GET"
    for target in targets:
        if not policy.can_request():
            break
        response = await _request(target, method_name, request_headers, body if method_name not in {"GET", "HEAD"} else None, timeout, retry_count, retry_codes, use_proxy, attempts)
        rows.append({"url": redact_url(target), "status": response.get("status"), "ok": response.get("ok"), "length": len(response.get("body") or ""), "headers": _safe_headers({str(k): str(v) for k, v in (response.get("headers") or {}).items()}), "transport": response.get("transport"), "elapsed_ms": response.get("elapsed_ms"), "error": str(response.get("error") or "")[:240]})
    return {"ok": any(row.get("ok") for row in rows), "requested": len(targets), "completed": len(rows), "results": rows, "attempts": attempts, "attempt_count": len(attempts), "request": {"method": method_name, "headers": _safe_headers(request_headers), "timeout_ms": timeout, "retries": retry_count, "retry_statuses": sorted(retry_codes), "route": route_name}, "engine": "network-additive", "equivalent": "httpx batch probe"}


async def diff(url_a: str, url_b: str, method: str = "GET", headers: str = "", timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = "408,429,500,502,503,504", route: str = "auto") -> dict[str, Any]:
    result = await batch(f"{url_a}\n{url_b}", method=method, headers=headers, timeout_ms=timeout_ms, retries=retries, retry_statuses=retry_statuses, route=route, max_requests=2)
    rows = result.get("results") or []
    comparison = {"same_status": len(rows) == 2 and rows[0].get("status") == rows[1].get("status"), "same_length": len(rows) == 2 and rows[0].get("length") == rows[1].get("length"), "length_delta": abs(int(rows[0].get("length") or 0) - int(rows[1].get("length") or 0)) if len(rows) == 2 else None}
    return {**result, "comparison": comparison, "engine": "network-additive-diff", "equivalent": "httpx response comparison"}


async def headers(url: str, request_headers: str = "", timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = "408,429,500,502,503,504", route: str = "auto") -> dict[str, Any]:
    result = await batch(url, method="HEAD", headers=request_headers, timeout_ms=timeout_ms, retries=retries, retry_statuses=retry_statuses, route=route, max_requests=1)
    row = (result.get("results") or [{}])[0]
    response_headers = row.get("headers") or {}
    recommended = {"strict-transport-security": "HSTS", "content-security-policy": "CSP", "x-content-type-options": "X-Content-Type-Options", "referrer-policy": "Referrer-Policy", "permissions-policy": "Permissions-Policy"}
    missing = [name for name in recommended if name not in {str(k).lower() for k in response_headers}]
    return {**result, "security_headers": response_headers, "missing_security_headers": missing, "engine": "network-additive-headers", "equivalent": "securityheaders-style response audit"}
