"""Back-compat shim → katana_engine."""

from .katana_engine import crawl, extract, extract_js

__all__ = ["crawl", "extract", "extract_js"]
