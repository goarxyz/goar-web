"""
Cloud storage enumeration — cloud_enum-class conversion (initstring/cloud_enum).

Checks public cloud object-storage naming patterns:
  AWS S3, Azure Blob/File/Queue/Table/App Service, GCP buckets/appspots
Uses cloud_enum fuzz.txt mutations against a base name.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .._http import http_request, redact_url
from .. import policy

def _headers(raw: str, user_agent: str) -> dict[str, str]:
    h = {"User-Agent": user_agent}; text = str(raw or "").strip()
    if text.startswith("{"):
        import json
        parsed = json.loads(text)
        if not isinstance(parsed, dict): raise ValueError("headers JSON must be an object")
        h.update({str(k): str(v) for k, v in parsed.items()})
    else:
        for line in text.splitlines():
            if ":" in line:
                k, _, v = line.partition(":"); h[k.strip()] = v.strip()
    return h

def _route(value: Any) -> bool | None:
    if value in (None, "", "auto", "AUTO"): return None
    if value in (True, "proxy", "PROXY", "true", "True"): return True
    if value in (False, "direct", "DIRECT", "false", "False"): return False
    raise ValueError("route must be auto, proxy, or direct")

_FUZZ = Path(__file__).with_name("fuzz.txt")

# Formats adapted from cloud_enum aws_checks / azure_checks / gcp_checks
AWS_FORMATS = [
    "https://{name}.s3.amazonaws.com",
    "https://{name}.s3-us-east-1.amazonaws.com",
    "https://{name}.s3.amazonaws.com/?list-type=2",
]
AZURE_FORMATS = [
    "https://{name}.blob.core.windows.net",
    "https://{name}.blob.core.windows.net/{name}",
    "https://{name}.file.core.windows.net",
    "https://{name}.queue.core.windows.net",
    "https://{name}.table.core.windows.net",
    "https://{name}.azurewebsites.net",
    "https://{name}.cloudapp.net",
    "https://{name}.database.windows.net",
]
GCP_FORMATS = [
    "https://storage.googleapis.com/{name}",
    "https://{name}.storage.googleapis.com",
    "https://{name}.appspot.com",
]


def _clean_cloud_name(value: str) -> str:
    """Match cloud_enum's hostname-oriented keyword cleanup."""
    return "".join(ch for ch in str(value or "").strip().lower() if ch.isalnum() or ch in ".-")


def _mutation_words(custom: str = "") -> list[str]:
    text = str(custom or "").strip()
    if text:
        return [line.strip() for line in text.replace(",", chr(10)).splitlines() if line.strip()]
    if _FUZZ.exists():
        return [w.strip() for w in _FUZZ.read_text(encoding="utf-8", errors="replace").splitlines() if w.strip()]
    return []


def _mutations(base: str, limit: int = 50) -> list[str]:
    """Legacy mutation order retained for cloud.enum and existing callers."""
    base = _clean_cloud_name(base)
    words = _mutation_words(); out = [base] if base else []
    for w in words:
        if len(out) >= limit: break
        for cand in (f"{base}-{w}", f"{base}{w}", f"{w}-{base}", f"{w}{base}"):
            cand = _clean_cloud_name(cand)
            if cand and cand not in out: out.append(cand)
            if len(out) >= limit: break
    return out[:max(1, int(limit or 1))]


def _upstream_mutations(bases: list[str], words: list[str], limit: int) -> list[str]:
    """Bounded cloud_enum build_names-compatible local permutation set."""
    out: list[str] = []
    for base in bases:
        clean_base = _clean_cloud_name(base)
        if clean_base and len(clean_base) <= 63 and clean_base not in out: out.append(clean_base)
        for word in words:
            mutation = _clean_cloud_name(word)
            for candidate in (f"{clean_base}{mutation}", f"{clean_base}.{mutation}", f"{clean_base}-{mutation}", f"{mutation}{clean_base}", f"{mutation}.{clean_base}", f"{mutation}-{clean_base}"):
                candidate = _clean_cloud_name(candidate)
                if candidate and len(candidate) <= 63 and candidate not in out: out.append(candidate)
                if len(out) >= limit: return out[:limit]
    return out[:limit]


def list_formats() -> dict[str, Any]:
    return {
        "ok": True,
        "aws": AWS_FORMATS,
        "azure": AZURE_FORMATS,
        "gcp": GCP_FORMATS,
        "fuzz_words": sum(1 for _ in _FUZZ.open()) if _FUZZ.exists() else 0,
        "source": "initstring/cloud_enum",
        "engine": "cloud",
        "equivalent": "cloud_enum",
    }


async def enumerate(
    name: str,
    providers: str = "aws,azure,gcp",
    max_mutations: int = 20,
    max_checks: int = 40,
    user_agent: str = "pyodide-security/cloud-enum/1.0",
    headers: str = "",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
) -> dict[str, Any]:
    """Enumerate cloud storage endpoints for a base name."""
    if not name or len(name) < 2:
        return {"ok": False, "error": "name required", "engine": "cloud"}

    prov = {p.strip().lower() for p in providers.split(",") if p.strip()}
    formats = []
    if "aws" in prov:
        formats.extend(("aws", f) for f in AWS_FORMATS)
    if "azure" in prov:
        formats.extend(("azure", f) for f in AZURE_FORMATS)
    if "gcp" in prov:
        formats.extend(("gcp", f) for f in GCP_FORMATS)

    muts = _mutations(name, limit=max(1, int(max_mutations)))
    request_headers = _headers(headers, user_agent); use_proxy = _route(route); timeout = max(1000, min(int(timeout_ms or 8000), 120000)); retryable = {int(x.strip()) for x in str(retry_statuses).split(",") if x.strip().isdigit()}
    found = []
    tested = 0
    for mut in muts:
        for provider, fmt in formats:
            if tested >= int(max_checks):
                break
            if not policy.can_request():
                break
            url = fmt.format(name=mut)
            # policy host check
            err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
            if err:
                continue
            tested += 1
            attempts = []; resp = {}
            for attempt in range(max(0, min(int(retries or 0), 5)) + 1):
                resp = await http_request(url, headers=request_headers, timeout_ms=timeout, use_proxy=use_proxy)
                attempts.append({"attempt": attempt + 1, "status": resp.get("status"), "error": resp.get("error"), "transport": resp.get("transport"), "final_url": redact_url(resp.get("final_url"))})
                if resp.get("ok") or int(resp.get("status") or 0) not in retryable: break
            st = resp.get("status") or 0
            body = resp.get("body") or ""
            # Open / interesting signals
            interesting = False
            reason = []
            if st in (200, 204, 301, 302, 403):
                interesting = True
                reason.append(f"status={st}")
            if "ListBucketResult" in body or "<Contents>" in body:
                interesting = True
                reason.append("s3-list")
            if "BlobNotFound" not in body and st == 200 and provider == "azure":
                reason.append("azure-200")
            if interesting:
                found.append({
                    "url": url,
                    "name": mut,
                    "provider": provider,
                    "status": st,
                    "reasons": reason,
                    "length": len(body),
                    "attempts": attempts,
                    "final_url": redact_url(resp.get("final_url") or url),
                    "transport": resp.get("transport"),
                })
        if tested >= int(max_checks):
            break
    return {
        "ok": True,
        "base_name": name,
        "mutations": len(muts),
        "tested": tested,
        "found": found,
        "found_count": len(found),
        "engine": "cloud",
        "equivalent": "cloud_enum",
        "source": "initstring/cloud_enum",
        "request": {"headers": {k: ("[redacted]" if k.lower() in {"authorization", "cookie", "x-api-key"} else v) for k, v in request_headers.items()}, "timeout_ms": timeout, "retries": retries, "route": "auto" if use_proxy is None else ("proxy" if use_proxy else "direct")},
    }


# alias
scan = enumerate


async def check_bucket(url: str = "", name: str = "", providers: str = "aws,azure,gcp", max_checks: int = 12, max_tests: int = 0, user_agent: str = "pyodide-security/cloud-enum/1.0", headers: str = "", timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = "408,429,500,502,503,504", route: str = "auto") -> dict:
    """Single-bucket check with an optional total live-probe cap."""
    if name and not url:
        cap = int(max_tests or max_checks or 12)
        return await enumerate(name=name, providers=providers, max_mutations=1, max_checks=max(1, min(cap, 12)), user_agent=user_agent, headers=headers, timeout_ms=timeout_ms, retries=retries, retry_statuses=retry_statuses, route=route)
    if url:
        err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
        if err: return {"ok": False, "error": err, "engine": "cloud"}
        request_headers = _headers(headers, user_agent); use_proxy = _route(route); timeout = max(1000, min(int(timeout_ms or 8000), 120000)); retryable = {int(x.strip()) for x in str(retry_statuses).split(",") if x.strip().isdigit()}; attempts=[]; resp={}
        for i in range(max(0, min(int(retries or 0), 5)) + 1):
            resp = await http_request(url, headers=request_headers, timeout_ms=timeout, use_proxy=use_proxy)
            attempts.append({"attempt": i+1, "status": resp.get("status"), "error": resp.get("error"), "transport": resp.get("transport"), "final_url": redact_url(resp.get("final_url"))})
            if resp.get("ok") or int(resp.get("status") or 0) not in retryable: break
        body = resp.get("body") or ""; st = resp.get("status") or 0; open_ = st == 200 and ("ListBucketResult" in body or "<Contents>" in body or len(body) > 0)
        safe={k:("[redacted]" if k.lower() in {"authorization","cookie","x-api-key"} else v) for k,v in request_headers.items()}
        return {"ok": bool(resp.get("ok")), "url": redact_url(url), "status": st, "open": open_, "length": len(body), "attempts": attempts, "request": {"headers": safe, "timeout_ms": timeout, "retries": retries, "route": "auto" if use_proxy is None else ("proxy" if use_proxy else "direct")}, "final_url": redact_url(resp.get("final_url") or url), "transport": resp.get("transport"), "error": resp.get("error"), "engine": "cloud"}
    return {"ok": False, "error": "url or name required", "engine": "cloud"}


def permute_buckets(name: str, max_mutations: int = 50, keywords: str = "", mutation_words: str = "", strategy: str = "legacy") -> dict:
    """Return bounded local bucket-name mutations; this helper makes no requests."""
    base = _clean_cloud_name(name)
    if not base: return {"ok": False, "error": "name required", "engine": "cloud"}
    limit = max(1, min(int(max_mutations or 50), 1000)); extras = [x.strip() for x in str(keywords or "").replace(",", chr(10)).splitlines() if x.strip()]; bases = [base] + [_clean_cloud_name(x) for x in extras]; bases = [x for x in bases if x]
    mode = str(strategy or "legacy").strip().lower()
    if mode not in {"legacy", "upstream"}: return {"ok": False, "error": "strategy must be legacy or upstream", "engine": "cloud"}
    words = _mutation_words(mutation_words)
    muts = _mutations(base, limit=limit) if mode == "legacy" and not extras and not mutation_words else _upstream_mutations(bases, words, limit)
    return {"ok": True, "base": name, "bases": bases, "mutations": muts, "count": len(muts), "strategy": mode, "mutation_source": "custom" if mutation_words else "cloud_enum fuzz.txt", "request_count": 0, "networked": False, "engine": "cloud", "source": "initstring/cloud_enum build_names"}
