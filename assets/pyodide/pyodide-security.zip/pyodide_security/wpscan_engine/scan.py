"""
WordPress scanner — WPScan-class with SecLists plugin/theme DBs.
"""
from __future__ import annotations

import gzip
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

from .._http import http_request, redact_url
from .. import policy

_ROOT = Path(__file__).resolve().parent
_PATHS = _ROOT / "interesting_paths.txt"


def _load_gz_lines(name: str) -> list[str]:
    p = _ROOT / name
    if not p.exists():
        return []
    with gzip.open(p, "rt", encoding="utf-8") as f:
        return [ln.strip() for ln in f.read().splitlines() if ln.strip()]


def list_paths(limit: int = 0) -> dict[str, Any]:
    rows = [ln.strip() for ln in _PATHS.read_text(encoding="utf-8").splitlines() if ln.strip()]
    out = rows[: int(limit)] if limit and limit > 0 else rows
    return {"ok": True, "count": len(rows), "returned": len(out), "paths": out,
            "source": "WPScan interesting + SecLists", "engine": "wpscan"}


def list_plugins(limit: int = 0) -> dict[str, Any]:
    rows = _load_gz_lines("plugins.txt.gz")
    out = rows[: int(limit)] if limit and limit > 0 else rows
    return {"ok": True, "count": len(rows), "returned": len(out), "plugins": out,
            "source": "SecLists wp-plugins.fuzz.txt", "engine": "wpscan"}


def list_themes(limit: int = 0) -> dict[str, Any]:
    rows = _load_gz_lines("themes.txt.gz")
    out = rows[: int(limit)] if limit and limit > 0 else rows
    return {"ok": True, "count": len(rows), "returned": len(out), "themes": out,
            "source": "SecLists wp-themes.fuzz.txt", "engine": "wpscan"}


async def scan(
    url: str,
    max_paths: int = 12,
    max_plugins: int = 8,
    max_themes: int = 4,
    max_tests: int = 0,
    user_agent: str = "pyodide-security/wpscan/3.0",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    include_attempts: bool = True,
) -> dict[str, Any]:
    err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "engine": "wpscan"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    if not url.endswith("/"):
        url += "/"

    headers = {"User-Agent": user_agent}
    timeout = max(1000, min(int(timeout_ms or 8000), 120000))
    retry_count = max(0, min(int(retries or 0), 5))
    route_name = route if route in ("auto", "proxy", "direct") else "auto"
    use_proxy = True if route_name == "proxy" else False if route_name == "direct" else None
    retry_codes = {int(item.strip()) for item in str(retry_statuses or "").split(",") if item.strip().isdigit()}
    attempts: list[dict[str, Any]] = []

    async def request(target: str) -> dict[str, Any]:
        response: dict[str, Any] = {}
        for _ in range(retry_count + 1):
            response = await http_request(target, headers=headers, timeout_ms=timeout, use_proxy=use_proxy)
            attempts.append({"attempt": len(attempts) + 1, "url": redact_url(target), "status": response.get("status"), "ok": response.get("ok"), "transport": response.get("transport"), "elapsed_ms": response.get("elapsed_ms"), "error": str(response.get("error") or "")[:240]})
            if response.get("ok") or int(response.get("status") or 0) not in retry_codes:
                break
        return response

    findings = []
    tested = 0
    is_wp = False

    base = await request(url)
    tested += 1
    body = base.get("body") or ""
    if any(x in body.lower() for x in ("wp-content", "wp-includes", "wordpress")):
        is_wp = True
        findings.append({"type": "fingerprint", "evidence": "wp markers in body", "severity": "info"})

    paths = [ln.strip() for ln in _PATHS.read_text(encoding="utf-8").splitlines() if ln.strip()]
    if max_paths and max_paths > 0:
        paths = paths[: int(max_paths)]

    for path in paths:
        if int(max_tests or 0) > 0 and tested >= int(max_tests):
            break
        if not policy.can_request():
            break
        tested += 1
        target = urljoin(url, path.lstrip("/"))
        resp = await request(target)
        st = resp.get("status") or 0
        if st in (200, 301, 302, 401, 403):
            entry = {"path": path, "url": redact_url(target), "status": st, "length": len(resp.get("body") or "")}
            b = (resp.get("body") or "").lower()
            if "xmlrpc" in path and st == 200:
                entry["tag"] = "xmlrpc"; is_wp = True
            if "wp-json" in path and st == 200:
                entry["tag"] = "rest"; is_wp = True
            if path.endswith("readme.txt") and "stable tag" in b:
                entry["tag"] = "plugin-readme"; is_wp = True
            findings.append(entry)

    # plugin enumeration via readme.txt
    plugins = _load_gz_lines("plugins.txt.gz")[: max(0, int(max_plugins))]
    plugins_found = []
    for slug in plugins:
        if int(max_tests or 0) > 0 and tested >= int(max_tests):
            break
        if not policy.can_request():
            break
        tested += 1
        readme = urljoin(url, f"wp-content/plugins/{slug}/readme.txt")
        resp = await request(readme)
        if resp.get("status") == 200 and "stable tag" in (resp.get("body") or "").lower():
            is_wp = True
            # version
            ver = None
            for line in (resp.get("body") or "").splitlines():
                if line.lower().startswith("stable tag:"):
                    ver = line.split(":", 1)[1].strip()
                    break
            plugins_found.append({"slug": slug, "version": ver, "url": redact_url(readme)})
            findings.append({"type": "plugin", "slug": slug, "version": ver, "status": 200})

    themes = _load_gz_lines("themes.txt.gz")[: max(0, int(max_themes))]
    themes_found = []
    for slug in themes:
        if int(max_tests or 0) > 0 and tested >= int(max_tests):
            break
        if not policy.can_request():
            break
        tested += 1
        css = urljoin(url, f"wp-content/themes/{slug}/style.css")
        resp = await request(css)
        if resp.get("status") == 200 and "theme name" in (resp.get("body") or "").lower():
            is_wp = True
            name = None
            for line in (resp.get("body") or "").splitlines():
                if line.lower().startswith("theme name:"):
                    name = line.split(":", 1)[1].strip()
                    break
            themes_found.append({"slug": slug, "name": name, "url": redact_url(css)})
            findings.append({"type": "theme", "slug": slug, "name": name, "status": 200})

    return {
        "ok": True,
        "url": redact_url(url),
        "is_wordpress": is_wp,
        "tested": tested,
        "findings": findings,
        "finding_count": len(findings),
        "plugins_found": plugins_found,
        "themes_found": themes_found,
        "plugin_db": len(_load_gz_lines("plugins.txt.gz")),
        "theme_db": len(_load_gz_lines("themes.txt.gz")),
        "engine": "wpscan",
        "equivalent": "WPScan",
        "source": "WPScan paths + SecLists plugins/themes",
        "request": {"timeout_ms": timeout, "retries": retry_count, "retry_statuses": sorted(retry_codes), "route": route_name, "headers": {"User-Agent": user_agent}},
        "attempts": attempts if include_attempts else [],
        "attempt_count": len(attempts),
    }
