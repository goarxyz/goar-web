"""Mozilla Observatory / securityheaders-class HTTP response header analysis."""

from __future__ import annotations

import re
from typing import Any

# Expected security headers with scoring weights and guidance
_CHECKS: list[dict[str, Any]] = [
    {
        "name": "strict-transport-security",
        "weight": 20,
        "required": True,
        "test": lambda v: "max-age=" in v.lower() and _max_age(v) >= 31536000,
        "advice": "Set HSTS with max-age>=31536000; include includeSubDomains (and preload if ready).",
    },
    {
        "name": "content-security-policy",
        "weight": 25,
        "required": True,
        "test": lambda v: "default-src" in v.lower() or "script-src" in v.lower(),
        "advice": "Deploy a CSP with default-src / script-src; avoid 'unsafe-inline' and '*' where possible.",
    },
    {
        "name": "x-content-type-options",
        "weight": 10,
        "required": True,
        "test": lambda v: v.lower().strip() == "nosniff",
        "advice": "Set X-Content-Type-Options: nosniff.",
    },
    {
        "name": "x-frame-options",
        "weight": 10,
        "required": False,
        "test": lambda v: v.upper() in ("DENY", "SAMEORIGIN"),
        "advice": "Set X-Frame-Options DENY/SAMEORIGIN or use CSP frame-ancestors.",
    },
    {
        "name": "referrer-policy",
        "weight": 10,
        "required": True,
        "test": lambda v: v.lower()
        in {
            "no-referrer",
            "same-origin",
            "strict-origin",
            "strict-origin-when-cross-origin",
            "no-referrer-when-downgrade",
        },
        "advice": "Prefer strict-origin-when-cross-origin or no-referrer.",
    },
    {
        "name": "permissions-policy",
        "weight": 10,
        "required": False,
        "test": lambda v: len(v) > 0,
        "advice": "Restrict powerful features (camera, mic, geolocation) via Permissions-Policy.",
    },
    {
        "name": "cross-origin-opener-policy",
        "weight": 5,
        "required": False,
        "test": lambda v: "same-origin" in v.lower(),
        "advice": "Consider Cross-Origin-Opener-Policy: same-origin.",
    },
    {
        "name": "cross-origin-resource-policy",
        "weight": 5,
        "required": False,
        "test": lambda v: v.lower() in ("same-origin", "same-site", "cross-origin"),
        "advice": "Set Cross-Origin-Resource-Policy appropriately.",
    },
    {
        "name": "cross-origin-embedder-policy",
        "weight": 5,
        "required": False,
        "test": lambda v: "require-corp" in v.lower() or "credentialless" in v.lower(),
        "advice": "COEP needed for cross-origin isolation (SharedArrayBuffer).",
    },
]


def _max_age(v: str) -> int:
    m = re.search(r"max-age\s*=\s*(\d+)", v, re.I)
    return int(m.group(1)) if m else 0


def _parse_headers(raw: str) -> dict[str, str]:
    headers: dict[str, str] = {}
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.upper().startswith("HTTP/"):
            continue
        if ":" not in line:
            continue
        k, _, v = line.partition(":")
        key = k.strip().lower()
        val = v.strip()
        if key in headers:
            headers[key] = headers[key] + ", " + val
        else:
            headers[key] = val
    return headers


def analyze(headers: str) -> dict[str, Any]:
    if not headers or not headers.strip():
        raise ValueError("paste raw HTTP response headers")
    parsed = _parse_headers(headers)
    results: list[dict[str, Any]] = []
    score = 0
    max_score = sum(c["weight"] for c in _CHECKS)

    for check in _CHECKS:
        name = check["name"]
        value = parsed.get(name)
        present = value is not None
        passed = bool(present and check["test"](value or ""))
        if passed:
            score += check["weight"]
        status = "pass" if passed else ("missing" if not present else "fail")
        severity = "info"
        if not passed:
            severity = "high" if check["required"] else "medium"
        entry = {
            "header": name,
            "status": status,
            "severity": severity if not passed else "ok",
            "value": value,
            "weight": check["weight"],
            "advice": None if passed else check["advice"],
        }
        # CSP deep notes
        if name == "content-security-policy" and value:
            notes = []
            low = value.lower()
            if "unsafe-inline" in low:
                notes.append("Contains 'unsafe-inline' (weakens XSS protection).")
            if "unsafe-eval" in low:
                notes.append("Contains 'unsafe-eval'.")
            if "*" in low:
                notes.append("Contains wildcard source.")
            if notes:
                entry["notes"] = notes
                if passed:
                    score -= min(10, check["weight"] // 2)
                    entry["status"] = "warn"
                    entry["severity"] = "medium"
        if name == "strict-transport-security" and value:
            if "includesubdomains" not in value.lower():
                entry.setdefault("notes", []).append("Missing includeSubDomains.")
        results.append(entry)

    # Dangerous headers
    extras = []
    if "server" in parsed:
        extras.append(
            {
                "header": "server",
                "status": "info",
                "severity": "low",
                "value": parsed["server"],
                "advice": "Avoid leaking detailed server version banners.",
            }
        )
    if "x-powered-by" in parsed:
        extras.append(
            {
                "header": "x-powered-by",
                "status": "fail",
                "severity": "medium",
                "value": parsed["x-powered-by"],
                "advice": "Remove X-Powered-By.",
            }
        )
    if parsed.get("access-control-allow-origin") == "*":
        extras.append(
            {
                "header": "access-control-allow-origin",
                "status": "warn",
                "severity": "medium",
                "value": "*",
                "advice": "ACAOrigin * with credentials is invalid; bare * may be overly open.",
            }
        )

    score = max(0, min(100, int(round(100 * score / max_score))))
    grade = (
        "A"
        if score >= 90
        else "B"
        if score >= 75
        else "C"
        if score >= 60
        else "D"
        if score >= 40
        else "F"
    )
    return {
        "score": score,
        "grade": grade,
        "checks": results,
        "extras": extras,
        "parsed_count": len(parsed),
        "headers_seen": sorted(parsed.keys()),
    }
