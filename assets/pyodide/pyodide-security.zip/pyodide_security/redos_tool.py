"""Static ReDoS risk heuristics for regular expressions."""

from __future__ import annotations

import re
from typing import Any


def analyze(pattern: str) -> dict[str, Any]:
    if pattern is None or pattern == "":
        raise ValueError("pattern is required")

    findings: list[dict[str, str]] = []
    score = 0

    # Nested quantifiers: (a+)+ (a*)* (a+){2,} etc.
    if re.search(r"\([^)]*[+*{][^)]*\)[+*{]", pattern):
        findings.append(
            {
                "severity": "high",
                "id": "nested-quantifiers",
                "message": "Nested quantifiers detected — classic catastrophic backtracking shape.",
            }
        )
        score += 40

    # Overlapping alternation with quantifier: (a|a)+ 
    if re.search(r"\([^)]*\|[^)]*\)[+*]", pattern):
        findings.append(
            {
                "severity": "high",
                "id": "quantified-alternation",
                "message": "Quantified group containing alternation — may cause exponential backtracking.",
            }
        )
        score += 30

    # Adjacent overlapping quantifiers: \d+\w+
    if re.search(r"(\\d|\\w|\\s|\.)\+(\\d|\\w|\\s|\.)\+", pattern):
        findings.append(
            {
                "severity": "medium",
                "id": "adjacent-overlapping",
                "message": "Adjacent overlapping quantifiers (e.g. \\d+\\w+).",
            }
        )
        score += 15

    # Unbounded repetition of wildcard
    if re.search(r"(\.\*){2,}|\.\*\.\*", pattern):
        findings.append(
            {
                "severity": "medium",
                "id": "multi-dotstar",
                "message": "Multiple .* sequences can be expensive on crafted input.",
            }
        )
        score += 15

    # Very long pattern
    if len(pattern) > 500:
        findings.append(
            {
                "severity": "low",
                "id": "long-pattern",
                "message": "Pattern is very long; review for accidental complexity.",
            }
        )
        score += 5

    compile_ok = True
    compile_error = None
    flags_note = None
    try:
        re.compile(pattern)
    except re.error as e:
        compile_ok = False
        compile_error = str(e)
        findings.append(
            {
                "severity": "critical",
                "id": "invalid",
                "message": f"Pattern does not compile: {e}",
            }
        )
        score = 100

    score = min(100, score)
    risk = (
        "critical"
        if score >= 80
        else "high"
        if score >= 50
        else "medium"
        if score >= 25
        else "low"
    )

    return {
        "pattern": pattern,
        "compile_ok": compile_ok,
        "compile_error": compile_error,
        "risk": risk,
        "score": score,
        "findings": findings,
        "advice": _advice(findings),
    }


def _advice(findings: list[dict[str, str]]) -> list[str]:
    if not findings:
        return ["No static ReDoS patterns found. Still prefer atomic groups / possessive quantifiers where available, and cap input length."]
    tips = [
        "Anchor patterns (^…$) when matching whole strings.",
        "Avoid nested quantifiers; rewrite with single-pass character classes.",
        "Cap input length before matching untrusted strings.",
        "Prefer re methods with explicit timeouts in services (or non-backtracking engines).",
    ]
    return tips
