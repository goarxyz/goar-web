
"""Payloads from swisskyrepo/PayloadsAllTheThings (ssti)."""
from .. import pat_data

def list_payloads():
    rows = pat_data.get("ssti")
    return {"payloads": rows, "count": len(rows), "source": "PayloadsAllTheThings/ssti"}
