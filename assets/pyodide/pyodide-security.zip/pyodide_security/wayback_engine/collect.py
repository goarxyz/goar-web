"""Wayback Machine CDX API collector."""
from __future__ import annotations

import json
import re
from typing import Any
from urllib.parse import urlencode

from .._http import http_request, redact_url
from .. import policy
from ..subenum_engine.sources import clean_domain


def _headers(raw: str, user_agent: str) -> dict[str, str]:
    out = {"User-Agent": user_agent, "Accept": "application/json"}
    text = str(raw or "").strip()
    if text.startswith("{"):
        parsed = json.loads(text)
        if not isinstance(parsed, dict):
            raise ValueError("headers JSON must be an object")
        out.update({str(k): str(v) for k, v in parsed.items()})
    else:
        for line in text.splitlines():
            if ":" in line:
                key, _, value = line.partition(":")
                out[key.strip()] = value.strip()
    return out


def _route(value: Any) -> bool | None:
    if value in (None, "", "auto", "AUTO"): return None
    if value in (True, "proxy", "PROXY", "true", "True"): return True
    if value in (False, "direct", "DIRECT", "false", "False"): return False
    raise ValueError("route must be auto, proxy, or direct")


def _safe_url(value: Any) -> str:
    """Mask ordinary and percent-encoded sensitive query tails in user-visible evidence."""
    safe = redact_url(value)
    return re.sub(r"(?i)(%3f|%26)(apikey|api_key|key|token|access_token|authorization|secret|signature|sig)(%3d|=)[^&#]*", lambda match: match.group(1) + match.group(2) + match.group(3) + "[redacted]", safe)


def _filters(raw: str, statuses: str, mimetypes: str) -> list[str]:
    values = [x.strip() for x in str(raw or "").splitlines() if x.strip()]
    if statuses.strip(): values.append("statuscode:" + "|".join(x.strip() for x in statuses.split(",") if x.strip()))
    if mimetypes.strip(): values.append("mimetype:" + "|".join(x.strip() for x in mimetypes.split(",") if x.strip()))
    return values[:20]


async def collect(
    domain: str,
    limit: int = 100,
    match_type: str = "domain",
    timeout_ms: int = 20000,
    user_agent: str = "pyodide-security/wayback/2.0",
    collapse: bool | str = True,
    include_subdomains: bool = True,
    date_from: str = "",
    date_to: str = "",
    filters: str = "",
    status_codes: str = "",
    mimetypes: str = "",
    offset: int = 0,
    show_resume_key: bool = False,
    resume_key: str = "",
    service_base: str = "https://web.archive.org/cdx/search/cdx",
    headers: str = "",
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
) -> dict[str, Any]:
    """Collect bounded CDX records and URL history through the shared Goar transport."""
    domain = clean_domain(domain)
    if not domain: return {"ok": False, "error": "domain required", "engine": "wayback"}
    scope = str(match_type or "domain").strip().lower()
    if scope not in {"exact", "prefix", "host", "domain"}: return {"ok": False, "error": "match_type must be exact, prefix, host, or domain", "engine": "wayback"}
    if not include_subdomains and scope == "domain": scope = "host"
    base = str(service_base or "https://web.archive.org/cdx/search/cdx").rstrip("?")
    target = domain + "/" if scope in {"domain", "host", "prefix"} else domain
    collapse_value = "urlkey" if collapse is True else "" if collapse in (False, "", "none", "false", "False") else str(collapse)
    cap = max(1, min(int(limit or 100), 10000)); skip = max(0, min(int(offset or 0), 100000))
    params: list[tuple[str, str]] = [("url", target), ("output", "json"), ("fl", "original,statuscode,mimetype,timestamp,digest,length"), ("matchType", scope), ("limit", str(cap))]
    if collapse_value: params.append(("collapse", collapse_value))
    if date_from.strip(): params.append(("from", date_from.strip()))
    if date_to.strip(): params.append(("to", date_to.strip()))
    if skip: params.append(("offset", str(skip)))
    if show_resume_key: params.append(("showResumeKey", "true"))
    if resume_key.strip(): params.append(("resumeKey", resume_key.strip()))
    params.extend(("filter", value) for value in _filters(filters, status_codes, mimetypes))
    url = base + ("&" if "?" in base else "?") + urlencode(params, doseq=True)
    err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if err: return {"ok": False, "error": err, "engine": "wayback"}
    request_headers = _headers(headers, user_agent); use_proxy = _route(route); timeout = max(1000, min(int(timeout_ms or 20000), 120000)); retryable = {int(x.strip()) for x in str(retry_statuses).split(",") if x.strip().isdigit()}; attempts: list[dict[str, Any]] = []; resp: dict[str, Any] = {}
    for attempt in range(max(0, min(int(retries or 0), 5)) + 1):
        resp = await http_request(url, headers=request_headers, timeout_ms=timeout, use_proxy=use_proxy)
        attempts.append({"attempt": attempt + 1, "status": resp.get("status"), "error": resp.get("error"), "transport": resp.get("transport"), "final_url": _safe_url(resp.get("final_url"))})
        if resp.get("ok") or int(resp.get("status") or 0) not in retryable: break
    body = str(resp.get("body") or "")
    rows: list[dict[str, Any]] = []; urls: list[str] = []; continuation = ""; parse_error = None
    try:
        data = json.loads(body or "[]")
        if isinstance(data, list) and data:
            field_names = data[0] if isinstance(data[0], list) else []
            for item in data[1:]:
                if isinstance(item, list) and not item:
                    continue
                if isinstance(item, list) and len(item) == 1 and show_resume_key:
                    continuation = str(item[0]); continue
                record = dict(zip(field_names, item)) if isinstance(item, list) else item if isinstance(item, dict) else {}
                archived_url = record.get("original", "") if isinstance(record, dict) else ""
                if archived_url:
                    record["snapshot_url"] = f"https://web.archive.org/web/{record.get('timestamp', '')}if_/{archived_url}" if record.get("timestamp") else ""
                    urls.append(archived_url); rows.append(record)
    except Exception as exc:
        parse_error = str(exc)
        for line in body.splitlines():
            if line.startswith("http"): urls.append(line.strip().split()[0])
    seen: set[str] = set(); unique = []
    for archived_url in urls:
        if archived_url not in seen: seen.add(archived_url); unique.append(archived_url)
    safe_headers = {key: ("[redacted]" if key.lower() in {"authorization", "cookie", "x-api-key"} else value) for key, value in request_headers.items()}
    return {"ok": bool(resp.get("ok")) and parse_error is None, "domain": domain, "urls": unique, "count": len(unique), "records": rows, "rows_sample": rows[:20], "records_count": len(rows), "resume_key": continuation, "status": resp.get("status"), "body": body, "body_length": len(body), "error": resp.get("error") or parse_error, "attempts": attempts, "attempt_count": len(attempts), "request": {"url": _safe_url(url), "headers": safe_headers, "timeout_ms": timeout, "retries": retries, "route": "auto" if use_proxy is None else ("proxy" if use_proxy else "direct"), "scope": scope, "collapse": collapse_value, "filters": _filters(filters, status_codes, mimetypes)}, "final_url": _safe_url(resp.get("final_url") or url), "transport": resp.get("transport"), "engine": "wayback", "equivalent": "waybackurls/CDX"}
