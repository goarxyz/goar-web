"""Portable Gitleaks-family secret scanner with full structured result handling.

The module preserves the existing inline-text workflow and adds browser-equivalent
configuration, source retrieval, decode, allowlist, baseline, and reporting paths.
All remote collection is routed through the shared Goar HTTP adapter.
"""
from __future__ import annotations

import base64
import hashlib
import json
import math
import re
from typing import Any
from urllib.parse import unquote

# Built-in portable rule corpus.  Custom Gitleaks-style rules can be supplied at
# run time through rules_json without replacing the default corpus.
_RULES: list[tuple[str, str, str, re.Pattern[str], float | None, int | None]] = [
    ("aws-access-key", "AWS Access Key ID", "critical", re.compile(r"\b(AKIA|ASIA)[0-9A-Z]{16}\b"), None, None),
    ("aws-secret-key", "AWS Secret Access Key (context)", "critical", re.compile(r"(?i)(aws_secret_access_key|aws_secret_key|secret_access_key)\s*[:=]\s*['\"]?([A-Za-z0-9/+=]{40})['\"]?"), None, 2),
    ("aws-mws", "AWS MWS Auth Token", "high", re.compile(r"amzn\.mws\.[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"), None, None),
    ("github-pat", "GitHub personal access token", "critical", re.compile(r"\bghp_[A-Za-z0-9]{36,}\b"), None, None),
    ("github-oauth", "GitHub OAuth token", "critical", re.compile(r"\bgho_[A-Za-z0-9]{36,}\b"), None, None),
    ("github-fine-grained", "GitHub fine-grained PAT", "critical", re.compile(r"\bgithub_pat_[A-Za-z0-9_]{20,}\b"), None, None),
    ("github-app", "GitHub App token", "critical", re.compile(r"\b(ghu|ghs)_[A-Za-z0-9]{36,}\b"), None, None),
    ("gitlab-pat", "GitLab PAT", "critical", re.compile(r"\bglpat-[A-Za-z0-9\-_]{20,}\b"), None, None),
    ("slack-token", "Slack token", "critical", re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}\b"), None, None),
    ("slack-webhook", "Slack webhook", "high", re.compile(r"https://hooks\.slack\.com/services/T[A-Z0-9]+/B[A-Z0-9]+/[A-Za-z0-9]+"), None, None),
    ("discord-webhook", "Discord webhook", "high", re.compile(r"https://discord(?:app)?\.com/api/webhooks/\d+/[A-Za-z0-9_-]+"), None, None),
    ("discord-token", "Discord bot token", "critical", re.compile(r"\b[MN][A-Za-z0-9]{23,}\.[\w-]{6}\.[\w-]{27,}\b"), None, None),
    ("google-api", "Google API key", "high", re.compile(r"\bAIza[0-9A-Za-z\-_]{35}\b"), None, None),
    ("google-oauth", "Google OAuth", "high", re.compile(r"\bya29\.[0-9A-Za-z\-_]{20,}\b"), None, None),
    ("stripe-key", "Stripe secret key", "critical", re.compile(r"\b(sk|rk)_(live|test)_[0-9a-zA-Z]{20,}\b"), None, None),
    ("twilio", "Twilio API key", "high", re.compile(r"\bSK[0-9a-fA-F]{32}\b"), None, None),
    ("sendgrid", "SendGrid API key", "critical", re.compile(r"\bSG\.[A-Za-z0-9_\-]{22}\.[A-Za-z0-9_\-]{43}\b"), None, None),
    ("private-key", "PEM private key header", "critical", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"), None, None),
    ("pgp-private", "PGP private key block", "critical", re.compile(r"-----BEGIN PGP PRIVATE KEY BLOCK-----"), None, None),
    ("jwt", "JWT token", "medium", re.compile(r"\beyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b"), None, None),
    ("npm-token", "NPM access token", "critical", re.compile(r"\bnpm_[A-Za-z0-9]{36,}\b"), None, None),
    ("pypi-token", "PyPI token", "critical", re.compile(r"\bpypi-[A-Za-z0-9_\-]{20,}\b"), None, None),
    ("digitalocean", "DigitalOcean token", "critical", re.compile(r"\bdop_v1_[a-f0-9]{64}\b"), None, None),
    ("openai-key", "OpenAI API key", "critical", re.compile(r"\bsk-[A-Za-z0-9]{20,}\b"), None, None),
    ("anthropic-key", "Anthropic API key", "critical", re.compile(r"\bsk-ant-[A-Za-z0-9\-_]{20,}\b"), None, None),
    ("huggingface", "HuggingFace token", "high", re.compile(r"\bhf_[A-Za-z0-9]{20,}\b"), None, None),
    ("generic-api-key", "Generic API key assignment", "medium", re.compile(r"(?i)(api[_\-]?key|apikey|api_secret)\s*[:=]\s*['\"]([A-Za-z0-9_\-]{16,})['\"]"), 3.5, 2),
    ("generic-secret", "Generic secret assignment", "medium", re.compile(r"(?i)(secret|passwd|password|token)\s*[:=]\s*['\"]([^'\"]{8,})['\"]"), 3.5, 2),
    ("basic-auth-url", "Basic auth embedded in URL", "high", re.compile(r"://[A-Za-z0-9_\-]+:[^@\s]{3,}@"), None, None),
]


def _shannon(value: str) -> float:
    if not value:
        return 0.0
    counts: dict[str, int] = {}
    for char in value:
        counts[char] = counts.get(char, 0) + 1
    length = len(value)
    return -sum((count / length) * math.log2(count / length) for count in counts.values())


def _mask(value: str) -> str:
    if len(value) <= 8:
        return "*" * len(value)
    return f"{value[:4]}…{value[-4:]}"


def _fingerprint(rule_id: str, value: str, source: str, line: int) -> str:
    digest = hashlib.sha256(f"{rule_id}\0{value}\0{source}\0{line}".encode("utf-8", "replace")).hexdigest()
    return f"{rule_id}:{digest[:24]}"


def _parse_headers(headers_json: str) -> dict[str, str]:
    if not headers_json or not headers_json.strip():
        return {}
    try:
        value = json.loads(headers_json)
    except Exception as exc:
        raise ValueError(f"headers_json must be a JSON object: {exc}") from exc
    if not isinstance(value, dict):
        raise ValueError("headers_json must be a JSON object")
    return {str(key): str(item) for key, item in value.items()}


def _parse_custom_rules(rules_json: str) -> list[tuple[str, str, str, re.Pattern[str], float | None, int | None]]:
    if not rules_json or not rules_json.strip():
        return []
    try:
        raw = json.loads(rules_json)
    except Exception as exc:
        raise ValueError(f"rules_json must be valid JSON: {exc}") from exc
    values = raw.get("rules", []) if isinstance(raw, dict) else raw
    if not isinstance(values, list):
        raise ValueError("rules_json must be an array or an object with a rules array")
    parsed = []
    for index, item in enumerate(values, 1):
        if not isinstance(item, dict):
            raise ValueError(f"rule {index} must be an object")
        rule_id = str(item.get("id") or f"custom-{index}").strip()
        expression = str(item.get("regex") or "")
        if not expression:
            raise ValueError(f"rule {rule_id} requires regex")
        try:
            compiled = re.compile(expression, re.I if item.get("ignore_case") else 0)
        except re.error as exc:
            raise ValueError(f"rule {rule_id} regex error: {exc}") from exc
        entropy = item.get("entropy")
        group = item.get("secret_group")
        parsed.append((
            rule_id,
            str(item.get("description") or rule_id),
            str(item.get("severity") or "medium").lower(),
            compiled,
            float(entropy) if entropy not in (None, "") else None,
            int(group) if group not in (None, "") else None,
        ))
    return parsed


def _parse_allowlist(allowlist: str) -> list[re.Pattern[str]]:
    patterns = []
    for value in (allowlist or "").splitlines():
        value = value.strip()
        if not value or value.startswith("#"):
            continue
        try:
            patterns.append(re.compile(value))
        except re.error:
            patterns.append(re.compile(re.escape(value)))
    return patterns


def _baseline_fingerprints(baseline_json: str) -> set[str]:
    if not baseline_json or not baseline_json.strip():
        return set()
    try:
        data = json.loads(baseline_json)
    except Exception as exc:
        raise ValueError(f"baseline_json must be valid JSON: {exc}") from exc
    findings = data.get("findings", data) if isinstance(data, dict) else data
    if not isinstance(findings, list):
        raise ValueError("baseline_json must contain a findings array or be an array")
    return {str(item.get("fingerprint")) for item in findings if isinstance(item, dict) and item.get("fingerprint")}


def _decoded_variants(text: str, depth: int) -> list[tuple[str, str]]:
    """Return source-tagged text variants for portable percent/base64/hex decoding."""
    variants = [("raw", text)]
    seen = {text}
    frontier = [("raw", text)]
    for step in range(1, max(0, min(int(depth), 4)) + 1):
        next_frontier: list[tuple[str, str]] = []
        for label, value in frontier:
            candidates: list[tuple[str, str]] = []
            if "%" in value:
                decoded = unquote(value)
                if decoded != value:
                    candidates.append((f"{label}:percent:{step}", decoded))
            for token in re.findall(r"\b[A-Za-z0-9+/]{24,}={0,2}\b", value):
                try:
                    decoded = base64.b64decode(token + "=" * (-len(token) % 4), validate=True).decode("utf-8")
                    candidates.append((f"{label}:base64:{step}", decoded))
                except Exception:
                    pass
            for token in re.findall(r"\b(?:[0-9A-Fa-f]{2}){16,}\b", value):
                try:
                    decoded = bytes.fromhex(token).decode("utf-8")
                    candidates.append((f"{label}:hex:{step}", decoded))
                except Exception:
                    pass
            for candidate_label, candidate in candidates:
                if candidate and candidate not in seen and len(candidate) <= 2_000_000:
                    seen.add(candidate)
                    next_frontier.append((candidate_label, candidate))
                    variants.append((candidate_label, candidate))
        frontier = next_frontier
        if not frontier:
            break
    return variants


def _sarif(findings: list[dict[str, Any]], source: str) -> dict[str, Any]:
    rules: dict[str, dict[str, Any]] = {}
    results = []
    for finding in findings:
        rules.setdefault(finding["rule_id"], {
            "id": finding["rule_id"],
            "name": finding["rule_id"],
            "shortDescription": {"text": finding["description"]},
            "properties": {"severity": finding["severity"]},
        })
        results.append({
            "ruleId": finding["rule_id"],
            "level": "error" if finding["severity"] in ("critical", "high") else "warning",
            "message": {"text": finding["description"]},
            "locations": [{"physicalLocation": {"artifactLocation": {"uri": source}, "region": {"startLine": finding["line"], "startColumn": finding["column"]}}}],
            "partialFingerprints": {"goarSecretFingerprint": finding["fingerprint"]},
        })
    return {"version": "2.1.0", "$schema": "https://json.schemastore.org/sarif-2.1.0.json", "runs": [{"tool": {"driver": {"name": "Goar Pysec Gitleaks-compatible scanner", "rules": list(rules.values())}}, "results": results}]}


async def scan(
    text: str = "",
    min_entropy: float = 3.5,
    source_url: str = "",
    headers_json: str = "",
    timeout_ms: int = 8000,
    max_source_bytes: int = 1_000_000,
    include_default_rules: bool = True,
    rules_json: str = "",
    allowlist: str = "",
    baseline_json: str = "",
    decode_depth: int = 0,
    redact: bool = True,
    report_format: str = "json",
) -> dict[str, Any]:
    """Scan inline or Goar-fetched content using configurable portable rules.

    `source_url` is fetched through `_http.http_request`, therefore it uses the
    same Goar client-fetch, authenticated proxy, Wisp/libcurl, and Epoxy fallback
    architecture as every other network-capable Pysec module.
    """
    source = "inline"
    fetched: dict[str, Any] | None = None
    if source_url and source_url.strip():
        from ._http import http_request
        source = source_url.strip()
        fetched = await http_request(source, method="GET", headers=_parse_headers(headers_json), timeout_ms=max(1000, min(int(timeout_ms), 120_000)))
        if not fetched.get("ok"):
            return {"ok": False, "error": fetched.get("error") or f"source request returned HTTP {fetched.get('status')}", "source": source, "transport": fetched.get("transport"), "request": {key: fetched.get(key) for key in ("status", "elapsed_ms", "via_proxy", "via_goar")}}
        text = str(fetched.get("body") or "")
    if text is None or not str(text):
        raise ValueError("text or source_url is required")
    text = str(text)
    byte_limit = max(1_024, min(int(max_source_bytes), 5_000_000))
    encoded = text.encode("utf-8", "replace")
    truncated = len(encoded) > byte_limit
    if truncated:
        text = encoded[:byte_limit].decode("utf-8", "replace")

    rules = ([] if not include_default_rules else list(_RULES)) + _parse_custom_rules(rules_json)
    patterns = _parse_allowlist(allowlist)
    baseline = _baseline_fingerprints(baseline_json)
    findings: list[dict[str, Any]] = []
    suppressed = {"allowlist": 0, "baseline": 0}

    for variant_label, variant in _decoded_variants(text, decode_depth):
        for line_no, line in enumerate(variant.splitlines() or [variant], 1):
            for rule_id, description, severity, expression, entropy_gate, secret_group in rules:
                for match in expression.finditer(line):
                    try:
                        secret = match.group(secret_group) if secret_group else (match.group(match.lastindex) if match.lastindex else match.group(0))
                    except (IndexError, TypeError):
                        secret = match.group(0)
                    secret = str(secret or "")
                    entropy = round(_shannon(secret), 3)
                    if entropy_gate is not None and entropy < entropy_gate:
                        continue
                    if any(pattern.search(secret) or pattern.search(line) for pattern in patterns):
                        suppressed["allowlist"] += 1
                        continue
                    fingerprint = _fingerprint(rule_id, secret, source, line_no)
                    if fingerprint in baseline:
                        suppressed["baseline"] += 1
                        continue
                    finding = {
                        "rule_id": rule_id,
                        "description": description,
                        "severity": severity if severity in ("critical", "high", "medium", "low") else "medium",
                        "line": line_no,
                        "column": match.start() + 1,
                        "match_masked": _mask(secret),
                        "match_length": len(secret),
                        "entropy": entropy,
                        "context": line.strip()[:240],
                        "source_variant": variant_label,
                        "fingerprint": fingerprint,
                    }
                    if not redact:
                        finding["match"] = secret
                    findings.append(finding)
            # Generic entropy detector is deliberately independent of custom rules.
            for match in re.finditer(r"\b[A-Za-z0-9+/=_\-]{32,}\b", line):
                secret = match.group(0)
                entropy = _shannon(secret)
                if entropy < max(float(min_entropy), 4.5):
                    continue
                fingerprint = _fingerprint("high-entropy", secret, source, line_no)
                if fingerprint in baseline or any(pattern.search(secret) for pattern in patterns):
                    continue
                finding = {"rule_id": "high-entropy", "description": "High-entropy string (possible secret)", "severity": "low", "line": line_no, "column": match.start() + 1, "match_masked": _mask(secret), "match_length": len(secret), "entropy": round(entropy, 3), "context": line.strip()[:240], "source_variant": variant_label, "fingerprint": fingerprint}
                if not redact:
                    finding["match"] = secret
                findings.append(finding)

    # De-duplicate decoded and raw matches by fingerprint, preserving first source variant.
    unique: dict[str, dict[str, Any]] = {finding["fingerprint"]: finding for finding in findings}
    findings = list(unique.values())
    rank = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    findings.sort(key=lambda item: (rank.get(item["severity"], 9), item["line"], item["column"]))
    summary = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    for finding in findings:
        summary[finding["severity"]] = summary.get(finding["severity"], 0) + 1
    result: dict[str, Any] = {
        "ok": True,
        "engine": "goar-pysec-gitleaks",
        "source": source,
        "source_bytes": len(text.encode("utf-8", "replace")),
        "source_truncated": truncated,
        "rules_active": len(rules),
        "decode_depth": max(0, min(int(decode_depth), 4)),
        "findings": findings,
        "count": len(findings),
        "summary": summary,
        "lines_scanned": len(text.splitlines() or [text]),
        "suppressed": suppressed,
        "redacted": bool(redact),
    }
    if fetched:
        result["request"] = {key: fetched.get(key) for key in ("status", "elapsed_ms", "via_proxy", "via_goar", "transport", "final_url")}
    report_format = str(report_format or "json").lower()
    if report_format == "sarif":
        result["sarif"] = _sarif(findings, source)
    elif report_format == "csv":
        fields = ["rule_id", "description", "severity", "line", "column", "match_masked", "match_length", "entropy", "fingerprint"]
        csv_rows = [",".join(fields)]
        for finding in findings:
            csv_rows.append(",".join(json.dumps(finding.get(field, ""), ensure_ascii=False) for field in fields))
        result["csv"] = "\n".join(csv_rows)
    return result


__all__ = ["scan"]
