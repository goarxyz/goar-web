"""
Unified network bootstrap for all pyodide_security engines.

Transport priority:
  1. libcurl.js + Wisp (wss://cors.manus.space/wisp/) [+ Epoxy if present]
  2. Manus HTTP CORS proxy (https://cors.manus.space/api/proxy/:url)
  3. Direct pyfetch (same-origin / CORS-open only)

Call `await network.ensure()` once at session start so every http_request
automatically gets a reliable path.
"""

from __future__ import annotations

import json
import re
from typing import Any

from . import libcurl_bridge
from . import proxy_tool
from . import _http

_WISP = "wss://cors.manus.space/wisp/"
_CORS = "https://cors.manus.space/api/proxy"

_last_ensure: dict[str, Any] | None = None


def status() -> dict[str, Any]:
    return {
        "libcurl": libcurl_bridge.status(),
        "proxy": _http.proxy_status() if hasattr(_http, "proxy_status") else proxy_tool.status(),
        "wisp_default": _WISP,
        "cors_default": _CORS,
        "last_ensure": _last_ensure,
        "recommended_order": [
            "libcurl+wisp(+epoxy)",
            "manus-http-cors",
            "direct-pyfetch",
        ],
    }


async def ensure(
    wisp_url: str = "",
    origin: str = "",
    force: bool = False,
    preferred: bool = True,
    epoxy_enabled: bool = True,
    transport_mode: str = "auto",
    verify_target: str = "",
    verify_timeout_ms: int = 8000,
    verify_retries: int = 0,
) -> dict[str, Any]:
    """
    Bring up the full network stack:

    1. libcurl.set_websocket(Wisp) when WASM is loaded in the host page
    2. Manus CORS API key via proxy.ensure / generate
    3. Wire configure_proxy so _http.http_request can fall back cleanly

    Safe to call multiple times.
    """
    global _last_ensure

    wisp = wisp_url or _WISP
    result: dict[str, Any] = {
        "ok": False,
        "libcurl": None,
        "proxy": None,
        "active_transports": [],
    }

    # --- 1) libcurl + Wisp (+ Epoxy detection) ---
    try:
        if transport_mode not in {"auto", "libcurl", "proxy", "direct"}:
            raise ValueError("transport_mode must be auto, libcurl, proxy, or direct")
        # Bridge vocabulary is auto/libcurl/epoxy/cors; network proxy/direct modes
        # govern _http routing and therefore disable bridge preference here.
        bridge_mode = {"auto": "auto", "libcurl": "libcurl", "proxy": "cors", "direct": "cors"}[transport_mode]
        libcurl_bridge.configure(
            preferred=bool(preferred and transport_mode in {"auto", "libcurl"}),
            wisp_url=wisp,
            epoxy_enabled=bool(epoxy_enabled),
            transport_mode=bridge_mode,
        )
        lc = await libcurl_bridge.ensure(wisp_url=wisp, force_websocket=transport_mode in {"auto", "libcurl"}, transport_mode=bridge_mode)
        result["libcurl"] = lc
        if lc.get("ok"):
            result["active_transports"].append(lc.get("transport") or "libcurl+wisp")
    except Exception as e:  # noqa: BLE001
        result["libcurl"] = {"ok": False, "error": str(e)}

    # --- 2) Manus CORS API key ---
    try:
        px = await proxy_tool.ensure(origin=origin, force=force)
        result["proxy"] = px
        if px.get("ok"):
            result["active_transports"].append("manus-http-cors")
            # ensure _http proxy mirrors key
            try:
                key = ""
                st = px.get("proxy") or {}
                key = st.get("api_key") or st.get("key") or ""
                if not key and hasattr(proxy_tool, "get_key"):
                    key = proxy_tool.get_key() or ""
                # proxy_tool.ensure already configures; double-check
                if key:
                    _http.configure_proxy(api_key=key, enabled=True, base_url=_CORS)
            except Exception:
                pass
    except Exception as e:  # noqa: BLE001
        result["proxy"] = {"ok": False, "error": str(e)}

    result["configuration"] = {
        "wisp_url": wisp,
        "preferred": bool(preferred),
        "epoxy_enabled": bool(epoxy_enabled),
        "transport_mode": transport_mode,
        "libcurl_bridge_mode": {"auto": "auto", "libcurl": "libcurl", "proxy": "cors", "direct": "cors"}[transport_mode],
        "verify_target": _http.redact_url(verify_target) if verify_target else None,
    }
    if verify_target:
        result["verification"] = await test(
            verify_target, timeout_ms=verify_timeout_ms, retries=verify_retries,
            route="proxy" if transport_mode == "proxy" else ("direct" if transport_mode == "direct" else "auto"),
        )
    result["ok"] = bool(result["active_transports"]) and (not verify_target or bool((result.get("verification") or {}).get("ok")))
    result["status"] = status()
    result["hint"] = (
        None
        if result["ok"]
        else (
            "No transport ready. Host page must either:\n"
            "  A) Load libcurl.js + WASM and set_websocket('wss://cors.manus.space/wisp/'), or\n"
            "  B) Expose POST /api/manus-key for CORS proxy key generation."
        )
    )
    _last_ensure = result
    return result


def _headers_from_json(raw: str | dict | None) -> dict[str, str]:
    if raw in (None, ""):
        return {}
    value = raw if isinstance(raw, dict) else json.loads(str(raw))
    if not isinstance(value, dict):
        raise ValueError("headers_json must be a JSON object")
    return {str(key): str(item) for key, item in value.items()}


def _safe_headers(headers: dict[str, Any]) -> dict[str, str]:
    sensitive = {"authorization", "cookie", "set-cookie", "x-api-key", "proxy-authorization"}
    return {str(key): "[redacted]" if str(key).lower() in sensitive else str(value) for key, value in headers.items()}


def _safe_body(value: Any) -> str:
    text = str(value or "")
    return re.sub(
        r"(?i)\b(authorization|cookie|api[_-]?key|access[_-]?token|token|secret|password)\s*([:=])\s*([\"']?)[^\s,;\"'<>]{3,}",
        lambda match: f"{match.group(1)}{match.group(2)}[redacted]",
        text,
    )


def _expected_statuses(raw: str | list[int] | None) -> tuple[set[int], list[str]]:
    if isinstance(raw, list):
        values = {int(item) for item in raw}
        return values, [str(item) for item in sorted(values)]
    values: set[int] = set()
    display: list[str] = []
    for piece in str(raw or "").split(","):
        item = piece.strip()
        if not item:
            continue
        if "-" in item:
            left, right = item.split("-", 1)
            if left.strip().isdigit() and right.strip().isdigit():
                start, end = int(left), int(right)
                if 100 <= start <= end <= 599 and end - start <= 499:
                    values.update(range(start, end + 1)); display.append(f"{start}-{end}")
            continue
        if item.isdigit() and 100 <= int(item) <= 599:
            values.add(int(item)); display.append(item)
    return values, display


def _route(value: str | bool | None) -> bool | None:
    if value in (None, "", "auto", "AUTO"):
        return None
    if value in (True, "proxy", "PROXY", "true", "True"):
        return True
    if value in (False, "direct", "DIRECT", "false", "False"):
        return False
    raise ValueError("route must be auto, proxy, or direct")


async def test(
    target: str = "https://example.com/",
    method: str = "GET",
    headers_json: str = "",
    body: str = "",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    expected_status: str = "",
    include_body: bool = True,
) -> dict[str, Any]:
    """Probe the shared stack with configurable browser-equivalent request evidence."""
    method = (method or "GET").upper()
    if method not in {"GET", "HEAD", "OPTIONS", "POST", "PUT", "PATCH", "DELETE"}:
        raise ValueError(f"unsupported HTTP method: {method}")
    headers = {"User-Agent": "pyodide-security/network-test", **_headers_from_json(headers_json)}
    timeout_ms = max(1000, min(int(timeout_ms or 8000), 120000))
    retries = max(0, min(int(retries or 0), 5))
    retryable = {int(value.strip()) for value in str(retry_statuses or "").split(",") if value.strip().isdigit()}
    expected, expected_display = _expected_statuses(expected_status)
    attempts: list[dict[str, Any]] = []
    resp: dict[str, Any] = {}
    use_proxy = _route(route)
    for index in range(retries + 1):
        resp = await _http.http_request(target, method=method, headers=headers, body=body or None, timeout_ms=timeout_ms, use_proxy=use_proxy)
        attempts.append({"attempt": index + 1, "status": resp.get("status"), "ok": resp.get("ok"), "transport": resp.get("transport"), "elapsed_ms": resp.get("elapsed_ms"), "error": resp.get("error")})
        if resp.get("ok") or int(resp.get("status") or 0) not in retryable:
            break
    status_code = int(resp.get("status") or 0)
    status_match = not expected or status_code in expected
    return {
        "ok": bool(resp.get("ok")) and status_match,
        "target": _http.redact_url(target),
        "status": status_code,
        "expected_status": expected_display,
        "status_match": status_match,
        "transport": resp.get("transport") or ("libcurl+wisp" if resp.get("via_libcurl") else ("manus-cors" if resp.get("via_proxy") else "direct")),
        "via_libcurl": resp.get("via_libcurl"),
        "via_proxy": resp.get("via_proxy"),
        "via_wisp": resp.get("via_wisp"),
        "elapsed_ms": resp.get("elapsed_ms"),
        "error": resp.get("error"),
        "final_url": _http.redact_url(resp.get("final_url")),
        "attempts": attempts,
        "attempt_count": len(attempts),
        "headers": _safe_headers(resp.get("headers") or {}),
        "body": _safe_body(resp.get("body")) if include_body else None,
        "body_length": len(str(resp.get("body") or "")),
        "request": {"method": method, "target": _http.redact_url(target), "headers": _safe_headers(headers), "body_length": len(str(body or "")), "timeout_ms": timeout_ms, "retries": retries, "retry_statuses": sorted(retryable), "route": "auto" if use_proxy is None else ("proxy" if use_proxy else "direct"), "include_body": bool(include_body)},
        "stack": status(),
    }
