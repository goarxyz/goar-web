"""Browser-adapted open-redirect testing through the shared Goar transport."""
from __future__ import annotations

import json
import re
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from .. import policy
from .._http import http_request, redact_url
from .payloads_pat import list_payloads as list_payloads_pat

_PARAMS = (
    "next", "url", "redirect", "redirect_uri", "redirect_url", "return", "returnTo",
    "return_to", "continue", "dest", "destination", "goto", "target", "rurl",
    "relayState", "forward", "out", "view", "image_url", "file", "data", "ref",
    "site", "uri", "to",
)
_DESTINATIONS = (
    "https://evil.psec.example/psec-redirect",
    "http://evil.psec.example/psec-redirect",
    "//evil.psec.example/psec-redirect",
    "///evil.psec.example/",
    "https:evil.psec.example",
    "/\\evil.psec.example/",
    "https://evil.psec.example%2f.example.com",
)
_META_JS = re.compile(
    r'(?i)<meta[^>]+http-equiv=["\']?refresh["\']?[^>]+url=([^"\'>\s]+)'
    r'|window\.location\s*=\s*["\']([^"\']+)'
    r'|location\.href\s*=\s*["\']([^"\']+)'
)
_SENSITIVE = re.compile(r"(?i)(authorization|cookie|set-cookie|x-api-key|api[_-]?key|token|secret|password)")


def _parse_headers(raw: str | dict[str, Any] | None) -> dict[str, str]:
    if isinstance(raw, dict):
        return {str(k): str(v) for k, v in raw.items()}
    raw = str(raw or "").strip()
    if not raw:
        return {}
    if raw.startswith("{"):
        try:
            obj = json.loads(raw)
            return {str(k): str(v) for k, v in obj.items()} if isinstance(obj, dict) else {}
        except (TypeError, ValueError):
            return {}
    output: dict[str, str] = {}
    for line in raw.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            if key.strip():
                output[key.strip()] = value.strip()
    return output


def _redact_headers(headers: dict[str, str]) -> dict[str, str]:
    return {key: "[redacted]" if _SENSITIVE.search(key) else value for key, value in headers.items()}


def _split(raw: str) -> list[str]:
    return [part.strip() for part in re.split(r"[\n,]+", str(raw or "")) if part.strip()]


def _parse_codes(raw: str, default: set[int]) -> set[int]:
    result: set[int] = set()
    for token in _split(raw):
        if "-" in token:
            left, _, right = token.partition("-")
            if left.isdigit() and right.isdigit():
                result.update(range(max(0, int(left)), min(999, int(right)) + 1))
        elif token.isdigit():
            result.add(int(token))
    return result or set(default)


def _extract_redirect_target(headers: dict[str, Any], body: str) -> str | None:
    for key, value in (headers or {}).items():
        if str(key).lower() == "location" and value:
            return str(value)
    match = _META_JS.search(body or "")
    if match:
        return next((group for group in match.groups() if group), None)
    return None


def _host(value: str) -> str:
    value = str(value or "").strip()
    parsed = urlparse(value if "://" in value or value.startswith("//") else "https://" + value)
    return (parsed.hostname or "").lower()


def _is_external(target: str, root_host: str) -> bool:
    if not target:
        return False
    if str(target).lower().startswith("javascript:"):
        return True
    host = _host(target)
    return bool(host and host != root_host and not host.endswith("." + root_host))


def _matches_destination(target: str, destination: str) -> bool:
    if not target:
        return False
    candidate_host = _host(target)
    expected_host = _host(destination)
    if expected_host and candidate_host == expected_host:
        return True
    return "evil.psec.example" in str(target).lower() and "evil.psec.example" in str(destination).lower()


def _form_with_payload(data: str, parameter: str, destination: str) -> str:
    pairs = parse_qsl(str(data or ""), keep_blank_values=True)
    mapping = dict(pairs)
    mapping[parameter] = destination
    return urlencode(mapping, doseq=True)


async def _request(
    target: str, method: str, headers: dict[str, str], body: str, timeout_ms: int,
    retries: int, retry_codes: set[int], route: str, attempts: list[dict[str, Any]],
) -> dict[str, Any]:
    use_proxy = True if route == "proxy" else False if route == "direct" else None
    result: dict[str, Any] = {}
    for index in range(max(0, min(int(retries or 0), 5)) + 1):
        result = await http_request(
            target,
            method=method,
            headers=headers,
            body=body if method not in ("GET", "HEAD", "OPTIONS") else None,
            timeout_ms=max(1000, min(int(timeout_ms or 8000), 120000)),
            use_proxy=use_proxy,
        )
        attempts.append({
            "attempt": index + 1,
            "url": redact_url(target),
            "method": method,
            "status": int(result.get("status") or 0),
            "ok": bool(result.get("ok")),
            "elapsed_ms": result.get("elapsed_ms"),
            "transport": result.get("transport"),
            "error": str(result.get("error") or "")[:240],
        })
        if result.get("ok") or int(result.get("status") or 0) not in retry_codes:
            break
    return result


def _payloads(custom_destinations: str, include_corpus: bool, max_dests: int) -> tuple[list[str], bool]:
    rows = _split(custom_destinations)
    if not rows:
        rows = list(_DESTINATIONS)
        if include_corpus:
            corpus = list_payloads_pat().get("payloads") or []
            rows.extend(str(item) for item in corpus if isinstance(item, str))
    ordered = list(dict.fromkeys(rows))
    limit = max(1, min(int(max_dests or 4), 40))
    return ordered[:limit], len(ordered) > limit


async def scan(
    url: str,
    parameters: str = "",
    max_params: int = 8,
    max_dests: int = 4,
    max_tests: int = 0,
    user_agent: str = "pyodide-security/redirect-engine/3.0",
    method: str = "GET",
    headers: str | dict[str, Any] = "",
    body: str = "",
    placement: str = "query",
    custom_destinations: str = "",
    include_corpus: bool = False,
    status_codes: str = "200-399",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    include_response_body: bool = False,
    preview_chars: int = 400,
    include_attempts: bool = False,
    stop_on_finding: bool = False,
) -> dict[str, Any]:
    err = policy.check_url_for_active(url)
    if err:
        return {"ok": False, "error": err, "engine": "redirect-browser-adapted", "policy": policy.status()}
    url = str(url or "").strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    method = str(method or "GET").upper()
    if method not in ("GET", "POST", "HEAD", "OPTIONS"):
        method = "GET"
    placement = placement if placement in ("query", "body", "both") else "query"
    route = route if route in ("auto", "proxy", "direct") else "auto"
    parsed = urlparse(url)
    root_host = (parsed.hostname or "").lower()
    existing = dict(parse_qsl(parsed.query, keep_blank_values=True))
    request_headers = _parse_headers(headers)
    request_headers.setdefault("User-Agent", user_agent)
    if method == "POST" and placement in ("body", "both"):
        request_headers.setdefault("Content-Type", "application/x-www-form-urlencoded")
    requested = _split(parameters)
    if not requested:
        lower = {item.lower() for item in _PARAMS}
        requested = [key for key in existing if key.lower() in lower]
        requested.extend(item for item in _PARAMS if item not in requested)
    params = list(dict.fromkeys(requested))[:max(1, min(int(max_params or 8), 30))]
    destinations, destinations_truncated = _payloads(custom_destinations, bool(include_corpus), max_dests)
    status_ok = _parse_codes(status_codes, set(range(200, 400)))
    retry_codes = _parse_codes(retry_statuses, {408, 429, 500, 502, 503, 504})
    test_cap = max(1, min(int(max_tests or len(params) * len(destinations)), 1000))
    findings: list[dict[str, Any]] = []
    tests: list[dict[str, Any]] = []
    attempts: list[dict[str, Any]] = []
    stopped_reason: str | None = None
    for parameter in params:
        for destination in destinations:
            if len(tests) >= test_cap:
                stopped_reason = "test limit reached"
                break
            if not policy.can_request():
                stopped_reason = "request budget exhausted"
                break
            query = dict(existing)
            request_body = str(body or "")
            if placement in ("query", "both"):
                query[parameter] = destination
            if placement in ("body", "both"):
                request_body = _form_with_payload(request_body, parameter, destination)
            target = urlunparse(parsed._replace(query=urlencode(query, doseq=True)))
            response = await _request(target, method, request_headers, request_body, timeout_ms, retries, retry_codes, route, attempts)
            status = int(response.get("status") or 0)
            response_headers = response.get("headers") or {}
            text = str(response.get("body") or "")
            location = _extract_redirect_target(response_headers, text)
            final = str(response.get("final_url") or "")
            destination_match = _matches_destination(location or final, destination)
            external = _is_external(location or final, root_host)
            confirmed = destination_match and external and status in status_ok
            entry: dict[str, Any] = {
                "parameter": parameter,
                "placement": placement,
                "payload": destination,
                "request_url": redact_url(target),
                "status": status,
                "location": location,
                "final_url": redact_url(final) if final else None,
                "destination_match": destination_match,
                "external_redirect": external,
                "confirmed": confirmed,
                "confidence": 95 if confirmed else 60 if destination_match else 0,
                "transport": response.get("transport"),
                "elapsed_ms": response.get("elapsed_ms"),
                "error": str(response.get("error") or "")[:240],
            }
            if include_response_body:
                entry["body_preview"] = text[:max(0, min(int(preview_chars or 400), 5000))]
            tests.append(entry)
            if confirmed:
                findings.append(entry)
                if stop_on_finding:
                    stopped_reason = "confirmed finding"
                    break
        if stopped_reason:
            break
    findings.sort(key=lambda row: (-int(row["confidence"]), row["parameter"], row["payload"]))
    return {
        "ok": True,
        "url": redact_url(url),
        "tested": len(tests),
        "candidate_count": len(params) * len(destinations),
        "parameters": params,
        "destinations": destinations,
        "destinations_truncated": destinations_truncated,
        "vulnerable": bool(findings),
        "findings": findings,
        "finding_count": len(findings),
        "tests": tests,
        "request": {"method": method, "placement": placement, "headers": _redact_headers(request_headers), "body_bytes": len(str(body or "")), "timeout_ms": max(1000, min(int(timeout_ms or 8000), 120000)), "retries": max(0, min(int(retries or 0), 5)), "route": route, "status_codes": sorted(status_ok)},
        "attempts": attempts if include_attempts else [],
        "attempt_count": len(attempts),
        "stopped_reason": stopped_reason,
        "engine": "redirect-browser-adapted",
        "version": "3.0",
        "equivalent": "PortSwigger open redirect / PayloadsAllTheThings",
        "limitations": ["Browser-adapted sequential HTTP request tests through the shared Goar transport; native list concurrency, raw requests, TLS/client controls and desktop report modes are not claimed."],
        "policy": policy.status(),
    }
