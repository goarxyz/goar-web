
from .. import pat_data
def list_payloads():
    rows = pat_data.get("open_redirect")
    return {"payloads": rows, "count": len(rows), "source": "PayloadsAllTheThings/open_redirect"}
