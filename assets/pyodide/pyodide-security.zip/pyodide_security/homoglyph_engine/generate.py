"""Homoglyph / confusable domain generator — IDN punycode attacks."""
from __future__ import annotations
from typing import Any

# Common Latin confusables
MAP={
    'a':['а','ɑ','α','а'],'e':['е','ε','ẹ'],'i':['і','ι','ɪ'],'o':['о','ο','ө'],
    'c':['с','ϲ'],'p':['р'],'x':['х','χ'],'y':['у','γ'],'s':['ѕ'],'b':['Ь','ｂ'],
    'h':['һ','հ'],'j':['ј'],'l':['ⅼ','Ɩ'],'n':['ո'],'u':['υ'],'v':['ν'],'w':['ԝ'],
    'A':['А','Α'],'B':['В','Β'],'E':['Е','Ε'],'H':['Н','Η'],'K':['К','Κ'],
    'M':['М','Μ'],'O':['О','Ο'],'P':['Р','Ρ'],'T':['Т','Τ'],'X':['Х','Χ'],'Y':['Υ'],
}

def generate(text: str, max_variants: int=50)->dict[str,Any]:
    text=text or ""
    variants=set()
    chars=list(text)
    for i,ch in enumerate(chars):
        for rep in MAP.get(ch, []):
            v=chars.copy(); v[i]=rep
            variants.add(''.join(v))
            if len(variants)>=max_variants: break
        if len(variants)>=max_variants: break
    # punycode note
    out=[]
    for v in sorted(variants)[:max_variants]:
        try:
            puny=v.encode('idna').decode('ascii')
        except Exception:
            puny=None
        out.append({"variant":v,"punycode":puny})
    return {"ok":True,"input":text,"count":len(out),"variants":out,"engine":"homoglyph","equivalent":"confusable homoglyphs"}
