"""Browser-adapted LinkFinder plus bundled gitleaks-rule JavaScript reconnaissance."""
from __future__ import annotations
import gzip, json, re
from pathlib import Path
from typing import Any
from urllib.parse import urljoin, urlparse
from .._http import http_request, redact_url
from .. import policy
_RULES=None

def _rules():
 global _RULES
 if _RULES is None:
  with gzip.open(Path(__file__).with_name('gitleaks_rules.json.gz'),'rt',encoding='utf-8') as f:_RULES=json.load(f)
 return _RULES

def _safe(v):
 return re.sub(r'(?im)(token|secret|api[_-]?key|password|authorization|cookie)(\s*[=:]\s*)[^\s,;"\']+',lambda m:f'{m.group(1)}{m.group(2)}[redacted]',str(v or ''))
def _headers(raw,ua):
 out={'User-Agent':str(ua)};t=str(raw or '').strip()
 if t.startswith('{'):
  x=json.loads(t)
  if not isinstance(x,dict):raise ValueError('headers JSON must be an object')
  out.update({str(k):str(v) for k,v in x.items()})
 else:
  for line in t.splitlines():
   if ':' in line:
    k,_,v=line.partition(':')
    if k.strip():out[k.strip()]=v.strip()
 return out
def _route(v):
 if v in ('',None,'auto'):return None
 if v=='proxy':return True
 if v=='direct':return False
 raise ValueError('route must be auto, proxy, or direct')
def _endpoints(text,base,max_hits,pattern=''):
 rx=re.compile(r'''(?:(?:https?://|//)[^\s"'<>`]+|(?:/|\.\.?/)[A-Za-z0-9_./?=&%#:-]+|[A-Za-z0-9_-]+\.(?:php|json|js|asp|aspx|jsp)(?:\?[^\s"']*)?)''')
 filt=re.compile(pattern) if pattern else None;out=[];seen=set()
 for m in rx.finditer(text or ''):
  raw=m.group(0).rstrip('.,;)');u=urljoin(base,raw)
  if filt and not filt.search(raw):continue
  if u not in seen:seen.add(u);out.append({'endpoint':redact_url(u),'raw':raw,'offset':m.start()})
  if len(out)>=max_hits:break
 return out

def list_rules(limit:int=0)->dict[str,Any]:
 rows=_rules();out=rows[:int(limit)] if limit and limit>0 else rows
 return {'ok':True,'count':len(rows),'returned':len(out),'rules':[{'id':r['id'],'description':r.get('description')} for r in out],'source':'gitleaks/gitleaks config/gitleaks.toml','engine':'jsrecon','equivalent':'gitleaks'}
def scan_text(text:str,max_hits:int=50,redact:bool=True)->dict[str,Any]:
 hits=[]
 for r in _rules():
  if len(hits)>=max_hits:break
  try:rx=re.compile(r['regex'],re.I|re.M)
  except re.error:continue
  for m in rx.finditer(text or ''):
   value=m.group(0)[:500];hits.append({'id':r['id'],'description':r.get('description'),'match':_safe(value) if redact else value,'offset':m.start()})
   if len(hits)>=max_hits:break
 return {'ok':True,'hit_count':len(hits),'hits':hits,'rule_db':len(_rules()),'engine':'jsrecon'}

async def analyze(url:str='',text:str='',user_agent:str='pyodide-security/gitleaks/1.0',max_scripts:int=10,scan_secrets:bool=True,headers:str='',timeout_ms:int=8000,retries:int=0,retry_statuses:str='408,429,500,502,503,504',route:str='auto',discover_scripts:bool=True,max_endpoints:int=100,endpoint_regex:str='',max_body_chars:int=300000,include_bodies:bool=False,preview_chars:int=1000,redact_secrets:bool=True)->dict[str,Any]:
 if text:
  base=url or 'https://local.invalid/';r=scan_text(text,max_endpoints,redact_secrets) if scan_secrets else {'ok':True,'hit_count':0,'hits':[],'rule_db':len(_rules()),'engine':'jsrecon'};r.update({'mode':'text','endpoints':_endpoints(text,base,max_endpoints,endpoint_regex),'endpoint_count':len(_endpoints(text,base,max_endpoints,endpoint_regex))});return r
 if not url:return {'ok':False,'error':'url or text required','engine':'jsrecon'}
 if not url.startswith(('http://','https://')):url='https://'+url
 err=policy.check_url_for_active(url)
 if err:return {'ok':False,'error':err,'engine':'jsrecon'}
 hdr=_headers(headers,user_agent);timeout=max(1000,min(int(timeout_ms or 8000),120000));retry=max(0,min(int(retries or 0),5));retryable={int(x) for x in str(retry_statuses or '').split(',') if x.strip().isdigit()};proxy=_route(route);limit=max(1,min(int(max_scripts or 10),30));body_limit=max(1000,min(int(max_body_chars or 300000),1000000));attempts=[]
 async def fetch(target):
  resp={};at=[]
  for n in range(retry+1):
   resp=await http_request(target,headers=hdr,timeout_ms=timeout,use_proxy=proxy);at.append({'url':redact_url(target),'attempt':n+1,'status':resp.get('status'),'ok':resp.get('ok'),'transport':resp.get('transport'),'elapsed_ms':resp.get('elapsed_ms'),'error':_safe(resp.get('error'))})
   if resp.get('ok') or int(resp.get('status') or 0) not in retryable:break
  attempts.extend(at);return resp
 root=await fetch(url);source=str(root.get('body') or '')[:body_limit];scripts=[url]
 if discover_scripts and '<script' in source.lower():
  for src in re.findall(r'''<script[^>]+src=["']([^"']+)["']''',source,re.I):
   u=urljoin(url,src)
   if u not in scripts:scripts.append(u)
 scripts=scripts[:limit];results=[];all_end=[];all_hits=[]
 for target in scripts:
  resp=root if target==url else await fetch(target);body=str(resp.get('body') or '')[:body_limit];eps=_endpoints(body,target,max_endpoints,endpoint_regex);sec=scan_text(body,max_endpoints,redact_secrets) if scan_secrets else {'hits':[],'hit_count':0};all_end.extend(eps);all_hits.extend(sec['hits']);row={'url':redact_url(target),'status':resp.get('status'),'length':len(body),'endpoint_count':len(eps),'secret_count':sec['hit_count'],'transport':resp.get('transport')}
  if include_bodies:row['body_preview']=_safe(body)[:max(0,min(int(preview_chars or 1000),200000))]
  results.append(row)
 seen=set();all_end=[x for x in all_end if not (x['endpoint'] in seen or seen.add(x['endpoint']))][:max_endpoints]
 return {'ok':True,'url':redact_url(url),'mode':'url','scripts':results,'script_count':len(results),'endpoints':all_end,'endpoint_count':len(all_end),'hits':all_hits[:max_endpoints],'hit_count':len(all_hits[:max_endpoints]),'rule_db':len(_rules()),'attempts':attempts,'attempt_count':len(attempts),'request':{'headers':{k:('[redacted]' if k.lower() in {'authorization','cookie','x-api-key'} else v) for k,v in hdr.items()},'timeout_ms':timeout,'retries':retry,'route':'auto' if proxy is None else ('proxy' if proxy else 'direct')},'engine':'jsrecon','equivalent':'LinkFinder + gitleaks','policy':policy.status()}
