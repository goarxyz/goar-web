"""Bounded browser-adapted XML external-entity testing through shared Goar transport."""
from __future__ import annotations

import gzip
import json
import re
from pathlib import Path
from typing import Any

from .. import policy
from .._http import http_request, redact_url

_PATH = Path(__file__).with_name("data") / "payloads.json.gz"
_PAYLOADS: list[str] | None = None
_SENSITIVE = re.compile(r"(?i)(authorization|cookie|set-cookie|x-api-key|api[_-]?key|token|secret|password)")
_SIGNALS = ("root:", "daemon:", "[extensions]", "for 16-bit", "base64", "doctype", "entity", "file://", "/etc/passwd", "win.ini", "system id", "external entity")


def _payloads() -> list[str]:
    global _PAYLOADS
    if _PAYLOADS is None:
        with gzip.open(_PATH, "rt", encoding="utf-8") as handle:
            _PAYLOADS = json.load(handle)
    return list(_PAYLOADS)


def _split(raw: str) -> list[str]:
    return [item.strip() for item in re.split(r"\n(?=<)|\n---+\n", str(raw or "")) if item.strip()]


def _parse_headers(raw: str | dict[str, Any] | None) -> dict[str, str]:
    if isinstance(raw, dict):
        return {str(key): str(value) for key, value in raw.items()}
    text = str(raw or "").strip()
    if not text:
        return {}
    if text.startswith("{"):
        try:
            value = json.loads(text)
            return {str(key): str(value) for key, value in value.items()} if isinstance(value, dict) else {}
        except (TypeError, ValueError):
            return {}
    output: dict[str, str] = {}
    for line in text.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            if key.strip():
                output[key.strip()] = value.strip()
    return output


def _redact_headers(headers: dict[str, str]) -> dict[str, str]:
    return {key: "[redacted]" if _SENSITIVE.search(key) else value for key, value in headers.items()}


def _codes(raw: str) -> set[int]:
    return {int(item.strip()) for item in str(raw or "").split(",") if item.strip().isdigit()}


def _ratio(left: str, right: str) -> float:
    if not left and not right:
        return 1.0
    from difflib import SequenceMatcher
    return round(SequenceMatcher(None, left[:12000], right[:12000]).ratio(), 4)


async def _request(url: str, method: str, headers: dict[str, str], body: str, timeout_ms: int, retries: int, retry_codes: set[int], route: str, attempts: list[dict[str, Any]], stage: str) -> dict[str, Any]:
    use_proxy = True if route == "proxy" else False if route == "direct" else None
    response: dict[str, Any] = {}
    for number in range(max(0, min(int(retries or 0), 5)) + 1):
        response = await http_request(url, method=method, headers=headers, body=body, timeout_ms=max(1000, min(int(timeout_ms or 8000), 120000)), use_proxy=use_proxy)
        attempts.append({"stage": stage, "attempt": number + 1, "url": redact_url(url), "method": method, "status": int(response.get("status") or 0), "ok": bool(response.get("ok")), "elapsed_ms": response.get("elapsed_ms"), "transport": response.get("transport"), "error": str(response.get("error") or "")[:240]})
        if response.get("ok") or int(response.get("status") or 0) not in retry_codes:
            break
    return response


def list_payloads(limit: int = 0, search: str = "", offset: int = 0) -> dict[str, Any]:
    rows = _payloads()
    if search:
        rows = [item for item in rows if str(search).lower() in item.lower()]
    start = max(0, int(offset or 0))
    rows = rows[start:]
    if limit and int(limit) > 0:
        rows = rows[:int(limit)]
    return {"ok": True, "count": len(_payloads()), "returned": len(rows), "payloads": rows, "source": "PayloadsAllTheThings/XXE Injection", "engine": "xxe-browser-adapted", "equivalent": "PayloadsAllTheThings XXE"}


async def scan(url: str, max_payloads: int = 8, content_type: str = "application/xml", user_agent: str = "pyodide-security/xxe/3.0", method: str = "POST", headers: str | dict[str, Any] = "", baseline_body: str = "<ping/>", custom_payloads: str = "", include_default: bool = True, status_codes: str = "", timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = "408,429,500,502,503,504", route: str = "auto", min_difference: float = 0.08, max_findings: int = 50, include_response_body: bool = False, preview_chars: int = 400, include_attempts: bool = False, stop_on_finding: bool = False) -> dict[str, Any]:
    error = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if error:
        return {"ok": False, "error": error, "engine": "xxe-browser-adapted", "policy": policy.status()}
    url = str(url or "").strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    method = str(method or "POST").upper()
    if method not in ("POST", "PUT", "PATCH"):
        method = "POST"
    route = route if route in ("auto", "proxy", "direct") else "auto"
    request_headers = _parse_headers(headers)
    request_headers.setdefault("User-Agent", user_agent)
    request_headers.setdefault("Content-Type", content_type or "application/xml")
    request_headers.setdefault("Accept", "*/*")
    candidates = (list(_payloads()) if include_default else []) + _split(custom_payloads)
    candidates = list(dict.fromkeys(candidates))[:max(1, min(int(max_payloads or 8), 100))]
    retry_codes = _codes(retry_statuses) or {408, 429, 500, 502, 503, 504}
    expected = _codes(status_codes)
    attempts: list[dict[str, Any]] = []
    baseline_headers = dict(request_headers)
    baseline_headers["Content-Type"] = "text/plain"
    baseline = await _request(url, method, baseline_headers, str(baseline_body or "<ping/>"), timeout_ms, retries, retry_codes, route, attempts, "baseline")
    baseline_text = str(baseline.get("body") or "")
    baseline_status = int(baseline.get("status") or 0)
    findings: list[dict[str, Any]] = []
    tested = 0
    stopped_reason: str | None = None
    for payload in candidates:
        if not policy.can_request():
            stopped_reason = "request budget exhausted"
            break
        tested += 1
        response = await _request(url, method, request_headers, payload, timeout_ms, retries, retry_codes, route, attempts, "payload")
        status = int(response.get("status") or 0)
        text = str(response.get("body") or "")
        similarity = _ratio(baseline_text.lower(), text.lower())
        signals = [signal for signal in _SIGNALS if signal in text.lower() and signal not in baseline_text.lower()]
        status_changed = status != baseline_status and status != 0
        accepted_status = not expected or status in expected
        meaningful_difference = (1.0 - similarity) >= max(0.0, min(float(min_difference or 0.08), 1.0))
        if accepted_status and (signals or (status_changed and meaningful_difference)):
            finding: dict[str, Any] = {"payload_preview": payload[:240], "status": status, "baseline_status": baseline_status, "signals": signals, "length": len(text), "baseline_length": len(baseline_text), "similarity": similarity, "status_changed": status_changed, "transport": response.get("transport"), "elapsed_ms": response.get("elapsed_ms")}
            if include_response_body:
                finding["body_preview"] = text[:max(0, min(int(preview_chars or 400), 5000))]
            findings.append(finding)
            if len(findings) >= max(1, min(int(max_findings or 50), 500)):
                stopped_reason = "finding limit reached"
                break
            if stop_on_finding:
                stopped_reason = "finding requested stop"
                break
    return {"ok": True, "url": redact_url(url), "tested": tested, "payload_count": len(candidates), "findings": findings, "finding_count": len(findings), "payload_db": len(_payloads()), "baseline": {"status": baseline_status, "length": len(baseline_text), "transport": baseline.get("transport"), "elapsed_ms": baseline.get("elapsed_ms")}, "request": {"method": method, "headers": _redact_headers(request_headers), "timeout_ms": max(1000, min(int(timeout_ms or 8000), 120000)), "retries": max(0, min(int(retries or 0), 5)), "route": route, "expected_statuses": sorted(expected)}, "attempts": attempts if include_attempts else [], "attempt_count": len(attempts), "stopped_reason": stopped_reason, "engine": "xxe-browser-adapted", "source": "PayloadsAllTheThings/XXE Injection", "limitations": ["Browser-adapted bounded HTTP XML evidence only; OOB callbacks, local file extraction, native proxy modes, raw socket behavior, filesystem reports, and desktop XXEinjector workflows are not claimed."], "policy": policy.status()}
