
"""Payloads from swisskyrepo/PayloadsAllTheThings (xxe)."""
from .. import pat_data

def list_payloads():
    rows = pat_data.get("xxe")
    return {"payloads": rows, "count": len(rows), "source": "PayloadsAllTheThings/xxe"}
