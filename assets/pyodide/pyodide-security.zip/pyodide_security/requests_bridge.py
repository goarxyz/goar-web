"""
Manus-aware requests bridge for Pyodide.

After pyodide-http.patch_all(), this installs a Session that routes every
request through the configured Manus CORS proxy (configure_proxy / auto-mint).
"""

from __future__ import annotations

import json
from typing import Any
from urllib.parse import quote


def patch_pyodide_http() -> dict[str, Any]:
    """Install optional pyodide-http hooks, or confirm the built-in host-fetch fallback."""
    try:
        import pyodide_http  # type: ignore

        pyodide_http.patch_all()
        return {"ok": True, "patched": True, "fallback": False, "version": getattr(pyodide_http, "__version__", "?")}
    except ModuleNotFoundError:
        # PyTerm supplies a worker-to-page HTTP bridge, so this optional package
        # is not a prerequisite for request tools in the portable build.
        return {"ok": True, "patched": False, "fallback": True, "engine": "pyodide-host-fetch"}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "patched": False, "fallback": False, "error": f"{type(e).__name__}: {e}"}


def _proxy_url(target: str, method: str = "GET") -> tuple[str, dict[str, str]]:
    from ._http import proxy_status

    st = proxy_status()
    if not st.get("configured") or not st.get("enabled"):
        raise RuntimeError("Manus proxy not configured — call proxy.configure first")
    # pull raw key via internal state
    from . import _http as h

    key = (h._proxy.get("api_key") or "").strip()
    base = (h._proxy.get("base_url") or "https://cors.manus.space/api/proxy").rstrip("?")
    q = f"url={quote(target, safe='')}&apikey={quote(key, safe='')}"
    if method.upper() not in ("GET", "HEAD"):
        q += f"&method={quote(method.upper(), safe='')}"
    headers = {
        "x-api-key": key,
        "x-target-url": target,
    }
    return f"{base}?{q}", headers


def proxied_request(
    method: str,
    url: str,
    headers: dict[str, str] | None = None,
    data: Any = None,
    json_body: Any = None,
    timeout: float = 30,
) -> dict[str, Any]:
    """
    Issue an HTTP request via Manus using requests (pyodide-http patched).
    Falls back to pyodide_security._http.http_request if requests missing.
    """
    method = (method or "GET").upper()
    try:
        import requests  # type: ignore

        patch_pyodide_http()
        proxy_url, pheaders = _proxy_url(url, method)
        hdrs = dict(pheaders)
        for k, v in (headers or {}).items():
            if k.lower() in ("authorization", "content-type"):
                hdrs[k] = v
        kwargs: dict[str, Any] = {"headers": hdrs, "timeout": timeout}
        if json_body is not None:
            kwargs["json"] = json_body
        elif data is not None:
            kwargs["data"] = data
        # Always GET/POST to the proxy hop; method override is in query
        hop_method = method if method in ("GET", "HEAD", "POST", "PUT", "PATCH", "DELETE") else "POST"
        if hop_method == "HEAD":
            hop_method = "GET"
        resp = requests.request(hop_method, proxy_url, **kwargs)
        return {
            "ok": 200 <= resp.status_code < 400,
            "status": resp.status_code,
            "headers": dict(resp.headers),
            "body": resp.text,
            "url": url,
            "via_proxy": True,
            "engine": "requests+pyodide-http+manus",
        }
    except Exception as e:  # noqa: BLE001
        return {
            "ok": False,
            "error": f"{type(e).__name__}: {e}",
            "url": url,
            "engine": "requests-bridge",
        }


def _json_object(raw: str | dict | None, field: str) -> dict[str, Any]:
    """Accept a Files-form JSON object while preserving direct Python callers."""
    if raw in (None, ""):
        return {}
    if isinstance(raw, dict):
        return {str(k): v for k, v in raw.items()}
    try:
        value = json.loads(str(raw))
    except Exception as exc:  # noqa: BLE001
        raise ValueError(f"{field} must be a JSON object: {exc}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"{field} must be a JSON object")
    return {str(k): v for k, v in value.items()}


def _with_query_params(url: str, raw: str | dict | None) -> str:
    params = _json_object(raw, "params_json")
    if not params:
        return url
    from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

    parts = urlsplit(url)
    existing = dict(parse_qsl(parts.query, keep_blank_values=True))
    existing.update({key: "" if value is None else str(value) for key, value in params.items()})
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(existing, doseq=True), parts.fragment))


def _route_flag(value: str | bool | None) -> bool | None:
    if value in (None, "", "auto", "AUTO"):
        return None
    if value in (True, "proxy", "PROXY", "true", "True"):
        return True
    if value in (False, "direct", "DIRECT", "false", "False"):
        return False
    raise ValueError("route must be auto, proxy, or direct")


def _safe_request_headers(headers: dict[str, Any]) -> dict[str, str]:
    """Preserve reproduction evidence without returning bearer credentials in results."""
    out: dict[str, str] = {}
    for key, value in headers.items():
        out[str(key)] = "[redacted]" if str(key).lower() in {"authorization", "cookie", "x-api-key"} else str(value)
    return out


async def proxied_request_async(
    method: str,
    url: str,
    headers: dict[str, str] | str | None = None,
    body: str | bytes | None = None,
    json_body: str | dict | None = None,
    params_json: str | dict | None = None,
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str | bool | None = "auto",
    response_mode: str = "text",
) -> dict[str, Any]:
    """Browser-equivalent Requests workflow through the established Goar transport."""
    from ._http import http_request, redact_url

    method = (method or "GET").upper()
    if method not in {"GET", "HEAD", "OPTIONS", "POST", "PUT", "PATCH", "DELETE"}:
        raise ValueError(f"unsupported HTTP method: {method}")
    request_headers = {str(key): str(value) for key, value in _json_object(headers, "headers_json").items()}
    target = _with_query_params(str(url), params_json)
    if json_body not in (None, ""):
        payload = _json_object(json_body, "json_body")
        request_headers.setdefault("Content-Type", "application/json")
        body = json.dumps(payload, separators=(",", ":"))
    timeout_ms = max(1000, min(int(timeout_ms or 8000), 120000))
    retries = max(0, min(int(retries or 0), 5))
    retryable = {int(part.strip()) for part in str(retry_statuses or "").split(",") if part.strip().isdigit()}
    use_proxy = _route_flag(route)
    attempts: list[dict[str, Any]] = []
    result: dict[str, Any] = {}
    for attempt in range(retries + 1):
        result = await http_request(target, method=method, headers=request_headers, body=body, timeout_ms=timeout_ms, use_proxy=use_proxy)
        attempts.append({
            "attempt": attempt + 1,
            "status": result.get("status"),
            "ok": result.get("ok"),
            "transport": result.get("transport"),
            "elapsed_ms": result.get("elapsed_ms"),
            "error": result.get("error"),
        })
        if result.get("ok") or int(result.get("status") or 0) not in retryable:
            break
    response_mode = (response_mode or "text").lower()
    if response_mode not in {"text", "json"}:
        raise ValueError("response_mode must be text or json")
    if response_mode == "json" and result.get("body") not in (None, ""):
        try:
            result["json"] = json.loads(str(result["body"]))
            result["json_ok"] = True
        except Exception as exc:  # noqa: BLE001
            result["json_ok"] = False
            result["json_error"] = f"{type(exc).__name__}: {exc}"
    result["url"] = redact_url(result.get("url") or target)
    result["final_url"] = redact_url(result.get("final_url") or result.get("url") or target)
    result.update({
        "engine": "requests-host-fetch",
        "request": {
            "method": method,
            "url": redact_url(target),
            "headers": _safe_request_headers(request_headers),
            "timeout_ms": timeout_ms,
            "route": "auto" if use_proxy is None else ("proxy" if use_proxy else "direct"),
            "response_mode": response_mode,
        },
        "attempts": attempts,
        "attempt_count": len(attempts),
    })
    return result


def status() -> dict[str, Any]:
    from ._http import proxy_status

    ph = patch_pyodide_http()
    try:
        import requests  # type: ignore

        req = True
        req_ver = getattr(requests, "__version__", "?")
    except Exception:
        req = False
        req_ver = None
    return {
        "pyodide_http": ph,
        "requests_available": req,
        "requests_version": req_ver,
        "proxy": proxy_status(),
        "engine": "requests-bridge",
    }


async def get(
    url: str,
    method: str = "GET",
    headers_json: str = "",
    params_json: str = "",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    response_mode: str = "text",
) -> dict:
    """Registry-friendly full request path through the established Goar host bridge."""
    return await proxied_request_async(
        method or "GET", url, headers=headers_json, params_json=params_json,
        timeout_ms=timeout_ms, retries=retries, retry_statuses=retry_statuses,
        route=route, response_mode=response_mode,
    )


async def post(
    url: str,
    body: str = "",
    content_type: str = "application/json",
    method: str = "POST",
    headers_json: str = "",
    params_json: str = "",
    json_body: str = "",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    response_mode: str = "text",
) -> dict:
    """Registry-friendly body/JSON request path through the existing Goar bridge."""
    headers = _json_object(headers_json, "headers_json")
    if content_type:
        headers.setdefault("Content-Type", content_type)
    return await proxied_request_async(
        method or "POST", url, headers=headers, body=body or None, json_body=json_body,
        params_json=params_json, timeout_ms=timeout_ms, retries=retries,
        retry_statuses=retry_statuses, route=route, response_mode=response_mode,
    )
