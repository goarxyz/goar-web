"""Bounded browser-adapted HTTP template scanner using packed Nuclei-style data."""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

from .. import policy
from .._http import http_request, redact_url

_TEMPLATES: list[dict[str, Any]] | None = None
_PATH = Path(__file__).with_name("data") / "templates.json"
_SENSITIVE = re.compile(r"(?i)(authorization|cookie|set-cookie|x-api-key|api[_-]?key|token|secret|password)")


def _templates() -> list[dict[str, Any]]:
    global _TEMPLATES
    if _TEMPLATES is None:
        _TEMPLATES = json.loads(_PATH.read_text(encoding="utf-8"))
    return list(_TEMPLATES)


def _split(raw: str) -> list[str]:
    return [part.strip() for part in re.split(r"[\n,]+", str(raw or "")) if part.strip()]


def _parse_headers(raw: str | dict[str, Any] | None) -> dict[str, str]:
    if isinstance(raw, dict):
        return {str(k): str(v) for k, v in raw.items()}
    text = str(raw or "").strip()
    if not text:
        return {}
    if text.startswith("{"):
        try:
            obj = json.loads(text)
            return {str(k): str(v) for k, v in obj.items()} if isinstance(obj, dict) else {}
        except (TypeError, ValueError):
            return {}
    result: dict[str, str] = {}
    for line in text.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            if key.strip():
                result[key.strip()] = value.strip()
    return result


def _redact_headers(headers: dict[str, str]) -> dict[str, str]:
    return {key: "[redacted]" if _SENSITIVE.search(key) else value for key, value in headers.items()}


def _parse_codes(raw: str, default: set[int]) -> set[int]:
    values: set[int] = set()
    for token in _split(raw):
        if "-" in token:
            left, _, right = token.partition("-")
            if left.isdigit() and right.isdigit():
                values.update(range(max(0, int(left)), min(999, int(right)) + 1))
        elif token.isdigit():
            values.add(int(token))
    return values or set(default)


def _tags(template: dict[str, Any]) -> set[str]:
    raw = template.get("tags") or template.get("tag") or template.get("category") or ""
    if isinstance(raw, list):
        return {str(item).strip().lower() for item in raw if str(item).strip()}
    return {item.strip().lower() for item in re.split(r"[,\s]+", str(raw)) if item.strip()}


def _render(value: str, base: str, hostname: str) -> str:
    return str(value).replace("{{BaseURL}}", base).replace("{{Hostname}}", hostname)


def list_templates(severity: str = "", category: str = "", limit: int = 0, q: str = "", offset: int = 0) -> dict[str, Any]:
    rows = _templates()
    if severity:
        allowed = {item.lower() for item in _split(severity)}
        rows = [row for row in rows if str(row.get("severity") or "").lower() in allowed]
    if category:
        needle = category.lower()
        rows = [row for row in rows if needle in str(row.get("category") or "").lower() or needle in _tags(row)]
    if q:
        needle = q.lower()
        rows = [row for row in rows if needle in str(row.get("id") or "").lower() or needle in str(row.get("name") or "").lower()]
    total = len(rows)
    start = max(0, int(offset or 0))
    rows = rows[start:]
    if limit and int(limit) > 0:
        rows = rows[:int(limit)]
    return {"ok": True, "count": total, "returned": len(rows), "templates": [{"id": row.get("id"), "name": row.get("name"), "severity": row.get("severity"), "category": row.get("category"), "tags": sorted(_tags(row)), "method": row.get("method"), "paths": len(row.get("paths") or [])} for row in rows], "template_db": len(_templates()), "source": "projectdiscovery/nuclei-templates (packed)", "engine": "nuclei-browser-adapted"}


def stats() -> dict[str, Any]:
    severity: dict[str, int] = {}
    category: dict[str, int] = {}
    for row in _templates():
        sev = str(row.get("severity") or "unknown").lower()
        cat = str(row.get("category") or "other").lower()
        severity[sev] = severity.get(sev, 0) + 1
        category[cat] = category.get(cat, 0) + 1
    return {"ok": True, "total": len(_templates()), "by_severity": severity, "by_category": dict(sorted(category.items())[:30]), "engine": "nuclei-browser-adapted"}


async def _request(target: str, method: str, headers: dict[str, str], body: str, timeout_ms: int, retries: int, retry_codes: set[int], route: str, attempts: list[dict[str, Any]], template_id: str) -> dict[str, Any]:
    use_proxy = True if route == "proxy" else False if route == "direct" else None
    response: dict[str, Any] = {}
    for number in range(max(0, min(int(retries or 0), 5)) + 1):
        response = await http_request(target, method=method, headers=headers, body=body if method not in ("GET", "HEAD", "OPTIONS") else None, timeout_ms=max(1000, min(int(timeout_ms or 8000), 120000)), use_proxy=use_proxy)
        attempts.append({"template": template_id, "attempt": number + 1, "url": redact_url(target), "method": method, "status": int(response.get("status") or 0), "ok": bool(response.get("ok")), "elapsed_ms": response.get("elapsed_ms"), "transport": response.get("transport"), "error": str(response.get("error") or "")[:240]})
        if response.get("ok") or int(response.get("status") or 0) not in retry_codes:
            break
    return response


async def scan(url: str, tags: str = "", severity: str = "info,low,medium,high,critical", templates: str = "", max_templates: int = 50, category: str = "", user_agent: str = "pyodide-security/nuclei/3.0", method: str = "", headers: str | dict[str, Any] = "", body: str = "", custom_paths: str = "", max_requests: int = 0, status_codes: str = "", timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = "408,429,500,502,503,504", route: str = "auto", include_response_body: bool = False, preview_chars: int = 400, include_attempts: bool = False, stop_on_finding: bool = False) -> dict[str, Any]:
    error = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if error:
        return {"ok": False, "error": error, "engine": "nuclei-browser-adapted", "policy": policy.status()}
    url = str(url or "").strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    base = url.rstrip("/")
    hostname = base.split("//", 1)[-1].split("/", 1)[0]
    selected = [row for row in _templates() if str(row.get("severity") or "info").lower() in ({item.lower() for item in _split(severity)} or {"info", "low", "medium", "high", "critical"})]
    wanted_tags = {item.lower() for item in _split(tags or category)}
    if wanted_tags:
        selected = [row for row in selected if wanted_tags.intersection(_tags(row))]
    wanted_ids = {item.lower() for item in _split(templates)}
    if wanted_ids:
        selected = [row for row in selected if str(row.get("id") or "").lower() in wanted_ids]
    selected = selected[:max(1, min(int(max_templates or 50), 500))]
    forced_method = str(method or "").upper()
    if forced_method not in ("", "GET", "POST", "HEAD", "OPTIONS"):
        forced_method = ""
    route = route if route in ("auto", "proxy", "direct") else "auto"
    request_headers = _parse_headers(headers)
    request_headers.setdefault("User-Agent", user_agent)
    if body and forced_method == "POST":
        request_headers.setdefault("Content-Type", "application/x-www-form-urlencoded")
    retry_codes = _parse_codes(retry_statuses, {408, 429, 500, 502, 503, 504})
    global_status = _parse_codes(status_codes, set()) if str(status_codes or "").strip() else set()
    custom = _split(custom_paths)
    request_limit = max(1, min(int(max_requests or len(selected) * 3 or 1), 2000))
    findings: list[dict[str, Any]] = []
    attempts: list[dict[str, Any]] = []
    cache: dict[tuple[str, str, str], dict[str, Any]] = {}
    tested = templates_run = invalid_regexes = 0
    stopped_reason: str | None = None
    for template in selected:
        if not policy.can_request():
            stopped_reason = "request budget exhausted"
            break
        template_id = str(template.get("id") or "unnamed")
        template_method = forced_method or str(template.get("method") or "GET").upper()
        template_method = template_method if template_method in ("GET", "POST", "HEAD", "OPTIONS") else "GET"
        paths = custom or list(template.get("paths") or [base])
        words = [str(item) for item in (template.get("words") or []) if str(item)]
        regexes: list[re.Pattern[str]] = []
        for source in template.get("regex") or []:
            try:
                regexes.append(re.compile(str(source), re.I))
            except re.error:
                invalid_regexes += 1
        template_status = global_status or {int(item) for item in (template.get("status") or [200]) if str(item).isdigit()} or {200}
        templates_run += 1
        for raw_path in paths:
            if tested >= request_limit:
                stopped_reason = "request limit reached"
                break
            if not policy.can_request():
                stopped_reason = "request budget exhausted"
                break
            rendered = _render(str(raw_path), base, hostname)
            target = rendered if rendered.startswith(("http://", "https://")) else urljoin(base + "/", rendered.lstrip("/"))
            rendered_body = _render(str(body or ""), base, hostname)
            key = (template_method, target, rendered_body)
            if key not in cache:
                tested += 1
                cache[key] = await _request(target, template_method, request_headers, rendered_body, timeout_ms, retries, retry_codes, route, attempts, template_id)
            response = cache[key]
            status = int(response.get("status") or 0)
            text = str(response.get("body") or "")
            if status not in template_status:
                continue
            evidence = [{"type": "word", "value": word[:160]} for word in words if word.lower() in text.lower()][:3]
            for regex in regexes:
                matched = regex.search(text)
                if matched:
                    evidence.append({"type": "regex", "value": matched.group(0)[:160]})
                    break
            if not words and not regexes:
                evidence.append({"type": "status", "value": status})
            if evidence:
                finding: dict[str, Any] = {"id": template_id, "name": template.get("name"), "severity": template.get("severity"), "category": template.get("category"), "tags": sorted(_tags(template)), "url": redact_url(target), "method": template_method, "status": status, "evidence": evidence[:4], "transport": response.get("transport"), "elapsed_ms": response.get("elapsed_ms")}
                if include_response_body:
                    finding["body_preview"] = text[:max(0, min(int(preview_chars or 400), 5000))]
                findings.append(finding)
                if stop_on_finding:
                    stopped_reason = "finding requested stop"
                    break
        if stopped_reason:
            break
    findings.sort(key=lambda row: (str(row.get("severity") or ""), str(row.get("id") or "")))
    return {"ok": True, "url": redact_url(url), "tested": tested, "templates_selected": len(selected), "templates_run": templates_run, "findings": findings, "finding_count": len(findings), "template_db": len(_templates()), "invalid_regexes": invalid_regexes, "request": {"method": forced_method or "template", "headers": _redact_headers(request_headers), "timeout_ms": max(1000, min(int(timeout_ms or 8000), 120000)), "retries": max(0, min(int(retries or 0), 5)), "route": route, "max_requests": request_limit, "status_codes": sorted(global_status)}, "attempts": attempts if include_attempts else [], "attempt_count": len(attempts), "stopped_reason": stopped_reason, "engine": "nuclei-browser-adapted", "equivalent": "projectdiscovery/nuclei", "source": "nuclei-templates packed", "limitations": ["Browser-adapted bounded HTTP template execution through shared Goar transport; native YAML DSL breadth, non-HTTP protocols, headless mode, native concurrency, template updates, filesystem reports, and desktop integrations are not claimed."], "policy": policy.status()}
