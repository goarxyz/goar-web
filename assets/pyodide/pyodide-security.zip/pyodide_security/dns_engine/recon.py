"""DNS recon via the existing browser-adapted DoH resolver."""
from __future__ import annotations
from typing import Any
from ..subenum_engine.sources import clean_domain
from ..subenum_engine.resolve import doh_resolve
from .._http import redact_url


def _options(headers: str, timeout_ms: int, retries: int, retry_statuses: str, route: str, service_base: str) -> dict[str, Any]:
    return {'headers': headers, 'timeout_ms': timeout_ms, 'retries': retries, 'retry_statuses': retry_statuses, 'route': route, 'service_base': service_base}


def _request_meta(provider: str, timeout_ms: int, retries: int, route: str, service_base: str, **extra: Any) -> dict[str, Any]:
    return {'provider': provider, 'timeout_ms': timeout_ms, 'retries': retries, 'route': route, 'service_base': redact_url(service_base or ''), **extra}


async def resolve_all(name: str, types: str = 'A,AAAA,MX,NS,TXT,CNAME,SOA', provider: str = 'cloudflare', headers: str = '', timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = '408,429,500,502,503,504', route: str = 'auto', service_base: str = '') -> dict[str, Any]:
    name = clean_domain(name)
    opts = _options(headers, timeout_ms, retries, retry_statuses, route, service_base)
    results = {}
    for record_type in [item.strip().upper() for item in types.split(',') if item.strip()]:
        results[record_type] = await doh_resolve(name, record_type, provider=provider, **opts)
    return {'ok': all(item.get('ok') for item in results.values()) if results else False, 'name': name, 'records': results, 'types': list(results), 'engine': 'dns', 'equivalent': 'dnsx/dig DoH', 'request': _request_meta(provider, timeout_ms, retries, route, service_base, types=list(results))}


async def domain_info(domain: str, provider: str = 'cloudflare', headers: str = '', timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = '408,429,500,502,503,504', route: str = 'auto', service_base: str = '') -> dict[str, Any]:
    domain = clean_domain(domain)
    opts = _options(headers, timeout_ms, retries, retry_statuses, route, service_base)
    records = {record_type: await doh_resolve(domain, record_type, provider=provider, **opts) for record_type in ('A', 'MX', 'NS', 'TXT')}
    return {'ok': any(item.get('ok') for item in records.values()), 'domain': domain, 'a': records['A'], 'mx': records['MX'], 'ns': records['NS'], 'txt': records['TXT'], 'records': records, 'engine': 'dns', 'request': _request_meta(provider, timeout_ms, retries, route, service_base)}


async def reverse_lookup(ip: str, provider: str = 'cloudflare', headers: str = '', timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = '408,429,500,502,503,504', route: str = 'auto', service_base: str = '') -> dict[str, Any]:
    parts = ip.strip().split('.')
    if len(parts) != 4 or not all(part.isdigit() and 0 <= int(part) <= 255 for part in parts):
        return {'ok': False, 'error': 'IPv4 required for reverse in this build', 'engine': 'dns'}
    ptr = '.'.join(reversed(parts)) + '.in-addr.arpa'
    res = await doh_resolve(ptr, 'PTR', provider=provider, **_options(headers, timeout_ms, retries, retry_statuses, route, service_base))
    return {'ok': res.get('ok', False), 'ip': ip, 'ptr': res, 'engine': 'dns', 'request': _request_meta(provider, timeout_ms, retries, route, service_base)}
