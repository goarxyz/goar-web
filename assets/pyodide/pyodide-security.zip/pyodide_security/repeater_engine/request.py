"""Browser-adapted HTTP Repeater and two-item Comparer through shared transport."""
from __future__ import annotations
import difflib
import json
import re
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse
from .._http import http_request, redact_url
from .. import policy


def _headers(raw: str, user_agent: str) -> dict[str,str]:
    out={"User-Agent":user_agent}; text=str(raw or "").strip()
    if text.startswith("{"):
        parsed=json.loads(text)
        if not isinstance(parsed,dict): raise ValueError("headers JSON must be an object")
        out.update({str(key):str(value) for key,value in parsed.items()})
    else:
        for line in text.splitlines():
            if ":" in line:
                key,_,value=line.partition(":");out[key.strip()]=value.strip()
    return out


def _route(value: str|bool|None)->bool|None:
    if value in (None,"","auto","AUTO"): return None
    if value in (True,"proxy","PROXY","true","True"): return True
    if value in (False,"direct","DIRECT","false","False"): return False
    raise ValueError("route must be auto, proxy, or direct")


def _safe_headers(headers:dict[str,str])->dict[str,str]:
    return {key:("[redacted]" if key.lower() in {"authorization","cookie","set-cookie","x-api-key","proxy-authorization"} else value) for key,value in headers.items()}

def _safe_url(value:Any)->str:
    safe=redact_url(value)
    return re.sub(r"(?i)(%3f|%26)(apikey|api_key|key|token|access_token|authorization|secret|signature|sig)(%3d|=)[^&#]*",lambda m:m.group(1)+m.group(2)+m.group(3)+"[redacted]",safe)

def _safe_text(value:Any)->str:
    pattern=r'''(?im)(?:["'])?(apikey|api_key|access_token|authorization|proxy-authorization|cookie|secret|token|password)(?:["'])?\s*(=|:)\s*(?:["'])?[^\r\n,;<>{}"']+'''
    return re.sub(pattern,lambda m:f"{m.group(1)}{m.group(2)}[redacted]",str(value or ""))

def _status_expectations(raw:str)->tuple[set[int],list[str]]:
    values:set[int]=set();display:list[str]=[]
    for piece in str(raw or "").split(","):
        item=piece.strip()
        if not item: continue
        if "-" in item:
            left,right=item.split("-",1)
            if left.strip().isdigit() and right.strip().isdigit():
                start,end=int(left),int(right)
                if 100<=start<=end<=599: values.update(range(start,end+1));display.append(f"{start}-{end}")
        elif item.isdigit() and 100<=int(item)<=599:
            values.add(int(item));display.append(item)
    return values,display

def _query_url(url:str, raw:str)->str:
    text=str(raw or "").strip()
    if not text: return url
    additions=parse_qsl(text.lstrip("?"),keep_blank_values=True)
    if not additions: raise ValueError("query_params must be URL query pairs")
    parsed=urlparse(url); replace={key for key,_ in additions};merged=[(key,value) for key,value in parse_qsl(parsed.query,keep_blank_values=True) if key not in replace]+additions
    return urlunparse(parsed._replace(query=urlencode(merged,doseq=True)))

def _raw_request(raw:str, fallback_url:str, fallback_method:str, fallback_headers:str, fallback_body:str)->tuple[str,str,str,str,bool]:
    text=str(raw or "").replace("\r\n","\n").strip("\n")
    if not text: return fallback_url,fallback_method,fallback_headers,fallback_body,False
    head,_,payload=text.partition("\n\n"); lines=head.splitlines()
    if not lines or len(lines[0].split())<2: raise ValueError("raw_request must start with 'METHOD path HTTP/version'")
    parts=lines[0].split(); parsed_headers={}
    for line in lines[1:]:
        if ":" in line:
            key,_,value=line.partition(":");parsed_headers[key.strip()]=value.strip()
    target=parts[1]; method=parts[0].upper()
    if target.startswith(("http://","https://")): url=target
    else:
        base=fallback_url or ""
        if not base:
            host=parsed_headers.get("Host","")
            if not host: raise ValueError("raw_request needs an absolute target, fallback url, or Host header")
            base="https://"+host
        p=urlparse(base);url=urlunparse(p._replace(path=target.split("?",1)[0] or "/",query=target.split("?",1)[1] if "?" in target else ""))
    header_lines="\n".join(f"{key}: {value}" for key,value in parsed_headers.items())
    return url,method,header_lines,payload,True

def _body_view(body:Any,mode:str,limit:int)->str|None:
    if mode=="none": return None
    text=_safe_text(body)
    return text if mode=="full" else text[:limit]


async def send(url:str, method:str="GET", headers:str="", body:str="", user_agent:str="pyodide-security/repeater/2.0", timeout_ms:int=8000, retries:int=0, retry_statuses:str="408,429,500,502,503,504", route:str="auto", query_params:str="", raw_request:str="", repeat_count:int=1, expected_status:str="", response_body_mode:str="full", response_preview_chars:int=4000, label:str="")->dict[str,Any]:
    """Replay a bounded HTTP request variant through the established Goar transport."""
    url,method,headers,body,raw_imported=_raw_request(raw_request,str(url or "").strip(),str(method or "GET"),headers,body)
    url=_query_url(str(url or "").strip(),query_params)
    if not url: return {"ok":False,"error":"url required","engine":"repeater"}
    if not url.startswith(("http://","https://")): url="https://"+url
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err: return {"ok":False,"error":err,"engine":"repeater"}
    method=str(method or "GET").upper()
    if method not in {"GET","HEAD","OPTIONS","POST","PUT","PATCH","DELETE"}: raise ValueError("unsupported HTTP method: "+method)
    mode=str(response_body_mode or "full").lower()
    if mode not in {"full","preview","none"}: raise ValueError("response_body_mode must be full, preview, or none")
    timeout=max(1000,min(int(timeout_ms or 8000),120000)); retries=max(0,min(int(retries or 0),5)); repeats=max(1,min(int(repeat_count or 1),10));preview=max(0,min(int(response_preview_chars or 4000),200000));retryable={int(value.strip()) for value in str(retry_statuses or "").split(",") if value.strip().isdigit()};expected,expected_display=_status_expectations(expected_status);hdrs=_headers(headers,user_agent);use_proxy=_route(route);attempts:list[dict[str,Any]]=[];replays:list[dict[str,Any]]=[];response:dict[str,Any]={}
    for replay in range(repeats):
        replay_attempts=[]
        for index in range(retries+1):
            response=await http_request(url,method=method,headers=hdrs,body=body or None,timeout_ms=timeout,use_proxy=use_proxy)
            item={"replay":replay+1,"attempt":index+1,"status":response.get("status"),"ok":response.get("ok"),"transport":response.get("transport"),"elapsed_ms":response.get("elapsed_ms"),"error":_safe_text(response.get("error")),"final_url":_safe_url(response.get("final_url"))};attempts.append(item);replay_attempts.append(item)
            if response.get("ok") or int(response.get("status") or 0) not in retryable: break
        replays.append({"replay":replay+1,"status":response.get("status"),"ok":response.get("ok"),"attempt_count":len(replay_attempts),"elapsed_ms":response.get("elapsed_ms"),"transport":response.get("transport")})
    status=int(response.get("status") or 0);status_match=not expected or status in expected;safe_body=_body_view(response.get("body"),mode,preview)
    return {"ok":bool(response.get("ok")) and status_match,"label":str(label or "")[:200] or None,"status_match":status_match,"expected_status":expected_display,"request":{"url":_safe_url(url),"method":method,"headers":_safe_headers(hdrs),"body":_safe_text(body) if body else "","body_length":len(str(body or "")),"raw_request_imported":raw_imported,"query_params":query_params or None,"timeout_ms":timeout,"retries":retries,"repeat_count":repeats,"route":"auto" if use_proxy is None else ("proxy" if use_proxy else "direct")},"response":{"status":status,"headers":_safe_headers(response.get("headers") or {}),"body":safe_body,"body_length":len(str(response.get("body") or "")),"body_mode":mode,"final_url":_safe_url(response.get("final_url") or url),"elapsed_ms":response.get("elapsed_ms"),"transport":response.get("transport"),"via_libcurl":response.get("via_libcurl"),"via_proxy":response.get("via_proxy"),"via_wisp":response.get("via_wisp"),"error":_safe_text(response.get("error"))},"attempts":attempts,"attempt_count":len(attempts),"replays":replays,"replay_count":len(replays),"engine":"repeater","equivalent":"Burp Repeater"}


def _units(text:str, mode:str)->list[str]:
    if mode=="words": return text.split()
    if mode=="bytes": return [f"{value:02x}" for value in text.encode("utf-8","replace")]
    return text.splitlines()


async def compare(url:str, method:str="GET", headers_a:str="", headers_b:str="", body:str="", body_a:str="", body_b:str="", user_agent:str="pyodide-security/repeater/2.0", timeout_ms:int=8000, retries:int=0, route:str="auto", retry_statuses:str="408,429,500,502,503,504", url_a:str="", url_b:str="", method_a:str="", method_b:str="", compare_mode:str="lines", include_headers:bool=True)->dict[str,Any]:
    """Replay two complete variants and compare responses by lines, words, or bytes."""
    mode=str(compare_mode or "lines").lower()
    if mode not in {"lines","words","bytes"}: return {"ok":False,"error":"compare_mode must be lines, words, or bytes","engine":"repeater"}
    a=await send(url_a or url,method_a or method,headers_a,body_a if body_a else body,user_agent,timeout_ms,retries,retry_statuses,route)
    b=await send(url_b or url,method_b or method,headers_b,body_b if body_b else body,user_agent,timeout_ms,retries,retry_statuses,route)
    ra=a.get("response") or {};rb=b.get("response") or {};text_a=str(ra.get("body") or "");text_b=str(rb.get("body") or "");units_a=_units(text_a,mode);units_b=_units(text_b,mode);diff=list(difflib.unified_diff(units_a,units_b,fromfile="variant-a",tofile="variant-b",lineterm=""));matcher=difflib.SequenceMatcher(a=units_a,b=units_b)
    return {"ok":bool(a.get("ok")) and bool(b.get("ok")),"a":a,"b":b,"compare_mode":mode,"status_diff":ra.get("status")!=rb.get("status"),"headers_diff":(ra.get("headers")!=rb.get("headers")) if include_headers else None,"body_diff":diff,"body_diff_count":len(diff),"similarity_ratio":round(matcher.ratio(),6),"units_a":len(units_a),"units_b":len(units_b),"len_diff":len(text_a)-len(text_b),"engine":"repeater","equivalent":"Burp Repeater / Comparer"}
