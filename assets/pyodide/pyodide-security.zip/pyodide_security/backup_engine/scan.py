"""Browser-adapted backup and sensitive-file discovery using the shared Goar transport."""
from __future__ import annotations

import gzip
import re
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

from .. import policy
from .._http import http_request, redact_url

_DATA = Path(__file__).with_name("data")
_FILES: list[str] | None = None
_SENSITIVE = re.compile(r"(?i)(authorization|cookie|set-cookie|x-api-key|api[_-]?key|token|secret|password)")


def _files() -> list[str]:
    global _FILES
    if _FILES is None:
        rows: list[str] = []
        for name in ("backup-files.txt.gz", "common.txt.gz"):
            path = _DATA / name
            if path.exists():
                with gzip.open(path, "rt", encoding="utf-8") as handle:
                    rows.extend(line.strip() for line in handle if line.strip())
        rows.extend((
            ".git/HEAD", ".git/config", ".env", ".env.local", ".env.backup",
            "backup.sql", "dump.sql", "db.sql", "database.sql", "wp-config.php.bak",
            "config.php.bak", "web.config.bak", ".DS_Store", "thumbs.db", "backup.zip",
            "backup.tar.gz", "site.zip", "www.zip", "html.zip",
        ))
        _FILES = list(dict.fromkeys(rows))
    return list(_FILES)


def _parse_headers(raw: str | dict[str, Any] | None) -> dict[str, str]:
    if isinstance(raw, dict):
        return {str(key): str(value) for key, value in raw.items()}
    text = str(raw or "").strip()
    if not text:
        return {}
    if text.startswith("{"):
        try:
            obj = __import__("json").loads(text)
            return {str(key): str(value) for key, value in obj.items()} if isinstance(obj, dict) else {}
        except (TypeError, ValueError):
            return {}
    result: dict[str, str] = {}
    for line in text.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            if key.strip():
                result[key.strip()] = value.strip()
    return result


def _redact_headers(headers: dict[str, str]) -> dict[str, str]:
    return {key: "[redacted]" if _SENSITIVE.search(key) else str(value) for key, value in headers.items()}


def _parse_codes(raw: str, default: set[int]) -> set[int]:
    values: set[int] = set()
    for part in str(raw or "").split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            left, _, right = part.partition("-")
            if left.strip().isdigit() and right.strip().isdigit():
                values.update(range(max(0, int(left)), min(999, int(right)) + 1))
        elif part.isdigit():
            values.add(int(part))
    return values or set(default)


def _paths(custom_paths: str, include_default: bool, extensions: str, max_paths: int) -> tuple[list[str], bool]:
    rows = list(_files()) if include_default else []
    rows.extend(item.strip().lstrip("/") for item in re.split(r"[\n,]+", str(custom_paths or "")) if item.strip())
    exts = [item.strip().lstrip(".") for item in re.split(r"[\n,]+", str(extensions or "")) if item.strip()]
    expanded: list[str] = []
    for item in rows:
        expanded.append(item)
        if exts and not item.endswith("/"):
            for ext in exts:
                if ext and not item.lower().endswith("." + ext.lower()):
                    expanded.append(f"{item}.{ext}")
    ordered = list(dict.fromkeys(expanded))
    limit = max(1, min(int(max_paths or 70), 1000))
    return ordered[:limit], len(ordered) > limit


async def _request(
    target: str, method: str, headers: dict[str, str], body: str, timeout_ms: int,
    retries: int, retry_codes: set[int], route: str, attempts: list[dict[str, Any]],
) -> dict[str, Any]:
    use_proxy = True if route == "proxy" else False if route == "direct" else None
    last: dict[str, Any] = {}
    for attempt in range(max(0, min(int(retries or 0), 5)) + 1):
        last = await http_request(target, method=method, headers=headers, body=body if method not in ("GET", "HEAD") else None, timeout_ms=max(1000, min(int(timeout_ms or 8000), 120000)), use_proxy=use_proxy)
        attempts.append({"attempt": attempt + 1, "url": redact_url(target), "method": method, "status": int(last.get("status") or 0), "ok": bool(last.get("ok")), "elapsed_ms": last.get("elapsed_ms"), "transport": last.get("transport"), "error": str(last.get("error") or "")[:240]})
        if last.get("ok") or int(last.get("status") or 0) not in retry_codes:
            break
    return last


def list_files(limit: int = 0, search: str = "", offset: int = 0) -> dict[str, Any]:
    rows = _files()
    needle = str(search or "").lower().strip()
    if needle:
        rows = [row for row in rows if needle in row.lower()]
    start = max(0, int(offset or 0))
    size = max(0, int(limit or 0))
    out = rows[start:start + size] if size else rows[start:]
    return {"ok": True, "count": len(rows), "returned": len(out), "files": out, "source": "SecLists Common-DB-Backups + common.txt", "engine": "backup-browser-adapted"}


async def scan(
    url: str,
    max_paths: int = 70,
    user_agent: str = "pyodide-security/backup/3.0",
    method: str = "GET",
    headers: str | dict[str, Any] = "",
    body: str = "",
    custom_paths: str = "",
    include_default: bool = True,
    extensions: str = "",
    status_codes: str = "200,403",
    exclude_statuses: str = "",
    min_length: int = 0,
    max_length: int = 0,
    match_regex: str = "",
    exclude_regex: str = "",
    timeout_ms: int = 8000,
    retries: int = 0,
    retry_statuses: str = "408,429,500,502,503,504",
    route: str = "auto",
    include_response_body: bool = False,
    preview_chars: int = 400,
    include_attempts: bool = False,
    stop_on_first: bool = False,
) -> dict[str, Any]:
    err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "engine": "backup-browser-adapted", "policy": policy.status()}
    url = str(url or "").strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    if not url.endswith("/"):
        url += "/"
    method = str(method or "GET").upper()
    if method not in ("GET", "HEAD", "OPTIONS", "POST"):
        method = "GET"
    route = route if route in ("auto", "proxy", "direct") else "auto"
    request_headers = _parse_headers(headers)
    request_headers.setdefault("User-Agent", user_agent)
    paths, truncated = _paths(custom_paths, bool(include_default), extensions, max_paths)
    success_codes = _parse_codes(status_codes, {200, 403})
    blocked_codes = _parse_codes(exclude_statuses, set()) if str(exclude_statuses or "").strip() else set()
    retry_codes = _parse_codes(retry_statuses, {408, 429, 500, 502, 503, 504})
    try:
        wanted = re.compile(match_regex) if str(match_regex or "").strip() else None
        unwanted = re.compile(exclude_regex) if str(exclude_regex or "").strip() else None
    except re.error as exc:
        return {"ok": False, "error": f"invalid regular expression: {exc}", "engine": "backup-browser-adapted"}
    found: list[dict[str, Any]] = []
    attempts: list[dict[str, Any]] = []
    tested = 0
    stopped_reason: str | None = None
    for path in paths:
        if not policy.can_request():
            stopped_reason = "request budget exhausted"
            break
        tested += 1
        target = urljoin(url, path.lstrip("/"))
        response = await _request(target, method, request_headers, str(body or ""), timeout_ms, retries, retry_codes, route, attempts)
        status = int(response.get("status") or 0)
        text = str(response.get("body") or "")
        length = len(text)
        accepted = status in success_codes and status not in blocked_codes
        if min_length and length < max(0, int(min_length)):
            accepted = False
        if max_length and length > max(0, int(max_length)):
            accepted = False
        if wanted and not wanted.search(text):
            accepted = False
        if unwanted and unwanted.search(text):
            accepted = False
        if accepted:
            item = {"path": path, "url": redact_url(target), "status": status, "length": length, "transport": response.get("transport"), "elapsed_ms": response.get("elapsed_ms")}
            if include_response_body:
                item["body_preview"] = text[:max(0, min(int(preview_chars or 400), 5000))]
            found.append(item)
            if stop_on_first:
                stopped_reason = "first accepted result"
                break
    return {
        "ok": True,
        "url": redact_url(url),
        "tested": tested,
        "candidate_count": len(paths),
        "truncated": truncated,
        "found": found,
        "found_count": len(found),
        "path_db": len(_files()),
        "request": {"method": method, "headers": _redact_headers(request_headers), "timeout_ms": max(1000, min(int(timeout_ms or 8000), 120000)), "retries": max(0, min(int(retries or 0), 5)), "route": route, "success_codes": sorted(success_codes), "exclude_statuses": sorted(blocked_codes)},
        "attempts": attempts if include_attempts else [],
        "attempt_count": len(attempts),
        "stopped_reason": stopped_reason,
        "engine": "backup-browser-adapted",
        "source": "SecLists Common-DB-Backups + common.txt",
        "limitations": ["Browser-adapted sequential discovery through the shared Goar transport; native dirsearch concurrency, filesystem reports, client certificates, and raw socket behavior are not claimed."],
        "policy": policy.status(),
    }
