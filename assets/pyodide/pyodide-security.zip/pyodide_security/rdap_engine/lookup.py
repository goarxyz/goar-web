"""Browser-adapted RDAP domain and IP lookup (RFC 9082 query format)."""
from __future__ import annotations

import ipaddress
import json
from typing import Any
from urllib.parse import quote

from .. import policy
from .._http import http_request, redact_url
from ..subenum_engine.sources import clean_domain

_DEFAULT_BASE = "https://rdap.org"


def _base(value: str) -> str:
    raw = str(value or _DEFAULT_BASE).strip().rstrip("/")
    if not raw.startswith(("http://", "https://")):
        raw = "https://" + raw
    return raw


def _headers(raw: str | dict | None, user_agent: str) -> dict[str, str]:
    headers = {"User-Agent": user_agent, "Accept": "application/rdap+json, application/json"}
    if raw in (None, ""):
        return headers
    if isinstance(raw, dict):
        headers.update({str(k): str(v) for k, v in raw.items()})
        return headers
    text = str(raw).strip()
    if text.startswith("{"):
        try:
            decoded = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValueError(f"headers must be a JSON object or Header: value lines: {exc}") from exc
        if not isinstance(decoded, dict):
            raise ValueError("headers JSON must be an object")
        headers.update({str(k): str(v) for k, v in decoded.items()})
        return headers
    for line in text.splitlines():
        if ":" in line:
            key, _, value = line.partition(":")
            if key.strip():
                headers[key.strip()] = value.strip()
    return headers


def _safe_headers(headers: dict[str, str]) -> dict[str, str]:
    return {key: ("[redacted]" if key.lower() in {"authorization", "cookie", "x-api-key"} else value) for key, value in headers.items()}


def _route(value: str | bool | None) -> bool | None:
    if value in (None, "", "auto", "AUTO"):
        return None
    if value in (True, "proxy", "PROXY", "true", "True"):
        return True
    if value in (False, "direct", "DIRECT", "false", "False"):
        return False
    raise ValueError("route must be auto, proxy, or direct")


async def _request(url: str, headers: dict[str, str], timeout_ms: int, retries: int, retry_statuses: str, use_proxy: bool | None) -> dict[str, Any]:
    timeout = max(1000, min(int(timeout_ms or 8000), 120000))
    retry_count = max(0, min(int(retries or 0), 5))
    retryable = {int(x.strip()) for x in str(retry_statuses or "").split(",") if x.strip().isdigit()}
    attempts: list[dict[str, Any]] = []
    response: dict[str, Any] = {}
    for index in range(retry_count + 1):
        response = await http_request(url, headers=headers, timeout_ms=timeout, use_proxy=use_proxy)
        attempts.append({"attempt": index + 1, "status": response.get("status"), "ok": response.get("ok"), "transport": response.get("transport"), "elapsed_ms": response.get("elapsed_ms"), "error": response.get("error"), "final_url": redact_url(response.get("final_url"))})
        if response.get("ok") or int(response.get("status") or 0) not in retryable:
            break
    result = dict(response)
    result.update({"attempts": attempts, "attempt_count": len(attempts), "final_url": redact_url(response.get("final_url") or url), "request": {"url": redact_url(url), "headers": _safe_headers(headers), "timeout_ms": timeout, "retries": retry_count, "route": "auto" if use_proxy is None else ("proxy" if use_proxy else "direct")}})
    return result


def _events(data: dict[str, Any]) -> list[dict[str, Any]]:
    out = []
    for event in data.get("events") or []:
        if isinstance(event, dict):
            out.append({"action": event.get("eventAction"), "date": event.get("eventDate"), "actor": event.get("eventActor")})
    return out


def _entities(data: dict[str, Any]) -> list[dict[str, Any]]:
    out = []
    for item in data.get("entities") or []:
        if isinstance(item, dict):
            out.append({"handle": item.get("handle"), "roles": item.get("roles") or [], "object_class": item.get("objectClassName")})
    return out


def _summary(data: dict[str, Any], kind: str) -> dict[str, Any]:
    common = {"object_class": data.get("objectClassName"), "handle": data.get("handle"), "status": data.get("status") or [], "events": _events(data), "entities": _entities(data), "notices": data.get("notices") or [], "remarks": data.get("remarks") or [], "links": data.get("links") or []}
    if kind == "domain":
        common.update({"ldh_name": data.get("ldhName"), "unicode_name": data.get("unicodeName"), "nameservers": [name.get("ldhName") for name in (data.get("nameservers") or []) if isinstance(name, dict) and name.get("ldhName")], "secure_dns": data.get("secureDNS")})
    else:
        common.update({"name": data.get("name"), "type": data.get("type"), "start_address": data.get("startAddress"), "end_address": data.get("endAddress"), "ip_version": data.get("ipVersion"), "country": data.get("country"), "cidr0_cidrs": data.get("cidr0_cidrs") or []})
    return common


async def _lookup(kind: str, value: str, service_base: str, headers: str, timeout_ms: int, retries: int, retry_statuses: str, route: str, user_agent: str) -> dict[str, Any]:
    target = f"{_base(service_base)}/{kind}/{quote(value, safe=':.')}"
    err = policy.check_url_for_active(target) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "engine": "rdap"}
    req_headers = _headers(headers, user_agent)
    response = await _request(target, req_headers, timeout_ms, retries, retry_statuses, _route(route))
    raw = str(response.get("body") or "")
    try:
        data = json.loads(raw)
    except Exception:
        data = None
    rdap_data = data if isinstance(data, dict) else None
    return {"ok": bool(response.get("ok")) and rdap_data is not None, "lookup_ok": bool(response.get("ok")) and rdap_data is not None, "kind": kind, "query": value, "status": response.get("status"), "data": rdap_data, "summary": _summary(rdap_data, kind) if rdap_data else None, "body": raw, "body_length": len(raw), "error": response.get("error") or (None if rdap_data else "non-RDAP JSON response"), "attempts": response.get("attempts") or [], "attempt_count": response.get("attempt_count"), "request": response.get("request"), "final_url": response.get("final_url"), "transport": response.get("transport"), "engine": "rdap", "equivalent": "RDAP RFC 9082"}


async def domain_rdap(domain: str, user_agent: str = "pyodide-security/rdap/2.0", service_base: str = _DEFAULT_BASE, headers: str = "", timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = "408,429,500,502,503,504", route: str = "auto") -> dict[str, Any]:
    normalized = clean_domain(domain)
    if not normalized or "." not in normalized:
        raise ValueError("a registrable domain is required")
    return await _lookup("domain", normalized, service_base, headers, timeout_ms, retries, retry_statuses, route, user_agent)


async def ip_rdap(ip: str, user_agent: str = "pyodide-security/rdap/2.0", service_base: str = _DEFAULT_BASE, headers: str = "", timeout_ms: int = 8000, retries: int = 0, retry_statuses: str = "408,429,500,502,503,504", route: str = "auto") -> dict[str, Any]:
    normalized = str(ipaddress.ip_address(str(ip).strip()))
    return await _lookup("ip", normalized, service_base, headers, timeout_ms, retries, retry_statuses, route, user_agent)
