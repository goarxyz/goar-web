from .lookup import domain_rdap, ip_rdap
__all__=["domain_rdap","ip_rdap"]
