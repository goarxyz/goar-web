"""
Global security policy & request budget for pyodide-security.

All live (network) tools should consult this module so that:
  - request volume is bounded
  - dangerous hosts are blocked by default
  - active scanning can be gated
"""

from __future__ import annotations

from typing import Any

_policy: dict[str, Any] = {
    "max_requests": 80,
    "requests_used": 0,
    "allow_active_scanning": True,   # set False for pure passive mode
    "blocked_hosts": {
        "localhost",
        "127.0.0.1",
        "0.0.0.0",
        "::1",
        "metadata.google.internal",
        "169.254.169.254",
        "metadata",
        "[::1]",
    },
    "require_https_for_active": False,
}


def status() -> dict[str, Any]:
    return {
        "max_requests": _policy["max_requests"],
        "requests_used": _policy["requests_used"],
        "remaining": max(0, _policy["max_requests"] - _policy["requests_used"]),
        "allow_active_scanning": _policy["allow_active_scanning"],
        "blocked_hosts": sorted(_policy["blocked_hosts"]),
        "require_https_for_active": _policy["require_https_for_active"],
    }


def configure(
    max_requests: int | None = None,
    allow_active_scanning: bool | None = None,
    require_https_for_active: bool | None = None,
    extra_blocked_hosts: list[str] | None = None,
    reset_budget: bool = False,
) -> dict[str, Any]:
    if max_requests is not None:
        _policy["max_requests"] = max(1, int(max_requests))
    if allow_active_scanning is not None:
        _policy["allow_active_scanning"] = bool(allow_active_scanning)
    if require_https_for_active is not None:
        _policy["require_https_for_active"] = bool(require_https_for_active)
    if extra_blocked_hosts:
        for h in extra_blocked_hosts:
            _policy["blocked_hosts"].add(h.lower().strip())
    if reset_budget:
        _policy["requests_used"] = 0
    return status()


def reset_budget() -> dict[str, Any]:
    _policy["requests_used"] = 0
    return status()


def can_request() -> bool:
    return _policy["requests_used"] < _policy["max_requests"]


def consume(n: int = 1) -> bool:
    """Consume budget. Returns False if budget would be exceeded."""
    if _policy["requests_used"] + n > _policy["max_requests"]:
        return False
    _policy["requests_used"] += n
    return True


def is_host_blocked(host: str) -> bool:
    if not host:
        return True
    h = host.lower().split(":")[0].strip(".")
    if h in _policy["blocked_hosts"]:
        return True
    # also block obvious private / link-local prefixes
    if h.startswith("127.") or h.startswith("10.") or h.startswith("192.168.") or h.startswith("169.254."):
        return True
    if h.endswith(".local") or h.endswith(".internal") or h.endswith(".localhost"):
        return True
    return False


def active_allowed() -> bool:
    return bool(_policy["allow_active_scanning"])


def check_url_for_active(url: str) -> str | None:
    """
    Return an error string if the URL is not allowed for active scanning,
    otherwise None.
    """
    if not active_allowed():
        return "active scanning disabled by policy (policy.configure allow_active_scanning=True)"
    from urllib.parse import urlparse
    p = urlparse(url if "://" in url else "https://" + url)
    host = p.hostname or ""
    if is_host_blocked(host):
        return f"host '{host}' is blocked by policy"
    if _policy["require_https_for_active"] and p.scheme != "https":
        return "policy requires HTTPS for active scanning"
    return None
